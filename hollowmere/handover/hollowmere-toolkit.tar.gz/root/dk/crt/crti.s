	.arm
	.section .text._init,"ax",%progbits
	.global _init
	.type _init,%function
_init:	bx lr
	.section .text._fini,"ax",%progbits
	.global _fini
	.type _fini,%function
_fini:	bx lr
