# 3DS Homebrew Playbook

How Hollowmere (a 3D stereoscopic 3DS game) was built from nothing in a cloud sandbox: every tool, every workaround, and every bug we hit while testing on a real 3DS XL. Written so the next game goes faster.

---

## 0. The short version

- **Language / libraries:** C, **libctru** (system access), **citro3d** (3D GPU), **citro2d** (2D/HUD), **picasso** (shader assembler).
- **Output formats:**
  - `.3dsx`: runs from the Homebrew Launcher. Simplest, always try this first.
  - `.cia`: installs to the HOME Menu with FBI. Built with **makerom** + **bannertool**.
- **Testing:** **Panda3DS** emulator built from source, driven headlessly through its HTTP API (keys + screenshots).
- **Normal world:** install devkitPro (`devkitARM`, `3ds-dev`) and skip section 2.
- **Our world:** devkitPro's package servers and Docker Hub were blocked, so the whole toolchain was rebuilt from GitHub sources using the system's **clang + lld**. Section 2 records exactly how.

---

## 1. What the sandbox could and couldn't reach

| Reachable | Blocked |
|---|---|
| GitHub (`git clone`, including submodules) | `pkg.devkitpro.org`, Docker Hub |
| npm / PyPI registries | apt mirrors (`archive.ubuntu.com`) |
| | GitHub release assets (`objects.githubusercontent.com`) |
| | ftp.gnu.org |
| | Every temporary file host (0x0.st, catbox/litterbox, tmpfiles, file.io, transfer.sh, temp.sh…) |

Pre-installed and useful: **clang/lld 18**, llvm-ar/objcopy/etc, gcc/g++, cmake, Python 3 with **Pillow**, Xvfb, Mesa (llvmpipe) EGL/GL runtime, SDL2 runtime.

Lessons:
- **Check the network first** (`curl -sI <host>`) before planning a toolchain.
- **To serve a file to the 3DS by QR**, a host has to be added to the allowed domains on claude.ai (web browser → Settings → Capabilities, not in the mobile app). Otherwise you upload the CIA yourself and paste the link.
- **Machine:** 2 cores, 7 GB RAM. Building GCC from source was avoided because it's too slow; clang was the right call.

---

## 2. Building the toolchain from source (clang instead of devkitARM)

All sources cloned from `github.com/devkitPro/*`:
- `libctru`
- `citro3d`
- `citro2d`
- `picasso`
- `3dstools`
- `newlib`
- `devkitarm-crtls`
- `buildscripts` (for its patches)
- `tex3ds` (reference only)

Install prefix: `~/dk`.

### 2.1 Compiler wrappers (`~/dk/bin`)
Shell scripts named like devkitARM's tools so autoconf/Makefiles find them:

```sh
# arm-none-eabi-gcc (also copied to -cc; -g++ uses clang++)
exec clang --target=arm-none-eabi -march=armv6k -mtune=mpcore -mfloat-abi=hard -mfpu=vfpv2 \
  -mtp=soft -fuse-ld=lld -D__DEVKITARM__ \
  -Wno-error=implicit-function-declaration -Wno-error=int-conversion -Wno-error=incompatible-pointer-types "$@"
```
- `-ar`, `-ranlib`, `-nm`, `-objcopy`, `-strip`, `-objdump`, `-readelf` → the `llvm-*` equivalents.
- `-ld` → `ld.lld`.
- `-as` → `clang -c -x assembler`.

The 3DS CPU is an **ARM11 MPCore: armv6k, VFPv2, hard-float**. `-mtp=soft` means thread-pointer reads go through `__aeabi_read_tp`, which libctru provides.

### 2.2 newlib (the C library), devkitPro flavour
libctru needs devkitPro's patched newlib (`sys/iosupport.h`, `libsysbase`).

- Cloned `devkitPro/newlib` (it's an upstream mirror). Applied `buildscripts/patches/newlib-<ver>.patch` with `patch -p1`, and it went in cleanly.
- Configured as in `buildscripts/build-newlib.sh`:
  ```
  CFLAGS_FOR_TARGET="-O2 -ffunction-sections -fdata-sections" \
  ../newlib/configure --target=arm-none-eabi --prefix=$HOME/dk --disable-multilib \
    --disable-newlib-supplied-syscalls --enable-newlib-mb --disable-newlib-wide-orient --enable-newlib-register-fini
  ```
- Fixes needed for clang:
  - `newlib/libc/machine/arm/setjmp.S`: change `.fpu vfpxd` to `.fpu vfpv2` (clang's assembler doesn't know `vfpxd`).
  - Pass `MAKEINFO=true` to make, because texinfo isn't installed.
  - `libgloss/arm/linux-crt0.c` fails (naked function). It isn't needed: run `make -k` inside `arm-none-eabi/libgloss` and copy out `libsysbase.a` and `libpthread.a`.

### 2.3 Compiler runtime (replaces libgcc)
- Sparse-cloned `llvm/llvm-project` at the matching tag (`llvmorg-18.1.3`), keeping only `compiler-rt/lib/builtins`.
- Compiled every `*.c`, plus `arm/*.S` except the `*vfp*`, `switch*`, `sync_*` and `chkstk*` files.
- Also compiled `arm/*.c`. **`arm/aeabi_div0.c` is required**, otherwise you get an undefined `__aeabi_idiv0`.
- Archived as `~/dk/lib/libclang_rt.a`. armv6k has no hardware divide, so `__aeabi_idivmod`, `__aeabi_uldivmod` and friends come from here.

### 2.4 libctru
Compiled every `.c`/`.s`/`.cpp` in its source subfolders with `-D__3DS__ -O2 -ffunction-sections -fdata-sections`.

Fixes:
- **`include/3ds/asminc.h`:** delete the `.func` / `.endfunc` lines, because clang's assembler rejects them.
- **`console.c` needs `default_font_bin.h`:** generate a C array from `data/default_font.bin` with a few lines of Python (devkitPro's `bin2s` equivalent). The game also reuses this 8×8 font.
- Assemble `.s` files with `-x assembler-with-cpp`.

### 2.5 citro3d / citro2d
- **citro3d:** compile the C files and archive.
- **citro2d:** its own shader `render2d.v.pica` must be assembled with picasso and embedded as a C array.
- **We added two functions to citro2d's `base.c`** (keep these):
  - `C2D_DrawAlphaQuad(tex, x, y, w, h, l, t, r, b, color, depth)` draws through citro2d's internal *text* mode: colour from the vertex, alpha from the texture. Use it for bitmap-font text (see 6.4).
  - `C2D_DebugVtxUsed()` / `C2D_DebugVtxSize()` are debug probes for per-frame 2D buffer use.

### 2.6 Host tools
- **picasso:** `g++ -std=c++17 -DPACKAGE_STRING='"picasso 2.7"' picasso_assembler.cpp picasso_frontend.cpp`.
- **3dstools:** compile `3dsxtool`, `smdhtool` (with `lodepng`) and `3dsxdump` directly with g++.
- **makerom:** from `3DSGuy/Project_CTR` → `makerom/`, built with `make`.
- **bannertool:** from `diasurgical/bannertool` (the Steveice10 repo now needs auth), built with `make`. The binary lands in `output/linux-x86_64/`.
- **RSF template:** from `Steveice10/buildtools/3ds/template.rsf`.

### 2.7 Startup code and linker script
From `devkitarm-crtls`:
- Assemble `3dsx_crt0.s`.
- Copy `3dsx.ld`.
- Write a tiny `crti.s` that defines empty `_init`/`_fini` functions. There's no crtbegin/crtend; for plain C you don't need them.

**lld-specific fixes to `3dsx.ld`:**
- Add a `tls PT_TLS;` program header and put `.tdata`/`.tbss` in `: data : tls`. Without it lld errors with *"has an STT_TLS symbol but doesn't have an SHF_TLS section"*.
- Change `.bss ALIGN(4)` to `.bss ALIGN(8)`, which fixes an alignment warning.

Link wrapper `3ds-link`:
```sh
clang --target=arm-none-eabi -march=armv6k -mfloat-abi=hard -fuse-ld=lld -nostdlib \
  -Wl,-T,$HOME/dk/crt/3dsx.ld -Wl,--emit-relocs -Wl,--gc-sections \
  $HOME/dk/crt/3dsx_crt0.o $HOME/dk/crt/crti.o <objs> \
  -L... -Wl,--start-group -lcitro2d -lcitro3d -lctru -lm -lc -lsysbase -lclang_rt -Wl,--end-group -o out.elf
```
`--emit-relocs` is mandatory, because `3dsxtool` needs the relocations to make a relocatable `.3dsx`.

---

## 3. Building the game

`build.sh`:
1. `picasso -o world.shbin world.v.pica`, then Python turns it into `world_shbin.c/.h`.
2. Compile each `source/*.c` with the wrapper. `$EXTRA` carries `-DHM_DEBUG` / `-DHM_FORCE_STEREO` for test builds.
3. Link with `3ds-link`.
4. `tools/icon.py` (Pillow) draws the 48×48 icon, then `smdhtool --create "Title" "Desc" "Author" icon.png out.smdh`.
5. `3dsxtool game.elf game.3dsx --smdh=game.smdh`.

**CIA:**
```
bannertool makebanner -i banner.png(256x128) -a banner.wav(<3s) -o banner.bnr
bannertool makesmdh -s "Title" -l "Long title" -p "Author" -i icon.png -o icon.icn
makerom -f cia -o Game.cia -elf game.elf -rsf app.rsf -icon icon.icn -banner banner.bnr -target t -exefslogo \
  -DAPP_ENCRYPTED=false -DAPP_TITLE=... -DAPP_PRODUCT_CODE=CTR-H-XXXX -DAPP_UNIQUE_ID=0xFB4D1 \
  -DAPP_SYSTEM_MODE=64MB -DAPP_SYSTEM_MODE_EXT=Legacy -DAPP_CATEGORY=Application -DAPP_USE_ON_SD=true \
  -DAPP_MEMORY_TYPE=Application -DAPP_CPU_SPEED=268MHz -DAPP_ENABLE_L2_CACHE=false \
  -DAPP_VERSION_MAJOR=1 -DAPP_VERSION_MINOR=3 -DAPP_ROMFS=<empty dir>
```
- The **same ELF** works for both the `.3dsx` and the `.cia`.
- **Give each game its own `APP_UNIQUE_ID`**; the same ID overwrites on install.
- Keep the template's service list, which includes `dsp::DSP` for sound.
- The banner is the title screen screenshot (crop 400×200, resize to 256×128). The banner jingle is synthesised in Python with smooth envelopes.
- **Testing the CIA path in the emulator:** build a `.cxi` with the same makerom flags (`-f cxi`) and boot that. Panda3DS can't install CIAs.
- **Phones may refuse `.cia` downloads**, so also ship a `.zip`.

**Versioning:** `#define HM_VERSION "v1.x"` in `common.h`, shown bottom-right of both title screens. Bump it on every delivered build and put it in the filenames.

---

## 4. Emulator test rig (Panda3DS)

### 4.1 Building it
- `git clone --depth 1 wheremyfoodat/Panda3DS`, then `git submodule update --init --depth 1`.
- **Also** run `git submodule update --init --recursive` inside `third_party/dynarmic`; its nested externals (mcl, robin-map, zydis) are otherwise missing.
- CMake: `-DENABLE_VULKAN=OFF -DENABLE_DISCORD_RPC=OFF -DENABLE_LUAJIT=OFF -DENABLE_HTTP_SERVER=ON -DENABLE_WAYLAND=OFF -DENABLE_RENDERDOC_API=OFF -DENABLE_GIT_VERSIONING=OFF`, with clang/clang++. Target `Alber`. Builds in about 10 minutes on 2 cores.
- Upstream bugs patched:
  - In `CMakeLists.txt`, make `PANDA3DS_ENABLE_HTTP_SERVER` **PUBLIC** instead of PRIVATE. Otherwise the frontend sees a different `Emulator` class layout and crashes in `loadROM`.
  - `frontend_sdl.cpp`: `httpServer.processActions()` → `emu.httpServer.processActions()`.
  - `include/emulator.hpp`: make the `httpServer` member public.
- In `~/.local/share/Alber/config.toml`, set `EnableFastmem = false` (its SIGSEGV handler misfires here).

### 4.2 Running headless
```sh
pkill -x Alber; pkill -x Xvfb; sleep 1      # ALWAYS kill stale instances: they keep port 1234
SDL_VIDEO_X11_FORCE_EGL=1 timeout 300 xvfb-run -a -s "-screen 0 1280x1024x24" Alber game.3dsx &
```
- SDL was built without GLX (no GL headers), so **forcing EGL** is what makes it run.
- HTTP API on `localhost:1234`:
  - `/screen` returns a PNG of both screens stacked (400×480).
  - `/input?A=1` / `?A=0`.
  - `/status`.
  - Key names: A B X Y L R Up Down Left Right Start Select.
  - There is **no circle pad and no touch** via HTTP, and **ZL/ZR never reach the game**.
- Saves land in `~/.local/share/Alber/<rom-name>/SDMC/`. Delete the save there for fresh-game tests.
- A small Python driver (`press`, `hold`, `shot`) scripts runs. Combine screenshots into grids with Pillow to review many states at once.

### 4.3 Emulator speed and quirks
- It runs at **about 6–8 frames per real second** (software GL). **Hold keys for at least 0.6 s**, or they fall between frames and are never seen. Wait generously between steps.
- **Stale instance bug:** our inputs and screenshots once went to a leftover emulator from an earlier run, which produced impossible-looking results. Always `pkill` first.
- **Not emulated, works on hardware:**
  - citro2d **proctex** (procedural textures), so image tints and `C2D_DrawCircle` appear wrong or missing. Avoid both anyway (see 6.4).
  - **Stereo:** only the left eye is shown and the 3D slider reads 0. Add `HM_FORCE_STEREO` to run both eyes and inspect the left-eye image.
  - **Sound:** no audio device, so verify audio offline instead (section 7).

### 4.4 Debug build hooks (`-DHM_DEBUG`, compiled out of releases)
- Overlay on the bottom screen: fps, draw calls, citro2d vertex use, player position.
- **SELECT** cycles teleports through every NPC, each forage type, chests and boss arenas. Arena teleports also force that boss quest active.
- **L+Y:** level up, +500 gold, fill forage quests.
- **L+X:** spawn the local enemy in front of you.
- **L+A:** advance time of day.
- **L+Down:** open the shop.
- At boot, writes `sdmc:/3ds/hm_debug.txt` with world stats: props, obstacles, node counts, chest count, and every arena/NPC height and zone. That's how we caught a boss arena sitting in the wrong biome.

---

## 5. Game architecture (Hollowmere)

```
source/
  common.h   shared types, math helpers, gfx/world/audio API, HM_VERSION
  data.h     all content tables: items, enemies, NPCs, 24 quests + dialog, 38 achievements
  game.h     runtime structs (Save, Player, Enemy, Node, Drop, Particle...)
  gfx.c      shader setup, procedural meshes, chunked static world VBO, bitmap font,
             stereo projection, obj()/obj_ex() draw helper, frustum test, minimap texture
  world.c    deterministic RNG + value noise, island heightmap, biomes, props, collision
  audio.c    procedural SFX + 2 looping music tracks via ndsp
  game.c     logic: player, combat, enemies/bosses, loot, quests, bounties, shop,
             achievements, day/night, save/load, main loop
  ui.c       character/monster models from primitives, HUD, dialog, bottom-screen tabs, title
  world.v.pica  vertex shader: transform, per-vertex diffuse light, mulClr/addClr tint, distance fog
```

Key design choices that worked:
- **Everything is procedural:** meshes (cube, spheres, cones, cylinders, octahedron, ring, disc), terrain, textures (font, minimap) and audio. There are no asset files and no romfs.
- **Static world:** terrain plus baked props in one linear-memory VBO, split into 8×8 chunks drawn with distance and frustum culling.
- **Dynamic objects:** one draw per primitive with per-draw modelView and colour uniforms. Characters are about 12–20 primitives.
- **Determinism:** world generation and object placement use a fixed-seed RNG, so chest indices match the save bitmask on every boot. Never re-run placement mid-session.
- **Save:** one fixed-size struct written to `sdmc:/3ds/<game>.sav` with a magic and version. Autosave every 60 s, plus on quest turn-in, chest, achievement, bounty and exit.

---

## 6. Bugs we found and what they taught us

### 6.1 Time froze in the emulator → use the CPU tick counter
`osGetTime()` didn't advance in Panda3DS, so toasts never expired. Use:
```c
u64 now = svcGetSystemTick();
float dt = (now - last) / (double)SYSCLOCK_ARM11;
```
It's reliable on hardware and emulators. Clamp `dt` to about 0.05.

### 6.2 Texture row order
3DS textures are 8×8 tiles in Morton (Z-order) layout. **Write image row 0 (top) at memory row 0**, with no vertical flip, and use subtexture `top = 1 - y/H`. Our first font came out mirrored with the wrong glyphs because rows were flipped "bottom-up" as some docs imply. Morton offset within a tile:
```c
m = (x&1)|((y&1)<<1)|((x&2)<<1)|((y&2)<<2)|((x&4)<<2)|((y&4)<<3);   // RGBA8 pixel = (r<<24)|(g<<16)|(b<<8)|a
offset = ((y>>3)*(W>>3) + (x>>3))*64 + m;
```
Debug trick: draw the whole texture as one image to see the layout at a glance.

### 6.3 Bitmap font
- libctru's `default_font.bin` is 8×8, 256 glyphs. Byte = row (top first); bit `0x80` = leftmost pixel.
- **Make it proportional:** advance = rightmost lit column + 2. With a fixed 7 px advance, the 8 px-wide `W` and `M` smeared into their neighbours.
- **Wrap by pixel width, not character count.**
- For typewriter dialogue, lay out the *full* page and reveal the first N characters. Otherwise words jump lines as they type.

### 6.4 Coloured text without proctex
`C2D_DrawImage` with a tint uses the proctex unit to pass a blend factor. Panda3DS doesn't emulate it, so text came out white. Our `C2D_DrawAlphaQuad` uses citro2d's text-mode texenv (RGB from vertex, A = vertex alpha × texture alpha), which works everywhere. Draw circles as triangle fans instead of `C2D_DrawCircle`.

### 6.5 Mixing citro3d and citro2d in one frame
Per eye:
- `C3D_RenderTargetClear` + `C3D_FrameDrawOn`.
- Rebind *everything* for 3D: program, attr info, buf info, **all 6 texenv stages**, depth test, cull, blend.
- **Re-upload all uniforms.** citro2d's program shares the uniform shadow registers and clobbers yours.
- Then for HUD: `C2D_Prepare()`, `C2D_SceneBegin(target)`, then **`C3D_DepthTest(false, …)`** so the HUD isn't depth-tested against the 3D scene.

### 6.6 THE stereo shimmer bug: flush 2D before switching eyes
- **Symptom on the 3DS XL:** some HUD text (dialogue, "A: Talk to…") looked blinking or painful with the 3D slider up, while other text (the quest tracker) was fine.
- **Cause:** citro2d batches vertices and flushes lazily. We switched to the right-eye target without flushing, so the *last* batch of left-eye HUD was drawn into the right eye. Text drawn late was in one eye only, which the brain reads as shimmer. Text drawn early had been flushed by earlier state changes, so it was fine. Mono was fine because the bottom screen's `C2D_SceneBegin` flushed while still on the top target.
- **Fix:** call `C2D_Flush()` at the start of each eye and before `C3D_FrameEnd`.
- **How we found it:** your observation of *which* text failed, plus forcing stereo in the emulator, where the left eye showed an empty dialogue box.

### 6.7 Stereo comfort rules
- **Put the whole world behind the screen and keep HUD on the screen plane.** We first converged on the hero (about 9 units away), so foreground ground and trees popped *out*, and flat HUD boxes over them gave contradictory depth cues (window violation, eye strain). Fix: convergence distance about 3.6 (`focal` in `Mtx_PerspStereoTilt`), so all geometry recedes.
- **No fractional per-eye offsets on text.** Our "floating HUD" used sub-pixel disparity, which made glyphs sample differently per eye and look blurry. HUD text now has zero disparity, and all glyph positions are snapped to whole pixels. Only large transient titles float, by whole pixels.
- World-anchored labels (damage numbers, HP bars, `!` markers) are projected separately per eye with a non-tilted copy of each eye's projection (`Mtx_PerspStereo`), so they sit at true depth.
- Render the right eye only when the slider is above 0, and set `iod = slider × ~0.35`.

### 6.8 Controls
Camera-relative movement had the strafe sign inverted. Correct form:
```c
fwd = (sin camYaw, cos camYaw); right = (-cos camYaw, sin camYaw);
move = fwd*stickY + right*stickX;
```
Also: ZL/ZR are New 3DS buttons that need irrst. Don't rely on them; use L-combos for debug keys.

### 6.9 Gameplay bug: interaction priority
Pressing A beside a forage node gathered even while a monster was hitting you. Rule: if an enemy is within about 3 units, A attacks, and node and chest interaction are suppressed. NPC talk still wins.

### 6.10 Performance budget (Old 3DS, stereo doubles everything)
First build: about 850 draws per eye. After these changes, about 300:
- Horizontal frustum test (about ±41° plus the object's angular radius) for chunks and entities.
- Tighter distance limits, with fog at 19–40 units hiding the cut-off.
- Auto-LOD in `obj_ex`: tiny spheres and cylinders use low-poly meshes.
- Dropped invisible-at-size details (cheeks, rims).
- Lower-poly base sphere (5×8).

Also `osSetSpeedupEnable(true)` turns on 804 MHz + L2 cache on New 3DS.

### 6.11 Sound: crackle-free by construction
- Every effect starts and ends at exactly 0 (3–4 ms ramps), with smooth attack/decay envelopes.
- No hard-edged waves: the "square" wave is `tanh(2.5·sin)`.
- Music loops are mixed **with wrap-around indexing** (`buf[i % N] +=`), so notes crossing the loop end continue at the start. The seam is continuous.
- **Headroom:** effect peaks normalised to about 0.37 and channel volume 0.62, so four simultaneous effects plus music stay below full scale. The same effect can retrigger at most every 40 ms (stops coin spam stacking).
- **Verify offline:** compile `audio.c` on the host against a stub header (fake ndsp, `linearAlloc = malloc`) and dump every buffer to WAV. Check peak, max sample step, clipped count, edge values and loop-seam step. Do this before every audio change.
- On hardware, sound needs `sdmc:/3ds/dspfirm.cdc`, dumped once with **DSP1**. Without it, `ndspInit` fails and the game runs silently.

---

## 7. Checklist for the next game

1. Check the network. If devkitPro is reachable, install it and skip toolchain building.
2. Otherwise restore `~/dk` (wrappers, newlib, compiler-rt, libctru, citro3d, patched citro2d, tools, linker script) using section 2.
3. Copy the Hollowmere skeleton:
   - `gfx.c`, `audio.c`, the build script and the debug hooks are reusable as-is.
   - Replace `data.h`, `world.c`, `game.c` and `ui.c` with the new game.
4. From day one:
   - Use `svcGetSystemTick`.
   - Write textures with no row flip.
   - Draw text with `C2D_DrawAlphaQuad`, with **pixel-snapped glyphs**.
   - Call **`C2D_Flush()` per eye**.
   - Keep the world behind the screen.
   - Write crackle-free audio with an offline WAV check.
   - Put the version number on the title screen.
5. Test in Panda3DS:
   - Kill stale instances.
   - Hold keys 0.6 s.
   - Teleport with debug keys.
   - Do one `HM_FORCE_STEREO` run.
   - Check the draw-call and c2d counters.
6. Release: build without `HM_DEBUG`, then ship the `.3dsx`, the `.cia` and a `.cia` zip with the version in the filenames.
7. On the console:
   - **.3dsx:** copy to `SD:/3ds/` and launch from the Homebrew Launcher. If there's no HOME icon: Download Play → L+Down+Select → Miscellaneous options → "Switch the hb. title to the current app" → reopen Download Play.
   - **.cia:** install with FBI.
   - **Remote install by QR:** needs the file at a public URL.

## 8. Ideas parked for later
- C-stick camera on New 3DS (needs irrst).
- A real CIA icon jingle per game, plus the banner as a 3D model.
- A `servefiles`-style local server script for QR installs without a public host.
