import urllib.request, time, sys
B="http://localhost:1234"
def get(p):
    return urllib.request.urlopen(B+p, timeout=30).read()
def key(k, v): get(f"/input?{k}={v}")
def press(k, hold=0.6, after=0.6):
    key(k,1); time.sleep(hold); key(k,0); time.sleep(after)
def hold(k, secs):
    key(k,1); time.sleep(secs); key(k,0)
def shot(name):
    open(f"/root/emu/{name}.png","wb").write(get("/screen"))
