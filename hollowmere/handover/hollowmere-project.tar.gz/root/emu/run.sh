#!/bin/sh
pkill -x Alber 2>/dev/null; pkill -x Xvfb 2>/dev/null; sleep 1
cd ~/emu
SDL_VIDEO_X11_FORCE_EGL=1 timeout $2 xvfb-run -a -s "-screen 0 1280x1024x24" stdbuf -oL -eL ~/src/Panda3DS/build/Alber $1 > emu.log 2>&1 &
