# Minimal QR encoder: byte mode, version 3, ECC level L (55 data + 15 EC codewords, one block)
import sys
from PIL import Image, ImageDraw
URL = sys.argv[1]
V, N = 3, 29
DATA_CW, EC_CW = 55, 15
# --- data bits
bits = '0100' + format(len(URL), '08b') + ''.join(format(b, '08b') for b in URL.encode())
cap = DATA_CW * 8
bits += '0' * min(4, cap - len(bits))
bits += '0' * (-len(bits) % 8)
data = [int(bits[i:i+8], 2) for i in range(0, len(bits), 8)]
pads = [0xEC, 0x11]; i = 0
while len(data) < DATA_CW: data.append(pads[i % 2]); i += 1
# --- Reed-Solomon over GF(256), poly 0x11D
exp = [0]*512; log = [0]*256; x = 1
for k in range(255):
    exp[k] = x; log[x] = k; x <<= 1
    if x & 0x100: x ^= 0x11D
for k in range(255, 512): exp[k] = exp[k-255]
def mul(a, b): return 0 if a == 0 or b == 0 else exp[log[a] + log[b]]
gen = [1]
for k in range(EC_CW):
    ng = [0]*(len(gen)+1)
    for j, c in enumerate(gen):
        ng[j] ^= c; ng[j+1] ^= mul(c, exp[k])
    gen = ng
rem = data[:] + [0]*EC_CW
for k in range(DATA_CW):
    c = rem[k]
    if c:
        for j in range(len(gen)): rem[k+j] ^= mul(gen[j], c)
code = data + rem[DATA_CW:]
# --- matrix
M = [[None]*N for _ in range(N)]
def finder(r, c):
    for dr in range(-1, 8):
        for dc in range(-1, 8):
            rr, cc = r+dr, c+dc
            if 0 <= rr < N and 0 <= cc < N:
                on = 0 <= dr <= 6 and 0 <= dc <= 6 and (dr in (0, 6) or dc in (0, 6) or (2 <= dr <= 4 and 2 <= dc <= 4))
                M[rr][cc] = on
finder(0, 0); finder(0, N-7); finder(N-7, 0)
for k in range(8, N-8): M[6][k] = k % 2 == 0; M[k][6] = k % 2 == 0
ac = 22  # alignment pattern centre for version 3
for dr in range(-2, 3):
    for dc in range(-2, 3): M[ac+dr][ac+dc] = max(abs(dr), abs(dc)) != 1
M[N-8][8] = True  # dark module
reserved = set()
for k in range(9): reserved.add((8, k)); reserved.add((k, 8))
for k in range(8): reserved.add((8, N-1-k)); reserved.add((N-1-k, 8))
func = {(r, c) for r in range(N) for c in range(N) if M[r][c] is not None} | reserved
# place data
cbits = ''.join(format(b, '08b') for b in code)
idx = 0; c = N-1; up = True
while c > 0:
    if c == 6: c -= 1
    rows = range(N-1, -1, -1) if up else range(N)
    for r in rows:
        for cc in (c, c-1):
            if (r, cc) in func: continue
            M[r][cc] = idx < len(cbits) and cbits[idx] == '1'; idx += 1
    c -= 2; up = not up
masks = [lambda r,c:(r+c)%2==0, lambda r,c:r%2==0, lambda r,c:c%3==0, lambda r,c:(r+c)%3==0,
         lambda r,c:(r//2+c//3)%2==0, lambda r,c:(r*c)%2+(r*c)%3==0, lambda r,c:((r*c)%2+(r*c)%3)%2==0, lambda r,c:((r+c)%2+(r*c)%3)%2==0]
def fmt_bits(mask):
    d = (0b01 << 3) | mask  # ECC L = 01
    v = d << 10; g = 0b10100110111
    for k in range(14, 9, -1):
        if v & (1 << k): v ^= g << (k-10)
    return ((d << 10) | v) ^ 0b101010000010010
def build(mask):
    A = [row[:] for row in M]
    for r in range(N):
        for c in range(N):
            if (r, c) not in func and masks[mask](r, c): A[r][c] = not A[r][c]
    f = fmt_bits(mask)
    fb = [(f >> k) & 1 for k in range(15)]   # bit 0 = LSB
    # around top-left
    pos1 = [(8,0),(8,1),(8,2),(8,3),(8,4),(8,5),(8,7),(8,8),(7,8),(5,8),(4,8),(3,8),(2,8),(1,8),(0,8)]
    pos2 = [(N-1,8),(N-2,8),(N-3,8),(N-4,8),(N-5,8),(N-6,8),(N-7,8),(8,N-8),(8,N-7),(8,N-6),(8,N-5),(8,N-4),(8,N-3),(8,N-2),(8,N-1)]
    for k in range(15):
        A[pos1[k][0]][pos1[k][1]] = bool(fb[14-k])
        A[pos2[k][0]][pos2[k][1]] = bool(fb[14-k])
    A[N-8][8] = True
    return A
def penalty(A):
    p = 0
    for line in A + [list(col) for col in zip(*A)]:
        run = 1
        for k in range(1, N):
            if line[k] == line[k-1]: run += 1
            else:
                if run >= 5: p += run - 2
                run = 1
        if run >= 5: p += run - 2
    for r in range(N-1):
        for c in range(N-1):
            if A[r][c] == A[r+1][c] == A[r][c+1] == A[r+1][c+1]: p += 3
    dark = sum(map(sum, A)); p += abs(dark*100//(N*N) - 50)//5*10
    return p
best = min(range(8), key=lambda m: penalty(build(m)))
A = build(best)
S, Q = 12, 4
img = Image.new('RGB', ((N+2*Q)*S, (N+2*Q)*S), 'white'); d = ImageDraw.Draw(img)
for r in range(N):
    for c in range(N):
        if A[r][c]: d.rectangle([(c+Q)*S, (r+Q)*S, (c+Q+1)*S-1, (r+Q+1)*S-1], fill='black')
img.save(sys.argv[2]); print('mask', best)
