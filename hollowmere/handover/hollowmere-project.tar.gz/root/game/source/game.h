#pragma once
#include "data.h"

#define MAX_EN 48
#define MAX_NODES 320
#define MAX_CHESTS 32
#define MAX_DROPS 90
#define MAX_PART 360
#define MAX_FTXT 40
#define BAG_N 24
#define LVL_CAP 30

typedef struct {
	bool on; u8 type, state;
	V3 p; float yaw, hp, maxhp, t, atkCd, flash, hop, windup, deadT, slamT, slamCd, kbx, kbz, sx, sz, wanderT, wx, wz, hitShow, charge;
	bool boss, elite; u8 guard, rseq;
	u8 atk;                       // what the current wind-up becomes: 0 swipe, 1 slam (red ring), 2 dash (red arrow), 3 cast, 4 shot
	float guardT, recoverT, stunT, freezeT, chillT, burnT, burnDps, poisonT, dotAcc, dashT, castT;
	float aimX, aimZ, castX, castZ; u8 chillN, poisonStk; bool dashHit, growled;
	float dmgMul; u8 elem, lvl; u8 hitsRow; bool counter; // parry: each hit in a row makes the next more likely to be parried
	float hx, hz; bool leaving; // where it spawned; walking back there after losing interest
} Enemy;
enum { ES_IDLE, ES_CHASE, ES_WINDUP, ES_DEAD };

typedef struct { u8 type, zone, kid; bool alive; float x, z, y, regrow, pop, wob; } Node;
typedef struct { float x, z, y, yaw; bool golden; float openT; } Chest;
typedef struct { bool on; u8 kind, item; V3 p, v; float t; int amount; Gear g; bool settled; float ox, oz, fullT; } Drop; // kind 0 coin 1 item 2 gear
typedef struct { bool on; V3 p, v; float life, max, size, grav, emit; u32 col; u8 mesh; } Part;
typedef struct { bool on; V3 p; float t, life; char s[24]; u32 col; int scale; } FText;

#define CRAFT_SLOTS 4
typedef struct { u8 r, state, sub, pad; float left, total; } CraftJob;
typedef struct {
	u32 magic, version;
	float px, pz, yaw, hp, tod, playTime;
	int lvl, xp, gold;
	u16 items[IT_COUNT];
	Gear bag[BAG_N]; Gear weapon, charm;
	u8 qs[Q_COUNT_V1]; u16 qprog[Q_COUNT_V1];
	u32 ach[2];
	u32 chestsOpened;
	u8 kittens, lantern, zonesVisited, bossesKilled;
	u32 sForage, sKills, sChests, sGoldTotal, sCrits, sDigs, sBounties, sBoxes, sCombos, sTonics, sQuests;
	u8 bActive, bType, bTarget, bCount; u16 bProg, bGold, bXp; u8 bGear, pad[3];
	s8 tracked; u8 pad2[3];
	// v4 additions (appended so v3 saves load with these zeroed)
	Gear armor;
	u8 newGear, pad4[3];
	// v5 additions
	u16 xitems[XI_MAX];
	u8 crafterLvl, mq, mqState, pad5;
	u16 crafterXp, mqProg;
	u32 sMoonblooms, sCrafts;
	// v6 additions
	CraftJob jobs[CRAFT_SLOTS];
	u8 readyCache[3], pad6;
	// v7 additions: quests added after the original 24
	u8 qs2[8]; u16 qprog2[8];
	// v8: finished crafts waiting to be ticked off
	u8 doneR[8]; u8 doneN, pad8[3];
	// v9: more quests, items waiting at crafting stations, options
	u8 qs3[16]; u16 qprog3[16];
	u8 hold[2][8]; u8 holdN[2];
	u8 optLevels, pad9;
	u16 sEvents, sPortals;
	// v10: camera mode, difficulty slider (0-100, 75 = the original balance)
	u8 optCam, optDiff, pad10[2];
	// v11: shoulder-camera tuning, each 0-20 (side, height, distance, tilt)
	u8 camAdj[4];
	// v12: elemental achievements
	u16 sWeak[4], sWard[4];
	// v13: world level (foes no longer track yours), level-up picks, purse/pack limits
	u8 worldLvl, rumbleN, purseLv, bagLv, buffLv, lvlPicks, rumbleSeen, pad13; // rumbleN: odds are 1 in rumbleN*50
	// v14: endurance, shop boosts, spawn rate (0-100, 25 = the tuned rate)
	u8 staLv, boostHp, boostDef, boostSta, spawnPct, pad14[3];
	// v15: economy rework: per-item satchel pouches (pack points), bank, return stone
	u32 bank; u8 bankLv, packPts, tonicPts, gearPts, fortuneLv, retOn, seals, pad15; // v16: seals = bitmask of outer zones whose element seal is broken
	float retX, retZ;
	u8 pouch[32];
	// v17: dungeons. depFloor = deepest Depths floor reached per zone (checkpoint), depDone/pages/dunSeen bitmasks by zone
	u8 depFloor[Z_COUNT], depDone, riftTier, pages, dunSeen, riftSeen, riftNext;
	// v18: story doors in the Depths (note found / key from the islander), test unlocks, announcements, lore found per zone (bits = floors)
	u8 depNote, depKey, testUnlock, ann, depLore[Z_COUNT], pad18[2];
	// v19: perks (bits of PK_*), perk picks waiting
	u16 perks; u8 perkPicks, pad19;
} Save;
extern Save S;
static inline u16* itemp(int id) { return id < IT_COUNT ? &S.items[id] : &S.xitems[id - IT_COUNT]; }
#define IC(id) (*itemp(id))
#define TRACK_MAIN 100
#define TRACK_EVENT 101
static inline u8* qsp(int q) { return q < Q_COUNT_V1 ? &S.qs[q] : q < Q_COUNT_V1 + 8 ? &S.qs2[q - Q_COUNT_V1] : &S.qs3[q - Q_COUNT_V1 - 8]; }
static inline u16* qprogp(int q) { return q < Q_COUNT_V1 ? &S.qprog[q] : q < Q_COUNT_V1 + 8 ? &S.qprog2[q - Q_COUNT_V1] : &S.qprog3[q - Q_COUNT_V1 - 8]; }
#define QS(q) (*qsp(q))
#define QP(q) (*qprogp(q))
enum { QS_LOCKED, QS_AVAIL, QS_ACTIVE, QS_DONE };

typedef struct {
	V3 p; float yaw;
	float maxhp;
	float atkT, atkCd, rollT, rollCd, hurtT, inv;
	float rdx, rdz, walk; bool moving;
	int combo; float comboT; bool hitDone; bool finisher;
	float noDmgT, deadT, grace;
	bool bossHit, closeCall;
	float chargeT, rollAge; bool heavy, perfectUsed, nextCrit, aHeld; // heavy attack (hold A), perfect dodge
	float sta, staT; // endurance: attacks and rolls spend it, it refills when you ease off
} PlayerT;
extern PlayerT P;

extern Enemy en[MAX_EN];
extern Node nodes[MAX_NODES]; extern int nnodes;
extern Chest chests[MAX_CHESTS]; extern int nchests;
extern Drop drops[MAX_DROPS];
extern Part parts[MAX_PART];
extern FText ftx[MAX_FTXT];
extern float gtime, camYaw, shake, hitstop;
extern int curZone;
extern float goldShown;

// dialog / ui state
typedef struct { bool on; int npc; char pages[10][320]; char spk[10][16]; int n, cur; float chars; int action, arg; } Dialog;
extern Dialog D;
enum { ACT_NONE, ACT_ACCEPT, ACT_COMPLETE, ACT_SHOP, ACT_BOUNTY_ACCEPT, ACT_BOUNTY_DONE, ACT_ENDING, ACT_MQ_ACCEPT, ACT_MQ_COMPLETE };
typedef struct { char title[40]; char sub[64]; u32 col; float t; int kind; } Toast;
extern Toast toastQ[8]; extern int toastN;
typedef struct { char s[40]; u32 col; float t; } Feed;
extern Feed feed[6];
extern char zoneBanner[40]; extern float zoneBannerT; extern u32 zoneBannerCol;
extern int tab, scrollAch, scrollGear, selGear, tabHelpOpen;
extern bool shopOpen, paused;
extern int mode; enum { MODE_TITLE, MODE_PLAY };
extern float endingT, levelFlashT, deathT;
extern char promptText[48];
extern int bossIdx;
extern bool hasSave;
extern int pauseSel; extern int lvlPickSel;
#define PAUSE_N 12
float sta_max(void);
float en_size(const Enemy* e);
extern float slowmoT;
typedef struct { bool on; V3 p, v; float t, dmg; u8 elem; u32 col; } Shot;
#define MAX_SHOTS 24
extern Shot shots[MAX_SHOTS];
#define TRACK_RUMBLE 102
int gold_cap(void); int bag_cap(void); int bag_count(void); bool item_key(int id); int item_value(int id);
int item_cap(int id); bool item_full(int id); int gear_cap(void); int gear_count(void); void pouch_up(int id); int bank_cap(void); int vault_cost(void);
void return_stone(void); bool in_town(void); extern bool bankMode;
#define BANK_X 3.9f // Bram's strongbox, the west end of his cart
#define BANK_Z 2.8f
#define BANK_N 4
void sell_item(int id); void level_pick(int k);
extern float hudCoinFullT, hudBagFullT, hudStaFlash;
int boost_cost(int n);
extern bool camAdjOn; extern int camAdjSel;
static const u8 CAM_ADJ_DEF[4] = { 16, 10, 10, 10 };
float diff_hp(void); float diff_dmg(void); const char* diff_name(int d);
extern float kittenPos[3][2];
extern int titleSel;
extern bool guideOn, guideBounty, guideValid;
extern float guideX, guideZ;
extern int shopSel;
void ui_dpad(int dir);
void ui_menu_y(void);
typedef struct { bool on; int phase; float t, stepT, shake, flash; int shown, steps; Gear g; int kind; } Gacha;
extern Gacha G;
// HUD "juice": pickups fly from the player up to the XP bar / coin counter, and pay out on arrival
typedef struct { bool on, init; u8 kind; float sx, sy, cx, cy, t, dur; int amount; } HudFly; // kind 0 xp, 1 coin
#define MAX_HFLY 48
extern HudFly hfly[MAX_HFLY];
extern float hudXpFlash, hudCoinPulse;
void gacha_start(int kind, int minR);
void gacha_choice(int c); // 0 equip, 1 keep, 2 salvage
void craft(int r);
bool can_craft(int r);
int tome_cost(int big);
int tonic_cost(void);
bool giver_busy(int npc);
bool npc_met(int npc);
int quest_have(int q);
#define STALL_X 7.15f // Bram's cart: press A at its east end to shop without the chat
#define STALL_Z 2.8f
int tome_xp(int big);
int cache_cost(void);
extern int craftSel;
bool recipe_unlocked(int r);
bool recipe_uses_raw(int r);   // tier 2 that would fall back to raw ingredients
int recipe_quest_mark(int r);  // 0 none, 1 side quest wants it, 2 main story wants it, 3 part of a main story item
bool mq_active(void);          // story started and not finished
bool mq_ready(void);
bool mq_items_ok(void);
void mq_progress_text(char* buf);
void hl(const char* in, char* out, int cap);   // colour people/places yellow, items/monsters red, moon after night-only things
int queued_count(int item);
int craft_jobs(void);
void open_ready_cache(void);
void gacha_hit(void);
int item_icon(int id);
int recipe_icon(int r);
int gear_icon(const Gear* g);
int enemy_elem(int type);
int elem_icon(int el);
bool zone_open(int z);
// ---- dungeons (v1.28)
#define DMAX 56
#define DTS 2.0f
#define DWH 1.7f
enum { DT_ROCK, DT_FLOOR, DT_DOWN, DT_UP, DT_PORTAL, DT_GATE };
enum { OB_LORE, OB_NOTE, OB_LEVER, OB_BLOCK, OB_PLATE };
typedef struct { u8 i, j, type, state, hi, hj; float anim; } DObj;
typedef struct { float x, z; u8 kind, zone; } DunGate; // kind 0 Depths, 1 Rift
typedef struct { u8 i, j, type, state, elite; } DSpawn; // state 0 waiting, 1 out
typedef struct { u8 i, j; bool open, reward; float openT; } DChest;
typedef struct {
	u8 kind, zone, floor, floors, mod;
	int w, h, si, sj, xi, xj, gate, champ, nsp, nch;
	u8 t[DMAX][DMAX], seen[DMAX][DMAX];
	DSpawn sp[80]; DChest ch[4];
	bool champDead;
	float blastX[8], blastZ[8], blastT[8];
	// rifts (v1.29): a kill bar that summons the guardian, against the clock, at a tier you chose
	u8 tier, deaths, npyl, rtype, wave; bool guardOn, timeUp, done;
	float waveT, haul;
	float timeLeft, prog, need;
	// Depths puzzles (v1.29): the exit room is gated: 1 story door, 2 levers, 3 boulders on plates
	DObj ob[12]; int nob; u8 lock, ng; bool lockOpen; u8 gi[12], gj[12];
	struct { u8 i, j, type; bool used; } pyl[3];
} DunState;
extern float pylT[4]; // shrine buffs: power, haste, ward, storm
extern bool riftPick; extern int riftPickTier;
int rift_max(void);
bool has_af(int a); bool has_lp(int p); bool has_pk(int k);
extern int perkOffer[3], perkSel; extern float whirlCd;
void perk_pick(int k);
bool gate_open(int g); bool rifts_open(void);
enum { RT_HUNT, RT_ARENA, RT_DELVE };
float rift_hp_mul(int t); float rift_dmg_mul(int t);
extern DunState DG; extern DunGate gates[10]; extern int ngates;
float dun_x(int i); float dun_z(int j); int dun_ti(float x); int dun_tj(float z); int dun_tile(int i, int j);
const char* dun_name(void);
int near_seal(void);
int seal_key(int zone);
extern const char* seal_name[Z_COUNT];
void ack_craft(int i);   // -1 = all
bool item_night(int id);
bool quest_night(int q);
// buildings with a purpose
#define BLD_COUNT 2
typedef struct { const char* name; float x, z, yaw; int station; } BuildingDef;
extern const BuildingDef blddefs[BLD_COUNT];
int bld_stage(int b);            // 0 run-down, 1 working, 2 fully restored
void bld_door(int b, float* x, float* z);
const char* station_name(int st);
// world events (FATE-like)
enum { EVT_HORDE, EVT_PORTAL };
typedef struct { bool on; u8 type, nkeys, keyGot; float x, z, t, dur; int prog, need; float kx[5], kz[5]; } WorldEvent;
extern WorldEvent EV;
const char* event_name(void);
void event_progress_text(char* buf);
void event_unlocked(int type);
float armor_def(void);

// logic API used by ui
float player_maxhp(void);
float charm_val(int stat);
float weapon_power(void);
void gear_name(const Gear* g, char* out);
int xp_next(int lvl);
bool quest_ready(int q);
int npc_marker(int npc); // 0 none, 1 available(!), 2 ready(?), 3 active, 4/5/6 the same for the main story
const char* quest_progress_text(int q, char* buf);
void ui_tap(int x, int y);
void use_tonic(void);
void shop_buy(int i);
int whetstone_cost(void);
void equip_bag(int i);
void salvage_bag(int i);
int salvage_value(const Gear* g);
void bounty_text(char* buf);
bool bounty_ready(void);
bool night_now(void);
void do_save(void);
void game_new(void);
bool game_load(void);

// render
void render_world(int eye);
void render_hud(int eye);
void render_bottom(void);
void render_title(int eye);
void render_title_bottom(void);
void render_loading(int eye, float t, float progress);
void render_loading_bottom(float t, float progress);
extern float loadFadeT;
void spawn_part(V3 p, V3 v, float life, float size, u32 col, float grav, float emit, int mesh);
void burst(V3 p, int n, u32 col, float speed, float up, float life, float size, float emit);
void ftext(V3 p, const char* s, u32 col, int scale);
void toast(const char* title, const char* sub, u32 col, int kind);
void feed_add(const char* s, u32 col);
