#include "game.h"
#include <sys/stat.h>
#include <stddef.h>

Save S;
PlayerT P;
Enemy en[MAX_EN];
Node nodes[MAX_NODES]; int nnodes;
Chest chests[MAX_CHESTS]; int nchests;
Drop drops[MAX_DROPS];
Part parts[MAX_PART];
FText ftx[MAX_FTXT];
float gtime, camYaw = PI, shake, hitstop;
int curZone = -1;
float goldShown;
Dialog D;
Toast toastQ[8]; int toastN;
Feed feed[6];
char zoneBanner[40]; float zoneBannerT; u32 zoneBannerCol;
int tab, scrollAch, scrollGear, selGear = -1, tabHelpOpen;
bool shopOpen, paused;
int mode = MODE_TITLE;
float endingT, levelFlashT, deathT;
char promptText[48];
int bossIdx = -1;
float pylT[4]; bool riftPick; int riftPickTier;
bool hasSave;
int pauseSel;
bool camAdjOn; int camAdjSel;
float kittenPos[3][2];
int titleSel;
bool guideOn, guideBounty, guideValid;
float guideX, guideZ;
int shopSel;
Gacha G;
HudFly hfly[MAX_HFLY];
float hudXpFlash, hudCoinPulse, hudCoinFullT, hudBagFullT, hudStaFlash;
static int gain_gold(int g);
static float tiredMsgT;
int dbgParry, dbgShots, dbgHits;
int craftSel;

static float spawnT, autosaveT, mewT, pickCombo, pickComboT, bossRespawn[5];
static const int zone_ranged[Z_COUNT] = { EN_SPORE, EN_SPORE, EN_SPITTER, EN_CASTER, EN_FLINGER, EN_BOGSPIT };
Shot shots[MAX_SHOTS];
static const int zone_enemies[Z_COUNT][2] = { {EN_SLIME, EN_SLIME}, {EN_SLIME, EN_PUFF}, {EN_CRAB, EN_TIDE}, {EN_GOLEM, EN_RWISP}, {EN_THORN, EN_BOAR}, {EN_TOAD, EN_MWISP} };
static const int boss_zone_quest[5][3] = { {EN_GLOOPA, Z_MEADOW, Q_E2}, {EN_PINCER, Z_BEACH, Q_G2}, {EN_BRAMBLE, Z_FOREST, Q_F2}, {EN_CROAK, Z_SWAMP, Q_O2}, {EN_COLOSSUS, Z_RUINS, Q_R2} };

#define SAVE_PATH "sdmc:/3ds/hollowmere.sav"
#define SAVE_MAGIC 0x484D5245
#define SAVE_VER 19
#define HP_MULT 1.6f
#define DROP_LIFE 300.f // seconds a coin, item or gear drop lies around
#define DMG_MULT 1.6f
// difficulty slider: 75 is the tuned balance (x1). Below it foes soften, above it they toughen.
static float diff_k(float lo, float hi) { float d = S.optDiff; return d <= 75 ? lo + (1 - lo) * d / 75 : 1 + (hi - 1) * (d - 75) / 25; }
float diff_hp(void) { return diff_k(0.45f, 1.35f); }
float diff_dmg(void) { return diff_k(0.35f, 1.45f); }
const char* diff_name(int d) { return d < 25 ? "Relaxed" : d < 50 ? "Easy" : d < 75 ? "Normal" : d < 90 ? "Hard" : "Brutal"; }

// ------------------------------------------------------------ effects helpers
void spawn_part(V3 p, V3 v, float life, float size, u32 col, float grav, float emit, int mesh) {
	for (int i = 0; i < MAX_PART; i++) if (!parts[i].on) {
		Part* q = &parts[i]; q->on = true; q->p = p; q->v = v; q->life = q->max = life; q->size = size; q->col = col; q->grav = grav; q->emit = emit; q->mesh = mesh;
		return;
	}
}
void burst(V3 p, int n, u32 col, float speed, float up, float life, float size, float emit) {
	for (int i = 0; i < n; i++) {
		float a = rndf()*TAU, s = speed * rndr(0.4f, 1.0f);
		spawn_part(p, v3(cosf(a)*s, up * rndr(0.5f, 1.2f), sinf(a)*s), life * rndr(0.7f, 1.2f), size * rndr(0.7f, 1.2f), col, 9.0f, emit, MESH_CUBE);
	}
}
void ftext(V3 p, const char* s, u32 col, int scale) {
	int best = 0; float bt = -1;
	for (int i = 0; i < MAX_FTXT; i++) { if (!ftx[i].on) { best = i; break; } if (ftx[i].t > bt) { bt = ftx[i].t; best = i; } }
	FText* f = &ftx[best]; f->on = true; f->p = p; f->t = 0; f->life = 1.1f; strncpy(f->s, s, 23); f->s[23] = 0; f->col = col; f->scale = scale;
}
void toast(const char* title, const char* sub, u32 col, int kind) {
	if (toastN >= 8) return;
	Toast* t = &toastQ[toastN++];
	strncpy(t->title, title, 39); t->title[39] = 0; strncpy(t->sub, sub, 63); t->sub[63] = 0; t->col = col; t->t = 0; t->kind = kind;
}
void feed_add(const char* s, u32 col) {
	for (int i = 5; i > 0; i--) feed[i] = feed[i-1];
	strncpy(feed[0].s, s, 39); feed[0].s[39] = 0; feed[0].col = col; feed[0].t = 0;
}

// ------------------------------------------------------------ achievements
static void ach(int id) {
	if (S.ach[id >> 5] & (1u << (id & 31))) return;
	S.ach[id >> 5] |= 1u << (id & 31);
	toast("ACHIEVEMENT UNLOCKED", achdefs[id].name, 0xFFD23F, 1);
	sfx(SFX_ACH);
	burst(v3add(P.p, v3(0, 1.2f, 0)), 24, 0xFFD23F, 5, 8, 1.0f, 0.14f, 0.8f);
	if (mode == MODE_PLAY) do_save();
}
static void check_achievements(void) {
	if (S.sForage >= 1) ach(A_FORAGE1); if (S.sForage >= 50) ach(A_FORAGE50); if (S.sForage >= 250) ach(A_FORAGE250);
	if (S.sKills >= 1) ach(A_KILL1); if (S.sKills >= 100) ach(A_KILL100); if (S.sKills >= 500) ach(A_KILL500);
	if (S.sChests >= 1) ach(A_CHEST1); if (S.sChests >= 10) ach(A_CHEST10); if (S.sChests >= (u32)nchests && nchests > 0) ach(A_CHESTALL);
	if (S.sGoldTotal >= 500) ach(A_GOLD500); if (S.sGoldTotal >= 5000) ach(A_GOLD5K); if (S.sGoldTotal >= 25000) ach(A_GOLD25K);
	if (S.lvl >= 5) ach(A_LVL5); if (S.lvl >= 10) ach(A_LVL10); if (S.lvl >= 20) ach(A_LVL20);
	if (S.sQuests >= 5) ach(A_QUEST5);
	{ bool all = true; for (int q = 0; q < Q_COUNT; q++) if (q != Q_E0 && QS(q) != QS_DONE) all = false; if (all) ach(A_QUESTALL); }
	for (int b = 0; b < 5; b++) if (S.bossesKilled & (1 << b)) ach(A_BOSS0 + b);
	if (S.kittens == 7) ach(A_KITTENS);
	if (S.lantern) ach(A_LANTERN);
	if (S.sCrits >= 100) ach(A_CRIT100);
	if (S.sDigs >= 15) ach(A_DIG15);
	if ((S.zonesVisited & 0x3F) == 0x3F) ach(A_EXPLORER);
	if (S.sBounties >= 10) ach(A_BOUNTY10);
	if (S.sBoxes >= 5) ach(A_GAMBLER);
	if (S.sCombos >= 25) ach(A_COMBO25);
	if (S.weapon.upg >= 5) ach(A_UPG5);
	if (S.sTonics >= 10) ach(A_TONIC10);
	if (QS(Q_L5) == QS_DONE) ach(A_STORY1);
	{ static const int aw[4] = { A_WEAK_FIRE, A_WEAK_FROST, A_WEAK_VENOM, A_WEAK_STORM }, ad[4] = { A_WARD_FIRE, A_WARD_FROST, A_WARD_VENOM, A_WARD_STORM };
	  for (int k = 0; k < 4; k++) { if (S.sWeak[k] >= 10) ach(aw[k]); if (S.sWard[k] >= 10) ach(ad[k]); } }
	if (S.sMoonblooms >= 10) ach(A_MOONBLOOM);
	if (S.crafterLvl >= 3) ach(A_CRAFTER3);
}

// ------------------------------------------------------------ stats & gear
int xp_next(int lvl) { return 40 + lvl * lvl * 14; }
float charm_val(int stat) {
	if (!S.charm.used) return 0;
	if (S.charm.special == 1) { if (stat == 1) return 60; if (stat == 2) return 120; return 0; }
	return S.charm.base == stat ? S.charm.power : 0;
}
float player_maxhp(void) { return 60 + S.lvl * 10 + charm_val(3) + 15 * S.buffLv + 5 * S.boostHp; }
float sta_max(void) { return 100 + 20 * S.staLv + 8 * S.boostSta; }
// limits you grow by choosing them at level-up
int gold_cap(void) { return 0x3FFFFFFF; }                  // v1.26: no purse limit; carried gold is at risk instead (dropped when you faint)
int bag_cap(void) { return 40 + 10 * S.bagLv; }           // materials carried (key items and tonics don't count)
// v1.26 satchel: every material has its own pouch (20, +10 per pack point); tonics have one (5, +2); gear has slots (8, +2)
int item_cap(int id) { if (id == IT_TONIC) return 5 + 2 * S.tonicPts; if (item_key(id)) return 9999; return 20 + 10 * S.pouch[id < 32 ? id : 31]; }
bool item_full(int id) { return IC(id) >= item_cap(id); }
int gear_cap(void) { int c = 8 + 2 * S.gearPts; return c > BAG_N ? BAG_N : c; }
int gear_count(void) { int n = 0; for (int i = 0; i < BAG_N; i++) n += S.bag[i].used; return n; }
void pouch_up(int id) { // spend a pack point: id >= 0 a material pouch, -1 the tonic pouch, -2 gear slots
	if (S.packPts <= 0) { sfx(SFX_HURT); return; }
	if (id == -2 && gear_cap() >= BAG_N) { sfx(SFX_HURT); return; }
	S.packPts--;
	char b[48];
	if (id == -1) { S.tonicPts++; sprintf(b, "Tonic pouch holds %d", item_cap(IT_TONIC)); }
	else if (id == -2) { S.gearPts++; sprintf(b, "Gear pouch holds %d", gear_cap()); }
	else { S.pouch[id < 32 ? id : 31]++; sprintf(b, "%s pouch holds %d", itemd(id)->name, item_cap(id)); }
	toast("POUCH UPGRADED", b, 0x9FE0FF, 0); sfx(SFX_BUY); do_save();
}
int bank_cap(void) { return 2000 * (1 + S.bankLv); }
int vault_cost(void) { return 400 * (1 + S.bankLv) * (1 + S.bankLv); }
bool in_town(void) { return sqrtf(P.p.x * P.p.x + P.p.z * P.p.z) < 12.6f; }
bool bankMode;
bool item_key(int id) { return id == IT_PIE || id == IT_SHARD || id == IT_TONIC || id == XI_HANDLAMP || id == XI_MOTHLAMP || id == XI_LEDGER; }
int bag_count(void) { int n = 0; for (int i = 0; i < ALL_ITEMS; i++) if (!item_key(i)) n += IC(i); return n; }
int item_value(int id) { return id >= IT_COUNT ? 8 : id >= IT_GEL ? 5 : id == IT_CRYSTAL ? 5 : 3; }
float weapon_power(void) { return S.weapon.used ? S.weapon.power : 4; }
bool has_af(int a) { return (S.weapon.used && S.weapon.pad == a) || (S.armor.used && S.armor.pad == a) || (S.charm.used && S.charm.pad == a); }
bool has_lp(int p) { return (S.weapon.used && S.weapon.special == p) || (S.armor.used && S.armor.special == p) || (S.charm.used && S.charm.special == p); }
bool has_pk(int k) { return (S.perks >> k) & 1; }
int perkOffer[3] = { -1, -1, -1 }, perkSel; float whirlCd, phoenixCd, lastStandCd, frenzyT, echoT, stormT; int swingN; static u8 rollSeq;
static const float wbase_mult[WEAPON_BASES] = { 0.7f, 0.9f, 1.0f, 1.08f, 1.15f, 1.03f, 0.97f, 1.12f };

void gear_name(const Gear* g, char* out) {
	if (g->special == 1) { strcpy(out, "Biscuit's Whisker"); return; }
	const char* b = g->kind == 0 ? weapon_base[g->base % WEAPON_BASES] : (g->kind == 2 ? armor_base[g->base % ARMOR_BASES] : charm_base[g->base % CHARM_BASES]);
	if (g->kind == 0 && g->upg) sprintf(out, "%s %s +%d", prefix[g->rarity][g->pre & 3], b, g->upg);
	else sprintf(out, "%s %s", prefix[g->rarity][g->pre & 3], b);
	if (g->special >= LP_EMBERS && g->special < LP_END) sprintf(out, "%s %s", b, lp_name[g->special - LP_EMBERS]); // legendaries are named by their power
}
// table 0 = world drops (stingy), 1 = caches (generous)
static int lootTable = 0;
static int roll_rarity(float luck, int minR) {
	static const float tabs[2][R_COUNT] = { { 78, 18, 3.5f, 0.5f, 0 }, { 0, 52, 33, 11.5f, 3.5f } };
	float w[R_COUNT]; for (int i = 0; i < R_COUNT; i++) w[i] = tabs[lootTable][i];
	float m = 1 + luck / 100.f;
	for (int i = 1; i < R_COUNT; i++) w[i] *= m;
	float tot = 0; for (int i = minR; i < R_COUNT; i++) tot += w[i];
	float r = rndf() * tot;
	for (int i = minR; i < R_COUNT; i++) { if (r < w[i]) return i; r -= w[i]; }
	return minR;
}
static Gear gen_gear(int kind, int minR, int ilvl) {
	Gear g; memset(&g, 0, sizeof g);
	g.used = 1;
	g.kind = kind < 0 ? (rndf() < 0.45f ? 0 : (rndf() < 0.55f ? 2 : 1)) : kind;
	g.rarity = roll_rarity(charm_val(1) + 0, minR < 0 ? 0 : minR);
	g.ilvl = ilvl < 1 ? 1 : ilvl;
	g.pre = rndi(0, 3);
	if (g.kind != 1) { float ch = g.rarity == R_COMMON ? 0.15f : g.rarity == R_UNCOMMON ? 0.55f : 0.9f; if (rndf() < ch) g.elem = rndi(1, EL_COUNT - 1); }
	if (g.kind == 2) {
		g.base = rndi(0, ARMOR_BASES - 1);
		g.power = (u16)((4 + g.ilvl * 2.2f) * rarity_mult[g.rarity] * armor_mult[g.base] * rndr(0.92f, 1.08f));
	} else if (g.kind == 0) {
		g.base = rndi(1, WEAPON_BASES - 1);
		g.power = (u16)((5 + g.ilvl * 2.4f) * rarity_mult[g.rarity] * wbase_mult[g.base] * rndr(0.92f, 1.08f));
	} else {
		g.base = rndi(0, CHARM_BASES - 1);
		static const float cv[CHARM_BASES][R_COUNT] = { {5,9,14,20,28}, {10,18,28,40,60}, {20,35,55,80,120}, {10,20,32,48,70}, {3,5,8,12,18} };
		float v = cv[g.base][g.rarity];
		if (g.base == 3) v += g.ilvl * 2.5f * rarity_mult[g.rarity];
		g.power = (u16)v;
	}
	{ static const float ac[R_COUNT] = { 0, 0.3f, 0.7f, 1, 1 }; // affixes from uncommon up; legendaries also carry a power
	  if (rndf() < ac[g.rarity]) g.pad = g.kind == 0 ? rndi(AF_LEECH, AF_SWEEP) : g.kind == 2 ? rndi(AF_THORNS, AF_MEND) : rndi(AF_GILDED, AF_FRENZY);
	  if (g.rarity == R_LEGEND) g.special = (u8)rndi(LP_EMBERS, LP_END - 1); }
	return g;
}
int salvage_value(const Gear* g) { return 5 * (g->rarity + 1) * (g->rarity + 1) + g->ilvl * 2 + g->upg * 10; }
float armor_def(void) { return (S.armor.used ? S.armor.power : 0) + 4 * S.buffLv + 2 * S.boostDef; }
static bool gear_better(const Gear* g) {
	if (g->kind == 0) return !S.weapon.used || g->power > S.weapon.power;
	if (g->kind == 2) return !S.armor.used || g->power > S.armor.power;
	if (!S.charm.used) return true;
	if (S.charm.special) return false;
	return g->rarity > S.charm.rarity || (g->rarity == S.charm.rarity && g->base == S.charm.base && g->power > S.charm.power);
}
static void give_gear(Gear g) {
	char nm[48]; gear_name(&g, nm);
	if (g.rarity >= R_RARE) ach(A_RARE); if (g.rarity >= R_EPIC) ach(A_EPIC); if (g.rarity >= R_LEGEND) ach(A_LEGEND);
	char buf[64]; sprintf(buf, "+ %s%s", nm, gear_better(&g) ? " (upgrade!)" : ""); feed_add(buf, rarity_col[g.rarity]);
	S.newGear = 1;
	if (gear_count() < gear_cap()) for (int i = 0; i < BAG_N; i++) if (!S.bag[i].used) { S.bag[i] = g; return; }
	// gear pouch full: the weakest piece is salvaged for gold
	int lo = 0; for (int i = 1; i < BAG_N; i++) if (S.bag[i].rarity < S.bag[lo].rarity) lo = i;
	if (S.bag[lo].rarity <= g.rarity) { gain_gold(salvage_value(&S.bag[lo])); S.bag[lo] = g; }
	else gain_gold(salvage_value(&g));
	feed_add("Bag full: auto-salvaged", 0xAAAAAA);
}
void equip_bag(int i) {
	if (i < 0 || i >= BAG_N || !S.bag[i].used) return;
	Gear g = S.bag[i];
	Gear* slot = g.kind == 0 ? &S.weapon : (g.kind == 2 ? &S.armor : &S.charm);
	Gear old = *slot; *slot = g;
	if (old.used && !(old.kind == 0 && old.base == 0)) S.bag[i] = old; else memset(&S.bag[i], 0, sizeof(Gear));
	P.maxhp = player_maxhp(); if (S.hp > P.maxhp) S.hp = P.maxhp;
	sfx(SFX_BUY);
	do_save();
}
void salvage_bag(int i) {
	if (i < 0 || i >= BAG_N || !S.bag[i].used) return;
	int v = gain_gold(salvage_value(&S.bag[i]));
	memset(&S.bag[i], 0, sizeof(Gear));
	sfx(SFX_COIN);
	char b[32]; sprintf(b, "Salvaged +%dg", v); feed_add(b, 0xFFD23F);
}

// every coin goes through the purse: past its limit, gold is left behind
static float purseMsgT;
static int gain_gold(int g) {
	int room = gold_cap() - S.gold; if (room < 0) room = 0;
	int take = g < room ? g : room;
	S.gold += take; S.sGoldTotal += take;
	if (take < g) { hudCoinFullT = 1.6f; if (purseMsgT <= 0) { feed_add("Purse full! Level up to carry more.", 0xFFB04A); purseMsgT = 4; } }
	return take;
}
static void add_gold(int g, V3 at) {
	int t = gain_gold(g);
	char b[24]; if (t > 0) sprintf(b, "+%dg", t); else strcpy(b, "PURSE FULL");
	ftext(at, b, t > 0 ? 0xFFD23F : 0xFF9A4A, 1);
}
int lvlPickSel;
void perk_pick(int k) {
	if (S.perkPicks <= 0 || k < 0 || k > 2 || perkOffer[k] < 0) return;
	int p = perkOffer[k]; S.perks |= 1 << p; S.perkPicks--;
	char b[48]; sprintf(b, "%s %s", pk_d1[p], pk_d2[p]); toast(pk_name[p], b, 0xFFB04A, 2);
	sfx(SFX_LOOT_EPIC); burst(v3add(P.p, v3(0, 1, 0)), 40, 0xFFB04A, 6, 9, 1.2f, 0.15f, 1.0f);
	perkOffer[0] = -1; perkSel = 0; do_save();
}
static void perk_roll(void) { // three perks you don't have yet
	int pool[PK_COUNT], n = 0; for (int i = 0; i < PK_COUNT; i++) if (!has_pk(i)) pool[n++] = i;
	for (int k = 0; k < 3; k++) { if (n == 0) { perkOffer[k] = -1; continue; } int r = rndi(0, n - 1); perkOffer[k] = pool[r]; pool[r] = pool[--n]; }
}
void level_pick(int k) {
	if (S.lvlPicks <= 0) return;
	if (k == 0) { S.fortuneLv++; toast("FORTUNE", "+10% gold from every foe", 0xFFD23F, 0); }
	else if (k == 1) { S.packPts++; toast("PACK POINT", "Spend it on a pouch in the Bag tab", 0x9FE0FF, 0); }
	else if (k == 3) { S.staLv++; P.sta = sta_max(); toast("ENDURANCE", "+20 stamina, faster recovery", 0x9CFF8A, 0); }
	else { S.buffLv++; P.maxhp = player_maxhp(); S.hp += 15; if (S.hp > P.maxhp) S.hp = P.maxhp; toast("HARDIER", "+15 max HP, +4 defence, +3% damage", 0xFF7A8A, 0); }
	S.lvlPicks--;
	sfx(SFX_LOOT_RARE); burst(v3add(P.p, v3(0, 1, 0)), 30, k == 0 ? 0xFFD23F : k == 1 ? 0x9FE0FF : 0xFF7A8A, 5, 8, 1.0f, 0.14f, 0.9f);
	do_save();
}
static void add_xp(int x) {
	if (S.lvl >= LVL_CAP) return;
	S.xp += x;
	while (S.lvl < LVL_CAP && S.xp >= xp_next(S.lvl)) {
		S.xp -= xp_next(S.lvl); S.lvl++;
		P.maxhp = player_maxhp(); S.hp = P.maxhp;
		levelFlashT = 2.5f; gfx_set_flash(0.85f); shake = 0.35f;
		if (S.lvlPicks < 99) S.lvlPicks++; lvlPickSel = 0;
		if (S.lvl % 3 == 0 && S.perks != (1 << PK_COUNT) - 1) S.perkPicks++; // every third level: a new tool
		char b[40]; sprintf(b, "You are now level %d", S.lvl);
		toast("LEVEL UP!", b, 0x7CF0FF, 3);
		sfx(SFX_LEVEL);
		for (int i = 0; i < 40; i++) { float a = TAU * i / 40; spawn_part(v3add(P.p, v3(cosf(a)*0.8f, 0.2f, sinf(a)*0.8f)), v3(cosf(a)*2, rndr(4, 9), sinf(a)*2), 1.4f, 0.13f, i & 1 ? 0x7CF0FF : 0xFFFFFF, 2, 0.9f, MESH_OCTA); }
	}
}
static void give_item(int it, int n, bool quiet) {
	IC(it) += n;
	// item quests count only what you pick up, craft or buy after taking them
	for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_ACTIVE && questdefs[q].type == QT_FORAGE && questdefs[q].target == it && QP(q) < 999) QP(q) += n;
	if (S.mq < MQ_COUNT && S.mqState == 1 && mainq[S.mq].type == MQT_ITEM && mainq[S.mq].target == it && S.mqProg < 999) S.mqProg += n;
	if (!quiet) { char b[48]; sprintf(b, "+%d %s", n, n > 1 ? itemd(it)->plural : itemd(it)->name); feed_add(b, itemd(it)->col); }
}

// ------------------------------------------------------------ hud fly-ups
static void hud_fly(int kind, int amount, int n) {
	for (int k = 0; k < n; k++) {
		HudFly* f = NULL;
		for (int i = 0; i < MAX_HFLY; i++) if (!hfly[i].on) { f = &hfly[i]; break; }
		if (!f) { if (kind == 0) add_xp(amount); else gain_gold(amount); return; } // no free slot: pay out at once
		memset(f, 0, sizeof *f);
		f->on = true; f->kind = kind; f->amount = k == 0 ? amount : 0;
		f->t = -0.06f * k; f->dur = 0.55f + rndf() * 0.2f;
		f->cx = rndr(-60, 60); f->cy = rndr(-50, -20); // curve offset
	}
}
static void update_hud_fly(float dt) {
	if (hudXpFlash > 0) hudXpFlash -= dt * 2.2f;
	if (hudCoinPulse > 0) hudCoinPulse -= dt * 2.2f;
	if (hudStaFlash > 0) hudStaFlash -= dt * 2; if (tiredMsgT > 0) tiredMsgT -= dt;
	if (hudCoinFullT > 0) hudCoinFullT -= dt; if (hudBagFullT > 0) hudBagFullT -= dt; if (purseMsgT > 0) purseMsgT -= dt;
	for (int i = 0; i < MAX_HFLY; i++) {
		HudFly* f = &hfly[i]; if (!f->on) continue;
		f->t += dt;
		if (f->t >= f->dur) {
			f->on = false;
			if (f->kind == 0) { if (f->amount) add_xp(f->amount); hudXpFlash = 1; sfx_pitch(SFX_BLIP, 1.6f); }
			else { gain_gold(f->amount); hudCoinPulse = 1; }
		}
	}
}

// ------------------------------------------------------------ drops
static Drop* new_drop(V3 p) {
	for (int i = 0; i < MAX_DROPS; i++) if (!drops[i].on) { memset(&drops[i], 0, sizeof(Drop)); drops[i].on = true; drops[i].p = p; return &drops[i]; }
	return NULL;
}
static void drop_coins(V3 p, int total, int pieces) {
	if (pieces < 1) pieces = 1;
	for (int i = 0; i < pieces; i++) {
		Drop* d = new_drop(v3add(p, v3(0, 0.6f, 0))); if (!d) { add_gold(total, p); return; }
		d->kind = 0; d->amount = total / pieces + (i < total % pieces ? 1 : 0);
		if (d->amount <= 0) { d->on = false; continue; }
		float a = rndf()*TAU, s = rndr(1.5f, 4);
		d->v = v3(cosf(a)*s, rndr(5, 9), sinf(a)*s);
	}
}
static void drop_xp(V3 p, int total) {
	if (total < 1) total = 1;
	int pieces = total < 4 ? 1 : (total < 20 ? 2 : (total < 60 ? 3 : 6));
	for (int i = 0; i < pieces; i++) {
		Drop* d = new_drop(v3add(p, v3(0, 0.6f, 0))); if (!d) { add_xp(total); return; }
		d->kind = 3; d->amount = total / pieces + (i < total % pieces ? 1 : 0); d->ox = p.x; d->oz = p.z;
		if (d->amount <= 0) { d->on = false; continue; }
		float a = rndf()*TAU, sp = rndr(3.8f, 6.0f); // flung well clear of the body
		d->v = v3(cosf(a)*sp, rndr(8, 11), sinf(a)*sp);
	}
}
static void drop_item(V3 p, int it) {
	Drop* d = new_drop(v3add(p, v3(0, 0.6f, 0))); if (!d) { give_item(it, 1, false); return; }
	d->kind = 1; d->item = it; float a = rndf()*TAU; d->v = v3(cosf(a)*2, 7, sinf(a)*2);
}
static void drop_gear(V3 p, Gear g) {
	Drop* d = new_drop(v3add(p, v3(0, 0.8f, 0))); if (!d) { give_gear(g); return; }
	d->kind = 2; d->g = g; float a = rndf()*TAU; d->v = v3(cosf(a)*2.5f, 9, sinf(a)*2.5f);
	if (g.rarity >= R_EPIC) sfx(SFX_LOOT_EPIC); else if (g.rarity >= R_RARE) sfx(SFX_LOOT_RARE);
}

// boss loot explosions: gear shoots out one piece at a time, each with its own ping, rarest last
typedef struct { float t; V3 p; Gear g; } LootQ;
static LootQ lootQ[16]; static int nlootQ;
static void loot_fountain(V3 at, Gear g) {
	if (nlootQ >= 16) { drop_gear(at, g); return; }
	float t = 0.25f + nlootQ * 0.22f; lootQ[nlootQ].t = t; lootQ[nlootQ].p = at; lootQ[nlootQ].g = g; nlootQ++;
	for (int i = nlootQ - 1; i > 0 && lootQ[i].g.rarity < lootQ[i - 1].g.rarity; i--) { Gear tmp = lootQ[i].g; lootQ[i].g = lootQ[i - 1].g; lootQ[i - 1].g = tmp; }
}
static void update_loot_fountain(float dt) {
	for (int i = 0; i < nlootQ; i++) {
		lootQ[i].t -= dt; if (lootQ[i].t > 0) continue;
		Drop* d = new_drop(v3add(lootQ[i].p, v3(0, 1.0f, 0)));
		if (!d) give_gear(lootQ[i].g); else { d->kind = 2; d->g = lootQ[i].g; float a = rndf() * TAU, sp = rndr(3, 5.5f); d->v = v3(cosf(a) * sp, rndr(11, 14), sinf(a) * sp); }
		u32 c = rarity_col[lootQ[i].g.rarity]; burst(v3add(lootQ[i].p, v3(0, 1.2f, 0)), 14, c, 4, 10, 0.6f, 0.12f, 1.0f);
		if (lootQ[i].g.rarity >= R_EPIC) { sfx(SFX_LOOT_EPIC); shake = 0.25f; } else if (lootQ[i].g.rarity >= R_RARE) sfx(SFX_LOOT_RARE); else sfx_pitch(SFX_COIN, 0.8f + i * 0.1f);
		lootQ[i] = lootQ[--nlootQ]; i--;
	}
}
// ------------------------------------------------------------ quests
bool quest_ready(int q) {
	const QuestDef* d = &questdefs[q];
	if (QS(q) != QS_ACTIVE) return false;
	switch (d->type) {
	case QT_FORAGE: return quest_have(q) >= d->count && (!d->nightOnly || night_now());
	case QT_KILL: return QP(q) >= d->count;
	case QT_DELIVER: return IC(IT_PIE) >= 1;
	case QT_BOSS: return QP(q) >= 1;
	case QT_KITTEN: return S.kittens == 7;
	case QT_LANTERN: return IC(IT_SHARD) >= 5;
	case QT_TOME: case QT_BUYTONIC: case QT_CRAFTTONIC: case QT_EVENT: case QT_PORTAL: return QP(q) >= d->count;
	}
	return false;
}
// you meet each islander through the story; until then they have nothing for you
bool npc_met(int npc) { return S.mq > npc_meet_ch[npc]; }
// ------------------------------------------------------------ element seals
// each outer zone is walled off by its own element; the element it fears breaks the seal (the last zone's boss blade is the key)
const char* seal_name[Z_COUNT] = { "", "", "ice wall", "fire ward", "thorn wall", "storm reeds" };
static const char* seal_verb[Z_COUNT] = { "", "", "Melt", "Snuff out", "Shock apart", "Rot away" };
static const s8 seal_npc[Z_COUNT] = { -1, -1, NPC_GUS, NPC_RUST, NPC_FERN, NPC_ODESSA };
bool zone_open(int z) { return z <= Z_MEADOW || (S.seals & (1 << z)); }
int seal_key(int zone) { return elem_weak[zone_elem[zone]]; }
int near_seal(void) {
	int best = -1; float bd = 2.2f;
	for (int i = 0; i < nseal; i++) {
		if (zone_open(sealpts[i].zone)) continue;
		float d = dist2d(P.p.x, P.p.z, sealpts[i].x, sealpts[i].z); if (d < bd) { bd = d; best = i; }
	}
	return best;
}
static bool owns_elem_weapon(int el) {
	if (S.weapon.used && S.weapon.elem == el) return true;
	for (int i = 0; i < BAG_N; i++) if (S.bag[i].used && S.bag[i].kind == 0 && S.bag[i].elem == el) return true;
	return false;
}
// 0 can't, 1 right element equipped, 2 key is in the bag (equip it), 3 no key anywhere but the story is here: hack through
static int seal_state(int z) {
	int k = seal_key(z);
	if (S.weapon.used && S.weapon.elem == k) return 1;
	if (owns_elem_weapon(k)) return 2;
	if (S.mq >= npc_meet_ch[seal_npc[z]]) return 3;
	return 0;
}
static void refresh_quests(void);
static void break_seal(int z) {
	S.seals |= 1 << z;
	u32 c = elem_col[zone_elem[z]], kc = elem_col[seal_key(z)];
	for (int i = 0; i < nseal; i++) if (sealpts[i].zone == z && dist2d(P.p.x, P.p.z, sealpts[i].x, sealpts[i].z) < 26) {
		V3 p = v3(sealpts[i].x, sealpts[i].y + 0.8f, sealpts[i].z);
		burst(p, 3, c, 3, 4, 0.8f, 0.14f, 0.8f); burst(p, 2, kc, 2, 5, 0.9f, 0.12f, 1.0f);
	}
	shake = 0.35f; sfx(SFX_LEVEL); add_xp(25);
	char sub[64]; sprintf(sub, "%s is open", zone_names[z]);
	toast("SEAL BROKEN", sub, kc, 0);
	refresh_quests(); do_save();
}
static bool quest_zones_ok(int q) { // quests that send you somewhere sealed wait for the seal
	switch (q) {
	case Q_B1: return zone_open(Z_SWAMP);
	case Q_B2: return zone_open(Z_RUINS);
	case Q_AP2: return zone_open(Z_FOREST);
	case Q_FG2: case Q_AP1: return zone_open(Z_BEACH);
	case Q_T0: return zone_open(Z_BEACH) && zone_open(Z_FOREST) && zone_open(Z_SWAMP);
	}
	return true;
}
static bool quest_people_met(int q) { const QuestDef* d = &questdefs[q]; return npc_met(d->giver) && (d->turnin < 0 || npc_met(d->turnin)); }
int quest_have(int q) { int h = QP(q), c = IC(questdefs[q].target); return h < c ? h : c; }
static void refresh_quests(void) {
	for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_LOCKED) {
		s8 r = questdefs[q].req;
		if ((r < 0 || QS(r) == QS_DONE) && quest_people_met(q) && quest_zones_ok(q)) QS(q) = QS_AVAIL;
	}
	// quests whose prerequisite moved (older saves): lock them again until it's done
	for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_AVAIL) {
		s8 r = questdefs[q].req;
		if ((r >= 0 && QS(r) != QS_DONE) || !quest_people_met(q) || !quest_zones_ok(q)) QS(q) = QS_LOCKED;
	}
}
// ------------------------------------------------------------ main story
bool mq_active(void) { return S.mq < MQ_COUNT; }
bool mq_items_ok(void) {
	if (S.mq >= MQ_COUNT || S.mqState != 1) return false;
	const MainQuest* m = &mainq[S.mq];
	if (m->type == MQT_ITEM) return S.mqProg >= m->count && IC(m->target) >= m->count;
	if (m->type == MQT_QUEST) return QS(m->target) == QS_DONE;
	if (m->type == MQT_TALK) return false; // done the moment you talk to them
	return S.mqProg >= m->count;
}
// who you report to for the current chapter
int mq_turnin(void) { const MainQuest* m = &mainq[S.mq]; return S.mqState == 1 && m->type == MQT_TALK ? m->target : m->giver; }
bool mq_ready(void) { return mq_items_ok() && (!mainq[S.mq].night || night_now()); }
void mq_progress_text(char* buf) {
	if (S.mq >= MQ_COUNT) { strcpy(buf, "The story is complete... for now."); return; }
	const MainQuest* m = &mainq[S.mq];
	if (S.mqState == 0) { char t[64]; sprintf(t, "Talk to %s", npcdefs[m->giver].name); hl(t, buf, 120); return; }
	if (mq_ready()) { char t[64]; sprintf(t, "Return to %s!", npcdefs[m->giver].name); hl(t, buf, 120); return; }
	if (m->type == MQT_TALK) { char t[64]; sprintf(t, "Meet %s", npcdefs[m->target].name); hl(t, buf, 120); return; }
	if (m->type == MQT_QUEST) { char t[64]; sprintf(t, "Help %s with their quests", npcdefs[m->giver].name); hl(t, buf, 120); return; }
	if (mq_items_ok()) { char t[64]; sprintf(t, "Wait for nightfall " IS_MOON " then see %s", npcdefs[m->giver].name); hl(t, buf, 120); return; }
	if (m->type == MQT_KILL) { char t[96]; sprintf(t, "%d/%d %s", S.mqProg > m->count ? m->count : S.mqProg, m->count, fam_plural[m->target]); hl(t, buf, 120); return; }
	int h = S.mqProg < IC(m->target) ? S.mqProg : IC(m->target); if (h > m->count) h = m->count;
	bool craftable = false; for (int r = 0; r < RECIPE_COUNT; r++) if (recipes[r].out == CR_ITEM && recipes[r].arg == m->target) craftable = true;
	char t[96];
	int qd = queued_count(m->target);
	if (craftable && qd > 0 && h < m->count) { const CraftJob* j = &S.jobs[0]; sprintf(t, "Crafting %s... %d:%02d", itemd(m->target)->name, (int)j->left / 60, (int)j->left % 60); }
	else sprintf(t, "%s %d/%d %s", craftable ? "Craft" : "Gather", h, m->count, m->count > 1 ? itemd(m->target)->plural : itemd(m->target)->name);
	hl(t, buf, 120);
}
// one quest per person: someone with a quest on the go has nothing new until it's handed in
bool giver_busy(int npc) { for (int q = 0; q < Q_COUNT; q++) if (questdefs[q].giver == npc && QS(q) == QS_ACTIVE) return true; return false; }
int npc_marker(int npc) {
	if (npc == NPC_TILLY && S.rumbleSeen == 1) return 4;
	if (S.mq < MQ_COUNT && mainq[S.mq].giver == npc) {
		if (S.mqState == 0) return 4;
		if (mq_ready()) return 5;
	}
	if (S.mq < MQ_COUNT && S.mqState == 1 && mainq[S.mq].type == MQT_TALK && mainq[S.mq].target == npc) return 5;
	if (!npc_met(npc)) return 0;
	if (npc == NPC_BOARD) return S.bActive ? (bounty_ready() ? 2 : 3) : 1;
	for (int q = 0; q < Q_COUNT; q++) {
		int tin = questdefs[q].turnin >= 0 ? questdefs[q].turnin : questdefs[q].giver;
		if (tin == npc && quest_ready(q)) return 2;
	}
	if (!giver_busy(npc)) for (int q = 0; q < Q_COUNT; q++) if (questdefs[q].giver == npc && QS(q) == QS_AVAIL) return 1;
	for (int q = 0; q < Q_COUNT; q++) if (questdefs[q].giver == npc && QS(q) == QS_ACTIVE) return 3;
	if (S.mq < MQ_COUNT && mainq[S.mq].giver == npc) return 6;
	return 0;
}
const char* quest_progress_text(int q, char* buf) {
	const QuestDef* d = &questdefs[q];
	switch (d->type) {
	case QT_FORAGE: { int h = quest_have(q); if (h > d->count) h = d->count; sprintf(buf, "%d/%d %s", h, d->count, d->count > 1 ? itemd(d->target)->plural : itemd(d->target)->name);
		if (h >= d->count && d->nightOnly && !night_now()) strcpy(buf, "Wait for nightfall " IS_MOON); break; }
	case QT_KILL: sprintf(buf, "%d/%d %s", QP(q) > d->count ? d->count : QP(q), d->count, fam_plural[d->target]); break;
	case QT_DELIVER: sprintf(buf, "Bring the pie to %s", npcdefs[d->turnin].name); break;
	case QT_BOSS: sprintf(buf, QP(q) ? "Defeated!" : "Defeat %s", endefs[d->target].name); break;
	case QT_KITTEN: { int k = (S.kittens&1) + ((S.kittens>>1)&1) + ((S.kittens>>2)&1); sprintf(buf, "%d/3 kittens found", k); break; }
	case QT_LANTERN: sprintf(buf, "%d/5 Lantern Shards", IC(IT_SHARD) > 5 ? 5 : IC(IT_SHARD)); break;
	case QT_TOME: strcpy(buf, "Buy an XP Tome from Bram"); break;
	case QT_BUYTONIC: strcpy(buf, "Buy a Healing Tonic from Bram"); break;
	case QT_EVENT: strcpy(buf, EV.on && EV.type == EVT_HORDE ? "A surge is on: break it!" : "Break a Monster Surge (out in the wilds)"); break;
	case QT_PORTAL: sprintf(buf, EV.on && EV.type == EVT_PORTAL ? "A portal is open: grab the keys!" : "Close a portal (watch the wilds)"); break;
	case QT_CRAFTTONIC: strcpy(buf, IC(IT_BERRY) >= 2 && IC(IT_SUNPETAL) >= 3 ? "Craft a Healing Tonic (Craft tab)" : "Gather 2 Moonberries + 3 Sunpetals"); break;
	}
	if (quest_ready(q)) { int tin = d->turnin >= 0 ? d->turnin : d->giver; sprintf(buf, "Return to %s!", npcdefs[tin].name); }
	{ char t[160]; strcpy(t, buf); hl(t, buf, 120); }
	return buf;
}

static void dlg_open(int npc, const char* text, int action, int arg) {
	memset(&D, 0, sizeof D);
	D.on = true; D.npc = npc; D.action = action; D.arg = arg;
	const char* p = text; int n = 0;
	while (*p && n < 10) {
		const char* e = strchr(p, '|'); int len = e ? (int)(e - p) : (int)strlen(p);
		if (len > 219) len = 219;
		const char* q = p;
		if (*q == '@') { const char* c = memchr(q, ':', len); if (c) { int sl = (int)(c - q - 1); if (sl > 15) sl = 15; memcpy(D.spk[n], q + 1, sl); D.spk[n][sl] = 0; len -= (int)(c + 1 - q); q = c + 1; } }
		char raw[240]; memcpy(raw, q, len); raw[len] = 0;
		hl(raw, D.pages[n], 318); n++;
		if (!e) break; p = e + 1;
	}
	D.n = n; D.cur = 0; D.chars = 0;
	sfx(SFX_BLIP);
}

static void complete_quest(int q) {
	const QuestDef* d = &questdefs[q];
	if (d->type == QT_FORAGE) IC(d->target) -= d->count;
	if (d->type == QT_DELIVER) IC(IT_PIE) -= 1;
	if (d->type == QT_LANTERN) { IC(IT_SHARD) -= 5; S.lantern = 1; endingT = 0.001f; }
	QS(q) = QS_DONE; S.sQuests++;
	sfx(SFX_QUEST);
	toast("QUEST COMPLETE", d->title, 0x7CF07C, 0);
	add_gold(d->gold, v3add(P.p, v3(0, 2, 0)));
	burst(v3add(P.p, v3(0, 1, 0)), 30, 0xFFD23F, 5, 9, 1.2f, 0.15f, 0.8f);
	add_xp((int)(d->xp * 0.2f + 0.5f));
	if (d->rItem >= 0) give_item(d->rItem, d->rCount, false);
	if (d->rGear >= 0) {
		Gear g;
		if (q == Q_T0) { memset(&g, 0, sizeof g); g.used = 1; g.kind = 1; g.base = 1; g.rarity = R_LEGEND; g.ilvl = 10; g.special = 1; g.power = 60; }
		else { int lv = S.lvl + 1; g = gen_gear(d->rGearKind == 1 ? 1 : 0, d->rGear, lv); if (d->rElem && g.kind == 0) g.elem = d->rElem; }
		drop_gear(v3add(P.p, v3(0, 0.5f, 0)), g);
	}
	if (S.tracked == q) { S.tracked = -1; if (!guideBounty) guideOn = false; }
	refresh_quests();
	// the story chapter waiting on this quest wraps up in the same conversation
	if (q != Q_E3 && S.mq < MQ_COUNT && S.mqState == 1 && mainq[S.mq].type == MQT_QUEST && mainq[S.mq].target == q) {
		int tin = d->turnin >= 0 ? d->turnin : d->giver;
		if (mainq[S.mq].giver == tin) { dlg_open(tin, mainq[S.mq].done, ACT_MQ_COMPLETE, S.mq); S.tracked = TRACK_MAIN; guideOn = true; }
		else { S.tracked = TRACK_MAIN; guideOn = true; }
	}
	do_save();
}

static void crafter_xp(int x);
static void update_crafting(float dt);
static void mq_complete(void) {
	const MainQuest* m = &mainq[S.mq];
	int who = mq_turnin();
	if (m->type == MQT_ITEM) IC(m->target) -= m->count;
	add_gold(m->gold, v3add(P.p, v3(0, 2, 0)));
	add_xp(tome_xp(0));
	crafter_xp(m->cxp);
	sfx(SFX_QUEST); sfx(SFX_LOOT_RARE);
	toast("STORY PROGRESS", m->title, 0xC79BFF, 2);
	burst(v3add(P.p, v3(0, 1, 0)), 36, 0xC79BFF, 5, 9, 1.3f, 0.15f, 1.0f);
	S.mq++; S.mqState = 0; S.mqProg = 0;
	refresh_quests(); // whoever you just met now has quests
	if (S.mq < MQ_COUNT && mainq[S.mq].giver == who) { dlg_open(who, mainq[S.mq].intro, ACT_MQ_ACCEPT, S.mq); do_save(); return; } // they carry the story straight on
	if (S.mq >= MQ_COUNT) {
		toast("THE END (FOR NOW)", STORY_TITLE, 0xFFD86A, 1);
		if (S.tracked == TRACK_MAIN) { S.tracked = -1; guideOn = false; }
		do_save();
		gacha_start(0, R_RARE);
		return;
	}
	do_save();
}

// credit 'do this once' tutorial quests
static void quest_credit(int type) {
	for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_ACTIVE && questdefs[q].type == type && QP(q) < questdefs[q].count) { QP(q)++; if (QP(q) == questdefs[q].count) { toast("OBJECTIVE DONE", questdefs[q].title, 0x7CF07C, 0); sfx(SFX_QUEST); } }
}

// ------------------------------------------------------------ buildings
const BuildingDef blddefs[BLD_COUNT] = {
	{ "Old Forge", 8.5f, -8.0f, -PI*0.25f, ST_FORGE },
	{ "Apothecary", -8.5f, -8.0f, PI*0.25f, ST_APOTH },
};
int bld_stage(int b) {
	if (b == 0) return (QS(Q_FG1) == QS_DONE) + (QS(Q_FG2) == QS_DONE);
	return (QS(Q_AP1) == QS_DONE) + (QS(Q_AP2) == QS_DONE);
}
const char* station_name(int st) { return st == ST_FORGE ? "the Forge" : st == ST_APOTH ? "the Apothecary" : ""; }
void bld_door(int b, float* x, float* z) { *x = blddefs[b].x + sinf(blddefs[b].yaw) * 2.6f; *z = blddefs[b].z + cosf(blddefs[b].yaw) * 2.6f; }
static int near_building(void) {
	for (int b = 0; b < BLD_COUNT; b++) { float x, z; bld_door(b, &x, &z); if (dist2d(P.p.x, P.p.z, x, z) < 1.8f) return b; }
	return -1;
}
// a station-made item handed over at its building
static void station_deliver(int r) {
	const Recipe* c = &recipes[r];
	if (c->out == CR_INFUSE) {
		Gear* g = c->amount == 1 ? &S.armor : &S.weapon;
		char t[48];
		if (!g->used) { sprintf(t, "No %s equipped: kept for later", c->amount ? "armour" : "weapon"); feed_add(t, 0xFF9A7A); return; }
		g->elem = c->arg;
		sprintf(t, "%s %s", c->amount ? "Armour warded:" : "Weapon infused:", elem_name[c->arg]);
		toast(c->amount ? "WARD APPLIED" : "INFUSED!", t, elem_col[c->arg], 0);
		burst(v3add(P.p, v3(0, 1.2f, 0)), 28, elem_col[c->arg], 4, 7, 1.0f, 0.13f, 1.0f);
		sfx(SFX_LOOT_RARE);
	} else if (c->out == CR_ITEM) { give_item(c->arg, c->amount, false); if (c->arg == IT_TONIC) quest_credit(QT_CRAFTTONIC); sfx(SFX_BUY); }
}
static void building_use(int b) {
	static char buf[600];
	int st = bld_stage(b), slot = blddefs[b].station - 1;
	if (S.holdN[slot]) {
		int n = S.holdN[slot];
		// keep infusions that can't be applied yet (no gear equipped)
		u8 keep[8]; int nk = 0;
		for (int k = 0; k < n; k++) {
			const Recipe* c = &recipes[S.hold[slot][k]];
			if (c->out == CR_INFUSE && !(c->amount ? S.armor.used : S.weapon.used)) { keep[nk++] = S.hold[slot][k]; continue; }
			station_deliver(S.hold[slot][k]);
		}
		memcpy(S.hold[slot], keep, nk); S.holdN[slot] = nk;
		sprintf(buf, "Collected %d item%s from %s.", n - nk, n - nk == 1 ? "" : "s", station_name(blddefs[b].station));
		feed_add(buf, 0x9FFFA0); do_save();
		return;
	}
	if (b == 0) {
		if (st == 0) strcpy(buf, "@Old Forge:(The furnace is cold and choked with ash. A sign reads: 'Back soon. 1987.')|@Old Forge:(Bram the trader might know how to get it going again.)");
		else if (st == 1) strcpy(buf, "@Old Forge:(The furnace glows. Fire and Frost infusions can be made here.)|@Old Forge:(Start one in the Craft tab, then come back to collect it.)|@Old Forge:(The bellows wheeze. Bram has ideas.)");
		else strcpy(buf, "@Old Forge:(The Forge roars. Every infusion and ward can be made here.)|@Old Forge:(Infusions change your weapon's element. Wards protect your armour.)");
	} else {
		if (st == 0) strcpy(buf, "@Apothecary:(Rain drips through a hole in the roof onto dusty bottles.)|@Apothecary:(Pip from the bakery remembers this place.)");
		else if (st == 1) strcpy(buf, "@Apothecary:(Shelves of clean bottles. Tonic Batches can be brewed here.)|@Apothecary:(The empty garden beds look sad. Pip might help.)");
		else strcpy(buf, "@Apothecary:(Herbs everywhere. Tonic Batches and Night Draughts can be brewed here.)");
	}
	dlg_open(NPC_BOARD, buf, ACT_NONE, 0);
}

// ------------------------------------------------------------ bounties
bool bounty_ready(void) {
	if (!S.bActive) return false;
	if (S.bType == 0) return S.bProg >= S.bCount;
	return IC(S.bTarget) >= S.bCount;
}
void bounty_text(char* buf) {
	char t[96];
	if (S.bType == 0) sprintf(t, "Slay %d %s (%d/%d)", S.bCount, fam_plural[S.bTarget], S.bProg > S.bCount ? S.bCount : S.bProg, S.bCount);
	else { int h = IC(S.bTarget); if (h > S.bCount) h = S.bCount; sprintf(t, "Gather %d %s (%d/%d)", S.bCount, itemd(S.bTarget)->plural, h, S.bCount); }
	hl(t, buf, 90);
}
static void bounty_new(void) {
	int zones[6], nz = 0;
	for (int z = 1; z < Z_COUNT; z++) if ((S.zonesVisited & (1 << z)) || z == Z_MEADOW) zones[nz++] = z;
	int z = zones[rndi(0, nz-1)];
	S.bActive = 1; S.bProg = 0;
	if (night_now() && rndf() < 0.55f) { // night-only bounties
		if (rndf() < 0.5f) { S.bType = 0; S.bTarget = FAM_MOTH; S.bCount = rndi(4, 7); }
		else { S.bType = 1; S.bTarget = XI_MOONBLOOM; S.bCount = rndi(2, 4); }
	} else if (rndf() < 0.6f) {
		S.bType = 0; S.bTarget = endefs[zone_enemies[z][rndi(0, 1)]].fam; S.bCount = rndi(6, 12);
	} else {
		static const u8 zitems[Z_COUNT][2] = { {IT_BERRY, IT_BERRY}, {IT_BERRY, IT_SUNPETAL}, {IT_SHELL, IT_DRIFTWOOD}, {IT_CRYSTAL, IT_CORE}, {IT_SILVERLEAF, IT_GLOWCAP}, {IT_BOGLILY, IT_GLOWCAP} };
		S.bType = 1; S.bTarget = zitems[z][rndi(0, 1)]; S.bCount = rndi(4, 8);
	}
	S.bGold = S.bCount * 12 + S.lvl * 12 + 20;
	S.bXp = S.bCount * 10 + S.lvl * 10;
	S.bGear = rndf() < 0.45f;
}

// ------------------------------------------------------------ interaction
static int near_npc(void) {
	int best = -1; float bd = 2.4f;
	for (int i = 0; i < NPC_COUNT; i++) {
		float d = dist2d(P.p.x, P.p.z, npcdefs[i].x, npcdefs[i].z);
		if (i == NPC_BOARD) d -= 0.5f;
		if (d < bd) { bd = d; best = i; }
	}
	return best;
}
static int near_chest(void) {
	for (int i = 0; i < nchests; i++) if (!(S.chestsOpened & (1u << i)) && dist2d(P.p.x, P.p.z, chests[i].x, chests[i].z) < 1.9f) return i;
	return -1;
}
static int near_node(void) {
	int best = -1; float bd = 1.7f;
	for (int i = 0; i < nnodes; i++) {
		Node* n = &nodes[i];
		if (!n->alive) continue;
		if (n->type == ND_KITTEN && (QS(Q_T0) != QS_ACTIVE || (S.kittens & (1 << n->kid)))) continue;
		if (n->type == ND_MOONBLOOM && !night_now()) continue;
		float d = dist2d(P.p.x, P.p.z, n->x, n->z);
		if (d < bd) { bd = d; best = i; }
	}
	return best;
}

static void talk(int npc) {
	static char buf[1200];
	for (int z = 1; z < Z_COUNT; z++) if (depth_npc[z] == npc && (S.depNote & (1 << z)) && !(S.depKey & (1 << z))) { // you read their note in the Depths
		S.depKey |= 1 << z; dlg_open(npc, depth_keytalk[z], ACT_NONE, 0);
		char b[48]; sprintf(b, "%s: the door below will open", depth_key[z]); toast("GOT A KEY", b, 0xFFD23F, 2); sfx(SFX_LOOT_RARE);
		do_save(); return;
	}
	if (npc == NPC_TILLY && S.rumbleSeen == 1) {
		S.rumbleSeen = 2; if (S.tracked == TRACK_RUMBLE) { S.tracked = mq_active() ? TRACK_MAIN : -1; guideOn = S.tracked >= 0; }
		dlg_open(npc, "@Biscuit:Mrrow. Mrrrow mrow. MEW. Mrrrrow!|@Tilly:Biscuit felt it too! Her fur's all on end.|@Tilly:She says that when somebody on the island gets stronger, the island notices. It turns over in its sleep, and the ground shakes.|@Tilly:And then all the wild things out there wake up stronger too. To keep up with you!|@Biscuit:Mrrp.|@Tilly:Not every time you get stronger, though. Only when the ground shakes like that.|@Tilly:The further from town you go, the fiercer they get. So be careful out by the shore, okay?", ACT_NONE, 0);
		do_save(); return;
	}
	if (S.mq < MQ_COUNT && S.mqState == 1 && mainq[S.mq].type == MQT_TALK && mainq[S.mq].target == npc) { dlg_open(npc, mainq[S.mq].done, ACT_MQ_COMPLETE, S.mq); return; }
	if (npc == NPC_BOARD && !npc_met(npc)) { dlg_open(npc, "The board is bare. A few old nails, a curl of string. Nobody's posted anything yet.", ACT_NONE, 0); return; }
	if (npc == NPC_BOARD) {
		if (!S.bActive) { bounty_new(); char b[96]; bounty_text(b); sprintf(buf, "NEW BOUNTY POSTED|%s|Reward: %dg, %d XP%s", b, S.bGold, S.bXp, S.bGear ? " + gear" : ""); dlg_open(npc, buf, ACT_BOUNTY_ACCEPT, 0); }
		else if (bounty_ready()) { dlg_open(npc, "BOUNTY FULFILLED!|The village thanks you. Reward collected.", ACT_BOUNTY_DONE, 0); }
		else { char b[96]; bounty_text(b); sprintf(buf, "Current bounty:|%s", b); dlg_open(npc, buf, ACT_NONE, 0); }
		return;
	}
	bool mqHere = S.mq < MQ_COUNT && mainq[S.mq].giver == npc;
	if (mqHere && S.mqState == 0) { dlg_open(npc, mainq[S.mq].intro, ACT_MQ_ACCEPT, S.mq); return; }
	if (mqHere && mq_ready()) { dlg_open(npc, mainq[S.mq].done, ACT_MQ_COMPLETE, S.mq); return; }

	for (int q = 0; q < Q_COUNT; q++) {
		int tin = questdefs[q].turnin >= 0 ? questdefs[q].turnin : questdefs[q].giver;
		if (tin == npc && quest_ready(q)) { dlg_open(npc, questdefs[q].done, ACT_COMPLETE, q); return; }
	}
	if (!giver_busy(npc)) for (int q = 0; q < Q_COUNT; q++) if (questdefs[q].giver == npc && QS(q) == QS_AVAIL) { dlg_open(npc, questdefs[q].intro, ACT_ACCEPT, q); return; }
	if (npc == NPC_BRAM) { dlg_open(npc, "Have a look at my wares! Tap the bottom screen to buy.|In a hurry? Just press [A] at the end of my cart.", ACT_SHOP, 0); return; }
	if (mqHere) { dlg_open(npc, mainq[S.mq].prog, ACT_NONE, 0); return; }
	for (int q = 0; q < Q_COUNT; q++) if (questdefs[q].giver == npc && QS(q) == QS_ACTIVE) { dlg_open(npc, questdefs[q].prog, ACT_NONE, 0); return; }
	if (!npc_met(npc)) { dlg_open(npc, npcdefs[npc].idle[rndi(0, 2)], ACT_NONE, 0); return; }
	if (npc == NPC_MARI && QS(Q_L5) == QS_DONE) { dlg_open(npc, "@Marigold:I'm staying a while. Somebody has to keep the small lamps lit.|@Biscuit:(Biscuit approves. Probably.)", ACT_NONE, 0); return; }
	dlg_open(npc, npcdefs[npc].idle[rndi(0, 2)], ACT_NONE, 0);
}
static void dlg_finish(void) {
	int a = D.action, arg = D.arg;
	D.on = false;
	P.grace = 1.0f; // a moment of grace after a conversation (no blinking)
	switch (a) {
	case ACT_ACCEPT:
		QS(arg) = QS_ACTIVE; QP(arg) = 0;
		if (!(S.tracked == TRACK_MAIN && mq_active())) S.tracked = arg; // the story keeps the arrow until you pick another quest
		if (questdefs[arg].type == QT_DELIVER) give_item(IT_PIE, 1, false);
		if (arg == Q_EV0 || arg == Q_EV1) event_unlocked(arg == Q_EV1 ? EVT_PORTAL : EVT_HORDE);
		toast("NEW QUEST", questdefs[arg].title, 0x7CC8FF, 0); sfx(SFX_PICK);
		break;
	case ACT_COMPLETE: complete_quest(arg); break;
	case ACT_MQ_ACCEPT: {
		const MainQuest* m = &mainq[arg];
		S.mqState = 1; S.mqProg = 0; S.tracked = TRACK_MAIN; guideOn = true; guideBounty = false;
		if (m->chapter) { strncpy(zoneBanner, m->chapter, 39); zoneBanner[39] = 0; zoneBannerT = 3.6f; zoneBannerCol = 0xC79BFF; }
		toast("MAIN STORY", m->title, 0xC79BFF, 2); sfx(SFX_QUEST);
		if (m->type == MQT_QUEST && QS(m->target) == QS_DONE) { /* already done: hand it straight in next time */ }
		else if (!giver_busy(m->giver)) for (int q = 0; q < Q_COUNT; q++) if (questdefs[q].giver == m->giver && QS(q) == QS_AVAIL) { dlg_open(m->giver, questdefs[q].intro, ACT_ACCEPT, q); break; }
		do_save();
	} break;
	case ACT_MQ_COMPLETE: mq_complete(); break;
	case ACT_SHOP: shopOpen = true; bankMode = false; tab = 0; break;
	case ACT_BOUNTY_ACCEPT: toast("BOUNTY ACCEPTED", "Check the Quests tab", 0xFFB04A, 0); sfx(SFX_PICK); break;
	case ACT_BOUNTY_DONE: {
		if (S.bType == 1) IC(S.bTarget) -= S.bCount;
		add_gold(S.bGold, v3add(P.p, v3(0, 2, 0))); add_xp((int)(S.bXp * 0.15f));
		lootTable = 0;
		if (S.bGear) drop_gear(P.p, gen_gear(-1, R_UNCOMMON, S.lvl));
		S.bActive = 0; S.sBounties++; sfx(SFX_QUEST);
		if (guideBounty) guideOn = false;
		toast("BOUNTY COMPLETE", "Fresh bounties are posted", 0xFFB04A, 0);
		burst(v3add(P.p, v3(0, 1, 0)), 24, 0xFFB04A, 5, 8, 1.0f, 0.14f, 0.8f);
		do_save();
	} break;
	}
}

static void gather(int i) {
	Node* n = &nodes[i];
	V3 at = v3(n->x, n->y + 0.6f, n->z);
	if (n->type == ND_KITTEN) {
		S.kittens |= 1 << n->kid;
		sfx(SFX_MEOW);
		static const char* kn[3] = { "Button", "Pebble", "Socks" };
		char b[48]; sprintf(b, "Found %s!", kn[n->kid]);
		toast("KITTEN FOUND", b, 0xFF9FD0, 0);
		burst(at, 20, 0xFF9FD0, 3, 6, 1.0f, 0.12f, 0.7f);
		return;
	}
	if (n->type != ND_DIG && n->type != ND_KITTEN && node_item[n->type] != 255 && item_full(node_item[n->type])) { hudBagFullT = 1.6f; char b[40]; sprintf(b, "%s POUCH FULL", itemd(node_item[n->type])->name); ftext(v3(n->x, n->y + 1.6f, n->z), b, 0xFF9A4A, 1); sfx(SFX_HURT); return; }
	n->alive = false; n->pop = 0.25f;
	S.sForage++;
	pickComboT = 1.4f; pickCombo = pickCombo < 12 ? pickCombo + 1 : 12;
	if (n->type == ND_DIG) {
		S.sDigs++;
		sfx(SFX_DIG);
		burst(at, 16, 0x8A6A40, 3, 6, 0.8f, 0.14f, 0);
		float r = rndf();
		if (r < 0.45f) drop_coins(at, rndi(8, 20) + S.lvl * 3, rndi(4, 8));
		else if (r < 0.6f) { drop_coins(at, rndi(4, 10), 3); lootTable = 0; drop_gear(at, gen_gear(-1, 0, S.lvl)); }
		else if (r < 0.8f) { drop_coins(at, rndi(10, 24), 5); drop_xp(at, 2 + S.lvl); }
		else { drop_item(at, IT_TONIC); drop_coins(at, rndi(10, 30), 5); }
		n->regrow = rndr(50, 80);
		add_xp(1);
		return;
	}
	int it = node_item[n->type];
	int cnt = 1;
	if (n->type == ND_MOONBLOOM) S.sMoonblooms++;
	if (rndf() * 100 < 10 + charm_val(1) * 0.5f) cnt = 2;
	give_item(it, cnt, true);
	char b[40]; sprintf(b, cnt > 1 ? "+%d %s!" : "+%d %s", cnt, cnt > 1 ? itemd(it)->plural : itemd(it)->name);
	ftext(at, b, itemd(it)->col, 1);
	feed_add(b, itemd(it)->col);
	sfx_pitch(SFX_PICK, powf(2.f, (pickCombo - 1) / 12.f));
	burst(at, 12, itemd(it)->col, 2.5f, 5, 0.7f, 0.12f, 0.6f);
	add_xp(1);
	if (rndf() < 0.15f) drop_coins(at, rndi(1, 4), 1);
	n->regrow = rndr(45, 75);
}

static void open_chest(int i) {
	Chest* c = &chests[i];
	S.chestsOpened |= 1u << i; S.sChests++;
	c->openT = 0.001f;
	sfx(SFX_CHEST);
	V3 at = v3(c->x, c->y + 0.8f, c->z);
	int zl = endefs[zone_enemies[zone_at(c->x, c->z)][0]].lvl;
	drop_coins(at, (c->golden ? 80 : 25) + zl * (c->golden ? 15 : 6), c->golden ? 14 : 7);
	lootTable = 0;
	if (c->golden) drop_gear(at, gen_gear(-1, R_UNCOMMON, zl + 1));
	else if (rndf() < 0.5f) drop_gear(at, gen_gear(-1, 0, zl + 1));
	drop_xp(at, c->golden ? 6 + zl * 2 : 2 + zl);
	if (rndf() < 0.5f) drop_item(at, IT_TONIC);
	burst(at, 26, c->golden ? 0xFFD23F : 0xFFE9A0, 4, 8, 1.0f, 0.13f, 0.9f);
	shake = 0.15f;
	do_save();
}

void use_tonic(void) {
	if (P.deadT > 0) return;
	if (IC(IT_TONIC) <= 0) { sfx(SFX_HURT); feed_add("No Healing Tonics left", 0xFF7A7A); return; }
	if (S.hp >= P.maxhp) { sfx(SFX_BLIP); feed_add("Already at full health", 0xBBBBCC); return; }
	IC(IT_TONIC)--; S.sTonics++;
	float h = P.maxhp * (has_pk(PK_HERBAL) ? 0.8f : 0.5f); S.hp += h; if (S.hp > P.maxhp) S.hp = P.maxhp;
	char b[16]; sprintf(b, "+%d HP", (int)h); ftext(v3add(P.p, v3(0, 2.2f, 0)), b, 0x6BFF8A, 1);
	for (int k = 0; k < 18; k++) spawn_part(v3add(P.p, v3(rndr(-0.6f, 0.6f), rndr(0, 1.6f), rndr(-0.6f, 0.6f))), v3(0, rndr(1.5f, 3), 0), 0.9f, 0.1f, 0x6BFF8A, -1, 0.8f, MESH_OCTA);
	sfx(SFX_PICK);
}
int whetstone_cost(void) { return (int)(100 * powf(S.weapon.upg + 1, 1.45f)); } // v1.26: prices track what you earn, not a purse limit
int tome_xp(int big) { int need = xp_next(S.lvl); return big ? need : (need + 3) / 4; }
int tome_cost(int big) { int c = 40 + 22 * S.lvl + (3 * S.lvl * S.lvl) / 2; return big ? (int)(c * 3.5f) : c; }
int tonic_cost(void) { return 30 + 4 * S.lvl; }
int cache_cost(void) { return 120 + 14 * S.lvl; }
int boost_cost(int n) { return (int)(250 * powf(1 + n, 1.4f)); } // permanent little boosts: dear, and dearer each time
static bool pay(int c) { // in town, the strongbox tops up your purse
	int have = S.gold + (in_town() ? (int)S.bank : 0);
	if (have < c) { sfx(SFX_HURT); feed_add("Not enough gold", 0xFF7A7A); return false; }
	if (S.gold >= c) S.gold -= c; else { S.bank -= c - S.gold; S.gold = 0; }
	return true;
}
// Bram's strongbox: safe from fainting, but capped until you pay for a bigger vault
static void bank_act(int i) {
	if (i == 0) { int room = bank_cap() - (int)S.bank, n = S.gold < room ? S.gold : room; if (n <= 0) { sfx(SFX_HURT); feed_add(room <= 0 ? "Vault full: upgrade it" : "Nothing to deposit", 0xFF7A7A); return; } S.gold -= n; S.bank += n; sfx(SFX_COIN); char b[40]; sprintf(b, "Deposited %dg", n); feed_add(b, 0xFFD23F); }
	else if (i == 1 || i == 2) { int n = i == 1 ? 100 : (int)S.bank; if (n > (int)S.bank) n = S.bank; if (n <= 0) { sfx(SFX_HURT); return; } S.bank -= n; S.gold += n; sfx(SFX_COIN); char b[40]; sprintf(b, "Withdrew %dg", n); feed_add(b, 0xFFD23F); }
	else { int c = vault_cost(); if ((int)(S.gold + S.bank) < c) { sfx(SFX_HURT); feed_add("Not enough gold", 0xFF7A7A); return; } if (S.gold >= c) S.gold -= c; else { S.bank -= c - S.gold; S.gold = 0; } S.bankLv++; char b[40]; sprintf(b, "Vault holds %dg", bank_cap()); toast("VAULT UPGRADED", b, 0xFFD23F, 0); sfx(SFX_BUY); }
	do_save();
}
static void whetstone(void) {
	S.weapon.upg++; S.weapon.power = (u16)(S.weapon.power * 1.1f + 1);
	sfx(SFX_BUY); sfx(SFX_CRIT);
	char nm[48]; gear_name(&S.weapon, nm); toast("WEAPON UPGRADED", nm, 0x9FE0FF, 0);
	burst(v3add(P.p, v3(0, 1, 0)), 16, 0x9FE0FF, 3, 5, 0.8f, 0.1f, 0.9f);
}
// the return stone: home in a flash, and back out to where you were
static void dun_leave(bool cleared);
void return_stone(void) {
	if (bossIdx >= 0 || P.deadT > 0) { sfx(SFX_HURT); feed_add("Not mid-fight!", 0xFF7A7A); return; }
	if (dunOn && DG.kind && DG.rtype == RT_DELVE && DG.haul > 0) toast("HAUL LOST", "The stone can't carry rift treasure", 0xFF7A7A, 0);
	if (dunOn) dun_leave(false); // out of the dungeon first, then home; the stone brings you back to its door
	if (!in_town()) { S.retOn = 1; S.retX = P.p.x; S.retZ = P.p.z; P.p = v3(0, ground_h(0, 5.5f), 5.5f); toast("RETURN STONE", "Home! Use it again to go back.", 0x9FC8FF, 0); }
	else if (S.retOn) { P.p = v3(S.retX, ground_h(S.retX, S.retZ), S.retZ); S.retOn = 0; toast("RETURN STONE", "Back where you left off.", 0x9FC8FF, 0); }
	else { sfx(SFX_HURT); feed_add("Nowhere to return to", 0xFF7A7A); return; }
	{ float nx, nz; world_blocked(P.p.x, P.p.z, 0.4f, &nx, &nz); P.p.x = nx; P.p.z = nz; }
	rp.tx = P.p.x; rp.tz = P.p.z; rp.camx = P.p.x - sinf(camYaw) * 9; rp.camz = P.p.z - cosf(camYaw) * 9;
	for (int i = 0; i < MAX_EN; i++) if (en[i].on && !en[i].boss) en[i].on = false;
	gfx_set_flash(0.8f); sfx(SFX_LOOT_RARE); burst(v3add(P.p, v3(0, 1, 0)), 30, 0x9FC8FF, 4, 7, 1.0f, 0.12f, 1.0f);
	paused = false; do_save();
}
void sell_item(int id) {
	if (item_key(id) || IC(id) <= 0) { sfx(SFX_HURT); return; }
	int n = IC(id) < 5 ? IC(id) : 5;
	IC(id) -= n; int got = gain_gold(n * item_value(id));
	char b[48]; sprintf(b, "Sold %d %s +%dg", n, n > 1 ? itemd(id)->plural : itemd(id)->name, got); feed_add(b, 0xFFD23F); sfx(SFX_COIN);
	do_save();
}
void shop_buy(int i) {
	if (bankMode) { bank_act(i); return; }
	switch (i) {
	case 0: if (item_full(IT_TONIC)) { sfx(SFX_HURT); feed_add("Tonic pouch full", 0xFF9A4A); return; } if (!pay(tonic_cost())) return; give_item(IT_TONIC, 1, true); quest_credit(QT_BUYTONIC); sfx(SFX_BUY); feed_add("+1 Healing Tonic", 0xFF5C7A); break;
	case 1: if (S.weapon.upg >= 10) { sfx(SFX_HURT); return; } if (!pay(whetstone_cost())) return; whetstone(); break;
	case 2: case 3: {
		if (S.lvl >= LVL_CAP) { sfx(SFX_HURT); return; }
		if (!pay(tome_cost(i == 3))) return;
		sfx(SFX_BUY);
		int x = tome_xp(i == 3);
		for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_ACTIVE && questdefs[q].type == QT_TOME && QP(q) < questdefs[q].count) { QP(q)++; toast("OBJECTIVE DONE", questdefs[q].title, 0x7CF07C, 0); }
		char b[24]; sprintf(b, "+%d XP", x); ftext(v3add(P.p, v3(0, 2.2f, 0)), b, 0x7CF0FF, 2);
		for (int k = 0; k < 24; k++) spawn_part(v3add(P.p, v3(rndr(-1, 1), rndr(0, 2), rndr(-1, 1))), v3(0, rndr(1, 3), 0), 1.0f, 0.1f, 0x7CF0FF, -1, 1, MESH_OCTA);
		add_xp(x);
	} break;
	case 7: if (!pay(boost_cost(S.boostHp))) return; S.boostHp++; P.maxhp = player_maxhp(); S.hp += 5; sfx(SFX_BUY); toast("VIGOUR", "+5 max HP for good", 0xFF7A8A, 0); break;
	case 8: if (!pay(boost_cost(S.boostDef))) return; S.boostDef++; sfx(SFX_BUY); toast("IRON SKIN", "+2 defence for good", 0xB0C0D0, 0); break;
	case 9: if (!pay(boost_cost(S.boostSta))) return; S.boostSta++; P.sta = sta_max(); sfx(SFX_BUY); toast("SECOND WIND", "+8 stamina for good", 0x9CFF8A, 0); break;
	case 4: case 5: case 6: {
		if (!pay(cache_cost())) return;
		S.sBoxes++;
		gacha_start(i == 4 ? 0 : (i == 5 ? 2 : 1), R_UNCOMMON);
	} break;
	}
	do_save();
}

// ------------------------------------------------------------ crafting
// Tier 2 recipes take tier 1 items; any you lack are made on the spot from their raw ingredients.
static int lastMissing = -1;
static int bld_of_station(int st) { for (int b = 0; b < BLD_COUNT; b++) if (blddefs[b].station == st) return b; return -1; }
bool recipe_unlocked(int r) {
	const Recipe* c = &recipes[r];
	if (c->station && bld_stage(bld_of_station(c->station)) < c->stage) return false;
	return S.crafterLvl >= c->unlock;
}
static int recipe_for(int id) {
	for (int r = 0; r < RECIPE_COUNT; r++) if (recipes[r].tier == 1 && recipes[r].out == CR_ITEM && recipes[r].arg == id && recipes[r].amount == 1) return r;
	return -1;
}
static bool take(u16* inv, int id, int n, int depth, int* subcrafts) {
	int have = inv[id], use = have < n ? have : n;
	inv[id] -= use; n -= use;
	if (n <= 0) return true;
	int r = depth == 0 ? recipe_for(id) : -1;
	if (r < 0) { lastMissing = id; return false; }
	const Recipe* c = &recipes[r];
	for (int k = 0; k < n; k++) {
		if (!take(inv, c->inA, c->nA, depth + 1, subcrafts) || !take(inv, c->inB, c->nB, depth + 1, subcrafts)) return false;
		if (subcrafts) (*subcrafts)++;
	}
	return true;
}
static bool simulate(int r, u16* inv, int* subcrafts) {
	for (int i = 0; i < ALL_ITEMS; i++) inv[i] = IC(i);
	const Recipe* c = &recipes[r];
	lastMissing = -1;
	if (subcrafts) *subcrafts = 0;
	if (c->tier >= 2) return take(inv, c->inA, c->nA, 0, subcrafts) && take(inv, c->inB, c->nB, 0, subcrafts);
	return take(inv, c->inA, c->nA, 1, NULL) && take(inv, c->inB, c->nB, 1, NULL);
}
bool can_craft(int r) {
	if (!recipe_unlocked(r)) return false;
	if (recipes[r].out == CR_WHET && S.weapon.upg >= 10) return false;
	static u16 inv[ALL_ITEMS];
	return simulate(r, inv, NULL);
}
bool recipe_uses_raw(int r) {
	const Recipe* c = &recipes[r];
	return c->tier >= 2 && (IC(c->inA) < c->nA || IC(c->inB) < c->nB);
}
int recipe_quest_mark(int r) {
	const Recipe* c = &recipes[r];
	if (c->out != CR_ITEM) return 0;
	int id = c->arg;
	int have = IC(id) + queued_count(id);
	if (S.mq < MQ_COUNT && S.mqState == 1 && mainq[S.mq].type == MQT_ITEM && mainq[S.mq].target == id && have < mainq[S.mq].count) return 2;
	for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_ACTIVE && questdefs[q].type == QT_FORAGE && questdefs[q].target == id && have < questdefs[q].count) return 1;
	if (S.bActive && S.bType == 1 && S.bTarget == id && !bounty_ready()) return 1;
	if (c->tier == 1) for (int k = 0; k < RECIPE_COUNT; k++) if (recipes[k].tier >= 2 && (recipes[k].inA == id || recipes[k].inB == id) && recipe_quest_mark(k) == 2) return 3;
	return 0;
}
// the first raw ingredient you're missing for recipe r (for the guide arrow), or -1
static int recipe_missing(int r) { static u16 inv[ALL_ITEMS]; if (simulate(r, inv, NULL)) return -1; return lastMissing; }
static void crafter_xp(int x) {
	if (S.crafterLvl < 1) S.crafterLvl = 1;
	if (S.crafterLvl >= CRAFTER_MAX) return;
	S.crafterXp += x;
	while (S.crafterLvl < CRAFTER_MAX && S.crafterXp >= crafter_xp_need[S.crafterLvl]) {
		S.crafterXp -= crafter_xp_need[S.crafterLvl]; S.crafterLvl++;
		int nu = 0; for (int r = 0; r < RECIPE_COUNT; r++) if (recipes[r].unlock == S.crafterLvl) nu++;
		char b[48]; sprintf(b, "Crafting level %d: %d new recipe%s", S.crafterLvl, nu, nu == 1 ? "" : "s");
		toast("CRAFTER LEVEL UP!", b, 0xFFB86A, 3);
		sfx(SFX_LEVEL);
		burst(v3add(P.p, v3(0, 1.2f, 0)), 30, 0xFFB86A, 4, 8, 1.2f, 0.13f, 0.9f);
	}
	if (S.crafterLvl >= CRAFTER_MAX) S.crafterXp = 0;
}
int craft_jobs(void) { int n = 0; for (int i = 0; i < CRAFT_SLOTS; i++) if (S.jobs[i].state) n++; return n; }
int queued_count(int item) {
	int n = 0;
	for (int i = 0; i < CRAFT_SLOTS; i++) if (S.jobs[i].state && recipes[S.jobs[i].r].out == CR_ITEM && recipes[S.jobs[i].r].arg == item) n += recipes[S.jobs[i].r].amount;
	return n;
}
// crafts take 1-5 minutes; higher crafter levels work faster
static float recipe_time(int r, int sub) {
	const Recipe* c = &recipes[r];
	float t = 60;
	switch (c->out) {
	case CR_ITEM: t = c->tier >= 2 ? 180 : 60; break;
	case CR_XP: t = 60 + c->amount * 0.15f; break;
	case CR_WHET: t = 120; break;
	case CR_CACHE: t = 150; break;
	}
	t += sub * 60;
	t *= 1.0f - 0.07f * (S.crafterLvl - 1);
	return clampf(t, 60, 300);
}
void craft(int r) {
	if (r < 0 || r >= RECIPE_COUNT) return;
	const Recipe* c = &recipes[r];
	if (!recipe_unlocked(r)) { sfx(SFX_HURT); char b[40]; sprintf(b, "Needs crafting level %d", c->unlock); feed_add(b, 0xFF7A7A); return; }
	if (c->out == CR_WHET && S.weapon.upg >= 10) { sfx(SFX_HURT); return; }
	if (c->out == CR_INFUSE && c->amount == 1 && !S.armor.used) { sfx(SFX_HURT); feed_add("Wards need armour equipped", 0xFF7A7A); return; }
	if (craft_jobs() >= CRAFT_SLOTS) { sfx(SFX_HURT); feed_add("The crafting queue is full", 0xFF7A7A); return; }
	static u16 inv[ALL_ITEMS]; int sub = 0;
	if (!simulate(r, inv, &sub)) { sfx(SFX_HURT); feed_add("Missing ingredients", 0xFF7A7A); return; }
	for (int i = 0; i < ALL_ITEMS; i++) IC(i) = inv[i];
	int slot = craft_jobs();
	CraftJob* j = &S.jobs[slot];
	j->r = r; j->state = 1; j->sub = sub; j->total = j->left = recipe_time(r, sub);
	sfx(SFX_BUY);
	char b[48]; sprintf(b, "%s  %d:%02d%s", c->name, (int)j->total / 60, (int)j->total % 60, slot ? " (queued)" : "");
	toast("CRAFTING STARTED", b, 0xFFB86A, 0);
	if (sub) { sprintf(b, "(making %d part%s from scratch)", sub, sub > 1 ? "s" : ""); feed_add(b, 0xD8C8A8); }
	do_save();
}
static void finish_job(void) {
	CraftJob j = S.jobs[0];
	for (int i = 1; i < CRAFT_SLOTS; i++) S.jobs[i - 1] = S.jobs[i];
	memset(&S.jobs[CRAFT_SLOTS - 1], 0, sizeof(CraftJob));
	const Recipe* c = &recipes[j.r];
	if (c->station) {
		int slot = c->station - 1;
		if (S.holdN[slot] < 8) S.hold[slot][S.holdN[slot]++] = j.r; else station_deliver(j.r);
	} else switch (c->out) {
	case CR_ITEM: give_item(c->arg, c->amount, false); if (c->arg == IT_TONIC) quest_credit(QT_CRAFTTONIC); break;
	case CR_XP: { char b[24]; sprintf(b, "+%d XP", c->amount); ftext(v3add(P.p, v3(0, 2.2f, 0)), b, 0x7CF0FF, 2); add_xp(c->amount); } break;
	case CR_WHET: if (S.weapon.upg < 10) whetstone(); break;
	case CR_CACHE: if (S.readyCache[c->arg] < 99) S.readyCache[c->arg]++; break;
	}
	S.sCrafts++;
	if (S.doneN >= 8) { for (int k = 1; k < 8; k++) S.doneR[k - 1] = S.doneR[k]; S.doneN = 7; }
	S.doneR[S.doneN++] = j.r;
	sfx(SFX_QUEST); sfx(SFX_ACH);
	char sub[48]; if (c->station) sprintf(sub, "Collect it at %s", station_name(c->station)); else strcpy(sub, c->name);
	toast(c->out == CR_CACHE ? "CACHE READY!" : c->station ? "READY TO COLLECT!" : "CRAFT COMPLETE!", c->out == CR_CACHE ? "Open it in the Craft tab (Y)" : sub, c->tier >= 2 ? 0xFFD86A : 0xFFE9A0, 1);
	burst(v3add(P.p, v3(0, 1.4f, 0)), c->tier >= 2 ? 30 : 18, c->tier >= 2 ? 0xFFD86A : 0xFFE9A0, 3, 6, 0.8f, 0.12f, 0.9f);
	crafter_xp((c->tier >= 2 ? 12 : 4) + j.sub * 4);
	do_save();
}
static void update_crafting(float dt) {
	if (!S.jobs[0].state) return;
	S.jobs[0].left -= dt;
	if (S.jobs[0].left <= 0) finish_job();
}
void ack_craft(int i) {
	if (i < 0) { if (S.doneN) sfx(SFX_PICK); S.doneN = 0; return; }
	if (i >= S.doneN) return;
	for (int k = i + 1; k < S.doneN; k++) S.doneR[k - 1] = S.doneR[k];
	S.doneN--; sfx(SFX_BLIP);
}
void open_ready_cache(void) {
	for (int k = 0; k < 3; k++) if (S.readyCache[k]) { S.readyCache[k]--; gacha_start(k, R_UNCOMMON); return; }
}

// ------------------------------------------------------------ gacha cache opening
// phases: 0 idle (press A), 1 build-up (glow climbs the rarity ladder), 2 burst + reveal, 3 choose
void gacha_start(int kind, int minR) {
	memset(&G, 0, sizeof G);
	lootTable = 1;
	G.g = gen_gear(kind, minR, S.lvl + 1);
	lootTable = 0;
	G.on = true; G.kind = kind; G.phase = 1; G.shown = R_COMMON;
	G.steps = 4 + G.g.rarity + rndi(0, 2); // hits needed: better loot takes a few more
	sfx(SFX_CHEST);
}
void gacha_choice(int c) {
	if (!G.on || G.phase != 3) return;
	Gear g = G.g;
	if (g.rarity >= R_RARE) ach(A_RARE); if (g.rarity >= R_EPIC) ach(A_EPIC); if (g.rarity >= R_LEGEND) ach(A_LEGEND);
	if (c == 2) { int v = gain_gold(salvage_value(&g)); sfx(SFX_COIN); char b[32]; sprintf(b, "Salvaged +%dg", v); feed_add(b, 0xFFD23F); }
	else {
		give_gear(g);
		if (c == 0) { for (int i = 0; i < BAG_N; i++) if (S.bag[i].used && memcmp(&S.bag[i], &g, sizeof g) == 0) { equip_bag(i); break; } char nm[48], b[64]; gear_name(&g, nm); sprintf(b, "Equipped %s", nm); feed_add(b, rarity_col[g.rarity]); }
	}
	G.on = false;
	do_save();
}
// one hit on the cache: it jolts, and sometimes jumps a rarity
void gacha_hit(void) {
	if (!G.on || G.phase != 1 || G.t < 0.25f) return;
	G.steps--; G.stepT = 0.25f; // stepT = bounce timer
	int target = G.g.rarity;
	G.shake = 0.7f;
	if (G.shown < target && (G.steps <= target - G.shown || rndf() < 0.4f)) {
		G.shown++; G.flash = 0.45f; G.shake = 1.0f;
		sfx(G.shown >= R_EPIC ? SFX_LOOT_EPIC : SFX_LOOT_RARE);
	} else { sfx(SFX_HIT); sfx_pitch(SFX_BLIP, 0.9f + 0.1f * (8 - G.steps)); }
	if (G.steps <= 0) { G.phase = 2; G.t = 0; G.flash = 1.0f; G.shake = 1.0f; sfx(SFX_SLAM); sfx(G.g.rarity >= R_EPIC ? SFX_ACH : SFX_QUEST); }
}
static void gacha_update(float dt, u32 kd) {
	G.t += dt;
	if (G.shake > 0) G.shake -= dt * 3;
	if (G.flash > 0) G.flash -= dt * 2.5f;
	if (G.stepT > 0) G.stepT -= dt;
	switch (G.phase) {
	case 1: if (kd & KEY_A) gacha_hit(); break;
	case 2: if (G.t > 1.4f || (G.t > 0.4f && (kd & KEY_A))) G.phase = 3; break;
	case 3:
		if (kd & KEY_A) gacha_choice(0);
		else if (kd & KEY_B) gacha_choice(1);
		else if (kd & KEY_Y) gacha_choice(2);
		break;
	}
}

// ------------------------------------------------------------ enemies
static int enemy_count(bool bossOnly) { int c = 0; for (int i = 0; i < MAX_EN; i++) if (en[i].on && en[i].state != ES_DEAD && (!bossOnly || en[i].boss)) c++; return c; }
// stats from level: they grow the way yours do, then a steep penalty for out-levelling you (+4 is a death sentence)
// ranged foes lob slow shots you can roll through
static void fire_shot(Enemy* e, float dmg) {
	for (int i = 0; i < MAX_SHOTS; i++) if (!shots[i].on) {
		Shot* s = &shots[i]; V3 from = v3add(e->p, v3(0, 0.9f * endefs[e->type].scale, 0));
		V3 to = v3add(P.p, v3(0, 0.8f, 0)); V3 dv = v3norm(v3(to.x - from.x, to.y - from.y, to.z - from.z));
		dbgShots++; s->on = true; s->p = from; s->v = v3mul(dv, 9.5f); s->t = 0; s->dmg = dmg; s->elem = e->elem; s->col = e->elem ? elem_col[e->elem] : endefs[e->type].col;
		sfx_pitch(SFX_SWING, 1.5f);
		return;
	}
}
static void hurt_player(float dmg, V3 from, int elem);
static void update_shots(float dt) {
	for (int i = 0; i < MAX_SHOTS; i++) { Shot* s = &shots[i]; if (!s->on) continue;
		s->t += dt; s->p = v3add(s->p, v3mul(s->v, dt));
		if (s->t > 2.6f || s->p.y < ground_h(s->p.x, s->p.z) - 0.2f) { s->on = false; continue; }
		float nx, nz; if (world_blocked(s->p.x, s->p.z, 0.15f, &nx, &nz)) { s->on = false; burst(s->p, 6, s->col, 2, 3, 0.3f, 0.08f, 0.8f); continue; }
		if (dist2d(s->p.x, s->p.z, P.p.x, P.p.z) < 0.6f && fabsf(s->p.y - (P.p.y + 0.8f)) < 1.1f) {
			s->on = false; burst(s->p, 10, s->col, 3, 4, 0.4f, 0.1f, 1.0f);
			hurt_player(s->dmg, v3add(s->p, v3mul(s->v, -0.1f)), s->elem);
		}
	}
}
static void enemy_apply_level(Enemy* e) {
	const EnemyDef* ed = &endefs[e->type];
	int d = e->lvl - S.lvl;
	float frac = e->maxhp > 0 ? e->hp / e->maxhp : 1;
	float hpL = (3.f + e->lvl) / (3.f + ed->lvl), dmL = (6.f + e->lvl) / (6.f + ed->lvl);
	float hpG = d > 0 ? 1 + 0.25f * d + 0.06f * d * d : fmaxf(0.55f, 1 + 0.1f * d);  // v1.25: strong foes are big and slow to read, not just numbers
	float dmG = d > 0 ? 1 + 0.2f * d + 0.06f * d * d : fmaxf(0.5f, 1 + 0.12f * d);
	e->maxhp = ed->hp * (ed->boss ? 1.15f : HP_MULT) * hpL * hpG * diff_hp(); e->hp = e->maxhp * frac;
	e->dmgMul = dmL * dmG;
	if (e->elite && !e->boss) { e->maxhp *= e->guard ? 9.0f : dunOn && DG.kind == 1 ? 3.0f : 4.5f; e->dmgMul *= e->guard ? 1.45f : 1.3f; } // dungeon champions, rift elites, rift guardians
	if (dunOn && DG.kind == 1) { e->maxhp *= rift_hp_mul(DG.tier); e->dmgMul *= rift_dmg_mul(DG.tier); } // rift tier
	e->hp = e->maxhp * frac;
}
// the earth rumbles: the wilds catch up to your level
static void rumble(void) {
	int old = S.worldLvl; if (S.lvl > S.worldLvl) S.worldLvl = S.lvl;
	for (int i = 0; i < MAX_EN; i++) if (en[i].on && en[i].state != ES_DEAD) { en[i].lvl += S.worldLvl - old; enemy_apply_level(&en[i]); }
	gfx_set_flash(1.0f); shake = 1.4f; hitstop = 0.2f;
	sfx(SFX_SLAM); sfx(SFX_LOOT_EPIC);
	char b[48]; sprintf(b, "The wilds stir to level %d", S.worldLvl);
	toast("THE EARTH RUMBLES", b, 0xFFB04A, 2);
	if (!S.rumbleSeen) {
		S.rumbleSeen = 1;
		dlg_open(NPC_TILLY, "@You:The earth shakes beneath your feet. A flash of light rolls across the island.|@You:Out in the wilds, everything has gone very quiet.|@You:Better head back to town. Biscuit always seems to know what's going on.", ACT_NONE, 0);
		S.tracked = TRACK_RUMBLE; guideOn = true; guideBounty = false;
	}
	do_save();
}
static Enemy* spawn_enemy(int type, float x, float z) {
	for (int i = 0; i < MAX_EN; i++) if (!en[i].on) {
		Enemy* e = &en[i]; memset(e, 0, sizeof *e);
		e->on = true; e->type = type; e->p = v3(x, ground_h(x, z), z); e->sx = x; e->sz = z;
		e->boss = endefs[type].boss;
		// level follows yours: about your level near town, climbing the further out you go
		// level comes from the world level (raised only by rumbles), not yours:
		// about the world level near town, about +5 by the far shores
		{ float r = sqrtf(x*x + z*z); float t = clampf((r - 20) / 50, 0, 1);
		  int off = e->boss ? 1 : (int)(5 * t + 0.5f) + (r < 32 ? rndi(-2, 2) : rndi(-1, 1));
		  int L = S.worldLvl + off; if (L < 1) L = 1; if (L > LVL_CAP + 5) L = LVL_CAP + 5; e->lvl = L; }
		enemy_apply_level(e);
		e->elem = enemy_elem(type);

		e->yaw = rndf()*TAU; e->wx = x; e->wz = z; e->atkCd = 1; e->slamCd = 4; e->hx = x; e->hz = z;
		return e;
	}
	return NULL;
}
static void dun_on_kill(Enemy* e);
static void dot_damage(Enemy* e, float amt, u32 col);
static void apply_element(Enemy* e, int we, float dmg);
static void player_attack_hits(void);
static void dun_check_puzzles(void);
static void enemy_die(Enemy* e) {
	const EnemyDef* d = &endefs[e->type];
	e->state = ES_DEAD; e->deadT = 0;
	S.sKills++;
	if (dunOn) dun_on_kill(e);
	if (has_af(AF_BLOOM)) { S.hp += P.maxhp * 0.04f; if (S.hp > P.maxhp) S.hp = P.maxhp; }
	if (has_af(AF_FRENZY)) frenzyT = 4;
	if (has_pk(PK_BLOODLUST)) { P.sta += 12; if (P.sta > sta_max()) P.sta = sta_max(); }
	if (has_af(AF_BURST)) { static int depth; if (depth < 3) { depth++; // kills pop, and pops can chain a little
		V3 bp = e->p; burst(v3add(bp, v3(0, 0.6f, 0)), 18, 0xFF9A4A, 5, 6, 0.5f, 0.14f, 1.0f); sfx(SFX_SLAM);
		for (int i = 0; i < MAX_EN; i++) { Enemy* o = &en[i]; if (o == e || !o->on || o->state == ES_DEAD || dist2d(o->p.x, o->p.z, bp.x, bp.z) > 2.6f) continue; dot_damage(o, weapon_power() * 0.8f, 0xFF9A4A); }
		depth--; } }
	sfx(SFX_KILL);
	V3 at = v3add(e->p, v3(0, 0.5f * d->scale, 0));
	burst(at, e->boss ? 60 : 16, d->col, e->boss ? 7 : 4, e->boss ? 12 : 7, e->boss ? 1.6f : 0.9f, e->boss ? 0.25f : 0.14f, 0.3f);
	burst(at, e->boss ? 30 : 6, 0xFFFFFF, 3, 6, 0.6f, 0.09f, 1.0f);
	// a kill can shake the island awake: (foe level - yours) in N for foes above you, 1 in N otherwise. Bosses always do.
	if (e->boss) rumble();
	else if (S.lvl > S.worldLvl) { int dl = e->lvl - S.lvl; if (rndf() < (dl > 1 ? dl : 1) / (S.rumbleN * 50.f)) rumble(); }
	float lk = (3.f + e->lvl) / (3.f + d->lvl), up = 1 + 0.15f * (e->lvl > S.lvl ? e->lvl - S.lvl : 0); // tougher foes pay better
	drop_xp(at, (int)(d->xp * (e->boss ? 0.2f : 0.1f) * powf(lk, 1.6f) * up + 0.5f));
	bool delve = dunOn && DG.kind == 1 && DG.rtype == RT_DELVE; // a delve pays out only when you extract
	if (!delve) {
	{ int g = (int)((d->gold + rndi(0, d->gold)) * 1.5f * lk * up * (1 + 0.1f * S.fortuneLv) * (has_af(AF_GILDED) ? 1.3f : 1.0f)); if (g < 1) g = 1; drop_coins(at, g, e->boss ? 20 : rndi(2, 4)); }
	if (d->drop >= 0 && (e->boss || rndf() < 0.55f)) drop_item(at, d->drop);
	lootTable = 0;
	if (!e->boss && rndf() < 0.03f + charm_val(1) * 0.0003f) drop_gear(at, gen_gear(-1, 0, e->lvl));
	}
	if (e->boss) {
		loot_fountain(at, gen_gear(-1, R_RARE, e->lvl + 2)); // a boss is a pinata
		for (int k = 0; k < 3; k++) loot_fountain(at, gen_gear(-1, R_UNCOMMON, e->lvl + 1));
		drop_coins(at, 60 + e->lvl * 12, 16);
		shake = 0.5f; hitstop = 0.25f;
		for (int b = 0; b < 5; b++) if (boss_zone_quest[b][0] == e->type) {
			int q = boss_zone_quest[b][2];
			S.bossesKilled |= 1 << b;
			if (QS(q) == QS_ACTIVE && QP(q) == 0) {
				QP(q) = 1;
				give_item(IT_SHARD, 1, false);
				toast("LANTERN SHARD!", "A warm light pulses in your bag", 0xFFC94A, 2);
				sfx(SFX_LOOT_EPIC);
			}
			bossRespawn[b] = 360;
		}
		if (!P.bossHit) ach(A_UNTOUCHED);
		bossIdx = -1;
		do_save();
	}
	if (!delve && rndf() < 0.06f) drop_item(at, IT_TONIC);
	// quest & bounty kill credit
	if (S.mq < MQ_COUNT && S.mqState == 1 && mainq[S.mq].type == MQT_KILL && mainq[S.mq].target == d->fam && S.mqProg < mainq[S.mq].count) {
		S.mqProg++;
		if (S.mqProg == mainq[S.mq].count) { toast("STORY OBJECTIVE DONE", mainq[S.mq].title, 0xC79BFF, 2); sfx(SFX_QUEST); }
	}
	for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_ACTIVE && questdefs[q].type == QT_KILL && questdefs[q].target == d->fam) {
		QP(q)++;
		if (QP(q) == questdefs[q].count) { toast("OBJECTIVE DONE", questdefs[q].title, 0x7CF07C, 0); sfx(SFX_QUEST); }
	}
	if (EV.on && EV.type == EVT_HORDE && dist2d(e->p.x, e->p.z, EV.x, EV.z) < 18) { EV.prog++; }
	if (S.bActive && S.bType == 0 && S.bTarget == d->fam) { S.bProg++; if (S.bProg == S.bCount) toast("BOUNTY READY", "Return to the Bounty Board", 0xFFB04A, 0); }
}
static void hurt_player(float dmg, V3 from, int elem) {
	if (P.deadT > 0 || D.on || G.on) return;
	// perfect dodge: you rolled just as it landed
	if (P.rollT > 0 && P.rollAge < 0.28f && !P.perfectUsed) {
		P.perfectUsed = true; P.nextCrit = true; P.sta += 15; if (P.sta > sta_max()) P.sta = sta_max();
		slowmoT = 0.55f; sfx_pitch(SFX_LEVEL, 1.6f);
		if (has_pk(PK_RIPOSTE)) for (int i = 0; i < MAX_EN; i++) { Enemy* o = &en[i]; if (o->on && o->state != ES_DEAD && dist2d(o->p.x, o->p.z, P.p.x, P.p.z) < 4) { o->stunT = o->boss ? 0.5f : 1.3f; if (o->state == ES_WINDUP) o->state = ES_CHASE; } }
		ftext(v3add(P.p, v3(0, 2.4f, 0)), "PERFECT!", 0x9FE8FF, 2);
		burst(v3add(P.p, v3(0, 0.8f, 0)), 16, 0x9FE8FF, 3, 5, 0.5f, 0.1f, 1.0f);
		return;
	}
	if (P.inv > 0 || P.grace > 0 || pylT[2] > 0) return;
	char tag[4] = {0};
	if (elem) { // elemental attacks hurt a lot unless your armour matches
		if (S.armor.used && S.armor.elem == elem) { if (S.sWard[elem - 1] < 60000) S.sWard[elem - 1]++; dmg *= 0.5f; tag[0] = 0x80 + ICO_SHIELDOK; tag[1] = 0x80 + elem_icon(elem); } // -9 🛡🔥  you block fire
		else { dmg *= 1.7f; tag[0] = 0x80 + ICO_ANGER; tag[1] = 0x80 + elem_icon(elem); }                                       // -30 💢🔥 fire hits you hard
	}
	{ float def = armor_def(); dmg *= 1.0f - def / (def + 50.0f); if (dmg < 1) dmg = 1; }
	{ float cap = P.maxhp * (bossIdx >= 0 ? 0.6f : 0.45f); if (dmg > cap) dmg = cap; } // no single hit takes more than ~half your health
	S.hp -= dmg; P.hurtT = 0.3f; P.inv = 0.7f; P.noDmgT = 0;
	if (has_af(AF_THORNS)) { Enemy* best = NULL; float bd = 3.5f; for (int i = 0; i < MAX_EN; i++) { Enemy* o = &en[i]; if (!o->on || o->state == ES_DEAD) continue; float dd = dist2d(o->p.x, o->p.z, from.x, from.z); if (dd < bd) { bd = dd; best = o; } }
		if (best) dot_damage(best, dmg * 0.4f, 0xC8E070); }
	if (S.hp <= 0 && has_af(AF_PHOENIX) && phoenixCd <= 0) { S.hp = P.maxhp * 0.3f; phoenixCd = 180; P.inv = 1.5f; toast("PHOENIX", "Back from the brink", 0xFF8A3A, 0); burst(v3add(P.p, v3(0, 1, 0)), 40, 0xFF8A3A, 5, 9, 1.0f, 0.15f, 1.0f); sfx(SFX_LEVEL); }
	if (S.hp > 0 && S.hp < P.maxhp * 0.2f && has_pk(PK_LASTSTAND) && lastStandCd <= 0) { S.hp += P.maxhp * 0.35f; lastStandCd = 120; toast("LAST STAND", "+35% health", 0x7CF07C, 0); burst(v3add(P.p, v3(0, 1, 0)), 30, 0x7CF07C, 4, 7, 0.9f, 0.13f, 1.0f); }
	shake = 0.25f;
	sfx(SFX_HURT);
	char b[20]; sprintf(b, "-%d%s%s", (int)dmg, tag[0] ? " " : "", tag); ftext(v3add(P.p, v3(0, 2.2f, 0)), b, 0xFF5050, 1);
	V3 d = v3norm(v3(P.p.x - from.x, 0, P.p.z - from.z));
	P.rdx = d.x * 7; P.rdz = d.z * 7; P.rollT = -0.18f; // knockback slide
	if (bossIdx >= 0) P.bossHit = true;
	if (S.hp <= 0) { S.hp = 0; P.deadT = 3.0f; sfx(SFX_SLAM); }
	else if (S.hp < P.maxhp * 0.1f) P.closeCall = true;
}
// town safety: inside the fence you're invisible; foes stay out past ENEMY_RING unless chasing you
#define TOWN_R 12.6f
#define ENEMY_RING 21.0f
static bool inTown;
static void enemy_go_home(Enemy* e) {
	float hx = e->hx, hz = e->hz, hr = sqrtf(hx*hx + hz*hz);
	if (hr < ENEMY_RING + 2) { float k = (ENEMY_RING + 2 + rndr(0, 4)) / (hr > 0.1f ? hr : 1); if (hr <= 0.1f) { hx = e->p.x; hz = e->p.z; float r2 = sqrtf(hx*hx+hz*hz); k = (ENEMY_RING + 3) / (r2 > 0.1f ? r2 : 1); } hx *= k; hz *= k; }
	e->sx = hx; e->sz = hz; e->leaving = true; e->wanderT = rndr(2, 4);
}
// foes above your level look it: about 6% bigger per level (up to +30%)
float en_size(const Enemy* e) { float k = e->guard ? 2.0f : e->elite && !e->boss ? 1.45f : 1; int d = e->lvl - S.lvl; if (d <= 0) return k; if (d > 5) d = 5; return k * (1 + 0.06f * d); }
float slowmoT; // perfect-dodge slow motion (real seconds)
static void hit_enemy(Enemy* e, float dmg, bool crit, bool fin, const char* tag) {
	const EnemyDef* d = &endefs[e->type];
	e->hp -= dmg; e->flash = 0.12f; e->hitShow = 3;
	V3 dir = v3norm(v3(e->p.x - P.p.x, 0, e->p.z - P.p.z));
	float kb = (fin ? 9 : 5) / (e->boss ? 4.f : 1.f);
	e->kbx = dir.x * kb; e->kbz = dir.z * kb;
	if (e->state == ES_WINDUP && !e->boss) { e->state = ES_CHASE; e->atkCd = 0.6f; }
	if (!inTown && !e->boss && e->state == ES_IDLE) { e->state = ES_CHASE; e->leaving = false; } // hit it outside town and it fights back
	char b[20]; sprintf(b, crit ? "%d!%s%s" : "%d%s%s", (int)dmg, tag[0] ? " " : "", tag);
	ftext(v3add(e->p, v3(rndr(-0.3f, 0.3f), 1.0f * d->scale + 0.6f, 0)), b, crit ? 0xFFE14A : (fin ? 0xFF9A4A : 0xFFFFFF), crit || fin ? 2 : 1);
	burst(v3add(e->p, v3(0, 0.5f * d->scale, 0)), crit ? 14 : 7, crit ? 0xFFE14A : 0xFFFFFF, 4, 5, 0.4f, 0.09f, 1.0f);
	hitstop = crit ? 0.09f : 0.05f;
	if (crit) { shake = 0.18f; S.sCrits++; sfx(SFX_CRIT); } else sfx(SFX_HIT);
	if (e->hp <= 0) enemy_die(e);
}
// endurance: spends it if you have enough, otherwise says so
static bool spend_sta(float c) {
	if (P.sta < c) { if (tiredMsgT <= 0) { ftext(v3add(P.p, v3(0, 2.4f, 0)), "Out of breath!", 0x9CFF8A, 1); tiredMsgT = 1.2f; sfx_pitch(SFX_HURT, 1.4f); } hudStaFlash = 1; return false; }
	P.sta -= c; P.staT = 0.7f; return true;
}
// your weapon's element does something you can see and use
static void dot_damage(Enemy* e, float amt, u32 col) {
	e->hp -= amt; e->flash = 0.05f;
	char b[12]; sprintf(b, "%d", (int)(amt + 0.5f)); ftext(v3add(e->p, v3(rndr(-0.3f, 0.3f), 1.0f * endefs[e->type].scale + 0.4f, 0)), b, col, 1);
	if (e->hp <= 0 && e->state != ES_DEAD) enemy_die(e);
}
static void apply_element(Enemy* e, int we, float dmg) {
	if (!we || we == e->elem || e->state == ES_DEAD) return;
	const EnemyDef* d = &endefs[e->type];
	V3 hp = v3add(e->p, v3(0, 1.2f * d->scale + 0.9f, 0));
	switch (we) {
	case EL_FIRE: e->burnT = 3.0f; { float bd = dmg * (has_pk(PK_ELEMENT) ? 0.22f : 0.15f); if (bd > e->burnDps) e->burnDps = bd; } break; // burns, and melts guards and shields (see hits)
	case EL_FROST: // chills (slower moves and wind-ups); four hits freeze solid
		e->chillT = 3.0f;
		if (++e->chillN >= 4 && e->freezeT <= 0 && !e->boss) { e->chillN = 0; e->freezeT = 1.6f; e->dashT = 0; if (e->state == ES_WINDUP) e->state = ES_CHASE; ftext(hp, "FROZEN", 0x9FE8FF, 1); sfx_pitch(SFX_CRIT, 1.5f); }
		break;
	case EL_STORM: // interrupts wind-ups, and sometimes arcs to a second foe
		if (e->state == ES_WINDUP && !e->counter) { e->state = ES_CHASE; e->stunT = e->boss ? 0.4f : 0.9f; e->atkCd = 1.0f; e->slamT = 0; ftext(hp, "INTERRUPTED", 0xFFE14A, 1); sfx_pitch(SFX_CRIT, 1.3f); }
		if (rndf() < 0.35f) {
			Enemy* best = NULL; float bd = 4.5f;
			for (int k = 0; k < MAX_EN; k++) { Enemy* o = &en[k]; if (o == e || !o->on || o->state == ES_DEAD) continue; float dd = dist2d(o->p.x, o->p.z, e->p.x, e->p.z); if (dd < bd) { bd = dd; best = o; } }
			if (best) {
				for (int k = 0; k < 8; k++) { float t = k / 7.f; spawn_part(v3(lerpf(e->p.x, best->p.x, t), 1.0f + rndr(-0.2f, 0.2f), lerpf(e->p.z, best->p.z, t)), v3(0, 0, 0), 0.25f, 0.1f, 0xFFE14A, 0, 1.0f, MESH_OCTA); }
				dot_damage(best, dmg * 0.4f, 0xFFE14A);
			}
		}
		break;
	case EL_VENOM: e->poisonT = 4.0f; if (e->poisonStk < 5) e->poisonStk++; break; // stacks; poisoned foes hit softer
	}
}
static bool can_guard(const Enemy* e) { int r = en_role[e->type]; return r == R_SWARM || r == R_CHARGER || r == R_BOSS; }
static void player_attack_hits(void) {
	float pw = weapon_power() * (1 + 0.02f * (S.lvl - 1)) * (1 + 0.03f * S.buffLv) * (pylT[0] > 0 ? 2.0f : 1.0f);
	bool heavy = P.heavy;
	float reach = heavy ? 2.5f : 1.9f;
	bool any = false, chained = false;
	bool sweep = has_af(AF_SWEEP);
	int we = S.weapon.used ? S.weapon.elem : 0;
	for (int i = 0; i < MAX_EN; i++) {
		Enemy* e = &en[i];
		if (!e->on || e->state == ES_DEAD) continue;
		const EnemyDef* d = &endefs[e->type];
		float rad = d->radius * d->scale * en_size(e);
		float dx = e->p.x - P.p.x, dz = e->p.z - P.p.z;
		float dist = sqrtf(dx*dx + dz*dz);
		if (dist > reach + rad) continue;
		float ang = atan2f(dx, dz) - P.yaw;
		while (ang > PI) ang -= TAU; while (ang < -PI) ang += TAU;
		if (!sweep && fabsf(ang) > (heavy ? 1.9f : 1.35f) && dist > rad + 0.4f) continue;
		V3 hp = v3add(e->p, v3(0, 1.2f * d->scale + 0.9f, 0));
		// shields: crabs block from the front unless they've just swung (or you melt / smash through)
		bool brk = heavy || (P.finisher && has_pk(PK_BREAKER));
		if (en_role[e->type] == R_SHIELD && e->recoverT <= 0 && e->stunT <= 0 && e->freezeT <= 0 && we != EL_FIRE && !brk) {
			float fa = atan2f(-dx, -dz) - e->yaw; while (fa > PI) fa -= TAU; while (fa < -PI) fa += TAU;
			if (fabsf(fa) < 1.25f) {
				ftext(hp, "BLOCK", 0xB8C4D8, 1); sfx_pitch(SFX_HIT, 1.6f);
				burst(v3add(e->p, v3(dx > 0 ? -0.3f : 0.3f, 0.6f, 0)), 6, 0xFFFFFF, 3, 4, 0.25f, 0.06f, 1.0f);
				P.combo = 0; P.comboT = 0; { float kl = dist + 0.01f; P.rdx = -dx / kl * 3; P.rdz = -dz / kl * 3; P.rollT = -0.1f; }
				any = true; continue;
			}
		}
		// a raised guard (blue shimmer): hit it and it's turned aside, unless fire or a heavy blow breaks it
		if (e->guardT > 0) {
			if (we == EL_FIRE || brk) { e->guardT = 0; e->stunT = 0.8f; ftext(hp, "GUARD BROKEN", 0xFFA040, 1); sfx_pitch(SFX_CRIT, 0.8f); }
			else {
				dbgParry++; e->guardT = 0; e->hitsRow = 0; e->counter = true; e->state = ES_WINDUP; e->atk = 0; e->windup = e->boss ? 0.3f : 0.22f; e->atkCd = 0;
				ftext(hp, "PARRY!", 0x9FC8FF, 2);
				burst(v3add(e->p, v3(0, 0.8f * d->scale, 0)), 14, 0xBFD8FF, 4, 6, 0.35f, 0.08f, 1.0f);
				sfx_pitch(SFX_CRIT, 0.55f); shake = 0.15f; hitstop = 0.06f;
				P.atkCd = 0.6f; P.combo = 0; P.comboT = 0;
				{ float kl = dist + 0.01f; P.rdx = -dx / kl * 4; P.rdz = -dz / kl * 4; P.rollT = -0.12f; }
				any = true; continue;
			}
		}
		bool crit = P.nextCrit || rndf() * 100 < 8 + charm_val(4) + (has_af(AF_KEEN) ? 15 : 0); P.nextCrit = false;
		float dmg = pw * rndr(0.9f, 1.1f) * (crit ? 2.0f : 1.0f) * (P.finisher ? 1.6f : 1.0f) * (heavy ? 2.2f : 1.0f);
		if (e->recoverT > 0 || e->stunT > 0 || e->freezeT > 0) dmg *= 1.25f; // punish an opening
		if (has_af(AF_EXEC) && e->hp < e->maxhp * 0.3f) dmg *= 1.7f;
		char tag[4] = {0};
		if (e->elem) {
			if (we && elem_weak[e->elem] == we) { if (S.sWeak[we - 1] < 60000) S.sWeak[we - 1]++; dmg *= has_pk(PK_ELEMENT) ? 2.5f : 2.0f; tag[0] = 0x80 + ICO_EVENT; tag[1] = 0x80 + elem_icon(we); }
			else if (we == e->elem) { dmg *= 0.25f; tag[0] = 0x80 + ICO_NO; tag[1] = 0x80 + elem_icon(we); }
			else { dmg *= 0.5f; tag[0] = 0x80 + ICO_SHIELDOK; tag[1] = we ? 0x80 + elem_icon(we) : 0; }
		}
		{ int lg = e->lvl - S.lvl; if (lg > 0) dmg *= fmaxf(0.3f, 1 - 0.12f * lg); }
		e->hitsRow++; dbgHits++;
		if (heavy) { e->kbx += dx / (dist + 0.01f) * 6; e->kbz += dz / (dist + 0.01f) * 6; }
		Enemy* hitE = e; V3 hitAt = e->p;
		hit_enemy(e, dmg, crit, P.finisher || heavy, tag);
		apply_element(e, we, dmg);
		if (has_af(AF_LEECH)) { float h = fminf(dmg * 0.04f, P.maxhp * 0.03f); S.hp += h; if (S.hp > P.maxhp) S.hp = P.maxhp; }
		if (has_af(AF_CHAIN) && !chained) { chained = true; Enemy* best = NULL; float bd = 4.5f;
			for (int k = 0; k < MAX_EN; k++) { Enemy* o = &en[k]; if (o == hitE || !o->on || o->state == ES_DEAD) continue; float dd = dist2d(o->p.x, o->p.z, hitAt.x, hitAt.z); if (dd < bd) { bd = dd; best = o; } }
			if (best) { for (int k = 0; k < 6; k++) { float t = k / 5.f; spawn_part(v3(lerpf(hitAt.x, best->p.x, t), 1.0f, lerpf(hitAt.z, best->p.z, t)), v3(0, 0, 0), 0.25f, 0.1f, 0xC79BFF, 0, 1.0f, MESH_OCTA); } dot_damage(best, dmg * 0.5f, 0xC79BFF); } }
		// keep swinging and it may raise a guard: you'll see a blue shimmer; stop, or break it
		if (e->state != ES_DEAD && can_guard(e) && e->hitsRow >= 2 && e->state != ES_WINDUP && e->stunT <= 0 && e->freezeT <= 0 && e->dashT <= 0
		    && rndf() < 0.3f + 0.15f * (e->hitsRow - 2) + (e->boss ? 0.1f : 0)) {
			e->guardT = 0.9f; e->hitsRow = 0; ftext(hp, "GUARD", 0x7FB8FF, 1); sfx_pitch(SFX_HIT, 1.9f);
		}
		any = true;
	}
	if (any && P.finisher) S.sCombos++;
	if (heavy && (has_pk(PK_NOVA) || has_lp(LP_LANTERN))) { // a ring of force (and your element, with Nova)
		u32 c = we ? elem_col[we] : 0xFFE9A0; for (int k = 0; k < 24; k++) { float a = k * TAU / 24; spawn_part(v3add(P.p, v3(cosf(a) * 0.6f, 0.5f, sinf(a) * 0.6f)), v3(cosf(a) * 8, 0.5f, sinf(a) * 8), 0.4f, 0.14f, c, 0, 1.0f, MESH_OCTA); }
		for (int i = 0; i < MAX_EN; i++) { Enemy* o = &en[i]; if (!o->on || o->state == ES_DEAD || dist2d(o->p.x, o->p.z, P.p.x, P.p.z) > 3.6f) continue;
			if (has_lp(LP_LANTERN)) hit_enemy(o, pw * 1.5f, false, true, "");
			if (o->on && o->state != ES_DEAD && has_pk(PK_NOVA) && we) apply_element(o, we, pw); }
		shake = 0.25f; sfx(SFX_SLAM);
	}
	if (any && has_lp(LP_ECHO) && !heavy && ++swingN % 3 == 0) echoT = 0.14f; // the echo strikes again a beat later
	P.heavy = false;
}

static void update_enemies(float dt) {
	inTown = sqrtf(P.p.x*P.p.x + P.p.z*P.p.z) < TOWN_R;
	for (int i = 0; i < MAX_EN; i++) {
		Enemy* e = &en[i];
		if (!e->on) continue;
		const EnemyDef* d = &endefs[e->type];
		e->t += dt;
		if (e->flash > 0) e->flash -= dt;
		if (e->hitShow > 0) e->hitShow -= dt;
		if (e->state == ES_DEAD) { e->deadT += dt; if (e->deadT > 0.4f) e->on = false; continue; }
		float dx = P.p.x - e->p.x, dz = P.p.z - e->p.z, dist = sqrtf(dx*dx + dz*dz);
		if (!e->boss && !dunOn && dist > 42) { e->on = false; continue; } // dungeon foes stay put
		if ((d->fam == FAM_MOTH || d->fam == FAM_GAUNT) && !night_now() && e->state != ES_CHASE) { burst(v3add(e->p, v3(0, 1, 0)), 10, d->col, 2, 4, 0.6f, 0.1f, 0.8f); e->on = false; continue; } // they scatter at dawn
		float aggro = e->boss ? 13 : en_ranged(e->type) ? 9.0f : 6.5f; // v1.23: you have to get close (or hit them) to draw a foe
		float dm = DMG_MULT * diff_dmg() * (night_now() ? 1.15f : 1.0f);
		if (e->poisonStk) dm *= 1 - 0.08f * e->poisonStk; // poisoned foes hit softer
		float spd = d->speed;
		float mx = 0, mz = 0;
		bool alive = P.deadT <= 0;
		int role = en_role[e->type], gap = e->lvl - S.lvl;
		// statuses
		if (e->burnT > 0) { e->burnT -= dt; e->dotAcc += e->burnDps * dt; if (rndf() < dt * 12) spawn_part(v3add(e->p, v3(rndr(-0.4f, 0.4f), rndr(0.3f, 1.2f), rndr(-0.4f, 0.4f))), v3(0, 2, 0), 0.5f, 0.12f, 0xFF8A3A, -1, 1.0f, MESH_OCTA); if (e->burnT <= 0) e->burnDps = 0; }
		if (e->poisonT > 0) { e->poisonT -= dt; e->dotAcc += e->poisonStk * d->hp * 0.012f * dt; if (rndf() < dt * 6) spawn_part(v3add(e->p, v3(rndr(-0.4f, 0.4f), rndr(0.3f, 1.0f), rndr(-0.4f, 0.4f))), v3(0, 1, 0), 0.7f, 0.1f, 0x8CE05A, -0.5f, 0.8f, MESH_SPHERE_LO); if (e->poisonT <= 0) e->poisonStk = 0; }
		if (e->dotAcc >= 1) { int a = (int)e->dotAcc; e->dotAcc -= a; dot_damage(e, (float)a, e->burnT > 0 ? 0xFF8A3A : 0x8CE05A); if (e->state == ES_DEAD) continue; }
		if (e->chillT > 0) { e->chillT -= dt; if (e->chillT <= 0) e->chillN = 0; }
		if (e->freezeT > 0) e->freezeT -= dt;
		if (e->stunT > 0) e->stunT -= dt;
		if (e->recoverT > 0) e->recoverT -= dt;
		float slow = e->chillT > 0 ? 0.55f : 1.0f;
		if (e->castT > 0) { // a caster's red circle goes off where you stood
			e->castT -= dt;
			if (e->castT <= 0) { sfx(SFX_SLAM); burst(v3(e->castX, ground_h(e->castX, e->castZ) + 0.3f, e->castZ), 24, d->col, 5, 6, 0.6f, 0.12f, 1.0f);
				if (dist2d(P.p.x, P.p.z, e->castX, e->castZ) < 1.8f) hurt_player(d->dmg * dm * e->dmgMul * 1.2f, v3(e->castX, 0, e->castZ), e->elem); }
		}
		if (e->dashT > 0) { // a charger's dash runs down its red arrow
			e->dashT -= dt; float sp = 15 * slow;
			e->p.x += e->aimX * sp * dt; e->p.z += e->aimZ * sp * dt;
			if (!e->dashHit && dist2d(e->p.x, e->p.z, P.p.x, P.p.z) < 1.1f + d->radius * d->scale) { e->dashHit = true; hurt_player(d->dmg * dm * e->dmgMul * 1.3f, e->p, e->elem); }
			if (e->dashT <= 0) { e->recoverT = 0.9f; e->state = ES_CHASE; }
		}
		bool held = e->freezeT > 0 || e->stunT > 0 || e->dashT > 0 || e->recoverT > 0;
		if (e->guardT > 0) { // braced behind a guard: turn to you, then swing when it drops
			e->guardT -= dt; held = true;
			e->yaw = atan2f(dx, dz);
			if (e->guardT <= 0 && dist < d->radius * d->scale * en_size(e) + 1.6f) { e->state = ES_WINDUP; e->atk = 0; e->windup = 0.3f; }
		}
		// in town you're out of sight: foes lose interest and wander back where they came from
		if (!e->boss && (e->state == ES_CHASE || e->state == ES_WINDUP) && inTown) { e->state = ES_IDLE; enemy_go_home(e); }
		if (!e->boss && e->state == ES_IDLE && !e->leaving && sqrtf(e->p.x*e->p.x + e->p.z*e->p.z) < ENEMY_RING) enemy_go_home(e);
		if (e->state == ES_IDLE && e->leaving) {
			float wx = e->sx - e->p.x, wz = e->sz - e->p.z, wl = sqrtf(wx*wx + wz*wz);
			if (wl < 1.5f) e->leaving = false;
			else { mx = wx / wl * spd * 0.75f; mz = wz / wl * spd * 0.75f; }
		} else if (held && e->state != ES_IDLE) {
			// frozen, stunned, dashing, recovering or guarding: no new decisions
		} else if (e->state == ES_IDLE) {
			e->wanderT -= dt;
			if (e->wanderT <= 0) { e->wanderT = rndr(2, 4); float a = rndf()*TAU; e->wx = e->sx + cosf(a)*4; e->wz = e->sz + sinf(a)*4; }
			float wx = e->wx - e->p.x, wz = e->wz - e->p.z, wl = sqrtf(wx*wx + wz*wz);
			if (wl > 0.3f) { mx = wx / wl * spd * 0.4f; mz = wz / wl * spd * 0.4f; }
			if (dist < aggro && alive && !inTown) { e->state = ES_CHASE;
				if (gap >= 3 && !e->growled) { e->growled = true; ftext(v3add(e->p, v3(0, 1.6f * d->scale * en_size(e) + 0.6f, 0)), "!", gap >= 4 ? 0xE060FF : 0xFF5040, 3); sfx_pitch(SFX_SLAM, 1.4f); } }
		} else if (e->state == ES_CHASE) {
			if (!alive || dist > (e->boss ? aggro * 1.8f : 18)) { e->state = ES_IDLE; e->sx = e->p.x; e->sz = e->p.z; }
			float reach = d->radius * d->scale * en_size(e) + 0.9f;
			float wu = (gap > 0 ? 0.08f * gap : 0); // stronger foes wind up longer: they're meant to be read
			e->atkCd -= dt * slow;
			spd *= slow;
			if (role == R_RANGED || role == R_CASTER) { // keep their distance
				float lo = role == R_CASTER ? 7 : 6, hi = role == R_CASTER ? 10 : 9;
				if (dist > hi) { mx = dx / dist * spd; mz = dz / dist * spd; }
				else if (dist < lo) { mx = -dx / dist * spd * 0.8f; mz = -dz / dist * spd * 0.8f; }
				else { mx = -dz / dist * spd * 0.3f; mz = dx / dist * spd * 0.3f; }
				if (dist < 12 && e->atkCd <= 0) { e->state = ES_WINDUP; e->atk = role == R_CASTER ? 3 : 4; e->windup = (role == R_CASTER ? 0.45f : 0.6f) + wu; e->hitsRow = 0; }
			} else if (role == R_CHARGER && dist > 2.2f && dist < 7.5f && e->atkCd <= 0) { // crouch behind a red arrow, then dash
				e->state = ES_WINDUP; e->atk = 2; e->windup = 0.85f + wu; e->hitsRow = 0; e->aimX = dx / dist; e->aimZ = dz / dist;
			} else if (role == R_BRUTE && dist < reach + 0.6f && e->atkCd <= 0) { // slow slam inside a red ring
				e->state = ES_WINDUP; e->atk = 1; e->windup = 1.0f + wu; e->hitsRow = 0;
				e->aimX = e->p.x + dx / dist * 0.7f; e->aimZ = e->p.z + dz / dist * 0.7f;
			} else {
				if (dist > reach * 0.8f) { mx = dx / dist * spd; mz = dz / dist * spd; }
				if (role == R_SHIELD) { mx *= 0.8f; mz *= 0.8f; }
				if (dist < reach && e->atkCd <= 0) { e->state = ES_WINDUP; e->atk = 0; e->windup = (e->boss ? 0.55f : 0.45f) + wu; e->hitsRow = 0; }
			}
			if (e->boss) {
				e->slamCd -= dt;
				if (e->slamCd <= 0 && dist < 9) { e->slamT = 1.1f; e->slamCd = rndr(4.5f, 6.5f); }
			}
		} else if (e->state == ES_WINDUP) {
			e->windup -= dt * slow;
			if (e->atk == 2 && e->windup > 0.4f) { e->aimX = dx / (dist + 0.01f); e->aimZ = dz / (dist + 0.01f); } // aims, then locks in
			if (e->atk != 2 && e->atk != 1) e->yaw = atan2f(dx, dz);
			if (e->windup <= 0) {
				float reach = d->radius * d->scale * en_size(e) + 1.3f, cm = e->counter ? 1.3f : 1.0f;
				switch (e->atk) {
				case 4: fire_shot(e, d->dmg * dm * e->dmgMul); e->atkCd = rndr(2.2f, 3.0f); break;
				case 3: e->castX = P.p.x; e->castZ = P.p.z; e->castT = 1.15f; e->atkCd = rndr(3.0f, 3.8f); sfx_pitch(SFX_SWING, 0.7f); break;
				case 2: e->dashT = 0.45f; e->dashHit = false; e->yaw = atan2f(e->aimX, e->aimZ); sfx_pitch(SFX_DODGE, 0.7f); e->atkCd = rndr(2.0f, 2.8f); break;
				case 1: sfx(SFX_SLAM); shake = 0.35f;
					for (int k = 0; k < 20; k++) { float a = TAU * k / 20; spawn_part(v3(e->aimX + cosf(a) * 2.2f, ground_h(e->aimX, e->aimZ) + 0.2f, e->aimZ + sinf(a) * 2.2f), v3(cosf(a) * 3, 3, sinf(a) * 3), 0.5f, 0.16f, 0xB8A890, 10, 0, MESH_CUBE); }
					if (dist2d(P.p.x, P.p.z, e->aimX, e->aimZ) < 2.5f) hurt_player(d->dmg * dm * e->dmgMul * 1.35f, v3(e->aimX, 0, e->aimZ), e->elem);
					e->recoverT = 1.0f; e->atkCd = 1.6f; break;
				default:
					if (dist < reach + (e->counter ? 0.6f : 0)) hurt_player(d->dmg * dm * e->dmgMul * cm * rndr(0.9f, 1.1f), e->p, e->elem);
					e->kbx = dx / (dist + 0.01f) * 4; e->kbz = dz / (dist + 0.01f) * 4; // lunge
					e->atkCd = e->boss ? 0.85f : 1.0f;
					if (role == R_SHIELD) e->recoverT = 1.0f; // crabs open up after a swing: that's your window
					else if (role == R_SWARM) e->recoverT = 0.25f;
				}
				e->counter = false;
				e->state = ES_CHASE;
			}
		}
		if (e->slamT > 0) {
			e->slamT -= dt;
			mx *= 0.2f; mz *= 0.2f;
			if (e->slamT <= 0) {
				sfx(SFX_SLAM); shake = 0.45f;
				for (int k = 0; k < 30; k++) { float a = TAU * k / 30; spawn_part(v3add(e->p, v3(cosf(a)*1.5f, 0.2f, sinf(a)*1.5f)), v3(cosf(a)*8, 3, sinf(a)*8), 0.6f, 0.2f, 0xB8A890, 12, 0, MESH_CUBE); }
				if (dist < 4.6f) hurt_player(d->dmg * dm * e->dmgMul * 1.6f, e->p, e->elem);
			}
		}
		// hopping movers only move while airborne
		if (d->fam == FAM_SLIME || d->fam == FAM_TOAD) {
			e->hop += dt * (d->fam == FAM_TOAD ? 2.2f : 3.0f);
			float s = sinf(e->hop * PI);
			if (s < 0.05f) { mx *= 0.1f; mz *= 0.1f; } else { mx *= 1.6f; mz *= 1.6f; }
		}
		if (e->state == ES_WINDUP || held) { mx = mz = 0; }
		if (role == R_SHIELD && e->state == ES_CHASE && !held) { float ty = atan2f(dx, dz), dy = ty - e->yaw; while (dy > PI) dy -= TAU; while (dy < -PI) dy += TAU; float mt = 2.2f * dt; e->yaw += dy > mt ? mt : dy < -mt ? -mt : dy; } // shields turn slowly: circle round them
		float ox0 = e->p.x, oz0 = e->p.z;
		e->p.x += (mx + e->kbx) * dt; e->p.z += (mz + e->kbz) * dt;
		e->kbx *= powf(0.02f, dt); e->kbz *= powf(0.02f, dt);
		if (fabsf(mx) + fabsf(mz) > 0.1f && role != R_SHIELD) {
			float ty = atan2f(mx, mz), dy = ty - e->yaw;
			while (dy > PI) dy -= TAU; while (dy < -PI) dy += TAU;
			e->yaw += dy * clampf(dt * 8, 0, 1);
		}
		float nx, nz;
		world_blocked(e->p.x, e->p.z, d->radius * d->scale * 0.7f, &nx, &nz);
		e->p.x = nx; e->p.z = nz;
		if (!zone_open(zone_at(e->p.x, e->p.z)) && zone_open(zone_at(ox0, oz0))) { e->p.x = ox0; e->p.z = oz0; } // seals hold both ways
		if (ground_h(e->p.x, e->p.z) < -0.4f && d->fam != FAM_WISP && d->fam != FAM_MOTH) { e->p.x -= (mx + e->kbx) * dt; e->p.z -= (mz + e->kbz) * dt; }
		// keep enemies out of the village
		float rv = sqrtf(e->p.x*e->p.x + e->p.z*e->p.z);
		if (rv < TOWN_R + 1 && !e->boss) { e->p.x *= (TOWN_R + 1) / rv; e->p.z *= (TOWN_R + 1) / rv; } // never through the fence
		if (e->boss) {
			float ax = arena_pos[d->zone][0], az = arena_pos[d->zone][1], ox = e->p.x - ax, oz = e->p.z - az, ol = sqrtf(ox*ox + oz*oz);
			if (ol > 9) { e->p.x = ax + ox / ol * 9; e->p.z = az + oz / ol * 9; } // leashed to the arena
			rv = sqrtf(e->p.x*e->p.x + e->p.z*e->p.z);
			if (rv < 16) { e->p.x *= 16 / rv; e->p.z *= 16 / rv; } // and never near the village exits
		}
		e->p.y = ground_h(e->p.x, e->p.z);
		if (e->p.y < -0.3f) e->p.y = -0.3f;
		// separation
		for (int j = i + 1; j < MAX_EN; j++) {
			Enemy* o = &en[j]; if (!o->on || o->state == ES_DEAD) continue;
			float sx = o->p.x - e->p.x, sz = o->p.z - e->p.z, sd = sx*sx + sz*sz, rr = (d->radius * d->scale + endefs[o->type].radius * endefs[o->type].scale) * 0.9f;
			if (sd < rr*rr && sd > 0.0001f) { float l = sqrtf(sd), push = (rr - l) * 0.5f; e->p.x -= sx/l*push; e->p.z -= sz/l*push; o->p.x += sx/l*push; o->p.z += sz/l*push; }
		}
	}
}
static void dun_update(float dt);
static void spawn_logic(float dt) {
	if (dunOn) { dun_update(dt); return; } // dungeons place their own foes
	spawnT -= dt;
	if (spawnT <= 0) {
		bool nt = night_now();
		{ float sr = S.spawnPct < 5 ? 5 : S.spawnPct; spawnT = (nt ? 0.8f : 1.0f) * 25.f / sr; if (spawnT < 0.2f) spawnT = 0.2f; }
		int cap = (int)((nt ? 17 : 15) * S.spawnPct / 25.f + 0.5f); if (cap > MAX_EN - 8) cap = MAX_EN - 8; // spawn-rate slider (25 = tuned)
		if (enemy_count(false) - enemy_count(true) < cap) {
			float a = rndf()*TAU, r = rndr(14, 24);
			float x = P.p.x + cosf(a)*r, z = P.p.z + sinf(a)*r;
			int zn = zone_at(x, z);
			float rv = sqrtf(x*x + z*z);
			if (zn != Z_VILLAGE && zone_open(zn) && rv > ENEMY_RING && ground_h(x, z) > 0.1f && fabsf(x) < WORLD_HALF - 3 && fabsf(z) < WORLD_HALF - 3) {
				bool clear = true;
				for (int b = 0; b < 5; b++) if (dist2d(x, z, arena_pos[boss_zone_quest[b][1]][0], arena_pos[boss_zone_quest[b][1]][1]) < 8) clear = false;
				if (clear) {
					int t = rndf() < 0.2f ? zone_ranged[zn] : zone_enemies[zn][rndf() < 0.62f ? 0 : 1];
					if (nt && rndf() < 0.45f) t = ((zn == Z_RUINS || zn == Z_SWAMP) && rndf() < 0.4f) ? EN_GAUNT : EN_MOTH;
					float nx, nz;
					if (!world_blocked(x, z, 0.6f, &nx, &nz)) { spawn_enemy(t, x, z); if (en_role[t] == R_SWARM) for (int k = rndi(1, 2); k > 0; k--) spawn_enemy(t, x + rndr(-1.8f, 1.8f), z + rndr(-1.8f, 1.8f)); } // swarms come in packs
				}
			}
		}
	}
	// bosses
	for (int b = 0; b < 5; b++) {
		if (bossRespawn[b] > 0) bossRespawn[b] -= dt;
		int type = boss_zone_quest[b][0], z = boss_zone_quest[b][1], q = boss_zone_quest[b][2];
		bool want = QS(q) == QS_ACTIVE && QP(q) == 0; // v1.25: bosses stay dead once beaten
		if (!want) continue;
		float ax = arena_pos[z][0], az = arena_pos[z][1];
		if (dist2d(P.p.x, P.p.z, ax, az) > 30) continue;
		bool exists = false;
		for (int i = 0; i < MAX_EN; i++) if (en[i].on && en[i].type == type) exists = true;
		if (!exists) { Enemy* e = spawn_enemy(type, ax, az); if (e) { e->elite = QS(q) == QS_DONE; } }
	}
	// boss engagement
	bossIdx = -1;
	for (int i = 0; i < MAX_EN; i++) if (en[i].on && en[i].boss && en[i].state != ES_DEAD && dist2d(P.p.x, P.p.z, en[i].p.x, en[i].p.z) < 18) {
		if (bossIdx < 0) {
			static int lastBoss = -1;
			if (lastBoss != en[i].type) { lastBoss = en[i].type; strcpy(zoneBanner, endefs[en[i].type].name); zoneBannerT = 3.0f; zoneBannerCol = 0xFF6A5A; P.bossHit = false; }
		}
		bossIdx = i;
	}
}

#include "dungeon.inc"
// ------------------------------------------------------------ player
static void update_player(float dt, u32 kd, u32 kh) {
	if (P.deadT > 0) {
		P.deadT -= dt;
		if (P.deadT <= 0) {
			if (dunOn && DG.kind == 1 && DG.rtype == RT_DELVE && DG.haul > 0) { toast("THE RIFT KEEPS YOUR HAUL", "Everything you carried in there is gone", 0xFF7A7A, 2); DG.haul = 0; }
			if (dunOn && DG.kind == 1 && DG.rtype == RT_HUNT && !DG.done) { // a hunt doesn't throw you out: it takes time instead
				int pen = 15 * (DG.deaths + 1); DG.deaths++; DG.timeLeft -= pen; if (DG.timeLeft < 0) DG.timeLeft = 0;
				P.p = v3(dun_x(DG.si), 0, dun_z(DG.sj) + DTS * 1.2f); S.hp = P.maxhp; P.inv = 2.0f;
				char b2[48]; sprintf(b2, "-%d seconds. The next one costs more.", pen); toast("THE RIFT TAKES ITS TOLL", b2, 0xFF7A7A, 0);
				return;
			}
			bool inDun = dunOn; if (dunOn) dun_leave(false); // fainting below spills your gold at the entrance
			int lost = S.gold * 3 / 10; S.gold -= lost; // carried gold is at risk: it's left where you fell
			if (lost > 0) drop_coins(v3add(P.p, v3(0, 0.3f, 0)), lost, lost > 40 ? 10 : 4);
			P.p = v3(0, ground_h(0, 5), 5); P.yaw = PI; S.hp = P.maxhp; camYaw = PI;
			for (int i = 0; i < MAX_EN; i++) if (en[i].on && !en[i].boss) en[i].on = false;
			char b[64]; sprintf(b, lost ? (inDun ? "You dropped %dg at the entrance. Go get it!" : "You dropped %dg where you fell. Go get it!") : "Back to the village.", lost);
			toast("YOU FAINTED", b, 0xFF7A7A, 0); S.retOn = 0;
		}
		return;
	}
	circlePosition cp; hidCircleRead(&cp);
	float sx = cp.dx / 156.f, sy = cp.dy / 156.f;
	float mag = sqrtf(sx*sx + sy*sy);
	if (mag < 0.12f) { sx = sy = 0; mag = 0; } else if (mag > 1) { sx /= mag; sy /= mag; mag = 1; }
	if (D.on || shopOpen) { sx = sy = 0; mag = 0; }
	float fx = sinf(camYaw), fz = cosf(camYaw);
	float rx = -fz, rz = fx; // right vector
	rx = -cosf(camYaw); rz = sinf(camYaw);
	float mx = fx * sy + rx * sx, mz = fz * sy + rz * sx;
	float speed = 6.0f * (1 + charm_val(0) / 100.f) * (pylT[1] > 0 ? 1.45f : 1.0f);
	float h = ground_h(P.p.x, P.p.z);
	if (h < -0.05f) speed *= 0.6f; // wading
	if (P.atkT > 0) speed *= 0.35f;
	P.moving = mag > 0;

	// roll
	if (P.rollCd > 0) P.rollCd -= dt;
	{ // endurance refills once you ease off
		if (P.staT > 0) P.staT -= dt;
		else if (P.sta < sta_max()) { P.sta += dt * 40 * (1 + 0.12f * S.staLv); if (P.sta > sta_max()) P.sta = sta_max(); }
	}
	if ((kd & KEY_B) && P.rollCd <= 0 && P.rollT <= 0 && !D.on && !shopOpen && !spend_sta(has_af(AF_TIRELESS) ? 10 : 20)) {}
	else if ((kd & KEY_B) && P.rollCd <= 0 && P.rollT <= 0 && !D.on && !shopOpen) {
		float dx = mag > 0 ? mx : sinf(P.yaw), dz = mag > 0 ? mz : cosf(P.yaw);
		float l = sqrtf(dx*dx + dz*dz); if (l < 0.01f) { dx = sinf(P.yaw); dz = cosf(P.yaw); l = 1; }
		P.rdx = dx / l * 12; P.rdz = dz / l * 12; P.rollT = 0.32f; P.rollCd = 0.55f; P.inv = 0.38f; P.rollAge = 0; P.perfectUsed = false; P.aHeld = false; P.chargeT = 0;
		P.yaw = atan2f(dx, dz); rollSeq++;
		sfx(SFX_DODGE);
		burst(P.p, 6, 0xD8C8A8, 2, 2, 0.4f, 0.12f, 0);
	}
	float vx, vz;
	if (P.rollT > 0) { P.rollT -= dt; vx = P.rdx; vz = P.rdz; }
	else if (P.rollT < 0) { P.rollT += dt; if (P.rollT > 0) P.rollT = 0; vx = P.rdx; vz = P.rdz; P.rdx *= 0.85f; P.rdz *= 0.85f; }
	else {
		vx = mx * speed; vz = mz * speed;
		if (mag > 0 && P.atkT <= 0) {
			float ty = atan2f(mx, mz), dy = ty - P.yaw;
			while (dy > PI) dy -= TAU; while (dy < -PI) dy += TAU;
			P.yaw += dy * clampf(dt * 14, 0, 1);
		}
	}
	float nx = P.p.x + vx * dt, nz = P.p.z + vz * dt;
	if (ground_h(nx, nz) < -0.55f) { nx = P.p.x; nz = P.p.z; }
	if (!zone_open(zone_at(nx, nz))) { // sealed zone: slide along the barrier
		if (zone_open(zone_at(nx, P.p.z))) nz = P.p.z; else if (zone_open(zone_at(P.p.x, nz))) nx = P.p.x; else { nx = P.p.x; nz = P.p.z; }
	}
	world_blocked(nx, nz, 0.4f, &nx, &nz);
	P.p.x = nx; P.p.z = nz;
	P.p.y = ground_h(P.p.x, P.p.z); if (P.p.y < -0.45f) P.p.y = -0.45f;
	if (P.moving) P.walk += dt * 10 * mag;

	// attack / interact
	if (P.atkCd > 0) P.atkCd -= dt;
	if (P.comboT > 0) { P.comboT -= dt; if (P.comboT <= 0) P.combo = 0; }
	if (P.atkT > 0) {
		float prev = P.atkT; P.atkT -= dt;
		if (prev > 0.16f && P.atkT <= 0.16f && !P.hitDone) { P.hitDone = true; player_attack_hits(); }
	}
	promptText[0] = 0;
	int npc = -1, ch = -1, nd = -1, bl = -1, sl = -1, slSt = 0, dw = 0, gt = -1; bool stall = false;
	if (!D.on && !shopOpen) {
		// everything in reach competes; the closest one wins, so nothing hides another
		bool threat = false;
		for (int i = 0; i < MAX_EN; i++) if (en[i].on && en[i].state != ES_DEAD && dist2d(P.p.x, P.p.z, en[i].p.x, en[i].p.z) < 3.2f + endefs[en[i].type].radius * endefs[en[i].type].scale) threat = true;
		int n0 = near_npc(), b0 = near_building(), c0 = threat ? -1 : near_chest(), d0 = threat ? -1 : near_node();
		float best = 99, dd;
		if (n0 >= 0 && (dd = dist2d(P.p.x, P.p.z, npcdefs[n0].x, npcdefs[n0].z) - (n0 == NPC_BOARD ? 0.5f : 0)) < best) { best = dd; npc = n0; }
		if (b0 >= 0) { float x, z; bld_door(b0, &x, &z); if ((dd = dist2d(P.p.x, P.p.z, x, z)) < best) { best = dd; npc = -1; bl = b0; } }
		if ((dd = dist2d(P.p.x, P.p.z, STALL_X, STALL_Z)) < 1.6f && dd < best) { best = dd; npc = bl = -1; stall = true; bankMode = false; }
		if ((dd = dist2d(P.p.x, P.p.z, BANK_X, BANK_Z)) < 1.6f && dd < best) { best = dd; npc = bl = -1; stall = true; bankMode = true; }
		if (c0 >= 0 && (dd = dist2d(P.p.x, P.p.z, chests[c0].x, chests[c0].z)) < best) { best = dd; npc = bl = -1; stall = false; ch = c0; }
		if (d0 >= 0 && (dd = dist2d(P.p.x, P.p.z, nodes[d0].x, nodes[d0].z)) < best) { best = dd; npc = bl = ch = -1; stall = false; nd = d0; }
		if (dunOn) { float d0; int w = dun_near(&d0); if (w && d0 < best) { best = d0; npc = bl = ch = nd = -1; stall = false; dw = w; } }
		else { float d0; int g = near_gate(&d0); if (g >= 0 && d0 < best) { best = d0; npc = bl = ch = nd = -1; stall = false; gt = g; } }
		{ int s0 = near_seal(); if (s0 >= 0 && (dd = dist2d(P.p.x, P.p.z, sealpts[s0].x, sealpts[s0].z)) < best) { best = dd; npc = bl = ch = nd = -1; stall = false; sl = s0; } }
		if (dw || gt >= 0) sl = -1;
		if (dw == 1) sprintf(promptText, DG.kind ? "A: Go deeper (floor %d, haul x%.1f)" : "A: Descend to floor %d", DG.floor + 1, 1 + 0.5f * DG.floor);
		else if (dw == 2) strcpy(promptText, DG.kind ? (DG.rtype == RT_DELVE && DG.haul > 0 ? "A: Leave (and lose your haul)" : "A: Leave (the rift closes behind you)") : DG.floor > 1 ? "A: Climb out (this floor is remembered)" : "A: Climb back out");
		else if (dw == 3) strcpy(promptText, DG.kind && DG.rtype == RT_DELVE ? "A: Extract with your haul" : "A: Step into the light (leave)");
		else if (dw == 40) strcpy(promptText, (S.depNote >> DG.zone) & 1 ? "Locked. Someone in town has the key" : "A: Read the note on the door");
		else if (dw >= 20) { static const char* ov[5] = { "A: Read", "A: Read the note", "A: Pull the lever", "A: Reset the stones", "" }; strcpy(promptText, ov[DG.ob[dw - 20].type]); }
		else if (dw >= 10) strcpy(promptText, DG.ch[dw - 10].reward ? "A: Open the champion's hoard" : "A: Open chest");
		else if (gt >= 0) {
			const DunGate* g = &gates[gt];
			if (!gate_open(gt)) strcpy(promptText, "Boarded up. The story will open it");
			else if (g->kind) strcpy(promptText, "A: Step into the Shimmering Rift");
			else if (S.depDone & (1 << g->zone)) sprintf(promptText, "A: Enter %s (cleared)", depth_names[g->zone]);
			else if (S.depFloor[g->zone] > 1) sprintf(promptText, "A: Enter %s (floor %d)", depth_names[g->zone], S.depFloor[g->zone]);
			else sprintf(promptText, "A: Enter %s", depth_names[g->zone]);
		}
		else if (sl >= 0) {
			int z = sealpts[sl].zone, k = seal_key(z); slSt = seal_state(z);
			char ic[2] = { (char)(0x80 + elem_icon(k)), 0 };
			if (slSt == 1) sprintf(promptText, "A: %s the %s %s", seal_verb[z], seal_name[z], ic);
			else if (slSt == 2) sprintf(promptText, "Equip your %s weapon %s to break this", elem_name[k], ic);
			else if (slSt == 3) sprintf(promptText, "A: Hack through the %s", seal_name[z]);
			else sprintf(promptText, "The %s: only %s %s can break it", seal_name[z], elem_name[k], ic);
		}
		else 		if (stall) strcpy(promptText, bankMode ? "A: Open Bram's strongbox" : "A: Browse Bram's stall");
		else if (npc >= 0) sprintf(promptText, npc == NPC_BOARD ? "A: Read the Bounty Board" : "A: Talk to %s", npcdefs[npc].name);
		else if (bl >= 0) { int sl = blddefs[bl].station - 1; if (S.holdN[sl]) sprintf(promptText, "A: Collect from %s (%d)", station_name(blddefs[bl].station), S.holdN[sl]); else sprintf(promptText, "A: Look at the %s", blddefs[bl].name); }
		else if (ch >= 0) sprintf(promptText, chests[ch].golden ? "A: Open golden chest" : "A: Open chest");
		else if (nd >= 0) {
			Node* n = &nodes[nd];
			if (n->type == ND_KITTEN) sprintf(promptText, "A: Pick up the kitten");
			else if (n->type == ND_DIG) sprintf(promptText, "A: Dig here");
			else sprintf(promptText, "A: %s %s%s", node_verb[n->type], itemd(node_item[n->type])->name, n->type == ND_MOONBLOOM ? " " IS_MOON : "");
		}
	}
	if ((kd & KEY_A) && !D.on && !shopOpen) {
		if (stall) { shopOpen = true; shopSel = 0; tab = 0; sfx(SFX_PICK); P.yaw = atan2f((bankMode ? BANK_X : STALL_X) - P.p.x, (bankMode ? BANK_Z : STALL_Z) - P.p.z); }
		else if (npc >= 0) { talk(npc); P.yaw = atan2f(npcdefs[npc].x - P.p.x, npcdefs[npc].z - P.p.z); }
		else if (bl >= 0) building_use(bl);
		else if (ch >= 0) open_chest(ch);
		else if (nd >= 0) gather(nd);
		else if (dw) dun_use(dw);
		else if (gt >= 0 && gate_open(gt)) dun_enter(gt);
		else if (sl >= 0 && (slSt == 1 || slSt == 3)) break_seal(sealpts[sl].zone);
		else if (P.atkCd <= 0 && P.rollT <= 0 && spend_sta(P.comboT > 0 && P.combo == 2 ? 18 : 12)) {
			P.aHeld = true; P.chargeT = 0;
			P.combo = P.comboT > 0 ? P.combo + 1 : 1;
			if (P.combo > 3) P.combo = 1;
			P.finisher = P.combo == 3;
			P.atkT = P.finisher ? 0.36f : 0.3f; P.atkCd = P.finisher ? 0.5f : 0.3f; P.hitDone = false; P.comboT = 0.65f;
			if (frenzyT > 0) { P.atkCd *= 0.6f; P.atkT *= 0.8f; }
			sfx_pitch(SFX_SWING, P.finisher ? 0.8f : 1.0f + P.combo * 0.08f);
			// lunge a little toward nearest enemy in front
			float best = 3.0f; int bi = -1;
			for (int i = 0; i < MAX_EN; i++) if (en[i].on && en[i].state != ES_DEAD) { float d = dist2d(P.p.x, P.p.z, en[i].p.x, en[i].p.z); if (d < best) { best = d; bi = i; } }
			if (bi >= 0 && mag == 0) P.yaw = atan2f(en[bi].p.x - P.p.x, en[bi].p.z - P.p.z);
		}
	}
	// hold A after a swing to charge a heavy blow; let go to unleash it (breaks guards and shields)
	if (P.aHeld) {
		if (!(kh & KEY_A) || D.on || shopOpen) {
			if (P.chargeT >= 0.55f && P.rollT <= 0 && !D.on && spend_sta(26)) {
				P.heavy = true; P.finisher = true; P.combo = 3; P.atkT = 0.42f; P.atkCd = 0.6f; P.hitDone = false; P.comboT = 0;
				sfx_pitch(SFX_SWING, 0.6f); shake = 0.12f;
			}
			P.aHeld = false; P.chargeT = 0;
		} else if (P.atkT <= 0) {
			P.chargeT += dt;
			if (P.chargeT > 0.55f && rndf() < dt * 20) spawn_part(v3add(P.p, v3(rndr(-0.5f, 0.5f), rndr(0.2f, 1.4f), rndr(-0.5f, 0.5f))), v3(0, 2, 0), 0.4f, 0.1f, S.weapon.elem ? elem_col[S.weapon.elem] : 0xFFE9A0, 0, 1.0f, MESH_OCTA);
		}
	}
	if (P.rollT > 0) P.rollAge += dt;
	if (kd & KEY_X) use_tonic(); // X drinks a tonic any time
	if (whirlCd > 0) whirlCd -= dt; if (phoenixCd > 0) phoenixCd -= dt; if (lastStandCd > 0) lastStandCd -= dt; if (frenzyT > 0) frenzyT -= dt;
	if (has_af(AF_MEND) && P.noDmgT > 4 && S.hp < P.maxhp) { S.hp += P.maxhp * 0.02f * dt; if (S.hp > P.maxhp) S.hp = P.maxhp; }
	if (echoT > 0) { echoT -= dt; if (echoT <= 0) { burst(v3add(P.p, v3(sinf(P.yaw), 1, cosf(P.yaw))), 10, 0xB8E8FF, 3, 3, 0.3f, 0.1f, 1.0f); player_attack_hits(); } }
	if (P.rollT > 0 && (has_lp(LP_EMBERS) || has_pk(PK_CHARGE))) for (int i = 0; i < MAX_EN; i++) { Enemy* o = &en[i];
		if (!o->on || o->state == ES_DEAD || o->rseq == rollSeq || dist2d(o->p.x, o->p.z, P.p.x, P.p.z) > 1.5f + endefs[o->type].radius) continue;
		o->rseq = rollSeq;
		if (has_lp(LP_EMBERS)) { o->burnT = 3.5f; if (o->burnDps < weapon_power() * 0.35f) o->burnDps = weapon_power() * 0.35f; }
		if (has_pk(PK_CHARGE)) { o->stunT = o->boss ? 0.3f : 0.7f; if (o->state == ES_WINDUP && !o->boss) o->state = ES_CHASE; hit_enemy(o, weapon_power() * 0.6f, false, false, ""); } }
	if (has_lp(LP_STORMS) && S.hp > P.maxhp * 0.7f) { stormT -= dt; if (stormT <= 0) { stormT = 1.2f; Enemy* best = NULL; float bd = 6; for (int i = 0; i < MAX_EN; i++) { Enemy* o = &en[i]; if (!o->on || o->state == ES_DEAD) continue; float dd = dist2d(o->p.x, o->p.z, P.p.x, P.p.z); if (dd < bd) { bd = dd; best = o; } }
		if (best && best->state != ES_IDLE) { burst(v3add(best->p, v3(0, 1, 0)), 12, 0xFFE14A, 4, 6, 0.4f, 0.1f, 1.0f); sfx_pitch(SFX_CRIT, 1.5f); hit_enemy(best, weapon_power() * 0.6f, false, false, ""); } } }
	if ((kd & KEY_ZR) && has_pk(PK_WHIRL) && whirlCd <= 0 && P.rollT <= 0 && !D.on && !shopOpen && spend_sta(25)) { // Whirlwind
		whirlCd = 5; sfx_pitch(SFX_SWING, 0.7f); shake = 0.15f;
		for (int k = 0; k < 20; k++) { float a = k * TAU / 20; spawn_part(v3add(P.p, v3(cosf(a) * 1.8f, 0.9f, sinf(a) * 1.8f)), v3(-sinf(a) * 6, 0.3f, cosf(a) * 6), 0.35f, 0.12f, 0xE8F0FF, 0, 1.0f, MESH_OCTA); }
		float pw = weapon_power() * (1 + 0.02f * (S.lvl - 1)) * (1 + 0.03f * S.buffLv) * (pylT[0] > 0 ? 2.0f : 1.0f);
		for (int i = 0; i < MAX_EN; i++) { Enemy* o = &en[i]; if (!o->on || o->state == ES_DEAD || dist2d(o->p.x, o->p.z, P.p.x, P.p.z) > 2.7f + endefs[o->type].radius) continue;
			hit_enemy(o, pw * 1.3f, false, true, ""); if (o->on && o->state != ES_DEAD) apply_element(o, S.weapon.used ? S.weapon.elem : 0, pw); }
		P.yaw += PI; }

	if (P.inv > 0) P.inv -= dt;
	if (P.grace > 0) P.grace -= dt;
	if (P.hurtT > 0) P.hurtT -= dt;
	P.noDmgT += dt;
	// no passive regeneration: heal with Healing Tonics (bought from Bram or crafted)
	if (P.closeCall && P.noDmgT > 4) { P.closeCall = false; ach(A_CLOSE); }
}

static void update_drops(float dt) {
	float magnet = 2.6f * (1 + charm_val(2) / 100.f);
	for (int i = 0; i < MAX_DROPS; i++) {
		Drop* d = &drops[i]; if (!d->on) continue;
		d->t += dt;
		float dx = P.p.x - d->p.x, dy = P.p.y + 0.8f - d->p.y, dz = P.p.z - d->p.z;
		float dist = sqrtf(dx*dx + dy*dy + dz*dz);
		float mg = (d->kind == 2 ? 2.4f : (d->kind == 3 ? 1.5f * (1 + charm_val(2) / 200.f) : magnet)) * (has_pk(PK_REACH) ? 2 : 1);
		float wait = d->kind == 3 ? 0.3f : 0.55f;
		if (d->kind == 3) { float hd = sqrtf(dx*dx + dz*dz); if (hd < mg && fabsf(dy) < 2.6f) dist = 0; else dist = 99; } // flat reach, generous height
		bool full = d->kind == 1 && item_full(d->item);
		if (d->fullT > 0) d->fullT -= dt;
		if (full && d->t > wait && dist < 1.3f && P.deadT <= 0 && d->fullT <= 0) { // can't carry it: it hops off you
			float hx = -dx, hz = -dz, hl_ = sqrtf(hx*hx + hz*hz) + 0.01f;
			d->v = v3(hx / hl_ * 3, 6, hz / hl_ * 3); d->settled = false; d->fullT = 1.5f;
			ftext(v3add(d->p, v3(0, 0.9f, 0)), "POUCH FULL", 0xFF9A4A, 1);
			if (d->kind == 0) hudCoinFullT = 1.6f; else hudBagFullT = 1.6f;
		}
		if (full) dist = 99; // no magnet while you're full
		if (d->t > wait && dist < mg && P.deadT <= 0) {
			// speed is capped and never overshoots: an old drop (it ages while you're full) used to fly straight past you
			float sp = d->kind == 3 ? 6 + d->t : 9 + d->t * 6; if (sp > 24) sp = 24;
			float step = sp * dt; if (step > dist) step = dist;
			d->p.x += dx / dist * step; d->p.y += dy / dist * step; d->p.z += dz / dist * step;
			d->settled = false;
			if (dist - step < 0.55f || d->kind == 3) { // XP is taken the instant you touch it
				d->on = false;
				pickComboT = 1.2f; pickCombo = pickCombo < 12 ? pickCombo + 1 : 12;
				if (d->kind == 0) { int t = gain_gold(d->amount); if (t < d->amount) { d->amount -= t; d->on = true; d->v = v3(0, 5, 0); d->settled = false; d->fullT = 1.5f; } hud_fly(1, 0, 1 + (d->amount > 6)); sfx_pitch(SFX_COIN, powf(2.f, (pickCombo - 1) / 12.f)); }
				else if (d->kind == 1) { give_item(d->item, 1, false); sfx_pitch(SFX_PICK, powf(2.f, (pickCombo - 1) / 12.f)); }
				else if (d->kind == 3) { add_xp(d->amount); hud_fly(0, 0, 3 + (d->amount > 10) + (d->amount > 30)); burst(d->p, 10, 0x3FA0FF, 2.5f, 4, 0.5f, 0.1f, 1.0f); sfx_pitch(SFX_PICK, 1.5f * powf(2.f, (pickCombo - 1) / 24.f)); char b[16]; sprintf(b, "+%d XP", d->amount); ftext(v3add(P.p, v3(rndr(-0.4f, 0.4f), 2.0f, 0)), b, 0x6AB4FF, 1); }
				else { give_gear(d->g); sfx(d->g.rarity >= R_RARE ? SFX_LOOT_RARE : SFX_PICK); burst(d->p, 14, rarity_col[d->g.rarity], 3, 5, 0.7f, 0.12f, 0.9f); }
			}
			continue;
		}
		if (!d->settled) {
			d->v.y -= 22 * dt;
			d->p = v3add(d->p, v3mul(d->v, dt));
			float g = ground_h(d->p.x, d->p.z); if (g < -0.1f) g = -0.1f;
			if (d->p.y < g + 0.25f) {
				d->p.y = g + 0.25f;
				if (d->kind == 3) {
					// XP lands and stays put; if it landed in deep water or inside a prop, pull it back to where the foe fell
					float nx, nz;
					for (int k = 0; k < 8 && (ground_h(d->p.x, d->p.z) < -0.3f || world_blocked(d->p.x, d->p.z, 0.35f, &nx, &nz)); k++) { d->p.x = lerpf(d->p.x, d->ox, 0.35f); d->p.z = lerpf(d->p.z, d->oz, 0.35f); }
					d->p.y = fmaxf(ground_h(d->p.x, d->p.z), -0.1f) + 0.25f;
					d->settled = true; d->v = v3(0, 0, 0);
				}
				else if (fabsf(d->v.y) < 1.5f) { d->settled = true; d->v = v3(0,0,0); }
				else { d->v.y = -d->v.y * 0.42f; d->v.x *= 0.6f; d->v.z *= 0.6f; }
			}
		}
		if (d->t > DROP_LIFE && d->kind != 3) d->on = false; // coins, items and gear vanish after 5 minutes (something carries them off)
	}
}

static void update_misc(float dt) {
	for (int i = 0; i < MAX_PART; i++) {
		Part* q = &parts[i]; if (!q->on) continue;
		q->life -= dt; if (q->life <= 0) { q->on = false; continue; }
		q->v.y -= q->grav * dt;
		q->p = v3add(q->p, v3mul(q->v, dt));
		q->v.x *= powf(0.3f, dt); q->v.z *= powf(0.3f, dt);
	}
	for (int i = 0; i < MAX_FTXT; i++) if (ftx[i].on) { ftx[i].t += dt; if (ftx[i].t > ftx[i].life) ftx[i].on = false; }
	for (int i = 0; i < 6; i++) feed[i].t += dt;
	if (toastN > 0) {
		toastQ[0].t += dt;
		if (toastQ[0].t > 2.6f) { for (int i = 1; i < toastN; i++) toastQ[i-1] = toastQ[i]; toastN--; }
	}
	if (zoneBannerT > 0) zoneBannerT -= dt;
	if (levelFlashT > 0) levelFlashT -= dt;
	if (pickComboT > 0) { pickComboT -= dt; if (pickComboT <= 0) pickCombo = 0; }
	// nodes regrow
	for (int i = 0; i < nnodes; i++) {
		Node* n = &nodes[i];
		n->wob += dt;
		if (n->pop > 0) n->pop -= dt;
		if (!n->alive && n->type != ND_KITTEN) {
			n->regrow -= dt;
			if (n->regrow <= 0 && dist2d(P.p.x, P.p.z, n->x, n->z) > 8) {
				if (n->type == ND_DIG) { float x, z; if (find_spot(n->zone, &x, &z, 0.8f)) { n->x = x; n->z = z; n->y = ground_h(x, z); } }
				n->alive = true; n->pop = -0.3f;
			}
		}
		if (n->type == ND_DIG && n->alive && rndf() < dt * 3 && dist2d(P.p.x, P.p.z, n->x, n->z) < 30)
			spawn_part(v3(n->x + rndr(-0.3f, 0.3f), n->y + 0.3f, n->z + rndr(-0.3f, 0.3f)), v3(0, 1.5f, 0), 0.8f, 0.07f, 0xFFF2A0, -0.5f, 1, MESH_OCTA);
	}
	// kittens mew when you're close
	if (QS(Q_T0) == QS_ACTIVE) {
		mewT -= dt;
		for (int k = 0; k < 3; k++) {
			if (S.kittens & (1 << k)) continue;
			float d = dist2d(P.p.x, P.p.z, kittenPos[k][0], kittenPos[k][1]);
			if (d < 14 && mewT <= 0) { mewT = rndr(2.5f, 4); sfx_pitch(SFX_MEOW, rndr(1.0f, 1.25f)); ftext(v3(kittenPos[k][0], ground_h(kittenPos[k][0], kittenPos[k][1]) + 1.2f, kittenPos[k][1]), "mew!", 0xFFB0E0, 1); }
		}
	}
	// chest lids
	for (int i = 0; i < nchests; i++) if (chests[i].openT > 0 && chests[i].openT < 1) chests[i].openT += dt * 3;
}

// ------------------------------------------------------------ world events
WorldEvent EV;
static float evCooldown = 60;
static int evForce = -1; // the first event after its quest is accepted is that type
// each event type only appears once its quest has been taken
static bool ev_allowed(int type) { return QS(type == EVT_PORTAL ? Q_EV1 : Q_EV0) >= QS_ACTIVE; }
void event_unlocked(int type) { evForce = type; if (!EV.on && evCooldown > 25) evCooldown = 25; }
// 'heavy combat': foes on you, a boss in play, or you were just hit
static bool in_heavy_combat(void) {
	if (P.noDmgT < 6) return true;
	int n = 0;
	for (int i = 0; i < MAX_EN; i++) {
		Enemy* e = &en[i]; if (!e->on || e->state == ES_DEAD) continue;
		if (dist2d(e->p.x, e->p.z, P.p.x, P.p.z) > 16) continue;
		if (e->boss) return true;
		if (e->state == ES_CHASE || e->state == ES_WINDUP) n++;
	}
	return n >= 2;
}
const char* event_name(void) { return EV.type == EVT_PORTAL ? "Portal Rift" : "Monster Surge"; }
void event_progress_text(char* buf) {
	int left = (int)ceilf(EV.dur - EV.t); if (left < 0) left = 0;
	if (EV.type == EVT_PORTAL) sprintf(buf, "Keys %d/%d  %d:%02d", EV.keyGot, EV.nkeys, left / 60, left % 60);
	else sprintf(buf, "Defeat %d/%d  %d:%02d", EV.prog > EV.need ? EV.need : EV.prog, EV.need, left / 60, left % 60);
}
static bool event_spot_ok(float x, float z, float clear) {
	if (fabsf(x) > WORLD_HALF - 4 || fabsf(z) > WORLD_HALF - 4) return false;
	int zn = zone_at(x, z); if (zn == Z_VILLAGE || !zone_open(zn)) return false;
	if (ground_h(x, z) < 0.1f || sqrtf(x*x + z*z) < ENEMY_RING + 4) return false;
	for (int b = 1; b < Z_COUNT; b++) if (dist2d(x, z, arena_pos[b][0], arena_pos[b][1]) < 11) return false;
	float nx, nz; return !world_blocked(x, z, clear, &nx, &nz);
}
static void event_start(void) {
	for (int tries = 0; tries < 30; tries++) {
		float a = rndf() * TAU, r = rndr(18, 26);
		float x = P.p.x + cosf(a) * r, z = P.p.z + sinf(a) * r;
		if (!event_spot_ok(x, z, 2.0f)) continue;
		memset(&EV, 0, sizeof EV);
		EV.on = true; EV.x = x; EV.z = z;
		if (evForce >= 0) EV.type = evForce;
		else if (ev_allowed(EVT_PORTAL) && ev_allowed(EVT_HORDE)) EV.type = rndf() < 0.5f ? EVT_PORTAL : EVT_HORDE;
		else EV.type = ev_allowed(EVT_PORTAL) ? EVT_PORTAL : EVT_HORDE;
		evForce = -1;
		if (EV.type == EVT_PORTAL) {
			EV.nkeys = S.lvl >= 8 ? 5 : 4; EV.dur = 200; // generous
			int k = 0;
			for (int t2 = 0; t2 < 200 && k < EV.nkeys; t2++) {
				float ka = rndf() * TAU, kr = rndr(10, 28), kx = x + cosf(ka) * kr, kz = z + sinf(ka) * kr;
				if (!event_spot_ok(kx, kz, 0.7f)) continue;
				bool spaced = true; for (int j = 0; j < k; j++) if (dist2d(kx, kz, EV.kx[j], EV.kz[j]) < 7) spaced = false;
				if (!spaced) continue;
				EV.kx[k] = kx; EV.kz[k] = kz; k++;
			}
			if (k < 3) { EV.on = false; continue; }
			EV.nkeys = k;
		} else {
			EV.need = 6 + S.lvl / 3; EV.dur = 120;
		}
		toast("WORLD EVENT!", EV.type == EVT_PORTAL ? "A portal tore open nearby: find the keys!" : "Monsters are surging nearby!", 0xFF8A3A, 2);
		strcpy(zoneBanner, event_name()); zoneBannerT = 3.0f; zoneBannerCol = 0xFFAA5A;
		sfx(SFX_LOOT_EPIC);
		if (!guideOn || S.tracked != TRACK_MAIN) { S.tracked = TRACK_EVENT; guideOn = true; guideBounty = false; }
		return;
	}
	evCooldown = 6; // nowhere suitable: try again shortly
}
static void event_end(bool won) {
	bool portal = EV.type == EVT_PORTAL;
	EV.on = false;
	if (S.tracked == TRACK_EVENT) { S.tracked = mq_active() ? TRACK_MAIN : -1; if (S.tracked < 0) guideOn = false; }
	if (!won) { toast("EVENT FAILED", "It slipped away. More will come.", 0x9A9AB0, 0); sfx(SFX_HURT); evCooldown = rndr(100, 160); return; }
	V3 at = v3add(P.p, v3(0, 0.5f, 0));
	drop_coins(at, 40 + S.lvl * 12, 10);
	drop_xp(at, 8 + S.lvl * 2);
	lootTable = 0;
	if (rndf() < (portal ? 0.6f : 0.4f)) drop_gear(at, gen_gear(-1, R_UNCOMMON, S.lvl + 1));
	if (rndf() < 0.5f) drop_item(at, IT_TONIC);
	S.sEvents++;
	if (portal) { S.sPortals++; quest_credit(QT_PORTAL); } else quest_credit(QT_EVENT);
	toast("EVENT COMPLETE!", portal ? "The portal collapses in a shower of loot" : "The surge is broken!", 0xFFD23F, 1);
	sfx(SFX_QUEST); sfx(SFX_LOOT_RARE);
	burst(v3add(P.p, v3(0, 1, 0)), 40, portal ? 0xB070FF : 0xFF8A3A, 6, 10, 1.3f, 0.16f, 1.0f);
	shake = 0.3f;
	evCooldown = rndr(150, 240);
	do_save();
}
static float evSpawnT;
static void update_events(float dt) {
	if (!EV.on) {
		if (!ev_allowed(EVT_HORDE) && !ev_allowed(EVT_PORTAL)) return;
		if (curZone != Z_VILLAGE && curZone >= 0 && !D.on && !G.on && !in_heavy_combat()) {
			evCooldown -= dt;
			if (evCooldown <= 0) event_start();
		}
		return;
	}
	EV.t += dt;
	if (EV.t >= EV.dur) { event_end(false); return; }
	if (EV.type == EVT_PORTAL) {
		for (int k = 0; k < EV.nkeys; k++) if (!(EV.prog & (1 << k)) && dist2d(P.p.x, P.p.z, EV.kx[k], EV.kz[k]) < 1.7f) {
			EV.prog |= 1 << k; EV.keyGot++;
			sfx(SFX_CHEST); sfx_pitch(SFX_PICK, 1.3f);
			burst(v3(EV.kx[k], ground_h(EV.kx[k], EV.kz[k]) + 1, EV.kz[k]), 20, 0xFFD23F, 3, 6, 0.8f, 0.12f, 1.0f);
			char b[32]; sprintf(b, "Key %d/%d!", EV.keyGot, EV.nkeys); ftext(v3add(P.p, v3(0, 2.4f, 0)), b, 0xFFD23F, 2);
			if (EV.keyGot >= EV.nkeys) { event_end(true); return; }
		}
	} else {
		if (EV.prog >= EV.need) { event_end(true); return; }
		evSpawnT -= dt;
		if (evSpawnT <= 0) {
			evSpawnT = 2.2f;
			int near = 0;
			for (int i = 0; i < MAX_EN; i++) if (en[i].on && en[i].state != ES_DEAD && !en[i].boss && dist2d(en[i].p.x, en[i].p.z, EV.x, EV.z) < 16) near++;
			if (near < 5 && dist2d(P.p.x, P.p.z, EV.x, EV.z) < 40) {
				int zn = zone_at(EV.x, EV.z); if (zn == Z_VILLAGE) zn = Z_MEADOW;
				float a = rndf() * TAU, x = EV.x + cosf(a) * rndr(2, 7), z = EV.z + sinf(a) * rndr(2, 7);
				float nx, nz;
				if (ground_h(x, z) > 0.05f && !world_blocked(x, z, 0.6f, &nx, &nz)) {
					int t = night_now() && rndf() < 0.3f ? EN_MOTH : zone_enemies[zn][rndf() < 0.6f ? 0 : 1];
					Enemy* e = spawn_enemy(t, x, z); if (e) { e->state = ES_CHASE; burst(v3(x, ground_h(x, z) + 0.5f, z), 12, 0xFF8A3A, 3, 5, 0.6f, 0.12f, 0.9f); }
				}
			}
		}
	}
}
bool quest_night(int q) {
	const QuestDef* d = &questdefs[q];
	return (d->type == QT_KILL && (d->target == FAM_MOTH || d->target == FAM_GAUNT)) || (d->type == QT_FORAGE && item_night(d->target));
}

bool night_now(void) { return S.tod > 0.63f && S.tod < 0.93f; }
static void update_sky(float dt) {
	S.tod += dt / 480.f; if (S.tod >= 1) S.tod -= 1;
	// key colours: dawn .0, day .1-.5, dusk .58, night .68-.88, dawn .97
	static const float kt[] = { 0.0f, 0.08f, 0.5f, 0.58f, 0.66f, 0.9f, 0.97f, 1.0f };
	static const u32 kc[] = { 0xF4B48C, 0x8CC8F0, 0x8CC8F0, 0xF29A6E, 0x1E2A54, 0x1E2A54, 0xE8A07E, 0xF4B48C };
	static const float ka[] = { 0.42f, 0.47f, 0.47f, 0.40f, 0.30f, 0.30f, 0.40f, 0.42f };
	static const float kl[] = { 0.6f, 0.75f, 0.75f, 0.6f, 0.22f, 0.22f, 0.55f, 0.6f };
	int i = 0; while (i < 6 && S.tod > kt[i+1]) i++;
	float t = (S.tod - kt[i]) / (kt[i+1] - kt[i]);
	u32 a = kc[i], b = kc[i+1];
	int r = (int)lerpf((a>>16)&255, (b>>16)&255, t), g = (int)lerpf((a>>8)&255, (b>>8)&255, t), bb = (int)lerpf(a&255, b&255, t);
	rp.sky = (r<<16)|(g<<8)|bb;
	rp.ambient = lerpf(ka[i], ka[i+1], t);
	rp.light = lerpf(kl[i], kl[i+1], t);
	bool nt = night_now();
	rp.lightTint[0] = nt ? 0.7f : 1.0f; rp.lightTint[1] = nt ? 0.8f : 0.97f; rp.lightTint[2] = nt ? 1.2f : 0.92f;
	rp.fogStart = 19; rp.fogEnd = 40;
	if (dunOn) { // torchlit dark below ground
		rp.sky = DG.kind ? 0x150B22 : 0x0D0A0A; rp.ambient = 0.40f; rp.light = 0.62f;
		rp.lightTint[0] = 1.05f; rp.lightTint[1] = 0.9f; rp.lightTint[2] = DG.kind ? 1.1f : 0.75f;
		rp.fogStart = DG.mod == 2 ? 3 : 9; rp.fogEnd = DG.mod == 2 ? 11 : 24;
	}
	music_set_night(nt);
	if (nt && curZone != Z_VILLAGE) ach(A_NIGHT);
	// fireflies at night
	if (nt && rndf() < dt * 6) spawn_part(v3(P.p.x + rndr(-12, 12), P.p.y + rndr(0.5f, 2.5f), P.p.z + rndr(-12, 12)), v3(rndr(-0.3f, 0.3f), rndr(-0.2f, 0.3f), rndr(-0.3f, 0.3f)), 3.5f, 0.07f, 0xD8FF6A, 0, 1.2f, MESH_OCTA);
}

static void update_camera(float dt, u32 kh, u32 kd) {
	if (kh & KEY_L) camYaw += dt * 2.2f;
	if (kh & KEY_R) camYaw -= dt * 2.2f;
	float tx = P.p.x, ty = P.p.y + 1.0f, tz = P.p.z;
	float dist = 7.6f, hgt = 5.2f;
	bool ots = S.optCam == 1;
	if (endingT > 0 && endingT < 9) { ots = false; tx = 0; tz = 0; ty = 2.5f; dist = 12; hgt = 5 + endingT * 0.4f; camYaw += dt * 0.35f; }
	float cx, cz, cy;
	if (ots) { // over the shoulder: low and close, player off to one side, looking ahead (tunable in the pause menu)
		float side = (S.camAdj[0] - 10) * 0.15f, up = 1.25f + S.camAdj[1] * 0.1f, back = 1.9f + S.camAdj[2] * 0.15f;
		float tilt = (-10.f + S.camAdj[3] * 1.7f) * PI / 180.f, ahead = 4.0f;
		float fx = sinf(camYaw), fz = cosf(camYaw), rx = -fz, rz = fx;
		cx = P.p.x - fx * back + rx * side; cz = P.p.z - fz * back + rz * side; cy = P.p.y + up;
		tx = P.p.x + fx * ahead + rx * side; tz = P.p.z + fz * ahead + rz * side; ty = cy - tanf(tilt) * (back + ahead);
	} else { cx = tx - sinf(camYaw) * dist; cz = tz - cosf(camYaw) * dist; cy = ty + hgt; }
	float gh = ground_h(cx, cz) + (ots ? 0.6f : 1.5f); if (cy < gh) cy = gh;
	float k = clampf(dt * 8, 0, 1);
	rp.tx = lerpf(rp.tx, tx, k); rp.ty = lerpf(rp.ty, ty, k); rp.tz = lerpf(rp.tz, tz, k);
	rp.camx = lerpf(rp.camx, cx, k); rp.camy = lerpf(rp.camy, cy, k); rp.camz = lerpf(rp.camz, cz, k);
	if (shake > 0) { shake -= dt; rp.shakeX = rndr(-1, 1) * shake * 0.6f; rp.shakeY = rndr(-1, 1) * shake * 0.6f; } else rp.shakeX = rp.shakeY = 0;
	rp.focal = ots ? 3.4f : 3.6f; // convergence close to the camera: the whole world sits behind the screen, HUD stays in front
}

// ------------------------------------------------------------ save / load / setup
// Saving runs on a background thread: an SD card write can block for hundreds of
// milliseconds, which froze the game every autosave / achievement / chest.
static Thread saveThread;
static LightEvent saveEv;
static LightLock saveLock;
static Save saveBuf;
static volatile bool saveQuit, saveThreadOn;
static void write_save_file(const Save* sv) {
	FILE* f = fopen(SAVE_PATH, "wb");
	if (!f) return;
	fwrite(sv, sizeof *sv, 1, f);
	fclose(f);
}
static void save_worker(void* arg) {
	(void)arg;
	static Save local;
	while (true) {
		LightEvent_Wait(&saveEv);
		if (saveQuit) break;
		LightLock_Lock(&saveLock);
		local = saveBuf;
		LightLock_Unlock(&saveLock);
		write_save_file(&local);
	}
}
static void save_system_init(void) {
	mkdir("sdmc:/3ds", 0777);
	LightEvent_Init(&saveEv, RESET_ONESHOT);
	LightLock_Init(&saveLock);
	s32 prio = 0x30; svcGetThreadPriority(&prio, CUR_THREAD_HANDLE);
	saveThread = threadCreate(save_worker, NULL, 16 * 1024, prio + 1, -2, false);
	saveThreadOn = saveThread != NULL;
#ifdef HM_NOSAVETHREAD
	saveThreadOn = false;
#endif
}
static void save_system_exit(void) {
	if (!saveThreadOn) return;
	saveQuit = true;
	LightEvent_Signal(&saveEv);
	threadJoin(saveThread, U64_MAX);
	threadFree(saveThread);
	saveThreadOn = false;
}
void do_save(void) {
	S.magic = SAVE_MAGIC; S.version = SAVE_VER;
	S.px = P.p.x; S.pz = P.p.z; S.yaw = P.yaw;
	if (dunOn) { S.px = gates[DG.gate].x * 0.94f; S.pz = gates[DG.gate].z * 0.94f; } // a save from below resumes at the door
	hasSave = true;
	if (!saveThreadOn) { write_save_file(&S); return; }
	LightLock_Lock(&saveLock);
	saveBuf = S;          // snapshot; the worker always writes the latest one
	LightLock_Unlock(&saveLock);
	LightEvent_Signal(&saveEv);
}
// v1.21 replaced the main story. The old one (Marigold's ledger) became quests Q_L0-L5;
// the new story resumes at the first chapter this save hasn't already covered.
static void migrate_story_v12(Save* sv) {
	#define MQS(q) (*(q < Q_COUNT_V1 ? &sv->qs[q] : q < Q_COUNT_V1 + 8 ? &sv->qs2[q - Q_COUNT_V1] : &sv->qs3[q - Q_COUNT_V1 - 8]))
	for (int q = 0; q < Q_COUNT; q++) if (MQS(q) == QS_ACTIVE && questdefs[q].type == QT_FORAGE) { u16* pp = q < Q_COUNT_V1 ? &sv->qprog[q] : q < Q_COUNT_V1 + 8 ? &sv->qprog2[q - Q_COUNT_V1] : &sv->qprog3[q - Q_COUNT_V1 - 8]; int t = questdefs[q].target; *pp = t < IT_COUNT ? sv->items[t] : sv->xitems[t - IT_COUNT]; }
	int old = sv->mq; // ledger chapters 0-5
	for (int k = 0; k < 6; k++) MQS(Q_L0 + k) = k < old ? QS_DONE : (k == old && sv->mqState == 1 ? QS_ACTIVE : QS_LOCKED);
	int c = 0;
	for (; c < MQ_COUNT; c++) {
		const MainQuest* m = &mainq[c]; bool ok = false;
		if (c == 0) ok = MQS(Q_E0) == QS_DONE;
		else if (m->type == MQT_QUEST) ok = MQS(m->target) == QS_DONE;
		else if (m->type == MQT_TALK) { int n = m->target; if (n == NPC_BOARD) ok = sv->sBounties > 0 || sv->bActive; else if (n == NPC_MARI) ok = old > 0; else for (int q = 0; q < Q_COUNT; q++) if (questdefs[q].giver == n && MQS(q) >= QS_ACTIVE) ok = true; }
		if (!ok) break;
	}
	sv->mq = c; sv->mqState = 0; sv->mqProg = 0;
	{ float r = sqrtf(sv->px * sv->px + sv->pz * sv->pz); if (r > ISLAND_R0) { float k = (ISLAND_R0 + (r - ISLAND_R0) * 2) / r; sv->px *= k; sv->pz *= k; } } // island doubled
	if (sv->tracked == TRACK_MAIN) sv->tracked = -1;
	#undef MQS
}
static bool read_save(Save* out) {
	FILE* f = fopen(SAVE_PATH, "rb");
	if (!f) return false;
	memset(out, 0, sizeof *out);
	size_t n = fread(out, 1, sizeof *out, f);
	fclose(f);
	if (n < offsetof(Save, armor) || out->magic != SAVE_MAGIC) return false;
	// migrate older saves: appended fields start zeroed
	if (out->version == 3) { memset(&out->armor, 0, sizeof *out - offsetof(Save, armor)); out->version = 4; }
	if (out->version == 4) { memset(&out->xitems, 0, sizeof *out - offsetof(Save, xitems)); out->version = 5; }
	if (out->version == 5) { memset(&out->jobs, 0, sizeof *out - offsetof(Save, jobs)); out->version = 6; }
	if (out->version == 6) { memset(&out->qs2, 0, sizeof *out - offsetof(Save, qs2)); out->version = 7; }
	if (out->version == 7) { memset(&out->doneR, 0, sizeof *out - offsetof(Save, doneR)); out->version = 8; }
	if (out->version == 8) { memset(&out->qs3, 0, sizeof *out - offsetof(Save, qs3)); out->optLevels = 1; out->version = 9; }
	if (out->version == 9) { memset(&out->optCam, 0, sizeof *out - offsetof(Save, optCam)); out->optDiff = 75; island_save_remap(&out->px, &out->pz); out->version = 10; }
	if (out->version == 10) { memcpy(out->camAdj, CAM_ADJ_DEF, 4); out->version = 11; }
	if (out->version == 11) { memset(out->sWeak, 0, sizeof out->sWeak + sizeof out->sWard); migrate_story_v12(out); out->version = 12; }
	if (out->version == 12) { memset(&out->worldLvl, 0, 8); out->worldLvl = out->lvl; out->rumbleN = 2; out->version = 13; }
	if (out->version == 13) { memset(&out->staLv, 0, 8); out->spawnPct = 25; out->version = 14; }
	if (out->version == 14) { memset(&out->bank, 0, sizeof *out - offsetof(Save, bank)); out->packPts = out->bagLv; out->fortuneLv = out->purseLv; out->version = 15; } // purse/pack levels refunded as pack points and fortune
	if (out->version == 15) { // v16: element seals. Anywhere you've been, or whose islander you've met, starts open
		out->seals = out->zonesVisited & ~3u;
		const int zn[4] = { Z_BEACH, Z_FOREST, Z_SWAMP, Z_RUINS }, np[4] = { NPC_GUS, NPC_FERN, NPC_ODESSA, NPC_RUST };
		for (int k = 0; k < 4; k++) if (out->mq > npc_meet_ch[np[k]]) out->seals |= 1 << zn[k];
		out->version = 16;
	}
	if (out->version == 16) { memset(out->depFloor, 0, sizeof *out - offsetof(Save, depFloor)); out->version = 17; }
	if (out->version == 17) { out->riftTier = out->riftTier + 1; memset(&out->depNote, 0, sizeof *out - offsetof(Save, depNote)); out->version = 18; }
	if (out->version == 18) { out->perks = 0; out->perkPicks = out->lvl / 3; out->pad19 = 0; out->version = SAVE_VER; } // v19: a perk for every third level you already have // v18: riftTier = highest tier you can open
	if (out->crafterLvl < 1) out->crafterLvl = 1;
	return out->version == SAVE_VER;
}
// a spot for something you press A on: clear of obstacles AND of every node/chest already placed
static bool place_spot(int zone, float* ox, float* oz, float clear) {
	for (int t = 0; t < 40; t++) {
		float x, z; if (!find_spot(zone, &x, &z, clear)) return false;
		bool ok = true;
		for (int i = 0; i < nnodes && ok; i++) if (dist2d(x, z, nodes[i].x, nodes[i].z) < 2.4f) ok = false;
		for (int i = 0; i < nchests && ok; i++) if (dist2d(x, z, chests[i].x, chests[i].z) < 2.6f) ok = false;
		if (ok) { *ox = x; *oz = z; return true; }
	}
	return false;
}
static void place_world_objects(void) {
	// deterministic placement so chest indices match the save
	nnodes = 0; nchests = 0;
	// v1.20: keep gatherables and chests well clear of everything else you press A on
	world_reserve(npcdefs[NPC_MARI].x, npcdefs[NPC_MARI].z, 2.6f);
	world_reserve(npcdefs[NPC_BOARD].x, npcdefs[NPC_BOARD].z, 2.8f);
	world_reserve(STALL_X, STALL_Z, 2.4f);
	world_reserve(BANK_X, BANK_Z, 2.4f);
	for (int b = 0; b < BLD_COUNT; b++) { float x, z; bld_door(b, &x, &z); world_reserve(x, z, 2.6f); }
	struct { int type, zone, n; } spec[] = {
		{ND_BERRY, Z_MEADOW, 34}, {ND_BERRY, Z_VILLAGE, 4}, {ND_SUNPETAL, Z_MEADOW, 26}, {ND_SHELL, Z_BEACH, 28}, {ND_DRIFT, Z_BEACH, 20},
		{ND_SILVER, Z_FOREST, 28}, {ND_GLOWCAP, Z_FOREST, 16}, {ND_GLOWCAP, Z_SWAMP, 20}, {ND_LILY, Z_SWAMP, 24}, {ND_CRYSTAL, Z_RUINS, 26},
		{ND_DIG, Z_MEADOW, 5}, {ND_DIG, Z_BEACH, 6}, {ND_DIG, Z_FOREST, 6}, {ND_DIG, Z_SWAMP, 6}, {ND_DIG, Z_RUINS, 6},
	};
	for (u32 s = 0; s < sizeof spec / sizeof spec[0]; s++) for (int k = 0; k < spec[s].n && nnodes < MAX_NODES; k++) {
		float x, z; if (!place_spot(spec[s].zone, &x, &z, 1.0f)) continue;
		Node* n = &nodes[nnodes++]; memset(n, 0, sizeof *n);
		n->type = spec[s].type; n->zone = spec[s].zone; n->x = x; n->z = z; n->y = ground_h(x, z); n->alive = true; n->wob = rndf() * 10;
	}
	int kz[3] = { Z_FOREST, Z_BEACH, Z_SWAMP };
	for (int k = 0; k < 3; k++) {
		float x, z; if (!place_spot(kz[k], &x, &z, 1.5f) && !find_spot(kz[k], &x, &z, 1.5f)) { x = 10; z = 10; }
		Node* n = &nodes[nnodes++]; memset(n, 0, sizeof *n);
		n->type = ND_KITTEN; n->zone = kz[k]; n->kid = k; n->x = x; n->z = z; n->y = ground_h(x, z); n->alive = true;
		kittenPos[k][0] = x; kittenPos[k][1] = z;
	}
	int cz[] = { Z_VILLAGE, Z_MEADOW, Z_MEADOW, Z_MEADOW, Z_BEACH, Z_BEACH, Z_BEACH, Z_BEACH, Z_FOREST, Z_FOREST, Z_FOREST, Z_FOREST, Z_SWAMP, Z_SWAMP, Z_SWAMP, Z_SWAMP, Z_RUINS, Z_RUINS, Z_RUINS, Z_RUINS,
	             Z_MEADOW, Z_BEACH, Z_BEACH, Z_FOREST, Z_FOREST, Z_SWAMP, Z_SWAMP, Z_RUINS, Z_RUINS }; // v1.21: 9 more for the bigger island (indices 20+)
	for (int i = 0; i < (int)(sizeof cz / sizeof cz[0]) && nchests < MAX_CHESTS; i++) {
		float x, z; if (!place_spot(cz[i], &x, &z, 1.6f) && !place_spot(cz[i], &x, &z, 0.9f) && !find_spot(cz[i], &x, &z, 0.5f)) continue;
		Chest* c = &chests[nchests++];
		c->x = x; c->z = z; c->y = ground_h(x, z); c->yaw = rndf() * TAU; c->golden = (i % 4 == 3) && cz[i] != Z_MEADOW; c->openT = 0;
	}
	// v1.8: night-only moonblooms (placed last so chest positions match older saves)
	struct { int zone, n; } mb[] = { {Z_MEADOW, 9}, {Z_SWAMP, 11}, {Z_FOREST, 7} };
	for (int s = 0; s < 3; s++) for (int k = 0; k < mb[s].n && nnodes < MAX_NODES; k++) {
		float x, z; if (!place_spot(mb[s].zone, &x, &z, 1.0f)) continue;
		Node* n = &nodes[nnodes++]; memset(n, 0, sizeof *n);
		n->type = ND_MOONBLOOM; n->zone = mb[s].zone; n->x = x; n->z = z; n->y = ground_h(x, z); n->alive = true; n->wob = rndf() * 10;
	}
	dun_place_gates(); // v1.28, last so nothing else moves
}
void game_new(void) {
	memset(&S, 0, sizeof S);
	S.lvl = 1; S.gold = 0; S.tod = 0.12f; S.tracked = -1;
	memset(&S.weapon, 0, sizeof(Gear)); S.weapon.used = 1; S.weapon.kind = 0; S.weapon.base = 0; S.weapon.rarity = 0; S.weapon.ilvl = 1; S.weapon.power = 6; S.weapon.pre = 1;
	IC(IT_TONIC) = 2;
	S.crafterLvl = 1; S.optLevels = 1; S.optDiff = 75; memcpy(S.camAdj, CAM_ADJ_DEF, 4); S.worldLvl = 1; S.rumbleN = 2; S.spawnPct = 25;
	guideOn = false; guideBounty = false;
	refresh_quests();
	memset(&P, 0, sizeof P);
	P.p = v3(0, ground_h(0, 5), 5.5f); P.yaw = PI; camYaw = PI;
	P.maxhp = player_maxhp(); S.hp = P.maxhp; P.sta = sta_max();
	goldShown = 0;
	for (int i = 0; i < nchests; i++) chests[i].openT = 0;
	memset(en, 0, sizeof en); memset(drops, 0, sizeof drops);
	toast("WELCOME TO HOLLOWMERE", "Talk to Elder Maple (the purple !)", 0xC79BFF, 2);
	S.tracked = TRACK_MAIN; guideOn = true; // the arrow leads to the Elder from the first step
	do_save();
}
bool game_load(void) {
	if (!read_save(&S)) return false;
	memset(&P, 0, sizeof P);
	P.p = v3(S.px, ground_h(S.px, S.pz), S.pz); P.yaw = S.yaw; camYaw = S.yaw;
	P.maxhp = player_maxhp(); if (S.hp <= 0) S.hp = P.maxhp; P.sta = sta_max();
	{ int pz = zone_at(P.p.x, P.p.z); if (!zone_open(pz)) S.seals |= 1 << pz; } // never stranded inside a seal
	goldShown = S.gold;
	for (int i = 0; i < nchests; i++) chests[i].openT = (S.chestsOpened & (1u << i)) ? 1 : 0;
	guideBounty = false; guideOn = S.tracked == TRACK_MAIN && S.mq < MQ_COUNT; // the story arrow survives a reload
	refresh_quests();
	memset(en, 0, sizeof en); memset(drops, 0, sizeof drops);
	toast("WELCOME BACK", "Your adventure continues", 0x7CC8FF, 0);
	return true;
}

// ------------------------------------------------------------ quest guide arrow
static bool near_node_item(int item, float* x, float* z) {
	float bd = 1e9f; bool any = false;
	for (int pass = 0; pass < 2 && !any; pass++)
		for (int i = 0; i < nnodes; i++) {
			Node* n = &nodes[i];
			if (node_item[n->type] == 255 || node_item[n->type] != item) continue;
			if (pass == 0 && !n->alive) continue;
			float d = dist2d(P.p.x, P.p.z, n->x, n->z);
			if (d < bd) { bd = d; *x = n->x; *z = n->z; any = true; }
		}
	return any;
}
static bool near_enemy(bool byFam, int v, float* x, float* z) {
	float bd = 1e9f; bool any = false;
	for (int i = 0; i < MAX_EN; i++) {
		Enemy* e = &en[i]; if (!e->on || e->state == ES_DEAD || e->boss) continue;
		const EnemyDef* d = &endefs[e->type];
		if (byFam ? d->fam != v : d->drop != v) continue;
		float dd = dist2d(P.p.x, P.p.z, e->p.x, e->p.z);
		if (dd < bd) { bd = dd; *x = e->p.x; *z = e->p.z; any = true; }
	}
	if (any) return true;
	for (int t = 0; t < EN_COUNT; t++) if (!endefs[t].boss && (byFam ? endefs[t].fam == v : endefs[t].drop == v)) {
		int zn = endefs[t].zone; *x = arena_pos[zn][0]; *z = arena_pos[zn][1]; return true;
	}
	return false;
}
static bool npc_pos(int npc, float* x, float* z) { *x = npcdefs[npc].x; *z = npcdefs[npc].z; return true; }
static bool compute_guide(float* x, float* z) {
	if (dunOn) { // below ground the arrow points to the way down, once you've seen it
		if (DG.kind == 1) { if (DG.champ >= 0 && en[DG.champ].on) { *x = en[DG.champ].p.x; *z = en[DG.champ].p.z; return true; } if (DG.done) { *x = dun_x(DG.xi); *z = dun_z(DG.xj); return true; } return false; }
		if (DG.seen[DG.xj][DG.xi]) { *x = dun_x(DG.xi); *z = dun_z(DG.xj); return true; }
		return false;
	}
	if (!guideOn) return false;
	if (guideBounty) {
		if (!S.bActive) { guideOn = false; return false; }
		if (bounty_ready()) return npc_pos(NPC_BOARD, x, z);
		if (S.bType == 0) return near_enemy(true, S.bTarget, x, z);
		return near_node_item(S.bTarget, x, z) || near_enemy(false, S.bTarget, x, z);
	}
	int q = S.tracked;
	if (q == TRACK_EVENT) {
		if (!EV.on) return false;
		if (EV.type == EVT_HORDE) { *x = EV.x; *z = EV.z; return true; }
		float bd = 1e9f; bool any = false;
		for (int k = 0; k < EV.nkeys; k++) if (!(EV.prog & (1 << k))) { float dd = dist2d(P.p.x, P.p.z, EV.kx[k], EV.kz[k]); if (dd < bd) { bd = dd; *x = EV.kx[k]; *z = EV.kz[k]; any = true; } }
		return any;
	}
	if (q == TRACK_RUMBLE) return npc_pos(NPC_TILLY, x, z);
	if (q == TRACK_MAIN) {
		if (S.mq >= MQ_COUNT) return false;
		const MainQuest* m = &mainq[S.mq];
		if (S.mqState == 0 || mq_items_ok()) return npc_pos(m->giver, x, z);
		if (m->type == MQT_TALK) return npc_pos(m->target, x, z);
		if (m->type == MQT_QUEST) { int q = m->target; if (QS(q) == QS_ACTIVE) { if (quest_ready(q)) return npc_pos(questdefs[q].turnin >= 0 ? questdefs[q].turnin : questdefs[q].giver, x, z); return false; } return npc_pos(m->giver, x, z); }
		if (m->type == MQT_KILL) return near_enemy(true, m->target, x, z);
		int r = recipe_for(m->target);
		if (r < 0) for (int k = 0; k < RECIPE_COUNT; k++) if (recipes[k].out == CR_ITEM && recipes[k].arg == m->target) r = k;
		if (r < 0) return near_node_item(m->target, x, z) || near_enemy(false, m->target, x, z);
		if (queued_count(m->target)) return false; // being crafted
		int miss = recipe_missing(r);
		if (miss < 0) return false; // craftable now: no arrow, the HUD says so
		return near_node_item(miss, x, z) || near_enemy(false, miss, x, z);
	}
	if (q < 0 || QS(q) != QS_ACTIVE) return false;
	const QuestDef* d = &questdefs[q];
	if (quest_ready(q)) return npc_pos(d->turnin >= 0 ? d->turnin : d->giver, x, z);
	switch (d->type) {
	case QT_FORAGE: return near_node_item(d->target, x, z) || near_enemy(false, d->target, x, z);
	case QT_KILL: return near_enemy(true, d->target, x, z);
	case QT_DELIVER: return npc_pos(d->turnin, x, z);
	case QT_TOME: case QT_BUYTONIC: return npc_pos(NPC_BRAM, x, z);
	case QT_EVENT: case QT_PORTAL: if (!EV.on || EV.type != (d->type == QT_PORTAL ? EVT_PORTAL : EVT_HORDE)) return false; *x = EV.x; *z = EV.z; return true;
	case QT_CRAFTTONIC: if (IC(IT_BERRY) < 2) return near_node_item(IT_BERRY, x, z); if (IC(IT_SUNPETAL) < 3) return near_node_item(IT_SUNPETAL, x, z); return false;
	case QT_BOSS: { int zn = endefs[d->target].zone; *x = arena_pos[zn][0]; *z = arena_pos[zn][1]; return true; }
	case QT_KITTEN: {
		float bd = 1e9f; bool any = false;
		for (int k = 0; k < 3; k++) if (!(S.kittens & (1 << k))) { float dd = dist2d(P.p.x, P.p.z, kittenPos[k][0], kittenPos[k][1]); if (dd < bd) { bd = dd; *x = kittenPos[k][0]; *z = kittenPos[k][1]; any = true; } }
		return any;
	}
	default: return false;
	}
}

// ------------------------------------------------------------ main update
static void update_play(float dt, u32 kd, u32 kh) {
	if (paused && camAdjOn) { // live tuning of the shoulder camera; the world stays frozen behind it
		if (kd & (KEY_DUP | KEY_DDOWN)) { camAdjSel = (camAdjSel + ((kd & KEY_DUP) ? 3 : 1)) % 4; sfx(SFX_BLIP); }
		if (kd & (KEY_DLEFT | KEY_DRIGHT)) { int v = S.camAdj[camAdjSel] + ((kd & KEY_DRIGHT) ? 1 : -1); S.camAdj[camAdjSel] = v < 0 ? 0 : v > 20 ? 20 : v; sfx_pitch(SFX_BLIP, 0.8f + S.camAdj[camAdjSel] / 40.f); }
		if (kd & KEY_Y) { memcpy(S.camAdj, CAM_ADJ_DEF, 4); sfx(SFX_PICK); }
		if (kd & (KEY_A | KEY_B | KEY_START)) { camAdjOn = false; sfx(SFX_BLIP); }
		update_camera(1 / 60.f, kh, 0);
		return;
	}
	if (paused) {
		if (kd & (KEY_DUP | KEY_DDOWN)) { pauseSel = (pauseSel + ((kd & KEY_DUP) ? PAUSE_N - 1 : 1)) % PAUSE_N; sfx(SFX_BLIP); }
		if (pauseSel >= 10) { // testing switches: skip the story locks on dungeons and rifts
			if (kd & KEY_A) { int b = pauseSel == 10 ? 1 : 2; S.testUnlock ^= b; sfx(SFX_PICK);
				if (S.testUnlock & b) { if (b == 1) { S.seals = 0x3C; refresh_quests(); } toast(b == 1 ? "ALL DEPTHS OPEN" : "RIFTS OPEN", b == 1 ? "Seals broken too. Testing only" : "Testing only", 0xFFB070, 0); } }
			if (kd & (KEY_B | KEY_START)) { paused = false; sfx(SFX_BLIP); }
			return;
		}
		int ps = pauseSel; if (pauseSel == 1) ps = -1; else if (pauseSel > 1) ps = pauseSel - 1; // row 1 is the return stone; the rest moved down one
		if (ps == -1 && (kd & KEY_A)) { return_stone(); return; }
		pauseSel = ps; // reuse the existing row logic below with the old numbering
		if (pauseSel == 1 && (kd & (KEY_DLEFT | KEY_DRIGHT))) { // difficulty slider, 5% steps
			int d = S.optDiff + ((kd & KEY_DRIGHT) ? 5 : -5); S.optDiff = d < 0 ? 0 : d > 100 ? 100 : d; sfx_pitch(SFX_BLIP, 0.8f + S.optDiff / 125.f);
		}
		if (pauseSel == 2 && (kd & (KEY_DLEFT | KEY_DRIGHT))) { int v = S.rumbleN + ((kd & KEY_DRIGHT) ? 1 : -1); S.rumbleN = v < 2 ? 2 : v > 10 ? 10 : v; sfx(SFX_BLIP); }
		if (pauseSel == 3 && (kd & (KEY_DLEFT | KEY_DRIGHT))) { int v = S.spawnPct + ((kd & KEY_DRIGHT) ? 5 : -5); S.spawnPct = v < 0 ? 0 : v > 100 ? 100 : v; sfx_pitch(SFX_BLIP, 0.8f + S.spawnPct / 125.f); }
		if (pauseSel == 4 && (kd & (KEY_DLEFT | KEY_DRIGHT))) { S.optCam ^= 1; sfx(SFX_BLIP); }
		if (kd & KEY_A) {
			if (pauseSel == 0) paused = false;
			else if (pauseSel == 4) { S.optCam ^= 1; }
			else if (pauseSel == 5) { camAdjOn = true; camAdjSel = 0; S.optCam = 1; }
			else if (pauseSel == 6) { S.optLevels ^= 1; }
			else if (pauseSel == 7) { do_save(); toast("GAME SAVED", "", 0x7CF07C, 0); paused = false; }
			else if (pauseSel == 8) { do_save(); paused = false; mode = MODE_TITLE; }
			if (pauseSel != 1 && pauseSel != 2 && pauseSel != 3) sfx(SFX_BLIP);
		}
		if (kd & (KEY_START | KEY_B)) paused = false;
		pauseSel = pauseSel < 0 ? 1 : pauseSel >= 1 ? pauseSel + 1 : 0; // back to on-screen numbering
		return;
	}
	if (G.on) { update_hud_fly(dt); gacha_update(dt, kd); audio_update(dt); gtime += dt; goldShown += (S.gold - goldShown) * clampf(dt * 6, 0, 1); return; }
	if (riftPick) { // choose a rift tier: higher = tougher and richer
		if (kd & KEY_DLEFT) { if (riftPickTier > 1) riftPickTier--; sfx(SFX_BLIP); }
		if (kd & KEY_DRIGHT) { if (riftPickTier < rift_max()) riftPickTier++; sfx(SFX_BLIP); }
		if (kd & KEY_DDOWN) { riftPickTier = 1; sfx(SFX_BLIP); }
		if (kd & KEY_DUP) { riftPickTier = rift_max(); sfx(SFX_BLIP); }
		if ((kd & KEY_Y) && (S.testUnlock & 2)) { S.riftNext = (S.riftNext + 1) % 3; sfx(SFX_BLIP); } // testing: pick the rift type
		if (kd & KEY_B) { riftPick = false; sfx(SFX_BLIP); }
		else if (kd & KEY_A) { riftPick = false; int g = -1; float d0; g = near_gate(&d0); if (g >= 0) dun_enter_t(g, riftPickTier); }
		update_hud_fly(dt); audio_update(dt); gtime += dt;
		return;
	}
	if (S.perkPicks > 0 && !D.on && !shopOpen && P.deadT <= 0 && levelFlashT < 1.6f) { // a new tool: pick one of three perks
		if (perkOffer[0] < 0) perk_roll();
		if (perkOffer[0] < 0) S.perkPicks = 0; // you have them all
		if (kd & KEY_DLEFT) { perkSel = (perkSel + 2) % 3; sfx(SFX_BLIP); }
		if (kd & KEY_DRIGHT) { perkSel = (perkSel + 1) % 3; sfx(SFX_BLIP); }
		if (kd & (KEY_A | KEY_Y)) perk_pick(perkSel);
		update_hud_fly(dt); audio_update(dt); gtime += dt; if (levelFlashT > 0) levelFlashT -= dt;
		return;
	}
	if (S.lvlPicks > 0 && !D.on && !shopOpen && P.deadT <= 0 && levelFlashT < 1.6f) { // level-up reward: pick one of three
		if (kd & KEY_DLEFT) { lvlPickSel = (lvlPickSel + 3) % 4; sfx(SFX_BLIP); }
		if (kd & KEY_DRIGHT) { lvlPickSel = (lvlPickSel + 1) % 4; sfx(SFX_BLIP); }
		if (kd & (KEY_A | KEY_Y)) level_pick(lvlPickSel);
		update_hud_fly(dt); audio_update(dt); gtime += dt; if (levelFlashT > 0) levelFlashT -= dt;
		return;
	}
	if (kd & KEY_START) { paused = true; pauseSel = 0; sfx(SFX_BLIP); return; }
#ifdef HM_DEBUG
	{
		static int tp = 0;
		if ((kh & KEY_L) && (kd & KEY_SELECT)) {
			if (!guideValid) { bld_door(0, &guideX, &guideZ); guideValid = true; }
			if (guideValid) { P.p.x = guideX + 1.3f; P.p.z = guideZ; P.p.y = ground_h(P.p.x, P.p.z); float nx, nz; world_blocked(P.p.x, P.p.z, 0.4f, &nx, &nz); P.p.x = nx; P.p.z = nz; rp.tx = P.p.x; rp.tz = P.p.z; rp.camx = P.p.x - sinf(camYaw)*9; rp.camz = P.p.z - cosf(camYaw)*9; }
		} else if ((kh & KEY_R) && (kd & KEY_SELECT)) {
			float tx = 0, tz = 0; int n = tp++;
			if (n < NPC_COUNT) { tx = npcdefs[n].x + sinf(npcdefs[n].yaw)*1.6f; tz = npcdefs[n].z + cosf(npcdefs[n].yaw)*1.6f; }
			else if ((n -= NPC_COUNT) < ND_COUNT) { for (int i = 0; i < nnodes; i++) if (nodes[i].type == n) { tx = nodes[i].x + 1.2f; tz = nodes[i].z; break; } }
			else if ((n -= ND_COUNT) < 2) { tx = chests[n * 7].x + 1.4f; tz = chests[n * 7].z; }
			else if ((n -= 2) < 5) { int zz[5] = {Z_MEADOW, Z_BEACH, Z_FOREST, Z_SWAMP, Z_RUINS}; int bq[5] = {Q_E2, Q_G2, Q_F2, Q_O2, Q_R2}; tx = arena_pos[zz[n]][0] + 6; tz = arena_pos[zz[n]][1]; QS(bq[n]) = QS_ACTIVE; QP(bq[n]) = 0; }
			else { tp = 0; }
			P.p.x = tx; P.p.z = tz; P.p.y = ground_h(tx, tz); P.yaw = atan2f(-1, 0);
			float nx, nz; world_blocked(P.p.x, P.p.z, 0.4f, &nx, &nz); P.p.x = nx; P.p.z = nz;
			rp.tx = P.p.x; rp.tz = P.p.z; rp.camx = P.p.x - sinf(camYaw)*9; rp.camz = P.p.z - cosf(camYaw)*9;
		}
		if ((kh & KEY_L) && (kd & KEY_A)) { if (!night_now()) S.tod = 0.7f; }
		if ((kh & KEY_L) && (kd & KEY_DUP)) { S.tod = 0.2f; }
		if ((kh & KEY_R) && (kh & KEY_L) && (kd & KEY_DDOWN)) { if (dunOn && DG.champ >= 0) { enemy_die(&en[DG.champ]); P.p.x = dun_x(DG.xi) + 1.0f; P.p.z = dun_z(DG.xj) + 1.1f; } }
		else if ((kh & KEY_R) && (kd & KEY_DDOWN)) rumble();
		if ((kh & KEY_R) && (kd & KEY_Y)) { static int ci; static const int cyc[5] = { EN_CRAB, EN_BOAR, EN_TOAD, EN_MWISP, EN_GOLEM }; Enemy* e = spawn_enemy(cyc[ci++ % 5], P.p.x + sinf(P.yaw)*5, P.p.z + cosf(P.yaw)*5); if (e) { e->state = ES_CHASE; e->atkCd = 0.5f; } }
		if ((kh & KEY_R) && (kd & KEY_X)) { P.p.x = 0; P.p.z = 26; P.p.y = ground_h(0, 26); float nx, nz; world_blocked(P.p.x, P.p.z, 0.4f, &nx, &nz); P.p.x = nx; P.p.z = nz; P.yaw = 0; camYaw = 0; }
		if ((kh & KEY_R) && (kd & KEY_B)) { int z = zone_at(P.p.x, P.p.z); Enemy* e = spawn_enemy(zone_ranged[z], P.p.x + sinf(P.yaw)*7, P.p.z + cosf(P.yaw)*7); if (e) e->state = ES_CHASE; }
		if ((kh & KEY_R) && !(kh & KEY_L) && (kd & KEY_DLEFT)) drop_coins(v3add(P.p, v3(1.5f, 0.5f, 0)), 30, 5);
		if ((kh & KEY_R) && (kd & KEY_DUP)) { static int bt; bt ^= 1; P.p.x = bt ? BANK_X - 0.6f : STALL_X + 0.6f; P.p.z = bt ? BANK_Z : STALL_Z; P.p.y = ground_h(P.p.x, P.p.z); P.yaw = -PI/2; float nx, nz; world_blocked(P.p.x, P.p.z, 0.4f, &nx, &nz); P.p.x = nx; P.p.z = nz; }
		if ((kh & KEY_L) && !(kh & KEY_R) && (kd & KEY_DLEFT)) { EV.on = false; event_start(); }
		if ((kh & KEY_L) && (kh & KEY_R) && (kd & KEY_DLEFT) && !dunOn) { static int gi; const DunGate* g = &gates[gi++ % ngates]; P.p.x = g->x * 0.95f; P.p.z = g->z * 0.95f; P.p.y = ground_h(P.p.x, P.p.z); P.yaw = atan2f(g->x, g->z); camYaw = P.yaw; S.seals = 0x3C; }
		else if ((kh & KEY_L) && (kh & KEY_R) && (kd & KEY_DLEFT) && dunOn) { P.p.x = dun_x(DG.xi) + (DG.floor == DG.floors ? 4.0f : 1.0f); P.p.z = dun_z(DG.xj); }
		else if ((kh & KEY_L) && (kd & KEY_DRIGHT)) { S.seals = S.seals ? 0 : 0x3C; refresh_quests(); toast(S.seals ? "SEALS OPEN" : "SEALS SHUT", "debug", 0xFFFFFF, 0); }
		if ((kh & KEY_R) && (kd & KEY_DRIGHT)) { static int sz = 0; const int zs[4] = { Z_BEACH, Z_FOREST, Z_SWAMP, Z_RUINS }; int z = zs[sz++ & 3], b = -1; float bd = 1e9f; // cycle the four road seals; arms the right key
			for (int i = 0; i < nseal; i++) if (sealpts[i].zone == z && (fabsf(sealpts[i].x) < 1.6f || fabsf(sealpts[i].z) < 1.6f)) { float d = sealpts[i].x*sealpts[i].x + sealpts[i].z*sealpts[i].z; if (d < bd) { bd = d; b = i; } }
			if (b >= 0) { float r = sqrtf(bd), k = (r - 2.0f) / r; P.p.x = sealpts[b].x * k; P.p.z = sealpts[b].z * k; P.p.y = ground_h(P.p.x, P.p.z); P.yaw = atan2f(sealpts[b].x, sealpts[b].z); camYaw = P.yaw; if (sz > 4) S.weapon.elem = seal_key(z); } }
		if ((kh & KEY_L) && (kd & KEY_X)) { extern int craftForce; tab = 2; craftForce = 16; }
		if ((kh & KEY_L) && (kh & KEY_R) && (kd & KEY_DUP) && dunOn) { static int oi; if (DG.nob) { DObj* o = &DG.ob[oi++ % DG.nob]; P.p.x = dun_x(o->i) - 1.6f; P.p.z = dun_z(o->j); P.yaw = PI / 2; camYaw = P.yaw; } }
		else if ((kh & KEY_L) && (kh & KEY_R) && (kd & KEY_DUP)) { QS(Q_FG1) = QS(Q_FG2) = QS(Q_AP1) = QS(Q_AP2) = QS_DONE; for (int i = 0; i < IT_COUNT; i++) IC(i) += 5; IC(XI_MOONBLOOM) += 3; }
		if ((kh & KEY_L) && !(kh & KEY_R) && (kd & KEY_DDOWN)) { shopOpen = true; }
		if ((kh & KEY_L) && (kd & KEY_Y)) { add_xp(xp_next(S.lvl)); S.gold += 500; S.crafterXp += 30; for (int k = 0; k < CRAFT_SLOTS; k++) if (S.jobs[k].state) S.jobs[k].left = 0.5f; for (int i = 0; i < IT_COUNT; i++) if (i != IT_SHARD && i != IT_PIE) IC(i) += 5; IC(XI_MOONBLOOM) += 2; for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_ACTIVE && questdefs[q].type == QT_FORAGE) give_item(questdefs[q].target, questdefs[q].count, true);
			if (S.mq < MQ_COUNT && S.mqState == 1 && mainq[S.mq].type == MQT_ITEM) give_item(mainq[S.mq].target, mainq[S.mq].count, true); }
		if ((kh & KEY_L) && (kd & KEY_B)) { int z = zone_at(P.p.x, P.p.z); spawn_enemy(night_now() ? EN_MOTH : zone_enemies[z == Z_VILLAGE ? Z_MEADOW : z][0], P.p.x + sinf(P.yaw)*2.5f, P.p.z + cosf(P.yaw)*2.5f); }
	}
#endif
	if (kd & KEY_DLEFT) { tab = (tab + 6) % 7; sfx(SFX_BLIP); }
	if (kd & KEY_DRIGHT) { tab = (tab + 1) % 7; sfx(SFX_BLIP); }
	if ((kd & KEY_Y) && !shopOpen && !D.on) ui_menu_y(); // Y is the menu action button on every tab
	if ((kd & KEY_SELECT) && !(kh & (KEY_L | KEY_R))) { // SELECT swaps camera modes
		S.optCam ^= 1; sfx(SFX_BLIP);
		toast(S.optCam ? "CAMERA: OVER THE SHOULDER" : "CAMERA: CLASSIC", "SELECT swaps. Adjust it in the pause menu.", 0x7CC8FF, 0);
	}
	if (kd & KEY_DUP) ui_dpad(-1);
	if (kd & KEY_DDOWN) ui_dpad(1);
	if (kd & KEY_TOUCH) { touchPosition tp; hidTouchRead(&tp); ui_tap(tp.px, tp.py); }

	bool dialogThisFrame = D.on || shopOpen;
	bool shopWasOpen = shopOpen;
	if (D.on) {
		int len = strlen(D.pages[D.cur]);
		float prev = D.chars;
		D.chars += dt * 70;
		if ((int)D.chars / 3 != (int)prev / 3 && D.chars < len) sfx_pitch(SFX_BLIP, 0.9f + (D.npc % 4) * 0.1f);
		if (kd & (KEY_A | KEY_B)) {
			if (D.chars < len) D.chars = len;
			else if (D.cur + 1 < D.n) { D.cur++; D.chars = 0; sfx(SFX_BLIP); }
			else dlg_finish();
		}
	} else if (shopOpen && (kd & KEY_B)) { shopOpen = false; P.grace = 1.0f; }
	else if (shopOpen && shopWasOpen && (kd & (KEY_A | KEY_Y))) shop_buy(shopSel);

	if (hitstop > 0) { hitstop -= dt; dt *= 0.08f; }
	if (slowmoT > 0) { slowmoT -= dt; dt *= 0.35f; } // perfect dodge
	gtime += dt;
	S.playTime += dt;
	if (endingT > 0) {
		float pe = endingT; endingT += dt;
		if (pe < 1.5f && endingT >= 1.5f) { sfx(SFX_LOOT_EPIC); shake = 0.6f; for (int k = 0; k < 80; k++) { float a = rndf()*TAU, s = rndr(2, 9); spawn_part(v3(0, 3.2f, 0), v3(cosf(a)*s, rndr(3, 12), sinf(a)*s), 2.0f, 0.18f, k & 1 ? 0xFFD23F : 0xFFFFFF, 6, 1.0f, MESH_OCTA); } toast("THE GREAT LANTERN SHINES", "Hollowmere is saved!", 0xFFD23F, 2); }
		if (endingT > 2 && endingT < 14 && rndf() < dt * 2.5f) {
			V3 c = v3(rndr(-14, 14), rndr(12, 18), rndr(-14, 14)); u32 cols[] = { 0xFF5C7A, 0x7CF0FF, 0xFFD23F, 0xB98CFF, 0x7CF07C };
			u32 col = cols[rndi(0, 4)]; sfx_pitch(SFX_KILL, rndr(0.7f, 1.2f));
			for (int k = 0; k < 40; k++) { float a = rndf()*TAU, b = rndr(-1, 1), s = rndr(5, 8); spawn_part(c, v3(cosf(a)*sqrtf(1-b*b)*s, b*s, sinf(a)*sqrtf(1-b*b)*s), 1.6f, 0.16f, col, 3, 1.2f, MESH_OCTA); }
		}
		if (endingT > 16) endingT = 0;
	}
	update_player(dt, (dialogThisFrame || D.on || shopOpen) ? (kd & ~(KEY_A | KEY_B)) : kd, kh);
	update_crafting(dt);
	bool frozen = D.on || shopOpen; // talking or shopping pauses the world
	if (!frozen) {
		update_enemies(dt);
		spawn_logic(dt);
		if (!dunOn) update_events(dt);
		update_drops(dt);
		update_loot_fountain(dt);
		update_shots(dt);
		update_sky(dt);
	}
	update_misc(dt);
	update_hud_fly(dt);
	update_camera(dt, kh, kd);
	audio_update(dt);
	guideValid = compute_guide(&guideX, &guideZ);
	goldShown += (S.gold - goldShown) * clampf(dt * 6, 0, 1);
	if (fabsf(S.gold - goldShown) < 0.5f) goldShown = S.gold;
	int z = zone_at(P.p.x, P.p.z);
	if (z != curZone && !dunOn) {
		curZone = z;
		if (!(S.zonesVisited & (1 << z))) { S.zonesVisited |= 1 << z; add_xp(8); }
		strcpy(zoneBanner, zone_names[z]); zoneBannerT = 2.6f; zoneBannerCol = 0xFFFFFF;
		if (zone_elem[z]) { int l = strlen(zoneBanner); zoneBanner[l] = ' '; zoneBanner[l + 1] = (char)(0x80 + elem_icon(zone_elem[z])); zoneBanner[l + 2] = 0;
			static u8 taught;
			{ char t[40], b[64]; int el = zone_elem[z], we = S.weapon.used ? S.weapon.elem : 0; sprintf(t, "%s FOES HERE", el == EL_FIRE ? "FIRE" : el == EL_FROST ? "FROST" : el == EL_VENOM ? "VENOM" : "STORM");
				if (we == elem_weak[el]) sprintf(b, "Your %s weapon is strong here!", elem_name[we]);
				else if (we == el) sprintf(b, "Your %s weapon barely scratches them!", elem_name[we]);
				else sprintf(b, "They fear %s. Yours: %s", elem_name[elem_weak[el]], we ? elem_name[we] : "no element");
				toast(t, b, elem_col[el], 0); } }
	}
	if (!(S.ann & 1) && rifts_open() && !(S.testUnlock & 2)) { S.ann |= 1; toast("RIFTS HAVE OPENED", "Purple tears in every wild zone. Mind the edges", 0xC79BFF, 2); }
	if (!(S.ann & 2) && QS(Q_E2) == QS_DONE) { S.ann |= 2; toast("THE OLD CELLARS", "The boards are off the arch in the meadow", 0xFFD9A0, 2); }
	check_achievements();
}

static void update_title(float dt, u32 kd) {
	gtime += dt;
#ifndef HM_SHOTSCENE
	camYaw += dt * 0.12f;
#endif
	rp.tx = 0; rp.ty = 1; rp.tz = 0;
	rp.camx = -sinf(camYaw) * 30; rp.camz = -cosf(camYaw) * 30; rp.camy = 16;
	rp.focal = 16;
	S.tod = 0.2f; update_sky(0);
	audio_update(dt);
	if (kd & (KEY_DUP | KEY_DDOWN)) { titleSel ^= 1; sfx(SFX_BLIP); }
	if (!hasSave) titleSel = 0;
	if (kd & KEY_TOUCH) {
		touchPosition tp; hidTouchRead(&tp);
		if (tp.px > 60 && tp.px < 260 && tp.py > 70 && tp.py < 115) { titleSel = 0; kd |= KEY_A; }
		if (hasSave && tp.px > 60 && tp.px < 260 && tp.py > 125 && tp.py < 170) { titleSel = 1; kd |= KEY_A; }
	}
	if (kd & KEY_A) {
		sfx(SFX_QUEST);
		bool loaded = false;
		if (hasSave && titleSel == 0) loaded = game_load();
		if (!loaded) { for (int i = 0; i < nnodes; i++) { nodes[i].alive = true; nodes[i].pop = 0; } game_new(); }
		curZone = -1; mode = MODE_PLAY; paused = false; shopOpen = false; D.on = false; endingT = 0;
		rp.tx = P.p.x; rp.tz = P.p.z; rp.camx = P.p.x; rp.camz = P.p.z + 9; rp.camy = P.p.y + 7;
	}
}

static volatile int loadStage; static volatile bool loadDone;
float loadFadeT;
static void load_worker(void* arg) {
	(void)arg;
	world_gen(); loadStage = 2;
	audio_synth(0); loadStage = 4; // music is composed later, in the background
	loadDone = true;
}
int main(int argc, char** argv) {
	osSetSpeedupEnable(true); // New 3DS: 804MHz + L2 cache
	gfx_init();
	save_system_init();
	// heavy work (island generation, sound synthesis) runs on a worker thread while the
	// main thread plays the animated loading scene
	{
		s32 prio = 0x30; svcGetThreadPriority(&prio, CUR_THREAD_HANDLE);
		Thread lt = threadCreate(load_worker, NULL, 128 * 1024, prio + 1, -2, false);
		if (!lt) load_worker(NULL);
		u64 last = svcGetSystemTick(); float t = 0;
		while (!loadDone && aptMainLoop()) {
			u64 now = svcGetSystemTick(); float dt = (float)((double)(now - last) / SYSCLOCK_ARM11); last = now; if (dt > 0.05f) dt = 0.05f;
			t += dt;
			gfx_frame_begin();
			for (int eye = 0; eye < gfx_eyes(); eye++) { gfx_begin_eye(eye); render_loading(eye, t, loadStage / 4.f); }
			render_loading_bottom(t, loadStage / 4.f);
			gfx_frame_end();
		}
		if (lt) { threadJoin(lt, U64_MAX); threadFree(lt); }
		loadFadeT = t;
	}
	gfx_build_world();
	audio_start();
	place_world_objects();
	gtime = loadFadeT;
	{ extern void add_obst_pub(float x, float z, float r); add_obst_pub(npcdefs[NPC_MARI].x, npcdefs[NPC_MARI].z, 0.45f); }
	{ Save tmp; hasSave = read_save(&tmp); }
#ifdef HM_DEBUG
	{
		mkdir("sdmc:/3ds", 0777);
		FILE* f = fopen("sdmc:/3ds/hm_debug.txt", "w");
		if (f) {
			{ extern int gfx_vertex_count(void); fprintf(f, "props %d obst %d nodes %d chests %d verts %d (%d KB) linear free %lu KB\n", nprops, nobst, nnodes, nchests, gfx_vertex_count(), gfx_vertex_count() * 28 / 1024, (unsigned long)linearSpaceFree() / 1024); }
			for (int z = 1; z < Z_COUNT; z++) fprintf(f, "arena %d (%s): h=%.2f zone=%d\n", z, zone_names[z], ground_h(arena_pos[z][0], arena_pos[z][1]), zone_at(arena_pos[z][0], arena_pos[z][1]));
			for (int i = 0; i < NPC_COUNT; i++) fprintf(f, "npc %s h=%.2f zone=%d\n", npcdefs[i].name, ground_h(npcdefs[i].x, npcdefs[i].z), zone_at(npcdefs[i].x, npcdefs[i].z));
			for (int i = 0; i < nchests; i++) fprintf(f, "chest %d zone=%d golden=%d\n", i, zone_at(chests[i].x, chests[i].z), chests[i].golden);
			int cnt[ND_COUNT] = {0}; for (int i = 0; i < nnodes; i++) cnt[nodes[i].type]++;
			for (int t = 0; t < ND_COUNT; t++) fprintf(f, "nodetype %d: %d\n", t, cnt[t]);
			{ // closest pair of things you press A on (interaction clash check)
				float px[400], pz[400]; int n = 0;
				for (int i = 0; i < NPC_COUNT; i++) { px[n] = npcdefs[i].x; pz[n++] = npcdefs[i].z; }
				for (int b = 0; b < BLD_COUNT; b++) { bld_door(b, &px[n], &pz[n]); n++; }
				px[n] = STALL_X; pz[n++] = STALL_Z;
				int base = n;
				for (int i = 0; i < nchests; i++) { px[n] = chests[i].x; pz[n++] = chests[i].z; }
				for (int i = 0; i < nnodes && n < 400; i++) { px[n] = nodes[i].x; pz[n++] = nodes[i].z; }
				float md = 99; int mi = 0, mj = 0;
				for (int i = 0; i < n; i++) for (int j = (i >= base ? i + 1 : base); j < n; j++) { float d = dist2d(px[i], pz[i], px[j], pz[j]); if (d < md) { md = d; mi = i; mj = j; } }
				fprintf(f, "closest fixed-vs-gatherable or gatherable pair: %.2f m (%d,%d) at %.1f,%.1f\n", md, mi, mj, px[mi], pz[mi]);
			}
			fclose(f);
		}
	}
#endif
	titleSel = 0;
	u64 last = svcGetSystemTick();
	while (aptMainLoop()) {
		hidScanInput();
		u32 kd = hidKeysDown(), kh = hidKeysHeld();
		u64 now = svcGetSystemTick();
		float dt = (float)((double)(now - last) / SYSCLOCK_ARM11); last = now;
		if (dt > 0.05f) dt = 0.05f; if (dt <= 0) dt = 0.001f;
		if (mode == MODE_TITLE) update_title(dt, kd);
		else update_play(dt, kd, kh);

		gfx_frame_begin();
		for (int eye = 0; eye < gfx_eyes(); eye++) {
			gfx_begin_eye(eye);
			if (mode == MODE_TITLE) render_title(eye);
			else { render_world(eye); render_hud(eye); }
		}
		if (mode == MODE_TITLE) render_title_bottom(); else render_bottom();
#ifdef HM_DEBUG
		{ static int frames = 0; static float acc = 0, fps = 0; frames++; acc += dt; static int fc = 0; fc++; if (acc > 1) { fps = frames / acc; frames = 0; acc = 0; }
		  extern int g_draws, g_c2dUsed; extern float g_cmdUse, g_cmdPeak; char b[80]; sprintf(b, "d%d par%d sh%d st%d hit%d sl%x z%d", g_draws, dbgParry, dbgShots, (int)P.sta, dbgHits, S.seals, zone_at(P.p.x, P.p.z)); g_draws = 0; rect(0, 0, 230, 10, RGBA(0,0,0,200)); text(2, 1, 1, RGBA(255,255,0,255), b); }
#endif
		gfx_frame_end();
	}
	save_system_exit();
	if (mode == MODE_PLAY) do_save(); // thread stopped: this one writes synchronously
	audio_exit();
	gfx_exit();
	return 0;
}

// ------------------------------------------------------------ text highlighting
// people & places -> yellow, items & monsters -> red, night-only things get a moon after them
typedef struct { const char* s; u8 len, col, night; } HlTerm;
static HlTerm hlt[420]; static int nhl;
static char hlpool[9000]; static int hlpool_n;
static void hl_add(const char* s, int col, int night, bool lowerToo) {
	if (!s || !*s || nhl >= 418) return;
	for (int i = 0; i < nhl; i++) if (strcmp(hlt[i].s, s) == 0) goto lower;
	hlt[nhl].s = s; hlt[nhl].len = strlen(s); hlt[nhl].col = col; hlt[nhl].night = night; nhl++;
lower:
	if (lowerToo && s[0] >= 'A' && s[0] <= 'Z') {
		int L = strlen(s); if (hlpool_n + L + 1 > (int)sizeof hlpool) return;
		char* d = hlpool + hlpool_n; for (int k = 0; k <= L; k++) d[k] = (s[k] >= 'A' && s[k] <= 'Z') ? s[k] + 32 : s[k];
		hlpool_n += L + 1;
		hl_add(d, col, night, false);
	}
}
bool item_night(int id) { return id == XI_MOONBLOOM || id == XI_MOTHDUST; }
static int hl_cmp(const void* a, const void* b) { return ((const HlTerm*)b)->len - ((const HlTerm*)a)->len; }
static void hl_build(void) {
	for (int i = 0; i < NPC_COUNT; i++) if (i != NPC_BOARD) hl_add(npcdefs[i].name, 1, 0, false);
	static const char* people[] = { "Gus", "Maple", "Rustwick", "Wren Ashby", "Wren", "Biscuit", "Button", "Pebble", "Socks", "Marigold Ashby", "Elder" };
	for (u32 i = 0; i < sizeof people / sizeof *people; i++) hl_add(people[i], 1, 0, false);
	for (int z = 0; z < Z_COUNT; z++) hl_add(zone_names[z], 1, 0, false);
	static const char* places[] = { "village", "meadow", "beach", "swamp", "ruins", "woods", "forest", "Whisperwood", "Mirefen Swamp", "Mirefen", "Old Ruins", "Sunspray Beach",
		"mainland", "Great Lantern", "standing stones", "plaza", "island", "Hollowmere", "waterline", "reeds" };
	for (u32 i = 0; i < sizeof places / sizeof *places; i++) hl_add(places[i], 1, 0, false);
	for (int i = 0; i < ALL_ITEMS; i++) { hl_add(itemd(i)->name, 2, item_night(i), true); hl_add(itemd(i)->plural, 2, item_night(i), true); }
	static const char* items[] = { "Moonberry Pie", "Lantern Shards", "Lantern Shard", "XP Tomes", "XP Tome", "Grand XP Tome", "tonics", "moth lamps", "ledger", "moonblooms" };
	for (u32 i = 0; i < sizeof items / sizeof *items; i++) hl_add(items[i], 2, strstr(items[i], "moonbloom") != NULL, false);
	for (int t = 0; t < EN_COUNT; t++) { bool n = endefs[t].fam == FAM_MOTH || endefs[t].fam == FAM_GAUNT; hl_add(endefs[t].name, 2, n, false); hl_add(endefs[t].plural, 2, n, true); }
	for (int f = 0; f <= FAM_GAUNT; f++) hl_add(fam_plural[f], 2, f >= FAM_MOTH, false);
	static const char* mons[] = { "slime", "crab", "thornling", "boar", "toad", "wisp", "golem", "moths", "moth", "gaunts", "gaunt", "Gloopa" };
	for (u32 i = 0; i < sizeof mons / sizeof *mons; i++) hl_add(mons[i], 2, strncmp(mons[i], "moth", 4) == 0 || strncmp(mons[i], "gaunt", 5) == 0, false);
	qsort(hlt, nhl, sizeof *hlt, hl_cmp);
}
static bool is_letter(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'); }
void hl(const char* in, char* out, int cap) {
	if (!nhl) hl_build();
	for (const char* q = in; *q; q++) if ((unsigned char)*q < 8 && *q != '\n') { strncpy(out, in, cap - 1); out[cap - 1] = 0; return; } // already coloured
	int o = 0;
	const char* p = in;
	while (*p && o < cap - 1) {
		if (*p == '[') { // [A], [START]...: buttons get their own colour
			const char* e = strchr(p, ']');
			if (e && e - p < 14 && o + (e - p) + 3 < cap) { out[o++] = 5; memcpy(out + o, p, e - p + 1); o += e - p + 1; p = e + 1; out[o++] = 3; continue; }
		}
		if (p == in || !is_letter(p[-1])) {
			int hit = -1;
			for (int i = 0; i < nhl; i++) if (strncmp(p, hlt[i].s, hlt[i].len) == 0 && !is_letter(p[hlt[i].len])) { hit = i; break; }
			if (hit >= 0 && o + hlt[hit].len + 4 < cap) {
				out[o++] = hlt[hit].col;
				memcpy(out + o, p, hlt[hit].len); o += hlt[hit].len; p += hlt[hit].len;
				// keep possessive 's inside the colour
				if (p[0] == '\'' && p[1] == 's' && !is_letter(p[2]) && o + 3 < cap) { out[o++] = *p++; out[o++] = *p++; }
				out[o++] = 3;
				if (hlt[hit].night && o + 2 < cap) { out[o++] = (char)(0x80 + ICO_MOON); }
				continue;
			}
		}
		out[o++] = *p++;
	}
	out[o] = 0;
}

// ------------------------------------------------------------ icons for things
int item_icon(int id) {
	static const u8 map[ALL_ITEMS] = { ICO_BERRY, ICO_SUNPETAL, ICO_SHELL, ICO_WOOD, ICO_HERB, ICO_MUSHROOM, ICO_LOTUS, ICO_GEM, ICO_DROP, ICO_CRAB,
		ICO_CACTUS, ICO_OYSTER, ICO_ROCK, ICO_PIE, ICO_SHARD, ICO_TONIC,
		ICO_BLOSSOM, ICO_SPARKLES, ICO_LOTION, ICO_YARN, ICO_SEAGLASS, ICO_PEN, ICO_LANTERN, ICO_DIYA, ICO_BOOK };
	return id >= 0 && id < ALL_ITEMS ? map[id] : ICO_HELP;
}
int recipe_icon(int r) {
	const Recipe* c = &recipes[r];
	switch (c->out) {
	case CR_ITEM: return item_icon(c->arg);
	case CR_XP: return c->amount >= 600 ? ICO_BOOKR : c->amount >= 300 ? ICO_NOTEBOOK : c->amount >= 200 ? ICO_BOOKG : ICO_BOOKB;
	case CR_WHET: return ICO_WHET;
	case CR_INFUSE: return elem_icon(c->arg);
	default: return ICO_GIFT;
	}
}
int gear_icon(const Gear* g) {
	if (g->special == 1) return ICO_CAT;
	static const u8 w[WEAPON_BASES] = { ICO_TWIG, ICO_DAGGER, ICO_SWORDS, ICO_AXE, ICO_HAMMER, ICO_TRIDENT, ICO_WAND, ICO_PICK };
	static const u8 a[ARMOR_BASES] = { ICO_SHIRT, ICO_VEST, ICO_CHAINS, ICO_SHIELD, ICO_ROBE };
	static const u8 c[CHARM_BASES] = { ICO_FEATHER, ICO_CLOVER, ICO_MAGNET, ICO_HEARTS, ICO_TOOTH };
	if (g->kind == 0) return w[g->base % WEAPON_BASES];
	if (g->kind == 2) return a[g->base % ARMOR_BASES];
	return c[g->base % CHARM_BASES];
}

int enemy_elem(int type) {
	const EnemyDef* d = &endefs[type];
	if (d->fam == FAM_MOTH) return EL_FIRE;
	if (d->fam == FAM_GAUNT) return EL_FROST;
	return zone_elem[d->zone];
}
int elem_icon(int el) { static const u8 m[EL_COUNT] = { ICO_STAR, ICO_FIRE, ICO_ICE, ICO_SNAKE, ICO_BOLT }; return m[el % EL_COUNT]; }
