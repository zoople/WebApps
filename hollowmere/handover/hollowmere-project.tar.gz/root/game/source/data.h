// Game content: items, enemies, NPCs, quests, achievements
#pragma once
#include "common.h"

// ------------------------------------------------ items
enum { IT_BERRY, IT_SUNPETAL, IT_SHELL, IT_DRIFTWOOD, IT_SILVERLEAF, IT_GLOWCAP, IT_BOGLILY, IT_CRYSTAL,
       IT_GEL, IT_CLAW, IT_THORN, IT_PEARL, IT_CORE, IT_PIE, IT_SHARD, IT_TONIC, IT_COUNT };
typedef struct { const char* name; const char* plural; u32 col; } ItemDef;
static const ItemDef itemdefs[IT_COUNT] = {
	{"Moonberry", "Moonberries", 0xD9365A}, {"Sunpetal", "Sunpetals", 0xFFD23F}, {"Seashell", "Seashells", 0xF7B6A3},
	{"Driftwood", "Driftwood", 0xA9865B}, {"Silverleaf", "Silverleaf", 0xBFE3D6}, {"Glowcap", "Glowcaps", 0xC86BFF},
	{"Bog Lily", "Bog Lilies", 0xF2F2F2}, {"Starcrystal", "Starcrystals", 0xB98CFF}, {"Slime Gel", "Slime Gel", 0x6BE36B},
	{"Crab Claw", "Crab Claws", 0xF26A3D}, {"Thorn", "Thorns", 0x6E8B3D}, {"Marsh Pearl", "Marsh Pearls", 0xE8E4D8},
	{"Golem Core", "Golem Cores", 0x5CD6FF}, {"Moonberry Pie", "Moonberry Pies", 0xC9486A}, {"Lantern Shard", "Lantern Shards", 0xFFC94A},
	{"Healing Tonic", "Healing Tonics", 0xFF5C7A},
};

// extra items (v5+), stored in Save.xitems
enum { XI_MOONBLOOM = IT_COUNT, XI_MOTHDUST, XI_OIL, XI_TWINE, XI_SEAGLASS, XI_INK, XI_HANDLAMP, XI_MOTHLAMP, XI_LEDGER, ALL_ITEMS };
#define XI_MAX 24
static const ItemDef xitemdefs[ALL_ITEMS - IT_COUNT] = {
	{"Moonbloom", "Moonblooms", 0xCFE2FF}, {"Moth Dust", "Moth Dust", 0xE8E0B0}, {"Lamp Oil", "Lamp Oil", 0xF2C14E},
	{"Wick Twine", "Wick Twine", 0xD9C7A0}, {"Sea Glass", "Sea Glass", 0x7FD8C8}, {"Berry Ink", "Berry Ink", 0x6A2A5A},
	{"Hand Lamp", "Hand Lamps", 0xFFD86A}, {"Moth Lamp", "Moth Lamps", 0xFFE9A0}, {"Mended Ledger", "Mended Ledgers", 0xB07A4A},
};
static inline const ItemDef* itemd(int id) { return id < IT_COUNT ? &itemdefs[id] : &xitemdefs[id - IT_COUNT]; }

// forage nodes
enum { ND_BERRY, ND_SUNPETAL, ND_SHELL, ND_DRIFT, ND_SILVER, ND_GLOWCAP, ND_LILY, ND_CRYSTAL, ND_DIG, ND_KITTEN, ND_MOONBLOOM, ND_COUNT };
static const u8 node_item[ND_COUNT] = { IT_BERRY, IT_SUNPETAL, IT_SHELL, IT_DRIFTWOOD, IT_SILVERLEAF, IT_GLOWCAP, IT_BOGLILY, IT_CRYSTAL, 255, 255, XI_MOONBLOOM };
static const char* node_verb[ND_COUNT] = { "Pick", "Pick", "Collect", "Collect", "Pick", "Pick", "Pick", "Mine", "Dig", "Pick up", "Pick" };

// ------------------------------------------------ enemies
enum { FAM_SLIME, FAM_CRAB, FAM_THORN, FAM_BOAR, FAM_TOAD, FAM_WISP, FAM_GOLEM, FAM_BOSS, FAM_MOTH, FAM_GAUNT };
enum { EN_SLIME, EN_PUFF, EN_CRAB, EN_TIDE, EN_THORN, EN_BOAR, EN_TOAD, EN_MWISP, EN_GOLEM, EN_RWISP,
       EN_GLOOPA, EN_PINCER, EN_BRAMBLE, EN_CROAK, EN_COLOSSUS, EN_MOTH, EN_GAUNT,
       EN_SPORE, EN_SPITTER, EN_FLINGER, EN_BOGSPIT, EN_CASTER, EN_COUNT }; // v1.24: ranged foes, one per zone
typedef struct {
	const char* name; const char* plural; u8 fam, zone, lvl; float hp, dmg, speed, radius, scale; int xp, gold; s8 drop; u32 col; bool boss;
} EnemyDef;
static const EnemyDef endefs[EN_COUNT] = {
	{"Slime", "Slimes", FAM_SLIME, Z_MEADOW, 1, 18, 4, 2.2f, 0.45f, 1.0f, 6, 2, IT_GEL, 0x6BD95A, false},
	{"Puff Slime", "Puff Slimes", FAM_SLIME, Z_MEADOW, 2, 28, 6, 2.4f, 0.5f, 1.15f, 9, 3, IT_GEL, 0x6AB7F5, false},
	{"Sand Crab", "Sand Crabs", FAM_CRAB, Z_BEACH, 3, 40, 8, 3.0f, 0.5f, 1.0f, 14, 4, IT_CLAW, 0xE8643A, false},
	{"Tide Slime", "Tide Slimes", FAM_SLIME, Z_BEACH, 4, 46, 9, 2.6f, 0.5f, 1.2f, 16, 5, IT_GEL, 0x3FC9C9, false},
	{"Thornling", "Thornlings", FAM_THORN, Z_FOREST, 5, 60, 11, 2.8f, 0.5f, 1.0f, 22, 6, IT_THORN, 0x4E9A3A, false},
	{"Bramble Boar", "Bramble Boars", FAM_BOAR, Z_FOREST, 6, 80, 14, 4.0f, 0.65f, 1.0f, 30, 8, IT_THORN, 0x8A5A3C, false},
	{"Bog Toad", "Bog Toads", FAM_TOAD, Z_SWAMP, 8, 95, 15, 3.0f, 0.6f, 1.0f, 38, 9, IT_PEARL, 0x7A9A3A, false},
	{"Mire Wisp", "Mire Wisps", FAM_WISP, Z_SWAMP, 9, 70, 18, 3.4f, 0.45f, 1.0f, 42, 10, IT_PEARL, 0x9CFF6A, false},
	{"Rubble Golem", "Rubble Golems", FAM_GOLEM, Z_RUINS, 11, 160, 22, 1.9f, 0.75f, 1.0f, 60, 14, IT_CORE, 0x9A968A, false},
	{"Rune Wisp", "Rune Wisps", FAM_WISP, Z_RUINS, 12, 110, 24, 3.8f, 0.45f, 1.0f, 64, 14, IT_CORE, 0x7AB8FF, false},
	{"Gloopa the Gelatinous", "", FAM_BOSS, Z_MEADOW, 4, 260, 10, 2.0f, 1.4f, 3.2f, 150, 60, IT_GEL, 0xFF7EC8, true},
	{"King Pincer", "", FAM_BOSS, Z_BEACH, 6, 480, 16, 2.6f, 1.4f, 2.6f, 260, 100, IT_CLAW, 0xFF4A2A, true},
	{"Bramblehorn", "", FAM_BOSS, Z_FOREST, 9, 760, 22, 3.0f, 1.5f, 2.4f, 380, 150, IT_THORN, 0x5A3A22, true},
	{"Queen Croak", "", FAM_BOSS, Z_SWAMP, 12, 1050, 27, 2.6f, 1.5f, 2.8f, 520, 200, IT_PEARL, 0x5FB04A, true},
	{"The Hollow Colossus", "", FAM_BOSS, Z_RUINS, 15, 1600, 34, 1.8f, 1.8f, 2.8f, 800, 320, IT_CORE, 0x8C8A80, true},
	{"Lamp Moth", "Lamp Moths", FAM_MOTH, Z_SWAMP, 5, 55, 12, 3.6f, 0.45f, 1.0f, 26, 6, XI_MOTHDUST, 0xE8E0B0, false},
	{"Night Gaunt", "Night Gaunts", FAM_GAUNT, Z_RUINS, 10, 170, 26, 3.8f, 0.65f, 1.1f, 60, 14, XI_MOTHDUST, 0x3A3050, false},
	// ranged: keep their distance and lob shots you can roll through
	{"Spore Puff", "Spore Puffs", FAM_SLIME, Z_MEADOW, 2, 20, 5, 2.0f, 0.45f, 0.95f, 10, 3, IT_GEL, 0xC9A0FF, false},
	{"Shell Spitter", "Shell Spitters", FAM_CRAB, Z_BEACH, 4, 34, 8, 2.6f, 0.5f, 0.9f, 17, 5, IT_CLAW, 0x4FB0C0, false},
	{"Thorn Flinger", "Thorn Flingers", FAM_THORN, Z_FOREST, 6, 50, 11, 2.6f, 0.5f, 0.95f, 26, 7, IT_THORN, 0xB08A2A, false},
	{"Bog Spitter", "Bog Spitters", FAM_TOAD, Z_SWAMP, 9, 80, 14, 2.6f, 0.55f, 0.9f, 40, 10, IT_PEARL, 0x3F8A7A, false},
	{"Rune Caster", "Rune Casters", FAM_WISP, Z_RUINS, 12, 90, 20, 3.0f, 0.45f, 1.0f, 64, 14, IT_CORE, 0xFF9A5A, false},
};
static inline bool en_ranged(int t) { return t >= EN_SPORE; }
// v1.25 combat roles: each asks for a different answer, and each zone adds one new kind
//  swarm: weak, in packs, may raise a guard   shield: blocks hits from the front (go round, or hit after it swings)
//  charger: crouches behind a red arrow, then dashes (sidestep)   brute: slow slam inside a red ring (get out, then punish)
//  caster: drops a red circle where you stand (move)   ranged: lobs shots (roll through)
enum { R_SWARM, R_SHIELD, R_CHARGER, R_BRUTE, R_CASTER, R_RANGED, R_BOSS };
static const u8 en_role[EN_COUNT] = { R_SWARM, R_SWARM, R_SHIELD, R_SWARM, R_SWARM, R_CHARGER, R_BRUTE, R_CASTER, R_BRUTE, R_CASTER,
	R_BOSS, R_BOSS, R_BOSS, R_BOSS, R_BOSS, R_SWARM, R_CHARGER, R_RANGED, R_RANGED, R_RANGED, R_RANGED, R_RANGED };
static const char* fam_plural[] = { "slimes", "crabs", "thornlings", "boars", "toads", "wisps", "golems", "bosses", "lamp moths", "night gaunts" };
static const float arena_pos[Z_COUNT][2] = { {0,0}, {16.5f,-20.6f}, {-16.9f,63.2f}, {63.2f,-16.9f}, {12.6f,-62.8f}, {-63.2f,16.9f} }; // v1.21: island doubled

// ------------------------------------------------ gear
enum { R_COMMON, R_UNCOMMON, R_RARE, R_EPIC, R_LEGEND, R_COUNT };
static const char* rarity_name[R_COUNT] = { "Common", "Uncommon", "Rare", "Epic", "Legendary" };
static const u32 rarity_col[R_COUNT] = { 0xE6E6E6, 0x5BE36A, 0x4AA8FF, 0xC266FF, 0xFFA53A };
static const float rarity_mult[R_COUNT] = { 1.0f, 1.25f, 1.55f, 1.95f, 2.5f };
static const char* weapon_base[] = { "Twig", "Dagger", "Sword", "Axe", "Hammer", "Spear", "Wand", "Scythe" };
#define WEAPON_BASES 8
static const char* charm_base[] = { "Feather", "Clover", "Lodestone", "Heartstone", "Fang" };
static const char* charm_stat[] = { "Move speed", "Luck", "Pickup range", "Max HP", "Crit chance" };
#define CHARM_BASES 5
static const char* armor_base[] = { "Tunic", "Vest", "Mail", "Plate", "Robe" };
static const float armor_mult[] = { 0.85f, 1.0f, 1.12f, 1.25f, 0.95f };
static const u32 armor_tint[] = { 0xC9B48A, 0x8A5A34, 0x9AA0AA, 0xD0D6E0, 0x7A4FB5 };
#define ARMOR_BASES 5
static const char* prefix[R_COUNT][4] = {
	{"Plain", "Worn", "Sturdy", "Simple"}, {"Fine", "Keen", "Polished", "Balanced"}, {"Gleaming", "Runed", "Tidal", "Verdant"},
	{"Starforged", "Moonlit", "Wyrmbone", "Stormcall"}, {"Lantern-Blessed", "Mythic", "Sunsworn", "Eternal"} };

typedef struct { u8 used, kind, base, rarity, ilvl, upg, pre, special; u16 power; u8 elem, pad; } Gear; // kind 0 weapon, 1 charm, 2 armour

// ------------------------------------------------ elements
// Each zone's creatures carry an element. Weapons of the opposing element hit much harder;
// armour of an element shrugs off attacks of that element.
enum { EL_NONE, EL_FIRE, EL_FROST, EL_VENOM, EL_STORM, EL_COUNT };
static const char* elem_name[EL_COUNT] = { "", "Fire", "Frost", "Venom", "Storm" };
static const u32 elem_col[EL_COUNT] = { 0xFFFFFF, 0xFF7A3A, 0x8FD8FF, 0x8CE05A, 0xFFE14A };
static const u8 elem_weak[EL_COUNT] = { EL_NONE, EL_FROST, EL_FIRE, EL_STORM, EL_VENOM }; // a foe of element X is weak to elem_weak[X]
static const u8 zone_elem[Z_COUNT] = { EL_NONE, EL_NONE, EL_FROST, EL_FIRE, EL_VENOM, EL_STORM }; // village, meadow, beach, ruins, forest, swamp

// ------------------------------------------------ NPCs
enum { NPC_ELDER, NPC_PIP, NPC_BRAM, NPC_TILLY, NPC_GUS, NPC_FERN, NPC_ODESSA, NPC_RUST, NPC_MARI, NPC_BOARD, NPC_COUNT };
typedef struct {
	const char* name; float x, z, yaw; u32 body, skin, hair, hatcol; u8 hat; float scale;
	const char* idle[3];
} NpcDef;
static const NpcDef npcdefs[NPC_COUNT] = {
	{"Elder Maple", -3.2f, -3.0f, 0.8f, 0x7B4FB5, 0xF2C9A0, 0xF0F0F0, 0x5B3A8F, 1, 1.0f,
		{"The Lantern kept the island's spirits calm for a hundred years.", "Talk to everyone. Small kindnesses add up.", "My knees predict rain. My knees are usually wrong."}},
	{"Pip", -3.4f, 5.2f, PI*0.8f, 0xF5F0E6, 0xF7D3B5, 0xC9783E, 0xFFFFFF, 2, 0.95f,
		{"Flour on my nose? Again?", "A pie a day keeps the gloom away!", "Gus used to visit every Sunday. I miss his terrible jokes."}},
	{"Bram", 5.5f, 1.6f, PI, 0x3F8F5A, 0xE8B98F, 0x4A3020, 0x2E5E3E, 3, 1.05f,
		{"Everything's for sale, friend. Well, almost everything.", "Mystery Boxes! Could be junk, could be LEGENDARY.", "A sharp blade is a happy blade."}},
	{"Tilly", 3.4f, -5.0f, -PI*0.6f, 0xFF8FB0, 0xF7D3B5, 0xE8833A, 0xE8833A, 8, 0.75f,
		{"Biscuit is the best cat in the WHOLE world.", "Did you know cats sleep sixteen hours a day? Lucky.", "When I grow up I'm going to be a hero. Like you!"}},
	{"Old Gus", 10.1f, 41.8f, PI, 0x4A6FA5, 0xE3B58F, 0xBDBDBD, 0xFFD23F, 4, 1.0f,
		{"The sea gives, the sea takes. Mostly it takes my hat.", "Hrmph. Nice day for it, I suppose.", "Pip's pie... best thing I've eaten in years. Don't tell her."}},
	{"Fern", -7.3f, -42.4f, 0, 0x4E8A3E, 0xE8C29E, 0x7A4A2A, 0x3A6E30, 5, 0.95f,
		{"The trees whisper if you're quiet enough.", "Silverleaf for headaches. Glowcap for... glowing.", "Every creature here has a place. Even the grumpy ones."}},
	{"Odessa", -42.1f, -8.7f, PI*0.5f, 0x4A2E5E, 0xC9D9A8, 0x2A2A2A, 0x2E1E3E, 6, 1.0f,
		{"Heh heh. The stew's almost ready. Don't ask what's in it.", "Toads are lovely. Loud, but lovely.", "The swamp remembers everything."}},
	{"Sir Rustwick", 42.1f, 9.0f, -PI*0.5f, 0x9A9AA6, 0xF0C8A0, 0x888888, 0xC0C0CC, 7, 1.1f,
		{"Squeak. Ahem. That was my armor, not me.", "I have guarded these ruins for forty years. Nobody asked me to.", "A knight never retreats! A knight... strategically repositions."}},
	{"Marigold", -2.6f, 1.9f, 1.1f, 0x3FA7A0, 0xF4D2B8, 0xB0502A, 0x6A3A8A, 0, 0.92f,
		{"I keep reading the same page. Lit at dusk.", "Biscuit seems to know this island better than any of us.", "Aunt Wren's handwriting gets smaller every year. Like she was saving paper."}},
	{"Bounty Board", -5.6f, 3.4f, 0, 0, 0, 0, 0, 0, 1.0f, {"", "", ""}},
};

// ------------------------------------------------ quests
enum { QT_FORAGE, QT_KILL, QT_DELIVER, QT_BOSS, QT_KITTEN, QT_LANTERN, QT_TOME, QT_BUYTONIC, QT_CRAFTTONIC, QT_EVENT, QT_PORTAL };
typedef struct {
	const char* title; s8 giver; u8 type; u8 target; u8 count; s8 turnin; s8 req;
	int gold, xp; s8 rItem; u8 rCount; s8 rGear; u8 rGearKind;
	const char* intro; const char* prog; const char* done;
	u8 rElem;     // element of the reward weapon (the one the next zone needs)
	u8 nightOnly; // can only be handed in after dark
} QuestDef;
enum { Q_E0, Q_E1, Q_E2, Q_E3, Q_P0, Q_P1, Q_P2, Q_B0, Q_B1, Q_B2, Q_T0, Q_T1, Q_G0, Q_G1, Q_G2, Q_F0, Q_F1, Q_F2, Q_O0, Q_O1, Q_O2, Q_R0, Q_R1, Q_R2, Q_H0, Q_H1,
       Q_NT0, Q_NT1, Q_NT2, Q_EV0, Q_EV1, Q_FG1, Q_FG2, Q_AP1, Q_AP2,
       Q_L0, Q_L1, Q_L2, Q_L3, Q_L4, Q_L5, Q_COUNT }; // Q_L*: Marigold's ledger (was the main story before v1.21)
#define Q_COUNT_V1 24 // quests stored in the original save arrays
static const QuestDef questdefs[Q_COUNT] = {
	{"Berries for the Elder", NPC_ELDER, QT_FORAGE, IT_BERRY, 5, -1, Q_E0, 30, 40, IT_TONIC, 2, -1, 0,
		"Ah, a new face! Welcome to Hollowmere, little traveller.|Our Great Lantern has gone dark, and the island grows restless.|But first, my old bones need Moonberries. Bring me 5? The red-dotted bushes grow all over the meadow.",
		"Moonberries grow on the round bushes in the meadow. Walk up and press [A].",
		"Splendid! Sweet as starlight. You've a knack for this.|Take these. And do talk to everyone in the village. They all need a hand.|Bram the trader sells XP Tomes. Spend your gold there: books teach more than brawls.|And mind this: wounds don't mend on their own out there. Carry Healing Tonics, from Bram or from Pip's kitchen."},
	{"Slime Trouble", NPC_ELDER, QT_KILL, FAM_SLIME, 8, -1, -1, 60, 80, -1, 0, R_UNCOMMON, 0,
		"Since the Lantern dimmed, slimes have been gobbling the meadow flowers.|Thin their numbers. Eight should teach them manners.|[A] swings your weapon. Chain three swings for a big finisher! [B] rolls you out of danger.",
		"Defeat slimes in the meadow around the village.",
		"Ha! The flowers are perking up already.|Here, a proper weapon. That twig was embarrassing us both."},
	{"Gloopa Rises", NPC_ELDER, QT_BOSS, EN_GLOOPA, 1, -1, Q_E1, 150, 200, -1, 0, R_RARE, 0,
		"I feared this. Gloopa, the great gelatinous queen, has swallowed a Lantern Shard!|She wallows in the meadow north-east of the village, by the old standing stones.|When she rears up, a red ring appears. Roll out of it!",
		"Gloopa waits north-east of the village. Watch for the red ring!",
		"A Lantern Shard! Feel how warm it is.|And she was hoarding this blade. Feel the heat in it? Fire.|The beach creatures have gone cold as ice. Frost things fear fire. Keep this close.", EL_FIRE},

	{"Relight the Lantern", NPC_ELDER, QT_LANTERN, IT_SHARD, 5, -1, Q_R2, 500, 900, IT_TONIC, 5, R_LEGEND, 0,
		"Five shards, five guardians. Old Gus at the beach, Fern in Whisperwood, Odessa in the swamp, and Sir Rustwick in the ruins.|Bring all five shards to me and we'll make the Lantern shine again.",
		"Collect all 5 Lantern Shards from the island's guardians.",
		"All five... I never thought I'd see this day.|Stand back, child. Let's light it together!|...|It shines! Hollowmere will sleep soundly tonight. Thank you, hero.|The island is yours to roam. Bounties, treasure and secrets still wait."},
	{"Pie Ingredients", NPC_PIP, QT_FORAGE, IT_BERRY, 6, -1, Q_H1, 40, 50, IT_TONIC, 2, -1, 0,
		"Time for the real thing: my famous Moonberry Pie.|Could you fetch 6 Moonberries? The red-dotted bushes, same as for the Elder.",
		"Pip needs 6 Moonberries from the meadow bushes.",
		"Into the oven they go! Mmm, smell that.|Have some tonics. I brew them with leftover berries. Waste not!"},
	{"Special Delivery", NPC_PIP, QT_DELIVER, IT_PIE, 1, NPC_GUS, Q_P0, 60, 90, -1, 0, -1, 0,
		"This pie is for Old Gus down at Sunspray Beach, due south of the village.|He hasn't come to town in weeks. Mind the crabs!",
		"Deliver the Moonberry Pie to Old Gus at Sunspray Beach (south).",
		"A Moonberry Pie? From Pip? *sniff*|...Tell her I said thanks. And that I'll visit Sunday."},
	{"Honey Cakes", NPC_PIP, QT_FORAGE, IT_SUNPETAL, 5, -1, -1, 100, 120, -1, 0, R_UNCOMMON, 1,
		"Everyone's gloomy since the Lantern went dark. Honey cakes fix gloom. Science!|Could you find 5 Sunpetals? The big yellow flowers in the meadow.",
		"Pip needs 5 Sunpetals - big yellow flowers in the meadow.",
		"Perfect! The whole plaza will smell of honey.|Here, a little charm for luck."},
	{"Study Hard", NPC_BRAM, QT_TOME, 0, 1, -1, Q_H0, 30, 0, IT_TONIC, 1, -1, 0,
		"Now, friend, you look under-read.|Monsters won't teach you much. Books will! That's where real strength comes from.|Buy an XP Tome from my shop and read it. Press [A] at the coin on my cart to browse.",
		"Buy an XP Tome from Bram's shop ([A] at the coin on his cart).",
		"See? Sharper already. Most of your growth comes from books, not brawls.|Bring gold back whenever your purse is heavy. I'll always have more tomes."},
	{"Lily Perfume", NPC_BRAM, QT_FORAGE, IT_BOGLILY, 5, -1, Q_FG2, 160, 180, IT_TONIC, 2, -1, 0,
		"New business idea: perfume! Bog Lilies smell divine, believe it or not.|Five lilies from Mirefen Swamp, out west. Hold your nose on the way.",
		"Bram wants 5 Bog Lilies from Mirefen Swamp (west).",
		"Smell that! ...Okay, it smells a bit like swamp. Marketing will fix it."},
	{"Crystal Clear", NPC_BRAM, QT_FORAGE, IT_CRYSTAL, 4, -1, Q_B1, 260, 300, -1, 0, R_RARE, 1,
		"Starcrystals. The ruins to the east are full of them, and so are collectors' wallets.|Four should do. Don't get squashed by a golem.",
		"Bram wants 4 Starcrystals from the Old Ruins (east).",
		"Ooh, they hum! Take this charm. Found it in a crate, never could identify it."},
	{"Where Are My Kittens?", NPC_TILLY, QT_KITTEN, 0, 3, -1, Q_T1, 100, 150, -1, 0, R_LEGEND, 1,
		"Biscuit LOVES her crown. Now she misses her babies even more.|I heard meowing in the woods, by the beach, and near the swamp.|Please find Button, Pebble and Socks! Listen for mews!",
		"Find 3 kittens: one each in Whisperwood, Sunspray Beach and Mirefen Swamp. Listen for mews!",
		"BUTTON! PEBBLE! SOCKS! You found them ALL!|Biscuit says thank you. She wants you to have her lucky whisker charm!"},
	{"A Crown for Biscuit", NPC_TILLY, QT_FORAGE, IT_SUNPETAL, 4, -1, -1, 50, 70, IT_TONIC, 1, -1, 0,
		"While we wait for news of the kittens, Biscuit deserves a flower crown. She's basically a queen.|Can you get 4 Sunpetals?",
		"Tilly needs 4 Sunpetals for a flower crown.",
		"She looks SO regal. She hates it. Thank you!"},
	{"Crab Cleanup", NPC_GUS, QT_KILL, FAM_CRAB, 8, -1, -1, 90, 120, -1, 0, R_UNCOMMON, 0,
		"Hrmph. Crabs. Everywhere. Can't even mend my nets.|Knock some sense into eight of 'em, would ya?",
		"Defeat 8 Sand Crabs on Sunspray Beach.",
		"Quieter already. Here, this old thing was cluttering up my hut."},
	{"Driftwood Repairs", NPC_GUS, QT_FORAGE, IT_DRIFTWOOD, 6, -1, Q_G0, 110, 150, IT_TONIC, 2, -1, 0,
		"My boat's got more holes than a fishing net. Ha. Fishing net. Get it?|Six pieces of driftwood should patch her up.",
		"Gus needs 6 Driftwood from the beach.",
		"She floats! Mostly. Thanks, kid."},
	{"The King Under the Sand", NPC_GUS, QT_BOSS, EN_PINCER, 1, -1, Q_G1, 200, 280, -1, 0, R_RARE, 0,
		"Something big's been tunnelling under the south shore. A crab the size of a cart.|Had a glowing shard in its claw, too. One of the Elder's, I'd wager.|You'll find it at the southern tip of the beach.",
		"King Pincer lurks at the southern tip of Sunspray Beach.",
		"You did it! Ha! I'll be telling this one at the tavern for years.|The old king was sitting on this. Crackles in the hand, doesn't it? Storm.|Thornlings up in Whisperwood drip venom. Storm cuts right through venom. Take it.", EL_STORM},

	{"Herbal Remedy", NPC_FERN, QT_FORAGE, IT_SILVERLEAF, 6, -1, -1, 100, 160, IT_TONIC, 3, -1, 0,
		"Shh... the woods are listening. I'm Fern. I brew remedies for the village.|Silverleaf grows in the shade here. Six sprigs, please.",
		"Fern needs 6 Silverleaf from Whisperwood.",
		"Perfect. I'll make extra tonics. Take some, you look like you need them."},
	{"Thorns in My Side", NPC_FERN, QT_KILL, FAM_THORN, 10, -1, Q_F0, 150, 220, -1, 0, R_RARE, 0,
		"The thornlings used to be shy little sprouts. Now they bite.|Calm ten of them down. Firmly.",
		"Defeat 10 Thornlings in Whisperwood.",
		"The forest feels lighter. This blade was my grandmother's. Use it well."},
	{"The Bramblehorn", NPC_FERN, QT_BOSS, EN_BRAMBLE, 1, -1, Q_F1, 260, 380, -1, 0, R_RARE, 0,
		"The forest's guardian has gone wild. A great beast of bark and thorn.|It wears the Lantern Shard like a crown. Its clearing is to the north. Be brave.",
		"The Bramblehorn waits in the northern clearing of Whisperwood.",
		"It's resting now. Peacefully. Thank you for not hating it.|It left this thorn-blade behind. It carries the forest's venom.|Everything in the swamp crackles with storm. Venom grounds storm. You'll need it there.", EL_VENOM},

	{"Glowcap Stew", NPC_ODESSA, QT_FORAGE, IT_GLOWCAP, 8, -1, -1, 130, 220, -1, 0, -1, 0,
		"Heh heh heh. Don't mind the bubbling. I'm Odessa, and this is my swamp.|I'm cooking a stew that glows in the dark. Need 8 Glowcaps.",
		"Odessa needs 8 Glowcaps (glowing mushrooms in the swamp and woods).",
		"Into the pot! Want a taste? No? Your loss. Here, have some coin instead."},
	{"Toad Tax", NPC_ODESSA, QT_KILL, FAM_TOAD, 10, -1, Q_O0, 180, 280, -1, 0, R_RARE, 1,
		"The toads have been croaking ALL night since the Lantern went out. I haven't slept in weeks.|Ten of them. Quietly, if you can manage it.",
		"Defeat 10 Bog Toads in Mirefen Swamp.",
		"Silence. Glorious silence. Take this trinket. It's only slightly cursed. Joking!"},
	{"Queen Croak", NPC_ODESSA, QT_BOSS, EN_CROAK, 1, -1, Q_O1, 300, 480, -1, 0, R_EPIC, 0,
		"Their queen has a Lantern Shard stuck in her throat. That's what all the croaking is about.|She sits on her throne of mud at the western edge of the swamp.",
		"Queen Croak rules the western edge of Mirefen Swamp.",
		"Well done! She's already sounding better. Here's your shard, slightly slimy.|And this frost-iron blade was in her throne of mud. Cold as a grave.|The ruin golems burn like coals. Frost cracks them. Heh. Off you go.", EL_FROST},

	{"Polish My Armor", NPC_RUST, QT_FORAGE, IT_GEL, 8, -1, -1, 140, 240, IT_TONIC, 2, -1, 0,
		"Halt! Who goes there? Oh. A hero. Splendid.|My armor squeaks terribly. Slime Gel makes a fine polish. Eight dollops, if you please.",
		"Sir Rustwick needs 8 Slime Gel (dropped by slimes).",
		"Listen! ...Silence! Not a single squeak! You have my eternal gratitude."},
	{"The Golem Problem", NPC_RUST, QT_KILL, FAM_GOLEM, 8, -1, Q_R0, 220, 360, -1, 0, R_EPIC, 0,
		"The old stone golems have woken up and they keep knocking over my tent.|Eight of them should be enough. They're slow but they hit like a wagon.",
		"Defeat 8 Rubble Golems in the Old Ruins.",
		"Magnificent swordplay! Take this. It was meant for a knight, and you have earned it."},
	{"The Hollow Colossus", NPC_RUST, QT_BOSS, EN_COLOSSUS, 1, -1, Q_R1, 400, 650, -1, 0, R_EPIC, 1,
		"There is a giant in the heart of the ruins. I have... been meaning to deal with it. For forty years.|It holds the last Lantern Shard. Its stomp shakes the whole island. Roll out of the red ring!",
		"The Hollow Colossus stands at the eastern heart of the ruins.",
		"You have done what I could not. The ruins are yours, hero.|Take the shard home. Light that Lantern."},
	{"First Aid", NPC_BRAM, QT_BUYTONIC, 0, 1, -1, -1, 25, 0, -1, 0, -1, 0,
		"First lesson, friend. Out there, cuts don't close by themselves.|Only a Healing Tonic will patch you up. Buy one from me, then press [X] when you're hurt.|Press [A] at the coin on my cart to open the shop.",
		"Buy a Healing Tonic from Bram's shop. Press [X] to drink one when you're hurt.",
		"Smart. Never leave town without a few.|Bring gold back and I'll keep you stocked."},
	{"Pip's Kitchen Cure", NPC_PIP, QT_CRAFTTONIC, 0, 1, -1, Q_P2, 35, 0, IT_BERRY, 2, -1, 0,
		"Tonics from Bram? Pfft. Mine are better, and free, if you brew them yourself!|Two Moonberries and three Sunpetals. Open the Craft tab, pick Healing Tonic and press [Y].|It takes a minute to brew. Off you go, and come back when it's done!",
		"Craft a Healing Tonic in the Craft tab: 2 Moonberries + 3 Sunpetals.",
		"Look at that colour! You're a natural.|Brew a few before every trip. Here, more berries for the next batch."},
	// night quests
	{"Moonlit Brew", NPC_ODESSA, QT_FORAGE, XI_MOONBLOOM, 3, -1, Q_O2, 120, 150, IT_TONIC, 3, -1, 0,
		"Heh. My best brew needs moonblooms. They only open after dark.|Bring me three when the moon's up. The swamp has plenty, if you can see them.",
		"Odessa wants 3 Moonblooms. They only open at night.",
		"Ooh, still dewy. Take some tonics. Brewed by moonlight, they are."},
	{"Wings in the Dark", NPC_FERN, QT_KILL, FAM_MOTH, 5, -1, Q_F2, 140, 160, -1, 0, R_UNCOMMON, 0,
		"Lamp moths swarm the woods at night. They're stripping my glowcaps bare.|Thin them out? Five should do. They only come out after dark.",
		"Defeat 5 Lamp Moths. They only appear at night.",
		"The woods can breathe again. Take this. It hums when moths are near."},
	{"The Gaunt Watch", NPC_RUST, QT_KILL, FAM_GAUNT, 4, -1, Q_R2, 220, 260, -1, 0, R_RARE, 0,
		"Squeak. Ahem. Night Gaunts stalk the ruins once the sun is down.|A knight should face them. A knight would rather you did. Defeat four.",
		"Defeat 4 Night Gaunts in the ruins or swamp. Night only.",
		"Four! Truly a knight of the night shift. Take this blade."},
	// world events
	{"Strange Lights", NPC_GUS, QT_EVENT, 0, 1, -1, Q_G2, 150, 200, IT_TONIC, 2, -1, 0,
		"Hrmph. Something else has stirred since the old king went down. Monsters gather in swarms, all at once.|Go out into the wilds and keep your eyes open. A banner will tell you when a surge starts.|Break one and we'll know what we're dealing with.",
		"Break a Monster Surge. One will flare up out in the wilds soon.",
		"Broken, eh? Well fought.|Won't be the last of them, mind. Surges will keep flaring up from now on.|Whenever one starts near you, pitch in if you can spare the time. There's always good loot in it."},
	{"The Key Keeper", NPC_TILLY, QT_PORTAL, 0, 1, -1, Q_T0, 120, 150, -1, 0, R_UNCOMMON, 1,
		"I saw a swirly purple PORTAL out past the village! Biscuit hissed at it.|Gus says when one opens, keys scatter everywhere. Find them all before it closes!|Go wait out in the wilds. The next one's yours!",
		"Close a Portal Rift: grab every key before time runs out.",
		"You closed it?! Biscuit is very impressed. She found this for you.|Portals will keep popping open out in the wilds now, and they always drop treasure.|Whenever you see one, go key-hunting if you're free. Biscuit says so."},
	// buildings
	{"Stoke the Forge", NPC_BRAM, QT_FORAGE, IT_GEL, 6, -1, Q_B0, 60, 80, -1, 0, -1, 0,
		"See the blue-roofed house? That's the Old Forge. Cold for years.|Get it burning and it can infuse your weapon with an element. Fire beats frost, frost beats fire.|Slime Gel burns slow and hot. Bring me six and we'll light her up.",
		"Bring Bram 6 Slime Gel to relight the Old Forge.",
		"She's lit! Now the Forge can make Fire and Frost infusions.|Start one in the Craft tab. When it's done, collect it at the Forge door."},
	{"New Bellows", NPC_BRAM, QT_FORAGE, IT_DRIFTWOOD, 5, -1, Q_FG1, 120, 140, -1, 0, -1, 0,
		"The Forge breathes, but it wheezes. Five Driftwood for new bellows and she'll roar.|Then she can do Venom and Storm infusions, and armour wards too.",
		"Bring Bram 5 Driftwood for the Forge's bellows.",
		"Listen to her roar! Every infusion and ward can be made at the Forge now."},
	{"Mend the Roof", NPC_PIP, QT_FORAGE, IT_DRIFTWOOD, 4, -1, Q_P1, 60, 80, -1, 0, -1, 0,
		"The old Apothecary, the red-roofed house, has a hole in the roof. Grandma brewed there!|Four pieces of Driftwood would patch it. Then you can brew tonics in big batches.",
		"Bring Pip 4 Driftwood to mend the Apothecary roof.",
		"Dry as a biscuit! The Apothecary's open again.|Start a Tonic Batch in the Craft tab, then pick it up at the Apothecary door."},
	{"Herb Garden", NPC_PIP, QT_FORAGE, IT_SILVERLEAF, 5, -1, Q_AP1, 120, 140, -1, 0, -1, 0,
		"Every apothecary needs a herb garden. Five Silverleaf from the woods?|With fresh herbs, the Apothecary can brew my Night Draught.",
		"Bring Pip 5 Silverleaf for the Apothecary garden.",
		"Look at it bloom! The Apothecary can brew Night Draught now. Moonblooms make it strong."},
	// Marigold's ledger (the v1.0-1.20 main story, now Marigold's own chain)
	{"The Faded Ledger", NPC_MARI, QT_FORAGE, XI_HANDLAMP, 1, -1, -1, 120, 160, -1, 0, -1, 0,
		"@Marigold:This was my great-aunt Wren's ledger. The last Lamplighter. Everyone says she retired to the mainland in 1987.|@Biscuit:(Biscuit sniffs the ledger. Then sits on it. Firmly.)|@Marigold:The ink's gone pale. I need a proper lamp to read it, and the big one's dark. Could you make me a Hand Lamp?",
		"Craft a Hand Lamp (Craft tab): Lamp Oil plus Wick Twine, or the raw makings of both.",
		"@Marigold:Perfect. Let's see...|@Marigold:'1 March 1987. Lit at dusk. G. not home yet.'|@Marigold:And the next night. And the next. The same line, every night.|@Biscuit:(Biscuit turns to face the beach. Towards Gus's hut.)|@Marigold:Who's G?"},
	{"Blooms After Dark", NPC_GUS, QT_FORAGE, XI_MOONBLOOM, 4, -1, Q_L0, 160, 200, -1, 0, -1, 0,
		"@Gus:Wren Ashby. Hrmph. She left. Took the spring ferry in '87. I watched it go.|@Marigold:Then who wrote 'lit at dusk' for the next three hundred nights?|@Gus:...She planted moonblooms by the swamp and the meadow. Only open after dark. Daft things.|@Gus:Bring me four. If they've gone wild, she's long gone. If they haven't...",
		"Pick 4 Moonblooms. They only open at night, in the meadow, woods and swamp.",
		"@Gus:These were pruned. Recently. Somebody's been tending them.|@Gus:Wren always cut the stems on the slant. Said it helped them drink.|@Marigold:These are cut on the slant.|@Gus:...Aye. They are."},
	{"One for Every Night", NPC_MARI, QT_FORAGE, XI_MOTHLAMP, 1, -1, Q_L1, 200, 260, -1, 0, -1, 0,
		"@Marigold:There's a page I nearly missed. 'Small lamps. One for every night he's late.'|@Marigold:Little glass jars, a splash of oil, a twist of wick. Moth lamps, she calls them.|@Marigold:If I can hold one, I'll know what I'm looking for. Can you make one?",
		"Craft a Moth Lamp: Sea Glass plus Lamp Oil. Needs crafting level 2.",
		"@Marigold:It's lovely. It's exactly the sketch.|@Marigold:And she counted them. Page after page. 41. 112. 377.|@Marigold:Gus. How long were you at sea?|@Gus:...Long enough."},
	{"Moths at the Waterline", NPC_GUS, QT_KILL, FAM_MOTH, 6, -1, Q_L2, 240, 300, -1, 0, R_RARE, 1,
		"@Gus:Lamp moths have been thick round the island at night. Thicker every year.|@Gus:Moths only gather where there's been a flame. A lot of flame.|@Gus:Clear six of them off. Then we'll see what they've been circling.",
		"Defeat 6 Lamp Moths. They only come out at night.",
		"@Gus:There. Look at the reeds.|@Marigold:Jars. Hundreds of them. All along the waterline.|@Gus:Every one with a fresh wick.|@Gus:She never got on that ferry. She was here. The whole time."},
	{"The Last Pages", NPC_MARI, QT_FORAGE, XI_LEDGER, 1, -1, Q_L3, 300, 360, -1, 0, -1, 0,
		"@Marigold:The last pages are stuck together. Swamp water.|@Marigold:If we rebind them with fresh twine and touch up the ink, I think I can read them.|@Biscuit:(Biscuit lies across the ledger, purring, as if keeping it warm.)",
		"Craft a Mended Ledger: Berry Ink plus Wick Twine. Needs crafting level 3.",
		"@Marigold:'If the big lamp ever goes dark, I'll light the small ones. Every night, until you're home.'|@Marigold:It's dated last winter, Gus.|@Gus:Last winter I was mending nets two miles from her. Two miles.|@Gus:Forty years I thought she'd chosen the mainland. She thought I'd chosen the sea."},
	{"Lit at Dusk", NPC_GUS, QT_FORAGE, XI_HANDLAMP, 1, -1, Q_L4, 400, 500, -1, 0, R_EPIC, 1,
		"@Gus:One more lamp, then. A proper one. I'll light it myself.|@Gus:Not now. At dusk. That's when she lit them.|@Biscuit:(Biscuit settles by the door to wait for dark.)",
		"Craft another Hand Lamp, then bring it to Gus after dark.",
		"@Gus:...There.|@Gus:Home, Wren. Took the long way.|@Marigold:Gus. Down by the reeds. One of the jars is already lit.|@Gus:I didn't light that.|@Biscuit:(Biscuit is already walking towards it. Unhurried. As if she knows the way.)", 0, 1},
};

// ------------------------------------------------ achievements
typedef struct { const char* name; const char* desc; } AchDef;
enum { A_FORAGE1, A_FORAGE50, A_FORAGE250, A_KILL1, A_KILL100, A_KILL500, A_CHEST1, A_CHEST10, A_CHESTALL, A_GOLD500, A_GOLD5K, A_GOLD25K,
       A_LVL5, A_LVL10, A_LVL20, A_RARE, A_EPIC, A_LEGEND, A_QUEST5, A_QUESTALL, A_BOSS0, A_BOSS1, A_BOSS2, A_BOSS3, A_BOSS4,
       A_KITTENS, A_LANTERN, A_CRIT100, A_DIG15, A_EXPLORER, A_NIGHT, A_BOUNTY10, A_GAMBLER, A_COMBO25, A_UNTOUCHED, A_UPG5, A_CLOSE, A_TONIC10, A_STORY1, A_MOONBLOOM, A_CRAFTER3,
       A_WEAK_FIRE, A_WEAK_FROST, A_WEAK_VENOM, A_WEAK_STORM, A_WARD_FIRE, A_WARD_FROST, A_WARD_VENOM, A_WARD_STORM, A_COUNT };
static const AchDef achdefs[A_COUNT] = {
	{"First Pickings", "Gather your first forage."}, {"Green Thumb", "Gather 50 forages."}, {"Master Forager", "Gather 250 forages."},
	{"First Bonk", "Defeat a monster."}, {"Monster Hunter", "Defeat 100 monsters."}, {"Legend Slayer", "Defeat 500 monsters."},
	{"Treasure!", "Open a treasure chest."}, {"Treasure Hunter", "Open 10 chests."}, {"Every Last Chest", "Open every treasure chest."},
	{"Pocket Money", "Earn 500 gold."}, {"Tycoon", "Earn 5,000 gold."}, {"Moneybags", "Earn 25,000 gold."},
	{"Getting Stronger", "Reach level 5."}, {"Seasoned", "Reach level 10."}, {"Hero of Hollowmere", "Reach level 20."},
	{"Ooh, Shiny", "Find a Rare item."}, {"Purple Prose", "Find an Epic item."}, {"LEGENDARY!", "Find a Legendary item."},
	{"Helping Hand", "Complete 5 quests."}, {"Pillar of the Community", "Complete every quest."},
	{"Gloopa Gone", "Defeat Gloopa the Gelatinous."}, {"Shell Shocked", "Defeat King Pincer."}, {"Timber!", "Defeat the Bramblehorn."},
	{"Ribbit No More", "Defeat Queen Croak."}, {"Giant Slayer", "Defeat the Hollow Colossus."},
	{"Cat Herder", "Find all three kittens."}, {"Let There Be Light", "Relight the Great Lantern."},
	{"Critical Thinker", "Land 100 critical hits."}, {"Digger", "Dig up 15 buried treasures."}, {"Explorer", "Visit every region."},
	{"Night Owl", "Adventure under the stars."}, {"Bounty Hunter", "Complete 10 bounties."}, {"Gambler", "Open 5 loot caches."},
	{"Triple Threat", "Land 25 combo finishers."}, {"Untouchable", "Defeat a boss without being hit."}, {"Sharpened", "Upgrade a weapon to +5."},
	{"Close Call", "Survive a fight below 10% HP."}, {"Snack Time", "Drink 10 Healing Tonics."},
	{"Lit at Dusk", "Finish Marigold's ledger."}, {"Night Gardener", "Pick 10 Moonblooms."}, {"Journeyman", "Reach crafting level 3."},
	{"Kindling", "Hit 10 Frost weak spots with Fire."}, {"Cold Snap", "Hit 10 Fire weak spots with Frost."},
	{"Snakebite", "Hit 10 Storm weak spots with Venom."}, {"Thunderstruck", "Hit 10 Venom weak spots with Storm."},
	{"Fireproof", "Ward off 10 Fire attacks."}, {"Bundled Up", "Ward off 10 Frost attacks."},
	{"Antidote", "Ward off 10 Venom attacks."}, {"Grounded", "Ward off 10 Storm attacks."},
};

// ------------------------------------------------ crafting
// Tier 1: 2 of X + 3 of Y -> Z. Tier 2: two tier-1 items -> a better one; if you lack the
// tier-1 items, their raw ingredients are used instead. Recipes unlock with crafting level.
enum { CR_ITEM, CR_XP, CR_WHET, CR_CACHE, CR_INFUSE }; // CR_INFUSE: arg = element, amount 0 weapon / 1 armour
enum { ST_NONE, ST_FORGE, ST_APOTH };
typedef struct { const char* name; u8 tier, unlock; u8 inA, nA, inB, nB; u8 out, arg; u16 amount; const char* desc; u8 station, stage; } Recipe;
#define RECIPE_COUNT 26
static const Recipe recipes[RECIPE_COUNT] = {
	{"Lamp Oil",       1, 1, IT_BERRY,     2, IT_GEL,        3, CR_ITEM,  XI_OIL, 1,      "Pressed berry oil"},
	{"Wick Twine",     1, 1, IT_SILVERLEAF,2, IT_SUNPETAL,   3, CR_ITEM,  XI_TWINE, 1,    "Braided plant fibre"},
	{"Sea Glass",      1, 1, IT_SHELL,     2, IT_DRIFTWOOD,  3, CR_ITEM,  XI_SEAGLASS, 1, "Fired on a driftwood blaze"},
	{"Berry Ink",      1, 1, IT_GLOWCAP,   2, IT_BERRY,      3, CR_ITEM,  XI_INK, 1,      "Dark ink that glows faintly"},
	{"Hand Lamp",      2, 1, XI_OIL,       1, XI_TWINE,      1, CR_ITEM,  XI_HANDLAMP, 1, "A proper lamp to read by"},
	{"Moth Lamp",      2, 2, XI_SEAGLASS,  1, XI_OIL,        1, CR_ITEM,  XI_MOTHLAMP, 1, "Wren's little jar lamp"},
	{"Mended Ledger",  2, 3, XI_INK,       1, XI_TWINE,      1, CR_ITEM,  XI_LEDGER, 1,   "Rebound, re-inked pages"},
	{"Healing Tonic",  1, 1, IT_BERRY,     2, IT_SUNPETAL,   3, CR_ITEM,  IT_TONIC, 1,    "Heals half your HP"},
	{"Herbal Tonics",  1, 1, IT_SILVERLEAF,2, IT_GLOWCAP,    3, CR_ITEM,  IT_TONIC, 3,    "Three Healing Tonics"},
	{"Night Primer",   1, 2, XI_MOONBLOOM, 2, XI_MOTHDUST,   3, CR_XP,    0, 300,         "Read it: +300 XP"},
	{"Tide Journal",   1, 1, IT_DRIFTWOOD, 2, IT_SHELL,      3, CR_XP,    0, 60,          "Read it: +60 XP"},
	{"Swamp Almanac",  1, 2, IT_PEARL,     2, IT_BOGLILY,    3, CR_XP,    0, 220,         "Read it: +220 XP"},
	{"Star Treatise",  1, 3, IT_CORE,      2, IT_CRYSTAL,    3, CR_XP,    0, 600,         "Read it: +600 XP"},
	{"Whetstone",      1, 1, IT_CLAW,      2, IT_THORN,      3, CR_WHET,  0, 1,           "Weapon +1 (+10% power)"},
	{"Weapon Cache",   1, 2, IT_THORN,     2, IT_GEL,        3, CR_CACHE, 0, 0,           "Open a weapon cache"},
	{"Charm Cache",    1, 3, IT_PEARL,     2, IT_CLAW,       3, CR_CACHE, 1, 0,           "Open a charm cache"},
	// made at buildings, collected there
	{"Ember Oil",      1, 1, IT_SUNPETAL,  2, IT_BERRY,      3, CR_INFUSE, EL_FIRE, 0,    "Weapon becomes Fire", ST_FORGE, 1},
	{"Frost Oil",      1, 1, IT_SHELL,     2, IT_DRIFTWOOD,  3, CR_INFUSE, EL_FROST, 0,   "Weapon becomes Frost", ST_FORGE, 1},
	{"Frost Ward",     1, 1, IT_CLAW,      2, IT_SHELL,      3, CR_INFUSE, EL_FROST, 1,   "Armour resists Frost", ST_FORGE, 1},
	{"Venom Oil",      1, 1, IT_BOGLILY,   2, IT_GEL,        3, CR_INFUSE, EL_VENOM, 0,   "Weapon becomes Venom", ST_FORGE, 2},
	{"Storm Oil",      1, 1, IT_CRYSTAL,   2, IT_GLOWCAP,    3, CR_INFUSE, EL_STORM, 0,   "Weapon becomes Storm", ST_FORGE, 2},
	{"Fire Ward",      1, 1, IT_CORE,      2, IT_BERRY,      3, CR_INFUSE, EL_FIRE, 1,    "Armour resists Fire", ST_FORGE, 2},
	{"Venom Ward",     1, 1, IT_THORN,     2, IT_SILVERLEAF, 3, CR_INFUSE, EL_VENOM, 1,   "Armour resists Venom", ST_FORGE, 2},
	{"Storm Ward",     1, 1, IT_PEARL,     2, IT_BOGLILY,    3, CR_INFUSE, EL_STORM, 1,   "Armour resists Storm", ST_FORGE, 2},
	{"Tonic Batch",    1, 1, IT_BERRY,     2, IT_SUNPETAL,   3, CR_ITEM,  IT_TONIC, 4,    "Four tonics at once", ST_APOTH, 1},
	{"Night Draught",  1, 1, XI_MOONBLOOM, 1, IT_SILVERLEAF, 2, CR_ITEM,  IT_TONIC, 6,    "Six tonics, moon-brewed", ST_APOTH, 2},
};
static const u16 crafter_xp_need[] = { 0, 40, 70, 140, 260, 9999 }; // xp to reach level n+1 from level n
#define CRAFTER_MAX 5

// ------------------------------------------------ main story: The Great Lantern
// The spine of the game. It introduces every islander in turn; nobody offers quests until you've met them here.
// One zone at a time: each zone's boss drops the weapon element the next zone needs.
enum { MQT_ITEM, MQT_KILL, MQT_TALK, MQT_QUEST }; // TALK: meet npc 'target'. QUEST: finish quest 'target'
typedef struct { const char* title; s8 giver; u8 type; u8 target; u8 count; bool night; const char* chapter; int gold; u16 cxp;
	const char* intro; const char* prog; const char* done; } MainQuest;
#define MQ_COUNT 19
#define STORY_TITLE "The Great Lantern"
static const MainQuest mainq[MQ_COUNT] = {
	{"A Dark Lantern", NPC_ELDER, MQT_ITEM, IT_BERRY, 5, false, "Chapter 1: The Meadow", 60, 5,
		"Ah, a new face! Welcome to Hollowmere, traveller. I'm Elder Maple.|See the Great Lantern? Dark for a month now. Without it, the island's creatures have grown restless.|First things first. My old bones need Moonberries. Bring me five? The red-dotted bushes grow all over the meadow.",
		"Pick 5 Moonberries from the round bushes in the meadow. Walk up and press [A].",
		"Splendid. Sweet as starlight.|Mind this: wounds don't mend on their own out there. Carry Healing Tonics, and press [X] to drink one."},
	{"Slime Season", NPC_ELDER, MQT_QUEST, Q_E1, 1, false, NULL, 60, 5,
		"The real worry is the slimes. Since the Lantern dimmed, they've been eating the meadow bare.|I've a quest for you about them.",
		"Help Elder Maple: finish her quest Slime Trouble.",
		"The flowers are perking up already. You're a natural."},
	{"Pip's Kitchen", NPC_ELDER, MQT_TALK, NPC_PIP, 1, false, NULL, 40, 5,
		"Pip bakes for the whole village, and she's been run off her feet since the Lantern went out.|Go and say hello. She's just west of the Lantern.",
		"Talk to Pip, just west of the Great Lantern.",
		"Oh! A new face! I'm Pip. I feed this village, and lately it's been feeding on worry.|Pies help. Pies always help. Will you lend me a hand?"},
	{"Kitchen Help", NPC_PIP, MQT_QUEST, Q_H1, 1, false, NULL, 70, 10,
		"Ingredients first, then I'll teach you to brew your own tonics. Much cheaper than Bram's!",
		"Help Pip: finish Honey Cakes, then Pip's Kitchen Cure.",
		"Look at you, brewing like a pro!"},
	{"The Trader's Cart", NPC_PIP, MQT_TALK, NPC_BRAM, 1, false, NULL, 40, 5,
		"You'll want proper supplies too. Bram sells tonics, tomes and mystery caches. At fair-ish prices.|His cart's just east of the Lantern. Tell him I sent you.",
		"Talk to Bram at his cart, east of the Great Lantern.",
		"Bram's the name, trading's the game! Pip sent you? Then you're good for it.|Let's get you started properly."},
	{"Stocking Up", NPC_BRAM, MQT_QUEST, Q_B0, 1, false, NULL, 80, 5,
		"Two lessons, friend. Never leave town without tonics. And read: books teach more than brawls.",
		"Help Bram: finish First Aid, then Study Hard.",
		"Now you're ready for real trouble. And there IS real trouble.|Old Maple's been asking for you. Something about a slime the size of a house."},
	{"The Meadow Queen", NPC_ELDER, MQT_QUEST, Q_E2, 1, false, NULL, 120, 10,
		"Gloopa. The great gelatinous queen. She's swallowed a piece of the Lantern itself!|She wallows north-east of the village.",
		"Help Elder Maple: defeat Gloopa (her quest Gloopa Rises).",
		"Four more shards were flung to the corners of the island, each in the belly of some beast, I'd wager.|Since the Lantern died, each wild corner has sealed itself off with its own element. Ice, thorn, storm, flame.|Each guardian's blade is the key to the next seal. That fire blade will melt the ice to the south."},
	{"Odd Jobs", NPC_ELDER, MQT_TALK, NPC_BOARD, 1, false, NULL, 40, 5,
		"Before you go: folk have started pinning odd jobs on the Bounty Board, beside Pip's. Have a read.",
		"Read the Bounty Board, beside Pip's kitchen.",
		"BOUNTY BOARD|Notices go up here one at a time. Finish one and a fresh one appears.|Rewards: gold, experience, and sometimes gear."},
	{"Down to the Shore", NPC_ELDER, MQT_TALK, NPC_GUS, 1, false, "Chapter 2: Sunspray Beach", 60, 5,
		"Old Gus lives in a hut on Sunspray Beach, due south. Grumpy. But he notices things.|A wall of ice has sealed the road south. Equip Gloopa's fire blade and melt it: walk up and press [A].",
		"Melt the ice wall south of the village with a Fire weapon, then find Old Gus on Sunspray Beach.",
		"Hrmph. A visitor. Maple sent you, I suppose.|The beach has gone wrong. Crabs everywhere, cold as ice. And something big under the sand.|If you're staying, make yourself useful."},
	{"The King Under the Sand", NPC_GUS, MQT_QUEST, Q_G2, 1, false, NULL, 160, 10,
		"Help me set the beach right. Crabs first. Then my boat. Then... the big one.",
		"Help Old Gus: finish his quests up to The King Under the Sand.",
		"Two shards. Maple will be pleased."},
	{"A Stranger on the Plaza", NPC_GUS, MQT_TALK, NPC_MARI, 1, false, NULL, 60, 5,
		"There's a lass in the village asking about Wren Ashby. The old Lamplighter.|...Wren and I were close, once. Go and see her, would you? I'd rather not.",
		"Talk to Marigold on the plaza.",
		"Oh! You must be the one fixing everyone's problems. I'm Marigold Ashby. I came on the morning boat.|My great-aunt Wren was the last Lamplighter. I found her ledger, and it doesn't make sense.|When you have time, I could use your help with it."},
	{"Biscuit's Girl", NPC_MARI, MQT_TALK, NPC_TILLY, 1, false, NULL, 60, 5,
		"One more thing. The little girl south-east of the Lantern, Tilly. She's been crying all morning.|Her cat's kittens ran off when the Lantern died. Could you look in on her?",
		"Talk to Tilly, south-east of the Great Lantern.",
		"You're a HERO, aren't you? I can tell!|Biscuit had kittens and they ran off into the wild. And Biscuit's so sad.|Will you help me?"},
	{"Whisperwood", NPC_TILLY, MQT_TALK, NPC_FERN, 1, false, "Chapter 3: Whisperwood", 80, 5,
		"Fern lives in Whisperwood, up north. She knows every animal there. Maybe she's seen a kitten!|A thorn wall seals off the woods. Gus's storm blade can shock it apart, and the thornlings too.",
		"Break the thorn wall north of the village with a Storm weapon, then find Fern in Whisperwood.",
		"Shh. The woods are listening. I'm Fern.|Something has soured the forest. The thornlings bite, and the Bramblehorn has gone wild.|Help me, and the woods will remember you."},
	{"The Bramblehorn", NPC_FERN, MQT_QUEST, Q_F2, 1, false, NULL, 200, 10,
		"Remedies first, then the thornlings, then the guardian. In that order.",
		"Help Fern: finish her quests up to The Bramblehorn.",
		"Three shards. The forest breathes again."},
	{"Mirefen", NPC_FERN, MQT_TALK, NPC_ODESSA, 1, false, "Chapter 4: Mirefen Swamp", 80, 5,
		"Odessa in Mirefen Swamp, to the west, will know what comes next. She always does. It's unsettling.|Storm reeds fence off the swamp now. Venom rots them. Bring the venom blade.",
		"Rot away the storm reeds west of the village with a Venom weapon, then find Odessa in Mirefen Swamp.",
		"Heh heh heh. I wondered when you'd wander in. I'm Odessa.|The toads haven't stopped croaking since the Lantern died. Their queen's to blame.|Make yourself useful and I'll make it worth your while."},
	{"Queen Croak", NPC_ODESSA, MQT_QUEST, Q_O2, 1, false, NULL, 240, 15,
		"Stew, then toads, then the queen. The swamp has a pecking order.",
		"Help Odessa: finish her quests up to Queen Croak.",
		"Four shards! Heh. The last one's with the old knight in the ruins."},
	{"The Old Ruins", NPC_ODESSA, MQT_TALK, NPC_RUST, 1, false, "Chapter 5: The Old Ruins", 100, 5,
		"Sir Rustwick. Guarding ruins nobody asked him to guard, for forty years.|A fire ward burns across the eastern road. Your frost blade will snuff it, and the golems too. Be patient with him.",
		"Snuff the fire ward east of the village with a Frost weapon, then find Sir Rustwick in the Old Ruins.",
		"HALT! Who goes- oh. A hero. Splendid.|I have guarded these ruins for forty years. The Colossus at their heart holds the last shard.|I would deal with it myself. Tomorrow. Probably. Will you help?"},
	{"The Hollow Colossus", NPC_RUST, MQT_QUEST, Q_R2, 1, false, NULL, 300, 15,
		"First my armour, then the golems, then the giant. A knight prepares!",
		"Help Sir Rustwick: finish his quests up to The Hollow Colossus.",
		"Five shards! Go, hero! Take them to the Elder. I shall... guard the ruins."},
	{"Let There Be Light", NPC_ELDER, MQT_QUEST, Q_E3, 1, false, "Finale", 500, 20,
		"All five. I can feel them from here.|Come. Let's bring them to the Lantern together.",
		"Bring the five shards to Elder Maple (her quest Relight the Lantern).",
		"Hollowmere is whole again, thanks to you.|Bounties, treasure and secrets are still out there. And Marigold's ledger, if you haven't finished it."},
};
// the story chapter that introduces each islander; their quests open once it's done
static const s8 npc_meet_ch[NPC_COUNT] = { 0, 2, 4, 11, 8, 12, 14, 16, 10, 7 }; // elder pip bram tilly gus fern odessa rust mari board

// ------------------------------------------------ dungeons (v1.28)
// one fixed Depths (3 floors, a champion at the bottom, a page of Wren's journal) and one Rift (random every time) per zone
static const char* depth_names[Z_COUNT] = { "", "The Old Cellars", "Drowned Grotto", "Lamplighter's Vault", "Rootdeep Hollow", "Sunken Crypt" };
#define RIFT_NAME "Shimmering Rift"
// floor, wall side, wall top
static const u32 dun_pal[Z_COUNT + 1][3] = {
	{ 0x6B5A48, 0x4A4038, 0x5E5248 }, { 0x6B5A48, 0x4A4038, 0x5E5248 }, { 0x8A8466, 0x3E6670, 0x5A8A90 },
	{ 0x6A6460, 0x504A48, 0x6E6660 }, { 0x4E5E3A, 0x3A3428, 0x4E6A34 }, { 0x3E4A36, 0x2E3A30, 0x44543E },
	{ 0x3A2E4E, 0x2A2040, 0x54407A } }; // last row: rifts
static const char* rift_mods[5] = { "", "Swarming", "Darkness", "Volatile", "Marksmen" };
static const char* rift_mod_desc[5] = { "", "Twice the foes", "You can barely see", "Foes burst when they die", "Archers everywhere" };
// Wren's journal: one page waits at the bottom of each Depths (index = zone)
static const char* wren_pages[Z_COUNT] = { "",
	"@Wren:Wren's Journal, Page 1|@Wren:The Lantern doesn't burn oil. I told the Elder so, years ago. She laughed.|@Wren:It drinks from below. Five old lamps, one under each corner of the island. Someone has to keep them trimmed.|@Wren:Someone has always been me.",
	"@Wren:Wren's Journal, Page 2|@Wren:The grotto lamp was guttering again. Salt gets into everything. Even into me.|@Wren:Gus waited at the top of the steps with a flask of tea. He never asks where I go. I love him a little for that.|@Wren:I never told him that either.",
	"@Wren:Wren's Journal, Page 5|@Wren:My hands shake too much now to trim the wicks. I wrote to Marigold. She'll come, I think. She has my stubbornness.|@Wren:If the Lantern dims, it won't be the beasts' fault. It'll be mine, for getting old.|@Wren:Whoever reads this: keep the lamps. That's all. Keep the lamps.",
	"@Wren:Wren's Journal, Page 3|@Wren:The roots have grown round the forest lamp like fingers round a cup.|@Wren:Fern's grandmother knew. She left a ribbon tied to the last step. Faded now. I tied a new one beside it.",
	"@Wren:Wren's Journal, Page 4|@Wren:Odessa came down with me once. She said the dark down here isn't empty. It's waiting.|@Wren:She said it like a recipe. I've stopped laughing at her.",
};
// room templates (9x9): # wall, . floor, e foe, c treasure spot. Mirrored at random.
#define NTPL 9
static const char* dun_tpl[NTPL][9] = {
	{ ".........", ".e.....e.", "..#...#..", ".........", "....c....", ".........", "..#...#..", ".e.....e.", "........." },
	{ ".........", ".#.#.#.#.", ".........", ".#.e.e.#.", ".........", ".#.e.e.#.", ".........", ".#.#.#.#.", "........." },
	{ ".........", ".e.....e.", "..##.##..", "..#...#..", ".....c...", "..#...#..", "..##.##..", ".e.....e.", "........." },
	{ "###...###", "###...###", "##..e..##", ".........", "....c....", ".........", "##..e..##", "###...###", "###...###" },
	{ ".........", ".##.e.##.", ".........", ".##...##.", ".e..c..e.", ".##...##.", ".........", ".##.e.##.", "........." },
	{ "e........", ".#.......", "..#......", "...#..e..", ".........", "..e..#...", "......#..", ".......#.", "........e" },
	{ "#.#.#.#.#", ".........", "#..e.e..#", ".........", "....c....", ".........", "#..e.e..#", ".........", "#.#.#.#.#" },
	{ "...#.#...", ".e.....e.", "#.......#", ".........", "#...c...#", ".........", "#.......#", ".e.....e.", "...#.#..." },
	{ ".........", ".........", "..e...e..", ".........", ".........", ".........", "..e...e..", ".........", "........." }, // arena (champion room)
};
static const char* dun_tpl_start[9] = { ".........", ".........", "..#...#..", ".........", ".........", ".........", "..#...#..", ".........", "........." };

// ------------------------------------------------ Depths stories (v1.29): each Depths tells its own story.
// lore: something to read on floors 1, 3 and 4. Floor 2 ends at a story door with a note; its islander in town has the key.
static const char* depth_lore[Z_COUNT][3] = { { "", "", "" },
	{ "@You:Wine racks, long empty. Someone has chalked tallies on the wall: one mark a night, for years.|@You:Under the last row, in smaller writing: 'Lamp trimmed. W.'",
	  "@You:A tide line on the stone, chest high. The flood got this far.|@You:Someone carved 'T + M' into a beam above it, well clear of the water.",
	  "@You:A chair, one cushion, a blanket, a cold teapot.|@You:Wren came down here to sit with the lamp. Not to work. Just to sit." },
	{ "@You:Two oars, one far more worn than the other. A rowboat has been hauled up here many times.|@You:Painted on a broken bow plank, faded: the PATIENCE.",
	  "@You:Shells pressed into the wall in a pattern: a sun, a lamp, a very bad boat.|@You:Two sets of initials underneath. G.H. and W.A.",
	  "@You:A tin box, sealed with wax against the damp. Inside, dry tea leaves and a note.|@You:'For the next time you wait for me. W.'" },
	{ "@You:Maps of the island, one for every year. Each one marks five lamps.|@You:On the last map, four of them are crossed out in red.",
	  "@You:A workshop. Lamp parts everywhere, each labelled in tiny careful writing.|@You:A half-built lamp on the bench. The label says: 'For M.'",
	  "@You:Suits of armour line the hall, all facing the door, all polished.|@You:Every one has a name tag. They all say RUSTWICK." },
	{ "@You:Ribbons tied to every root that crosses the path. Red, then blue, then faded to nothing.|@You:Somebody has marked the way down for a very long time.",
	  "@You:A root as thick as a barrel has split the wall. Something glows in the crack.|@You:Glowcaps, planted in a neat row. Somebody wanted light down here.",
	  "@You:A sapling, growing in the dark, which it shouldn't be able to do.|@You:A watering can beside it. Recently filled." },
	{ "@You:Stone coffins, all empty and all very clean. Someone dusts down here.|@You:A ladle hangs on a hook by the stairs. It smells faintly of stew.",
	  "@You:Names carved into the walls, hundreds of them. Lamplighters, older than the village.|@You:The newest is W. ASHBY. There's room under it for one more.",
	  "@You:The water here is black and perfectly still. Your light doesn't show in it.|@You:Odessa was right. It isn't empty. It's waiting." } };
static const char* depth_note[Z_COUNT] = { "",
	"@You:A brass plate on the door: SEALED BY ORDER OF T. MAPLE.|@You:Scratched underneath with a hairpin: 'Ask his wife why. She'll pretend not to know. W.'",
	"@You:An iron sea-gate, rusted solid. There's a socket for a crank handle, and no handle.|@You:Tied to the bars: 'Gus has the handle. He'll say he lost it. He hasn't. W.'",
	"@You:A great door with a knight's crest. The lock is shaped like a gauntlet.|@You:Pinned to it: 'Rustwick has the key and forty years of excuses. Be kind. W.'",
	"@You:Roots have closed over the door like fingers round a cup.|@You:A ribbon on the latch: 'They open for the root-song. Fern's gran taught me. Badly. W.'",
	"@You:The door is sealed with thick green wax that smells of onions.|@You:A label: 'Odessa's seal. Only her stew melts it. Don't ask. I did. W.'" };
static const char* depth_keytalk[Z_COUNT] = { "",
	"Tobias's door. Oh dear.|The spring flood, years ago. Wren went down for the lamp and the water came up behind her. Tobias carried her out himself.|He sealed it that night and never spoke of it again. Here, his key. He'd want the lamp kept more than he'd want the door shut.",
	"Hrmph. She told you about the handle.|We used to row in at low tide. Her lamp, my boat. I'd wait at the gate and pretend I was fishing.|Kept it in my tackle box for forty years. Take it. Before I change my mind.",
	"Ah. The vault. Yes. I have been guarding it. Vigilantly. From myself, mostly.|She asked me to come down with her, at the end. I said tomorrow. I always said tomorrow.|Take the key, hero. A knight should know when he isn't the one for the job.",
	"The root-song? That's Gran's song. She sang it to the trees every spring.|Wren came to the funeral humming it. I thought she'd made it up.|Listen. It's four notes, and the trees forgive you if you get the third one wrong.",
	"Heh. My wax. I made it to keep the dark in, not to keep Wren out.|She'd sit on the step and eat a bowl while it melted. Said it was the best part of the job.|Take a jar. Pour it on the seal. Don't eat it. Well. Not all of it." };
static const char* depth_key[Z_COUNT] = { "", "Tobias's Key", "Gus's Crank", "Gauntlet Key", "The Root-Song", "Jar of Stew" };
static const s8 depth_npc[Z_COUNT] = { -1, NPC_ELDER, NPC_GUS, NPC_RUST, NPC_FERN, NPC_ODESSA };

// ------------------------------------------------ loot depth (v1.30): affixes that change how you play (Gear.pad)
enum { AF_NONE, AF_LEECH, AF_CHAIN, AF_EXEC, AF_BURST, AF_KEEN, AF_SWEEP,   // weapons
       AF_THORNS, AF_PHOENIX, AF_TIRELESS, AF_MEND,                         // armour
       AF_GILDED, AF_BLOOM, AF_FRENZY, AF_COUNT };                          // charms
static const char* af_name[AF_COUNT] = { "", "Vampiric", "Arcing", "Executioner", "Bursting", "Keen", "Sweeping",
	"Thorned", "Phoenix", "Tireless", "Mending", "Gilded", "Bloodbloom", "Frenzied" };
static const char* af_desc[AF_COUNT] = { "", "Hits heal you a little", "Hits leap to a second foe", "+70% damage to foes under 30%", "Kills explode on foes nearby",
	"+15% critical chance", "Swings hit all around you", "Foes that hit you take 40% back", "Survive a killing blow (3 min)", "Rolls cost half stamina",
	"Heal steadily when not hit", "+30% gold from foes", "Kills heal 4% of your health", "Kills quicken your swings" };
// legendary powers (Gear.special 10+), work from any slot
enum { LP_EMBERS = 10, LP_ECHO, LP_LANTERN, LP_STORMS, LP_END };
static const char* lp_name[4] = { "of Embers", "of Echoes", "of the Lantern", "of Storms" };
static const char* lp_desc[4] = { "Rolling through foes sets them alight", "Every third swing strikes twice", "Heavy attacks send out a shockwave", "Above 70% health, lightning zaps foes" };
// perks: every third level, pick a new tool (S.perks bits)
enum { PK_WHIRL, PK_NOVA, PK_CHARGE, PK_RIPOSTE, PK_LASTSTAND, PK_BLOODLUST, PK_BREAKER, PK_ELEMENT, PK_REACH, PK_HERBAL, PK_COUNT };
static const char* pk_name[PK_COUNT] = { "Whirlwind", "Elemental Nova", "Shoulder Charge", "Riposte", "Last Stand", "Bloodlust", "Shieldbreaker", "Elementalist", "Long Arms", "Herbalist" };
static const char* pk_d1[PK_COUNT] = { "[ZR]: spin and", "Heavy attacks", "Rolls into foes", "Perfect dodges", "Under 20% HP:", "Kills restore", "Finishers break", "Weak spots x2.5", "Loot flies to", "Tonics heal 80%" };
static const char* pk_d2[PK_COUNT] = { "hit all around", "burst element", "hit and stagger", "stun foes near", "heal 35% (2m)", "12 stamina", "guard & shield", "hotter burns", "you from 2x far", "(not 50%)" };
