// Procedural audio. Every sound starts and ends at zero amplitude with smooth
// envelopes, music loops are generated with wrap-around mixing so the loop seam
// is continuous: no clicks, no crackle.
#include "common.h"

#define SR 22050
#define SFX_CH0 1
#define SFX_CHN 6
#define MUS_DAY 0
#define MUS_NIGHT 7

typedef struct { s16* data; int n; } Snd;
static Snd snd[SFX_COUNT];
static Snd mus[2];
static ndspWaveBuf wb[8];
static bool audio_ok = false;
static int rr = 0;
static float musVol[2] = {0, 0}, musTarget[2] = {0.6f, 0};
static u64 lastPlay[SFX_COUNT];

#define TBL 4096
static float sintab[TBL];
static inline float fsin(float phase) { // phase in cycles
	phase -= floorf(phase);
	return sintab[(int)(phase * TBL) & (TBL-1)];
}

static float* fb; static int fbn;
static void fb_new(float seconds) { fbn = (int)(seconds * SR); fb = calloc(fbn, sizeof(float)); }

// envelope: linear attack, exponential-ish decay to zero by end
static inline float env_ad(float t, float dur, float att, float decayPow) {
	if (t < 0 || t >= dur) return 0;
	if (t < att) return t / att;
	float x = (t - att) / (dur - att);
	float e = powf(1 - x, decayPow);
	return e;
}
// wave: 0 sine, 1 soft square, 2 triangle, 3 bell (sine + harmonics)
static float wave(int w, float ph) {
	switch (w) {
	case 1: return tanhf(fsin(ph) * 2.5f) * 1.013f; // smooth 'square': no hard edges
	case 2: { float p = ph - floorf(ph); return p < 0.5f ? (4*p - 1) : (3 - 4*p); }
	case 3: return 0.7f*fsin(ph) + 0.2f*fsin(ph*2.01f) + 0.1f*fsin(ph*3.99f);
	default: return fsin(ph);
	}
}
static void tone_w(float start, float dur, float f0, float f1, float amp, int w, float att, float decayPow, bool wrap) {
	int s0 = (int)(start * SR), n = (int)(dur * SR);
	float ph = 0;
	for (int i = 0; i < n; i++) {
		float t = (float)i / SR;
		float f = f0 + (f1 - f0) * ((float)i / n);
		ph += f / SR;
		float v = wave(w, ph) * amp * env_ad(t, dur, att, decayPow);
		int idx = s0 + i;
		if (wrap) idx %= fbn; else if (idx >= fbn) break;
		fb[idx] += v;
	}
}
static void tone(float start, float dur, float f0, float f1, float amp, int w, float att, float decayPow) { tone_w(start, dur, f0, f1, amp, w, att, decayPow, false); }
static u32 nseed = 1234567;
static float nrand(void) { nseed = nseed*1664525u + 1013904223u; return ((nseed >> 9) & 0xFFFF) / 32768.f - 1.f; }
static void noise(float start, float dur, float amp, float lp0, float lp1, float att, float decayPow) {
	int s0 = (int)(start * SR), n = (int)(dur * SR);
	float y = 0;
	for (int i = 0; i < n && s0 + i < fbn; i++) {
		float t = (float)i / SR;
		float c = lp0 + (lp1 - lp0) * ((float)i / n);  // one-pole coefficient 0..1
		y += c * (nrand() - y);
		fb[s0 + i] += y * amp * env_ad(t, dur, att, decayPow);
	}
}
static Snd fb_finish(float gain) {
	Snd s; s.n = fbn;
	{ float pk = 0; for (int i = 0; i < fbn; i++) { float a = fabsf(fb[i] * gain); if (a > pk) pk = a; }
	  if (pk > 0.37f) gain *= 0.37f / pk; } // normalise loud effects so stacked sounds can't clip the mix
	s.data = linearAlloc(fbn * 2);
	// guarantee silent edges (fade 4ms in/out)
	int f = SR * 4 / 1000;
	for (int i = 0; i < fbn; i++) {
		float v = fb[i] * gain;
		if (i < f) v *= (float)i / f;
		if (i > fbn - f) v *= (float)(fbn - i) / f;
		// soft clip
		if (v > 1) v = 1; if (v < -1) v = -1;
		v = v - (v*v*v) * 0.15f;
		s.data[i] = (s16)(v * 30000);
	}
	free(fb); fb = NULL;
	DSP_FlushDataCache(s.data, fbn * 2);
	return s;
}

static float nf(int midi) { return 440.f * powf(2.f, (midi - 69) / 12.f); }

static void gen_sfx(void) {
	fb_new(0.28f); tone(0, 0.09f, nf(88), nf(88), 0.35f, 3, 0.003f, 2); tone(0.06f, 0.2f, nf(95), nf(95), 0.35f, 3, 0.003f, 2.5f); snd[SFX_PICK] = fb_finish(1);
	fb_new(0.3f); tone(0, 0.06f, nf(83), nf(83), 0.25f, 1, 0.002f, 1); tone(0.05f, 0.24f, nf(88), nf(88), 0.25f, 1, 0.002f, 2); snd[SFX_COIN] = fb_finish(1);
	fb_new(0.18f); noise(0, 0.08f, 0.6f, 0.5f, 0.1f, 0.002f, 2); tone(0, 0.16f, 160, 55, 0.6f, 0, 0.003f, 2); snd[SFX_HIT] = fb_finish(1);
	fb_new(0.45f); noise(0, 0.09f, 0.6f, 0.6f, 0.1f, 0.002f, 2); tone(0, 0.18f, 180, 50, 0.6f, 0, 0.003f, 2); tone(0.02f, 0.4f, 2093, 2093, 0.22f, 3, 0.002f, 3); tone(0.05f, 0.35f, 3136, 3136, 0.12f, 0, 0.002f, 3); snd[SFX_CRIT] = fb_finish(1);
	fb_new(0.5f); tone(0, 0.22f, 700, 140, 0.45f, 0, 0.004f, 1.5f); noise(0.02f, 0.25f, 0.35f, 0.3f, 0.05f, 0.01f, 2); tone(0.12f, 0.3f, nf(91), nf(91), 0.15f, 3, 0.003f, 3); tone(0.18f, 0.3f, nf(96), nf(96), 0.12f, 3, 0.003f, 3); snd[SFX_KILL] = fb_finish(1);
	fb_new(0.2f); noise(0, 0.18f, 0.5f, 0.05f, 0.35f, 0.07f, 1.5f); snd[SFX_SWING] = fb_finish(1);
	fb_new(0.25f); tone(0, 0.22f, 330, 140, 0.35f, 1, 0.004f, 1.5f); noise(0, 0.1f, 0.25f, 0.3f, 0.1f, 0.003f, 2); snd[SFX_HURT] = fb_finish(1);
	fb_new(1.3f);
	{ int n[] = {72, 76, 79, 84, 88, 91, 96}; for (int i = 0; i < 7; i++) { tone(i*0.08f, 0.9f - i*0.05f, nf(n[i]), nf(n[i]), 0.2f, 3, 0.004f, 2.2f); tone(i*0.08f, 0.6f, nf(n[i])*1.005f, nf(n[i])*1.005f, 0.08f, 2, 0.004f, 2); } }
	snd[SFX_LEVEL] = fb_finish(1);
	fb_new(1.1f);
	tone(0, 0.14f, nf(79), nf(79), 0.25f, 1, 0.003f, 1); tone(0.12f, 0.14f, nf(84), nf(84), 0.25f, 1, 0.003f, 1);
	tone(0.24f, 0.85f, nf(88), nf(88), 0.2f, 1, 0.005f, 1.8f); tone(0.24f, 0.85f, nf(91), nf(91), 0.18f, 3, 0.005f, 1.8f); tone(0.24f, 0.85f, nf(96), nf(96), 0.14f, 3, 0.005f, 2.2f);
	snd[SFX_ACH] = fb_finish(1);
	fb_new(0.9f);
	{ int n[] = {79, 83, 86, 91, 95}; tone(0, 0.18f, 95, 80, 0.3f, 2, 0.01f, 1); for (int i = 0; i < 5; i++) tone(0.15f + i*0.06f, 0.5f, nf(n[i]), nf(n[i]), 0.18f, 3, 0.003f, 2.5f); }
	snd[SFX_CHEST] = fb_finish(1);
	fb_new(0.04f); tone(0, 0.035f, 880, 880, 0.12f, 1, 0.002f, 1); snd[SFX_BLIP] = fb_finish(1);
	fb_new(1.0f);
	tone(0, 0.3f, nf(72), nf(72), 0.18f, 3, 0.004f, 1.5f); tone(0, 0.3f, nf(76), nf(76), 0.15f, 3, 0.004f, 1.5f); tone(0, 0.3f, nf(79), nf(79), 0.15f, 3, 0.004f, 1.5f);
	tone(0.25f, 0.7f, nf(77), nf(77), 0.18f, 3, 0.004f, 2); tone(0.25f, 0.7f, nf(81), nf(81), 0.15f, 3, 0.004f, 2); tone(0.25f, 0.7f, nf(84), nf(84), 0.15f, 3, 0.004f, 2); tone(0.3f, 0.65f, nf(96), nf(96), 0.08f, 0, 0.004f, 2);
	snd[SFX_QUEST] = fb_finish(1);
	fb_new(0.16f); noise(0, 0.15f, 0.45f, 0.1f, 0.5f, 0.04f, 1.5f); snd[SFX_DODGE] = fb_finish(1);
	fb_new(0.8f); for (int i = 0; i < 3; i++) { int n[] = {84, 88, 91}; tone(i*0.05f, 0.7f, nf(n[i]), nf(n[i]), 0.17f, 3, 0.004f, 2); } tone(0, 0.75f, 2600, 3400, 0.05f, 0, 0.05f, 1.5f); snd[SFX_LOOT_RARE] = fb_finish(1);
	fb_new(1.3f); tone(0, 0.5f, 300, 1200, 0.15f, 2, 0.05f, 1); { int n[] = {79, 83, 86, 91, 95, 98}; for (int i = 0; i < 6; i++) tone(0.35f + i*0.05f, 0.9f, nf(n[i]), nf(n[i]), 0.14f, 3, 0.004f, 2); } snd[SFX_LOOT_EPIC] = fb_finish(1);
	fb_new(0.35f); tone(0, 0.1f, 110, 60, 0.5f, 0, 0.003f, 2); noise(0, 0.12f, 0.4f, 0.15f, 0.05f, 0.003f, 2); tone(0.15f, 0.1f, 120, 60, 0.45f, 0, 0.003f, 2); noise(0.15f, 0.12f, 0.35f, 0.15f, 0.05f, 0.003f, 2); snd[SFX_DIG] = fb_finish(1);
	fb_new(0.45f); tone(0, 0.08f, nf(91), nf(91), 0.22f, 1, 0.002f, 1); tone(0.07f, 0.35f, nf(96), nf(96), 0.22f, 3, 0.002f, 2.5f); noise(0, 0.05f, 0.15f, 0.7f, 0.7f, 0.001f, 2); snd[SFX_BUY] = fb_finish(1);
	fb_new(0.5f);
	{
		int n = (int)(0.45f * SR); float ph = 0;
		for (int i = 0; i < n; i++) {
			float t = (float)i / n;
			float f = t < 0.35f ? lerpf(520, 780, t/0.35f) : lerpf(780, 470, (t-0.35f)/0.65f);
			ph += f / SR;
			float e = env_ad((float)i/SR, 0.45f, 0.04f, 1.2f);
			fb[i] += (0.6f*fsin(ph) + 0.25f*fsin(ph*2) + 0.15f*fsin(ph*3)) * 0.35f * e;
		}
	}
	snd[SFX_MEOW] = fb_finish(1);
	fb_new(0.7f); tone(0, 0.6f, 90, 35, 0.7f, 0, 0.004f, 1.6f); noise(0, 0.5f, 0.5f, 0.2f, 0.02f, 0.003f, 1.8f); snd[SFX_SLAM] = fb_finish(1);
}

// pluck: bell-ish with quick decay, wrapped into loop buffer
static void mus_note(float start, float dur, int midi, float amp, int w, float att) {
	tone_w(start, dur, nf(midi), nf(midi), amp, w, att, 2.0f, true);
}
static void mus_pad(float start, float dur, int midi, float amp) {
	// slow swell in and out: attack half, release half (sin^2 window) -> zero at both ends
	int s0 = (int)(start * SR), n = (int)(dur * SR);
	float ph = 0, ph2 = 0, f = nf(midi);
	for (int i = 0; i < n; i++) {
		ph += f / SR; ph2 += f * 1.004f / SR;
		float x = (float)i / n; float e = sinf(x * PI); e *= e;
		fb[(s0 + i) % fbn] += (fsin(ph) + 0.5f*fsin(ph2)) * amp * e;
	}
}
// music is composed on a background thread: no allocation there, everything is prepared up front
#define MUS_MAX_S 19.3f
static float musfb[(int)(MUS_MAX_S * SR) + 8];
static s16* musBuf[2]; static int musLen[2];
static volatile bool musReady[2]; static bool musQueued[2];
static Thread musThread;
static float mus_seconds(bool night) { float bpm = night ? 100.f : 120.f; return 60.f / bpm * 4 * 8; }
static Snd gen_music(bool night) {
	// 8 bars, 4/4. Day: 120bpm (16s). Night: 100bpm (19.2s)
	float bpm = night ? 100.f : 120.f;
	float beat = 60.f / bpm, bar = beat * 4;
	fbn = (int)(bar * 8 * SR); fb = musfb; memset(fb, 0, fbn * sizeof(float));
	int dayCh[8][3] = {{60,64,67},{57,60,64},{53,57,60},{55,59,62},{60,64,67},{57,60,64},{53,57,60},{55,59,62}};
	int nightCh[8][3] = {{57,60,64},{53,57,60},{48,52,55},{52,56,59},{57,60,64},{50,53,57},{53,57,60},{52,56,59}};
	int (*ch)[3] = night ? nightCh : dayCh;
	u32 seed = night ? 99 : 7;
	for (int b = 0; b < 8; b++) {
		float t0 = b * bar;
		// pad: 1.5 bars long, overlaps next bar, wraps at the loop end
		for (int k = 0; k < 3; k++) mus_pad(t0 - bar*0.25f + bar*8, bar * 1.5f, ch[b][k] + (night ? 0 : 0), night ? 0.05f : 0.045f);
		// bass
		mus_note(t0, beat * 1.8f, ch[b][0] - 24, 0.16f, 2, 0.01f);
		mus_note(t0 + beat*2, beat * 1.8f, ch[b][0] - 24 + (b & 1 ? 7 : 0), 0.13f, 2, 0.01f);
		// arpeggio / melody
		int steps = night ? 4 : 8;
		for (int s = 0; s < steps; s++) {
			seed = seed * 1103515245u + 12345u;
			if (night && ((seed >> 16) % 3 == 0)) continue;
			int tone_i = (s * (night ? 1 : 3) + b) % 3;
			int oct = ((seed >> 20) & 1) ? 12 : 24;
			float st = t0 + s * (bar / steps);
			mus_note(st, beat * (night ? 2.5f : 1.4f), ch[b][tone_i] + oct, night ? 0.09f : 0.075f, 3, 0.004f);
		}
		if (!night && (b == 3 || b == 7)) mus_note(t0 + beat*3.5f, beat * 2, ch[b][2] + 24 + 2, 0.06f, 0, 0.01f);
	}
	// no edge fade for music loops: the content wraps continuously
	Snd s; s.n = fbn; s.data = musBuf[night ? 1 : 0];
	for (int i = 0; i < fbn; i++) { float v = fb[i] * 0.9f; if (v > 1) v = 1; if (v < -1) v = -1; s.data[i] = (s16)(v * 30000); }
	fb = NULL;
	DSP_FlushDataCache(s.data, fbn * 2);
	return s;
}

static void set_vol(int ch, float v) {
	float mix[12] = {0}; mix[0] = v; mix[1] = v;
	ndspChnSetMix(ch, mix);
}

// synthesis is pure computation, so it can run on the loading thread
void audio_synth(int part) {
	if (part == 0) { for (int i = 0; i < TBL; i++) sintab[i] = sinf(TAU * i / TBL); gen_sfx(); }
	else { int m = part - 1; mus[m] = gen_music(m == 1); musReady[m] = true; }
}
static void mus_worker(void* a) { (void)a; audio_synth(1); audio_synth(2); }
void audio_init(void) { audio_synth(0); audio_start(); }
void audio_start(void) {
	if (R_FAILED(ndspInit())) { audio_ok = false; return; }
	audio_ok = true;
	ndspSetOutputMode(NDSP_OUTPUT_STEREO);
	for (int c = 0; c < 8; c++) {
		ndspChnReset(c);
		ndspChnSetInterp(c, NDSP_INTERP_LINEAR);
		ndspChnSetRate(c, SR);
		ndspChnSetFormat(c, NDSP_FORMAT_MONO_PCM16);
		set_vol(c, c == MUS_DAY || c == MUS_NIGHT ? 0 : 0.62f);
	}
	// buffers for the two music loops are allocated here, on the main thread; the
	// worker only fills them. Day music first: the title plays it.
	for (int m = 0; m < 2; m++) { musLen[m] = (int)(mus_seconds(m == 1) * SR); musBuf[m] = linearAlloc(musLen[m] * 2); }
	if (!musBuf[0] || !musBuf[1]) return;
	s32 prio = 0x30; svcGetThreadPriority(&prio, CUR_THREAD_HANDLE);
	musThread = threadCreate(mus_worker, NULL, 32 * 1024, prio + 1, 2, false); // New 3DS: spare core
	if (!musThread) musThread = threadCreate(mus_worker, NULL, 32 * 1024, prio + 1, -2, false);
	if (!musThread) mus_worker(NULL);
}
void audio_exit(void) {
	if (musThread) { threadJoin(musThread, U64_MAX); threadFree(musThread); musThread = NULL; }
	if (audio_ok) ndspExit();
}

void sfx_pitch(int id, float pitch) {
	if (!audio_ok || !snd[id].data) return;
	u64 now = svcGetSystemTick();
	if (now - lastPlay[id] < SYSCLOCK_ARM11 / 25) return; // same effect at most every 40ms
	lastPlay[id] = now;
	// Only reuse a channel whose wave buffer the DSP has finished with (FREE or DONE).
	// A buffer that is QUEUED can still report "not playing"; touching it corrupts
	// ndsp's queue and can hang the console. If every channel is busy, drop the sound.
	int ch = -1;
	for (int i = 0; i < SFX_CHN; i++) {
		int c = SFX_CH0 + (rr + i) % SFX_CHN;
		u8 st = wb[c].status;
		if (st == NDSP_WBUF_FREE || st == NDSP_WBUF_DONE) { ch = c; break; }
	}
	if (ch < 0) return;
	rr = (rr + 1) % SFX_CHN;
	ndspChnSetRate(ch, SR * pitch);
	memset(&wb[ch], 0, sizeof(ndspWaveBuf));
	wb[ch].data_vaddr = snd[id].data;
	wb[ch].nsamples = snd[id].n;
	ndspChnWaveBufAdd(ch, &wb[ch]);
}
void sfx(int id) { sfx_pitch(id, 1.0f); }

void music_set_night(bool night) { musTarget[0] = night ? 0 : 0.6f; musTarget[1] = night ? 0.6f : 0; }
void audio_update(float dt) {
	if (!audio_ok) return;
	// start each loop as soon as it has been composed, fading in from silence
	for (int m = 0; m < 2; m++) if (musReady[m] && !musQueued[m]) {
		int c = m ? MUS_NIGHT : MUS_DAY;
		DSP_FlushDataCache(mus[m].data, mus[m].n * 2);
		memset(&wb[c], 0, sizeof(ndspWaveBuf));
		wb[c].data_vaddr = mus[m].data; wb[c].nsamples = mus[m].n; wb[c].looping = true;
		musVol[m] = 0; set_vol(c, 0);
		ndspChnWaveBufAdd(c, &wb[c]);
		musQueued[m] = true;
	}
	for (int m = 0; m < 2; m++) {
		float d = musTarget[m] - musVol[m];
		float step = dt * 0.25f;
		if (fabsf(d) < step) musVol[m] = musTarget[m]; else musVol[m] += d > 0 ? step : -step;
		set_vol(m ? MUS_NIGHT : MUS_DAY, musVol[m]);
	}
}
