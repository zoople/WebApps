#include "common.h"
#include "icons.h"
#include "world_shbin.h"

RenderParams rp;
C3D_Mtx g_view;

static DVLB_s* dvlb;
static shaderProgram_s prog;
static int uProj, uMV, uLight, uLightClr, uAmb, uFogClr, uFogP, uMul, uAdd;
static C3D_AttrInfo attr;
static C3D_BufInfo bufi;
static C3D_RenderTarget *topT[2], *botT;
static Vtx* vbo;
static int vbo_n;
typedef struct { int start, count; } Range;
static Range meshr[MESH_COUNT];
static Range chunkr[CHUNKS][CHUNKS];
static Range waterr;
static int meshEnd; // the shared mesh library sits at the front of every vertex buffer
// dungeon: its own vertex buffer (mesh library copied in front, so obj_ex still works)
static Vtx* dvbo; static C3D_BufInfo dbufi; static bool dunMode; static Range dch[10][10]; static int dncx, dncz; static float dOX, dOZ, dCS;
static C3D_Mtx projT[2], projN[2];
static int eyes = 1;
static float flash_add = 0;
static C3D_Tex fontTex, mapTex, iconTex, sceneTex;
extern const uint16_t scene_tex[];
extern const uint32_t icons_tex[];
static Tex3DS_SubTexture glyph[256];
static u8 glyph_adv[256];
static Tex3DS_SubTexture mapSub;
extern const u8 default_font_bin[];

#define DISPLAY_TRANSFER_FLAGS \
	(GX_TRANSFER_FLIP_VERT(0) | GX_TRANSFER_OUT_TILED(0) | GX_TRANSFER_RAW_COPY(0) | \
	 GX_TRANSFER_IN_FORMAT(GX_TRANSFER_FMT_RGBA8) | GX_TRANSFER_OUT_FORMAT(GX_TRANSFER_FMT_RGB8) | \
	 GX_TRANSFER_SCALING(GX_TRANSFER_SCALE_NO))

// ---------------------------------------------------------------- mesh building
static Vtx* bv; static int bn, bcap;
static void bpush(Vtx v) {
	if (bn >= bcap) { // grow by half: the bigger island's build buffer must fit the heap alongside its old copy
		int nc = bcap ? bcap + bcap / 2 : 65536; Vtx* nb = realloc(bv, nc * sizeof(Vtx));
		if (!nb) return; // out of memory: drop the rest of the scenery rather than crash
		bv = nb; bcap = nc;
	}
	bv[bn++] = v;
}
static void btri_n(V3 a, V3 b, V3 c, V3 n, u32 rgb, u8 alpha) {
	Vtx v; v.nx = n.x; v.ny = n.y; v.nz = n.z;
	v.r = (rgb>>16)&255; v.g = (rgb>>8)&255; v.b = rgb&255; v.a = alpha;
	v.px=a.x; v.py=a.y; v.pz=a.z; bpush(v);
	v.px=b.x; v.py=b.y; v.pz=b.z; bpush(v);
	v.px=c.x; v.py=c.y; v.pz=c.z; bpush(v);
}
// mode 0: as wound, 1: outward from center, 2: upward
static void btri(V3 a, V3 b, V3 c, u32 rgb, V3 center, int mode) {
	V3 n = v3norm(v3cross(v3sub(b,a), v3sub(c,a)));
	if (mode == 1) { V3 cen = v3mul(v3add(v3add(a,b),c), 1.0f/3); if (v3dot(n, v3sub(cen, center)) < 0) n = v3mul(n, -1); }
	else if (mode == 2) { if (n.y < 0) n = v3mul(n, -1); }
	btri_n(a, b, c, n, rgb, 255);
}
static void bquad(V3 a, V3 b, V3 c, V3 d, u32 rgb, V3 center) { btri(a,b,c,rgb,center,1); btri(a,c,d,rgb,center,1); }

static void mesh_begin(int id) { meshr[id].start = bn; }
static void mesh_end(int id) { meshr[id].count = bn - meshr[id].start; }

static void gen_cone(int seg, float rot) {
	V3 c = v3(0, 0.35f, 0), apex = v3(0,1,0), base = v3(0,0,0);
	for (int i = 0; i < seg; i++) {
		float a0 = rot + TAU*i/seg, a1 = rot + TAU*(i+1)/seg;
		V3 p0 = v3(cosf(a0)*0.5f, 0, sinf(a0)*0.5f), p1 = v3(cosf(a1)*0.5f, 0, sinf(a1)*0.5f);
		btri(p0, p1, apex, 0xFFFFFF, c, 1);
		btri(p1, p0, base, 0xFFFFFF, c, 1);
	}
}
static void gen_sphere(int st, int sl) {
	V3 o = v3(0,0,0);
	for (int i=0;i<st;i++) for (int j=0;j<sl;j++) {
		float t0 = PI*i/st, t1 = PI*(i+1)/st, p0 = TAU*j/sl, p1 = TAU*(j+1)/sl;
		V3 a = v3(sinf(t0)*cosf(p0)*.5f, cosf(t0)*.5f, sinf(t0)*sinf(p0)*.5f);
		V3 b = v3(sinf(t0)*cosf(p1)*.5f, cosf(t0)*.5f, sinf(t0)*sinf(p1)*.5f);
		V3 c = v3(sinf(t1)*cosf(p1)*.5f, cosf(t1)*.5f, sinf(t1)*sinf(p1)*.5f);
		V3 d = v3(sinf(t1)*cosf(p0)*.5f, cosf(t1)*.5f, sinf(t1)*sinf(p0)*.5f);
		if (i > 0) btri(a,b,c,0xFFFFFF,o,1);
		if (i < st-1) btri(a,c,d,0xFFFFFF,o,1);
	}
}
static void gen_cyl(int seg) {
	V3 c = v3(0,0.5f,0);
	for (int i=0;i<seg;i++) {
		float a0 = TAU*i/seg, a1 = TAU*(i+1)/seg;
		V3 b0 = v3(cosf(a0)*.5f,0,sinf(a0)*.5f), b1 = v3(cosf(a1)*.5f,0,sinf(a1)*.5f);
		V3 t0 = v3(b0.x,1,b0.z), t1 = v3(b1.x,1,b1.z);
		bquad(b0,b1,t1,t0,0xFFFFFF,c);
		btri(t0,t1,v3(0,1,0),0xFFFFFF,c,1);
		btri(b1,b0,v3(0,0,0),0xFFFFFF,c,1);
	}
}
static void gen_meshes(void) {
	V3 o = v3(0,0,0);
	// cube
	mesh_begin(MESH_CUBE);
	{
		V3 p[8]; for (int i=0;i<8;i++) p[i] = v3((i&1)?0.5f:-0.5f, (i&2)?0.5f:-0.5f, (i&4)?0.5f:-0.5f);
		int f[6][4] = {{0,1,3,2},{4,6,7,5},{0,4,5,1},{2,3,7,6},{0,2,6,4},{1,5,7,3}};
		for (int i=0;i<6;i++) bquad(p[f[i][0]],p[f[i][1]],p[f[i][2]],p[f[i][3]],0xFFFFFF,o);
	}
	mesh_end(MESH_CUBE);
	mesh_begin(MESH_SPHERE); gen_sphere(5, 8); mesh_end(MESH_SPHERE);
	mesh_begin(MESH_SPHERE_LO); gen_sphere(3, 6); mesh_end(MESH_SPHERE_LO);
	mesh_begin(MESH_CONE); gen_cone(10, 0); mesh_end(MESH_CONE);
	mesh_begin(MESH_CONE5); gen_cone(5, 0.3f); mesh_end(MESH_CONE5);
	mesh_begin(MESH_PYR); gen_cone(4, PI/4); mesh_end(MESH_PYR);
	mesh_begin(MESH_CYL); gen_cyl(8); mesh_end(MESH_CYL);
	mesh_begin(MESH_CYL_LO); gen_cyl(5); mesh_end(MESH_CYL_LO);
	// octahedron
	mesh_begin(MESH_OCTA);
	{
		V3 t = v3(0,.5f,0), b = v3(0,-.5f,0);
		V3 r[4] = {v3(.5f,0,0), v3(0,0,.5f), v3(-.5f,0,0), v3(0,0,-.5f)};
		for (int i=0;i<4;i++) { btri(r[i],r[(i+1)%4],t,0xFFFFFF,o,1); btri(r[(i+1)%4],r[i],b,0xFFFFFF,o,1); }
	}
	mesh_end(MESH_OCTA);
	// half sphere (dome) y 0..0.5
	mesh_begin(MESH_HALFSPH);
	{
		int st = 3, sl = 10; V3 c = v3(0,0.1f,0);
		for (int i=0;i<st;i++) for (int j=0;j<sl;j++) {
			float t0 = (PI/2)*i/st, t1 = (PI/2)*(i+1)/st, p0 = TAU*j/sl, p1 = TAU*(j+1)/sl;
			V3 a = v3(sinf(t0)*cosf(p0)*.5f, cosf(t0)*.5f, sinf(t0)*sinf(p0)*.5f);
			V3 b = v3(sinf(t0)*cosf(p1)*.5f, cosf(t0)*.5f, sinf(t0)*sinf(p1)*.5f);
			V3 cc = v3(sinf(t1)*cosf(p1)*.5f, cosf(t1)*.5f, sinf(t1)*sinf(p1)*.5f);
			V3 d = v3(sinf(t1)*cosf(p0)*.5f, cosf(t1)*.5f, sinf(t1)*sinf(p0)*.5f);
			if (i > 0) btri(a,b,cc,0xFFFFFF,c,1);
			btri(a,cc,d,0xFFFFFF,c,1);
			if (i == st-1) btri(d, cc, v3(0,0,0), 0xFFFFFF, c, 1);
		}
	}
	mesh_end(MESH_HALFSPH);
	// ring
	mesh_begin(MESH_RING);
	for (int i=0;i<20;i++) {
		float a0 = TAU*i/20, a1 = TAU*(i+1)/20;
		V3 i0 = v3(cosf(a0)*.38f,0,sinf(a0)*.38f), i1 = v3(cosf(a1)*.38f,0,sinf(a1)*.38f);
		V3 o0 = v3(cosf(a0)*.5f,0,sinf(a0)*.5f), o1 = v3(cosf(a1)*.5f,0,sinf(a1)*.5f);
		btri(i0,o0,o1,0xFFFFFF,o,2); btri(i0,o1,i1,0xFFFFFF,o,2);
	}
	mesh_end(MESH_RING);
	mesh_begin(MESH_DISC);
	for (int i=0;i<14;i++) {
		float a0 = TAU*i/14, a1 = TAU*(i+1)/14;
		btri(v3(0,0,0), v3(cosf(a0)*.5f,0,sinf(a0)*.5f), v3(cosf(a1)*.5f,0,sinf(a1)*.5f), 0xFFFFFF, o, 2);
	}
	mesh_end(MESH_DISC);
}

// bake a mesh instance into the build buffer
static void bake(int mesh, float x, float y, float z, float sx, float sy, float sz, float yaw, float pitch, u32 rgb) {
	float cy = cosf(yaw), syw = sinf(yaw), cp = cosf(pitch), sp = sinf(pitch);
	Range r = meshr[mesh];
	float cr = ((rgb>>16)&255)/255.f, cg = ((rgb>>8)&255)/255.f, cb = (rgb&255)/255.f;
	for (int i = 0; i < r.count; i++) {
		Vtx s = bv[r.start + i];
		float px = s.px*sx, py = s.py*sy, pz = s.pz*sz;
		float nx = s.nx/sx, ny = s.ny/sy, nz = s.nz/sz;
		// pitch about X
		float py2 = py*cp - pz*sp, pz2 = py*sp + pz*cp; py = py2; pz = pz2;
		float ny2 = ny*cp - nz*sp, nz2 = ny*sp + nz*cp; ny = ny2; nz = nz2;
		// yaw about Y
		float px2 = px*cy + pz*syw; pz2 = -px*syw + pz*cy; px = px2; pz = pz2;
		float nx2 = nx*cy + nz*syw; nz2 = -nx*syw + nz*cy; nx = nx2; nz = nz2;
		V3 n = v3norm(v3(nx,ny,nz));
		Vtx v; v.px = px + x; v.py = py + y; v.pz = pz + z; v.nx = n.x; v.ny = n.y; v.nz = n.z;
		v.r = (u8)(s.r*cr); v.g = (u8)(s.g*cg); v.b = (u8)(s.b*cb); v.a = 255;
		bpush(v);
	}
}

static u32 shade(u32 rgb, float f) {
	int r = (int)(((rgb>>16)&255)*f), g = (int)(((rgb>>8)&255)*f), b = (int)((rgb&255)*f);
	if (r>255) r=255; if (g>255) g=255; if (b>255) b=255;
	return (r<<16)|(g<<8)|b;
}

int gfx_vertex_count(void) { return vbo_n; }
void gfx_build_world(void) {
	meshEnd = bn;
	// meshes already at the front of bv; append chunks
	for (int cz = 0; cz < CHUNKS; cz++) for (int cx = 0; cx < CHUNKS; cx++) {
		chunkr[cz][cx].start = bn;
		for (int j = cz*CHUNK_CELLS; j < (cz+1)*CHUNK_CELLS; j++)
		for (int i = cx*CHUNK_CELLS; i < (cx+1)*CHUNK_CELLS; i++) {
			float x0 = -WORLD_HALF + i*CELL, z0 = -WORLD_HALF + j*CELL, x1 = x0+CELL, z1 = z0+CELL;
			V3 a = v3(x0, heights[j][i], z0), b = v3(x1, heights[j][i+1], z0);
			V3 c = v3(x1, heights[j+1][i+1], z1), d = v3(x0, heights[j+1][i], z1);
			if (a.y < -1.2f && b.y < -1.2f && c.y < -1.2f && d.y < -1.2f) continue; // deep sea floor: skip
			u32 col = cellcolor[j][i];
			float j1 = 0.93f + 0.1f*hash2(i, j, 7), j2 = 0.93f + 0.1f*hash2(i, j, 13);
			if ((i + j) & 1) { btri(a, d, c, shade(col, j1), v3(0,0,0), 2); btri(a, c, b, shade(col, j2), v3(0,0,0), 2); }
			else { btri(a, d, b, shade(col, j1), v3(0,0,0), 2); btri(b, d, c, shade(col, j2), v3(0,0,0), 2); }
		}
		for (int p = 0; p < nprops; p++) {
			Prop* pr = &props[p];
			int pcx = (int)((pr->x + WORLD_HALF) / (CELL*CHUNK_CELLS)), pcz = (int)((pr->z + WORLD_HALF) / (CELL*CHUNK_CELLS));
			if (pcx < 0) pcx = 0; if (pcx >= CHUNKS) pcx = CHUNKS-1; if (pcz < 0) pcz = 0; if (pcz >= CHUNKS) pcz = CHUNKS-1;
			if (pcx != cx || pcz != cz) continue;
			bake(pr->mesh, pr->x, pr->y, pr->z, pr->sx, pr->sy, pr->sz, pr->yaw, pr->pitch, pr->rgb);
		}
		chunkr[cz][cx].count = bn - chunkr[cz][cx].start;
	}
	// water: big translucent plane
	waterr.start = bn;
	{
		float S = 160;
		Vtx v; memset(&v, 0, sizeof v); v.ny = 1; v.r = 255; v.g = 255; v.b = 255; v.a = 255;
		int N = 8; float st = 2*S/N;
		for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
			float x0 = -S + i*st, z0 = -S + j*st;
			V3 a = v3(x0,0,z0), b = v3(x0+st,0,z0), c = v3(x0+st,0,z0+st), d = v3(x0,0,z0+st);
			btri_n(a, d, c, v3(0,1,0), 0xFFFFFF, 255); btri_n(a, c, b, v3(0,1,0), 0xFFFFFF, 255);
		}
	}
	waterr.count = bn - waterr.start;

	vbo = linearAlloc(bn * sizeof(Vtx));
	memcpy(vbo, bv, bn * sizeof(Vtx));
	vbo_n = bn;
	GSPGPU_FlushDataCache(vbo, bn * sizeof(Vtx));
	BufInfo_Init(&bufi);
	BufInfo_Add(&bufi, vbo, sizeof(Vtx), 3, 0x210);

	// minimap texture 64x64 from cell colours
	#define MAPT 128 // texture side; the island fills WORLD_N x WORLD_N of it
	C3D_TexInit(&mapTex, MAPT, MAPT, GPU_RGBA8);
	u32* px = linearAlloc(MAPT*MAPT*4);
	memset(px, 0, MAPT*MAPT*4);
	for (int y = 0; y < WORLD_N; y++) for (int x = 0; x < WORLD_N; x++) {
		u32 c = cellcolor[y][x];
		float h = (heights[y][x] + heights[y+1][x+1]) * 0.5f;
		if (h < -0.05f) c = h < -0.8f ? 0x2A5F8E : 0x4A8CC0;
		c = shade(c, 0.85f + clampf(h, 0, 3)*0.08f);
		int my = y;
		int ofs = ((my>>3)*(MAPT>>3) + (x>>3))*64;
		int ix = x&7, iy = my&7;
		int m = (ix&1)|((iy&1)<<1)|((ix&2)<<1)|((iy&2)<<2)|((ix&4)<<2)|((iy&4)<<3);
		px[ofs + m] = (((c>>16)&255)<<24) | (((c>>8)&255)<<16) | ((c&255)<<8) | 0xFF;
	}
	GSPGPU_FlushDataCache(px, MAPT*MAPT*4);
	C3D_TexUpload(&mapTex, px);
	C3D_TexSetFilter(&mapTex, GPU_NEAREST, GPU_NEAREST);
	linearFree(px);
	mapSub.width = WORLD_N; mapSub.height = WORLD_N; mapSub.left = 0; mapSub.right = WORLD_N / 128.f; mapSub.top = 1; mapSub.bottom = 1 - WORLD_N / 128.f;
	free(bv); bv = NULL;
}

// ---------------------------------------------------------------- font
static void font_init(void) {
	C3D_TexInit(&fontTex, 128, 128, GPU_RGBA8);
	u32* px = linearAlloc(128*128*4);
	memset(px, 0, 128*128*4);
	for (int ch = 0; ch < 256; ch++) {
		int gx = (ch & 15) * 8, gy = (ch >> 4) * 8;
		for (int r = 0; r < 8; r++) {
			u8 bits = default_font_bin[ch*8 + r];
			for (int c = 0; c < 8; c++) {
				if (!(bits & (0x80 >> c))) continue;
				int x = gx + c, y = gy + r;
				int ofs = ((y>>3)*(128>>3) + (x>>3))*64;
				int ix = x&7, iy = y&7;
				int m = (ix&1)|((iy&1)<<1)|((ix&2)<<1)|((iy&2)<<2)|((ix&4)<<2)|((iy&4)<<3);
				px[ofs + m] = 0xFFFFFFFF;
			}
		}
		{ int maxc = -1, minc = 8; for (int r = 0; r < 8; r++) { u8 bits = default_font_bin[ch*8 + r]; for (int c = 0; c < 8; c++) if (bits & (0x80 >> c)) { if (c > maxc) maxc = c; if (c < minc) minc = c; } }
		  glyph_adv[ch] = maxc < 0 ? 4 : (u8)(maxc + 2); if (glyph_adv[ch] < 3) glyph_adv[ch] = 3; }
		if (ch > 0 && ch < 8) glyph_adv[ch] = 0;
		if (ch >= 0x80) glyph_adv[ch] = 11;
		glyph[ch].width = 8; glyph[ch].height = 8;
		glyph[ch].left = gx / 128.f; glyph[ch].right = (gx+8) / 128.f;
		glyph[ch].top = 1.f - gy / 128.f; glyph[ch].bottom = 1.f - (gy+8) / 128.f;
	}
	GSPGPU_FlushDataCache(px, 128*128*4);
	C3D_TexUpload(&fontTex, px);
	C3D_TexSetFilter(&fontTex, GPU_NEAREST, GPU_NEAREST);
	linearFree(px);
}

// ---------------------------------------------------------------- emoji icons (baked atlas, 24px cells)
static void icons_init(void) {
	C3D_TexInit(&iconTex, ICON_TW, ICON_TH, GPU_RGBA8);
	u32* px = linearAlloc(ICON_TW*ICON_TH*4);
	memcpy(px, icons_tex, ICON_TW*ICON_TH*4);
	GSPGPU_FlushDataCache(px, ICON_TW*ICON_TH*4);
	C3D_TexUpload(&iconTex, px);
	C3D_TexSetFilter(&iconTex, GPU_LINEAR, GPU_LINEAR);
	linearFree(px);
}
static void scene_init(void) {
	C3D_TexInit(&sceneTex, 512, 256, GPU_RGB565);
	u16* px = linearAlloc(512*256*2);
	memcpy(px, scene_tex, 512*256*2);
	GSPGPU_FlushDataCache(px, 512*256*2);
	C3D_TexUpload(&sceneTex, px);
	C3D_TexSetFilter(&sceneTex, GPU_LINEAR, GPU_LINEAR);
	linearFree(px);
}
void scene_draw(float x, float y) {
	static Tex3DS_SubTexture sub = { 400, 240, 0, 1, 400 / 512.f, 1 - 240 / 256.f };
	C2D_Image img = { &sceneTex, &sub };
	C2D_DrawImageAt(img, x, y, 0.5f, NULL, 1, 1);
}
void icon(int id, float x, float y, float size) {
	if (id < 0 || id >= ICO_COUNT) return;
	int gx = (id % ICON_COLS) * ICON_CELL, gy = (id / ICON_COLS) * ICON_CELL;
	Tex3DS_SubTexture sub = { ICON_CELL, ICON_CELL, gx / (float)ICON_TW, 1.f - gy / (float)ICON_TH, (gx + ICON_CELL) / (float)ICON_TW, 1.f - (gy + ICON_CELL) / (float)ICON_TH };
	C2D_Image img = { &iconTex, &sub };
	C2D_DrawImageAt(img, floorf(x + 0.5f), floorf(y + 0.5f), 0.5f, NULL, size / ICON_CELL, size / ICON_CELL);
}
// text codes: \x01 yellow (people, places), \x02 red (items, monsters), \x03 back to the base colour,
// \x04 purple (story), bytes 0x80+ draw an emoji icon inline
static bool shadowPass;
static u32 code_col(int code, u32 base) {
	u32 a = base & 0xFF000000;
	switch (code) { case 1: return C2D_Color32(255, 214, 90, 0) | a; case 2: return C2D_Color32(255, 112, 100, 0) | a; case 4: return C2D_Color32(205, 150, 255, 0) | a; case 5: return C2D_Color32(120, 220, 255, 0) | a; default: return base; }
}
static void draw_char(float x, float y, int scale, u32 rgba, unsigned char c) {
	if (c == ' ' || c < 8) return;
	if (c >= 0x80) { if (!shadowPass) icon(c - 0x80, x, y - scale, 10 * scale); return; }
	const Tex3DS_SubTexture* g = &glyph[c];
	x = floorf(x + 0.5f); y = floorf(y + 0.5f); // pixel-snap: crisp glyphs in both eyes
	C2D_DrawAlphaQuad(&fontTex, x, y, 8*scale, 8*scale, g->left, g->top, g->right, g->bottom, rgba, 0.5f);
}
void text(float x, float y, int scale, u32 rgba, const char* s) {
	float cx = x; u32 col = rgba;
	for (; *s; s++) {
		unsigned char c = (unsigned char)*s;
		if (*s == '\n') { cx = x; y += 9*scale; continue; }
		if (c < 8) { if (!shadowPass) col = code_col(c, rgba); continue; }
		draw_char(cx, y, scale, col, c);
		cx += glyph_adv[(unsigned char)*s]*scale;
	}
}
void text_shadow(float x, float y, int scale, u32 rgba, const char* s) {
	u8 a = (rgba >> 24) & 255;
	shadowPass = true; text(x+scale, y+scale, scale, C2D_Color32(0,0,0,(u8)(a*0.75f)), s); shadowPass = false;
	text(x, y, scale, rgba, s);
}
int text_w(const char* s, int scale) {
	int n = 0, best = 0;
	for (; *s; s++) { if (*s == '\n') { if (n > best) best = n; n = 0; } else n += glyph_adv[(unsigned char)*s]; }
	if (n > best) best = n;
	return best * scale;
}
void text_center(float cx, float y, int scale, u32 rgba, const char* s) { text_shadow(cx - text_w(s, scale)/2.f, y, scale, rgba, s); }
int text_wrap_n(float x, float y, int scale, u32 rgba, const char* s, int maxW, int maxLines, int reveal) {
	char line[200]; int lines = 0; char curc = 0;
	const char* p = s;
	while (*p && lines < maxLines) {
		int len = 0, lastSpace = -1, w = 0;
		while (p[len] && p[len] != '\n') {
			int cw = glyph_adv[(unsigned char)p[len]] * scale;
			if (w + cw > maxW) break;
			if (p[len] == ' ') lastSpace = len;
			w += cw; len++;
		}
		int take = len;
		if (p[len] && p[len] != '\n' && lastSpace > 0) take = lastSpace;
		if (take > 159) take = 159;
		if (take == 0 && p[0] && p[0] != '\n') take = 1;
		int vis = (int)(reveal - (p - s)); if (vis < 0) vis = 0; if (vis > take) vis = take;
		int o = 0; if (curc) line[o++] = curc;
		memcpy(line + o, p, vis); line[o + vis] = 0;
		for (int k = 0; k < take; k++) { unsigned char c = (unsigned char)p[k]; if (c > 0 && c < 8) curc = c == 3 ? 0 : (char)c; }
		if (vis > 0) text_shadow(x, y + lines*11*scale, scale, rgba, line);
		lines++;
		p += take;
		while (*p == ' ') p++;
		if (*p == '\n') p++;
	}
	return lines;
}
void rect(float x, float y, float w, float h, u32 rgba) { C2D_DrawRectSolid(x, y, 0.5f, w, h, rgba); }
void rect_grad(float x, float y, float w, float h, u32 t, u32 b) { C2D_DrawRectangle(x, y, 0.5f, w, h, t, t, b, b); }
void rect_outline(float x, float y, float w, float h, float t, u32 c) {
	rect(x, y, w, t, c); rect(x, y+h-t, w, t, c); rect(x, y, t, h, c); rect(x+w-t, y, t, h, c);
}
void circle(float x, float y, float r, u32 rgba) {
	int seg = r < 6 ? 8 : (r < 20 ? 14 : 22);
	for (int i = 0; i < seg; i++) {
		float a0 = TAU*i/seg, a1 = TAU*(i+1)/seg;
		C2D_DrawTriangle(x, y, rgba, x+cosf(a0)*r, y+sinf(a0)*r, rgba, x+cosf(a1)*r, y+sinf(a1)*r, rgba, 0.5f);
	}
}
void tri2d(float x0, float y0, float x1, float y1, float x2, float y2, u32 c) { C2D_DrawTriangle(x0,y0,c,x1,y1,c,x2,y2,c,0.5f); }
void minimap_draw(float x, float y, float size) {
	C2D_Image img = { &mapTex, &mapSub };
	C2D_DrawImageAt(img, x, y, 0.5f, NULL, size/(float)WORLD_N, size/(float)WORLD_N);
}

// ---------------------------------------------------------------- init / frame
void gfx_init(void) {
	gfxInitDefault();
	gfxSet3D(true);
	C3D_Init(0x100000);
	C2D_Init(6000);
	topT[0] = C3D_RenderTargetCreate(240, 400, GPU_RB_RGBA8, GPU_RB_DEPTH24_STENCIL8);
	topT[1] = C3D_RenderTargetCreate(240, 400, GPU_RB_RGBA8, GPU_RB_DEPTH24_STENCIL8);
	C3D_RenderTargetSetOutput(topT[0], GFX_TOP, GFX_LEFT, DISPLAY_TRANSFER_FLAGS);
	C3D_RenderTargetSetOutput(topT[1], GFX_TOP, GFX_RIGHT, DISPLAY_TRANSFER_FLAGS);
	botT = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

	dvlb = DVLB_ParseFile((u32*)world_shbin, world_shbin_size);
	shaderProgramInit(&prog);
	shaderProgramSetVsh(&prog, &dvlb->DVLE[0]);
	uProj = shaderInstanceGetUniformLocation(prog.vertexShader, "projection");
	uMV = shaderInstanceGetUniformLocation(prog.vertexShader, "modelView");
	uLight = shaderInstanceGetUniformLocation(prog.vertexShader, "lightVec");
	uLightClr = shaderInstanceGetUniformLocation(prog.vertexShader, "lightClr");
	uAmb = shaderInstanceGetUniformLocation(prog.vertexShader, "ambClr");
	uFogClr = shaderInstanceGetUniformLocation(prog.vertexShader, "fogClr");
	uFogP = shaderInstanceGetUniformLocation(prog.vertexShader, "fogParam");
	uMul = shaderInstanceGetUniformLocation(prog.vertexShader, "mulClr");
	uAdd = shaderInstanceGetUniformLocation(prog.vertexShader, "addClr");

	AttrInfo_Init(&attr);
	AttrInfo_AddLoader(&attr, 0, GPU_FLOAT, 3);
	AttrInfo_AddLoader(&attr, 1, GPU_FLOAT, 3);
	AttrInfo_AddLoader(&attr, 2, GPU_UNSIGNED_BYTE, 4);

	gen_meshes();
	font_init();
	icons_init();
	scene_init();
	rp.fov = 55.0f * PI / 180.0f;
	rp.focal = 9.0f;
	rp.fogStart = 19; rp.fogEnd = 40;
	rp.sky = 0x8CC8F0; rp.ambient = 0.45f; rp.light = 0.75f;
	rp.lightTint[0] = rp.lightTint[1] = rp.lightTint[2] = 1;
}

void gfx_exit(void) {
	C2D_Fini();
	C3D_Fini();
	gfxExit();
}

static float cur_eye_iod[2];
void gfx_frame_begin(void) {
	float slider = osGet3DSliderState();
	eyes = slider > 0.01f ? 2 : 1;
#ifdef HM_FORCE_STEREO
	eyes = 2; slider = 1.0f;
#endif
	float iod = slider * 0.35f;
	cur_eye_iod[0] = -iod; cur_eye_iod[1] = iod;
	for (int e = 0; e < 2; e++) {
		Mtx_PerspStereoTilt(&projT[e], rp.fov, 400.f/240.f, 0.3f, 90.0f, cur_eye_iod[e], rp.focal, false);
		Mtx_PerspStereo(&projN[e], rp.fov, 400.f/240.f, 0.3f, 90.0f, cur_eye_iod[e], rp.focal, false);
	}
	Mtx_LookAt(&g_view, FVec3_New(rp.camx + rp.shakeX, rp.camy + rp.shakeY, rp.camz), FVec3_New(rp.tx + rp.shakeX, rp.ty + rp.shakeY, rp.tz), FVec3_New(0,1,0), false);
	C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
}
size_t C2D_DebugVtxUsed(void);
int g_c2dUsed;
float g_cmdUse, g_cmdPeak;
void gfx_frame_end(void) { C2D_Flush(); g_c2dUsed = (int)C2D_DebugVtxUsed(); g_cmdUse = C3D_GetCmdBufUsage(); if (g_cmdUse > g_cmdPeak) g_cmdPeak = g_cmdUse; C3D_FrameEnd(0); }
int gfx_eyes(void) { return eyes; }
float gfx_eye_offset(int eye) { return eyes == 2 ? (eye == 0 ? -1.f : 1.f) * osGet3DSliderState() : 0.f; }

static void bind3d(int eye) {
	C3D_BindProgram(&prog);
	C3D_SetAttrInfo(&attr);
	C3D_SetBufInfo(dunMode && dvbo ? &dbufi : &bufi);
	for (int i = 0; i < 6; i++) C3D_TexEnvInit(C3D_GetTexEnv(i));
	C3D_TexEnv* env = C3D_GetTexEnv(0);
	C3D_TexEnvSrc(env, C3D_Both, GPU_PRIMARY_COLOR, 0, 0);
	C3D_TexEnvFunc(env, C3D_Both, GPU_REPLACE);
	C3D_DepthTest(true, GPU_GREATER, GPU_WRITE_ALL);
	C3D_CullFace(GPU_CULL_NONE);
	C3D_AlphaBlend(GPU_BLEND_ADD, GPU_BLEND_ADD, GPU_SRC_ALPHA, GPU_ONE_MINUS_SRC_ALPHA, GPU_SRC_ALPHA, GPU_ONE_MINUS_SRC_ALPHA);
	C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, uProj, &projT[eye]);
	// light direction in view space
	C3D_FVec L = FVec3_New(0.45f, 0.8f, 0.35f);
	L = FVec3_Normalize(L);
	C3D_FVec Lv = Mtx_MultiplyFVec3(&g_view, L);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uLight, Lv.x, Lv.y, Lv.z, 0);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uLightClr, rp.light*rp.lightTint[0], rp.light*rp.lightTint[1], rp.light*rp.lightTint[2], 0);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uAmb, rp.ambient, rp.ambient, rp.ambient*1.08f, 0);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uFogClr, ((rp.sky>>16)&255)/255.f, ((rp.sky>>8)&255)/255.f, (rp.sky&255)/255.f, 1);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uFogP, rp.fogStart, 1.0f/(rp.fogEnd - rp.fogStart), 0, 0);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uMul, 1, 1, 1, 1);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uAdd, 0, 0, 0, 0);
	C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, uMV, &g_view);
}

void gfx_begin_eye(int eye) {
	C2D_Flush(); // finish any queued 2D for the previous eye before switching targets
	u32 s = rp.sky;
	C3D_RenderTargetClear(topT[eye], C3D_CLEAR_ALL, (s << 8) | 0xFF, 0);
	C3D_FrameDrawOn(topT[eye]);
	bind3d(eye);
}

void gfx_dungeon_mode(bool on) { dunMode = on; }
// tiles: 0 rock, anything else floor. Rock that touches floor becomes a wall block of height wh.
void gfx_build_dungeon(const u8* t, int w, int h, float ox, float oz, float ts, float wh, u32 fc, u32 wc, u32 tc) {
	bv = NULL; bn = bcap = 0;
	for (int i = 0; i < meshEnd; i++) bpush(vbo[i]);
	#define TL(i, j) (((i) < 0 || (j) < 0 || (i) >= w || (j) >= h) ? 0 : t[(j) * w + (i)])
	const int CH = 6;
	dncx = (w + CH - 1) / CH; dncz = (h + CH - 1) / CH; if (dncx > 10) dncx = 10; if (dncz > 10) dncz = 10;
	dOX = ox; dOZ = oz; dCS = CH * ts;
	for (int cz = 0; cz < dncz; cz++) for (int cx = 0; cx < dncx; cx++) {
		dch[cz][cx].start = bn;
		for (int j = cz * CH; j < (cz + 1) * CH && j < h; j++) for (int i = cx * CH; i < (cx + 1) * CH && i < w; i++) {
			float x0 = ox + i * ts, z0 = oz + j * ts, x1 = x0 + ts, z1 = z0 + ts;
			if (TL(i, j)) {
				u32 c = shade(fc, ((i + j) & 1) ? 0.92f : 1.0f + 0.06f * hash2(i, j, 5));
				btri(v3(x0, 0, z0), v3(x0, 0, z1), v3(x1, 0, z1), c, v3(0,0,0), 2); btri(v3(x0, 0, z0), v3(x1, 0, z1), v3(x1, 0, z0), c, v3(0,0,0), 2);
				continue;
			}
			bool edge = false;
			for (int dj = -1; dj <= 1; dj++) for (int di = -1; di <= 1; di++) if (TL(i + di, j + dj)) edge = true;
			if (!edge) continue;
			float hh = wh * (0.92f + 0.16f * hash2(i, j, 9));
			V3 cen = v3(x0 + ts * 0.5f, hh * 0.5f, z0 + ts * 0.5f);
			u32 top = shade(tc, 0.9f + 0.2f * hash2(i, j, 3));
			btri(v3(x0, hh, z0), v3(x0, hh, z1), v3(x1, hh, z1), top, cen, 2); btri(v3(x0, hh, z0), v3(x1, hh, z1), v3(x1, hh, z0), top, cen, 2);
			u32 side = shade(wc, 0.85f + 0.2f * hash2(i, j, 4));
			if (TL(i, j - 1)) bquad(v3(x0, 0, z0), v3(x1, 0, z0), v3(x1, hh, z0), v3(x0, hh, z0), side, cen);
			if (TL(i, j + 1)) bquad(v3(x0, 0, z1), v3(x1, 0, z1), v3(x1, hh, z1), v3(x0, hh, z1), side, cen);
			if (TL(i - 1, j)) bquad(v3(x0, 0, z0), v3(x0, 0, z1), v3(x0, hh, z1), v3(x0, hh, z0), shade(side, 0.85f), cen);
			if (TL(i + 1, j)) bquad(v3(x1, 0, z0), v3(x1, 0, z1), v3(x1, hh, z1), v3(x1, hh, z0), shade(side, 0.85f), cen);
		}
		dch[cz][cx].count = bn - dch[cz][cx].start;
	}
	#undef TL
	if (dvbo) linearFree(dvbo);
	dvbo = linearAlloc(bn * sizeof(Vtx));
	if (dvbo) { memcpy(dvbo, bv, bn * sizeof(Vtx)); GSPGPU_FlushDataCache(dvbo, bn * sizeof(Vtx)); BufInfo_Init(&dbufi); BufInfo_Add(&dbufi, dvbo, sizeof(Vtx), 3, 0x210); }
	free(bv); bv = NULL; bn = bcap = 0;
}
void gfx_draw_world_static(void) {
	C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, uMV, &g_view);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uMul, 1, 1, 1, 1);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uAdd, 0, 0, 0, 0);
	float fx = rp.tx - rp.camx, fz = rp.tz - rp.camz; float fl = sqrtf(fx*fx+fz*fz); if (fl < 0.01f) fl = 1; fx /= fl; fz /= fl;
	if (dunMode && dvbo) {
		for (int cz = 0; cz < dncz; cz++) for (int cx = 0; cx < dncx; cx++) {
			if (!dch[cz][cx].count) continue;
			float mx = dOX + (cx + 0.5f) * dCS, mz = dOZ + (cz + 0.5f) * dCS;
			if (dist2d(mx, mz, rp.camx, rp.camz) > rp.fogEnd + dCS) continue;
			if (!gfx_visible(mx, mz, dCS * 0.75f)) continue;
			C3D_DrawArrays(GPU_TRIANGLES, dch[cz][cx].start, dch[cz][cx].count);
		}
		return;
	}
	float csz = CELL*CHUNK_CELLS;
	for (int cz = 0; cz < CHUNKS; cz++) for (int cx = 0; cx < CHUNKS; cx++) {
		if (!chunkr[cz][cx].count) continue;
		float mx = -WORLD_HALF + (cx+0.5f)*csz, mz = -WORLD_HALF + (cz+0.5f)*csz;
		float dx = mx - rp.camx, dz = mz - rp.camz;
		float d = sqrtf(dx*dx+dz*dz);
		if (d > rp.fogEnd + csz * 0.75f) continue;
		if (!gfx_visible(mx, mz, csz * 0.75f)) continue;
		C3D_DrawArrays(GPU_TRIANGLES, chunkr[cz][cx].start, chunkr[cz][cx].count);
	}
}

void gfx_set_flash(float f) { flash_add = f; }
bool gfx_visible(float x, float z, float r) {
	float fx = rp.tx - rp.camx, fz = rp.tz - rp.camz; float fl = sqrtf(fx*fx+fz*fz); if (fl < 0.01f) return true;
	fx /= fl; fz /= fl;
	float dx = x - rp.camx, dz = z - rp.camz, d = sqrtf(dx*dx+dz*dz);
	if (d < r + 2) return true;
	float along = (dx*fx + dz*fz) / d;          // cos of angle off forward
	float side = r / d; if (side > 1) side = 1;
	// half horizontal fov ~41 deg (cos ~0.75); widen by the object's angular radius
	float lim = cosf(0.80f + asinf(side));
	return along > lim;
}
void gfx_transparent(bool on) {
	if (on) C3D_DepthTest(true, GPU_GREATER, GPU_WRITE_COLOR);
	else C3D_DepthTest(true, GPU_GREATER, GPU_WRITE_ALL);
}

int g_draws;
void obj_ex(int mesh, float x, float y, float z, float sx, float sy, float sz, float yaw, float pitch, u32 rgb, float alpha, float emit) {
	float mx = sx > sy ? sx : sy; if (sz > mx) mx = sz;
	if (mesh == MESH_SPHERE && mx < 0.32f) mesh = MESH_SPHERE_LO;
	else if (mesh == MESH_CYL && mx < 0.45f) mesh = MESH_CYL_LO;
	C3D_Mtx m;
	Mtx_Copy(&m, &g_view);
	Mtx_Translate(&m, x, y, z, true);
	if (yaw != 0) Mtx_RotateY(&m, yaw, true);
	if (pitch != 0) Mtx_RotateX(&m, pitch, true);
	Mtx_Scale(&m, sx, sy, sz);
	C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, uMV, &m);
	float r = ((rgb>>16)&255)/255.f, g = ((rgb>>8)&255)/255.f, b = (rgb&255)/255.f;
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uMul, r, g, b, alpha);
	float e = emit + flash_add;
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uAdd, r*emit + flash_add, g*emit + flash_add, b*emit + flash_add, 0);
	(void)e;
	C3D_DrawArrays(GPU_TRIANGLES, meshr[mesh].start, meshr[mesh].count);
	g_draws++;
}
void obj(int mesh, float x, float y, float z, float sx, float sy, float sz, float yaw, u32 rgb) {
	obj_ex(mesh, x, y, z, sx, sy, sz, yaw, 0, rgb, 1, 0);
}

void gfx_draw_water(float t);
void gfx_draw_water(float t) {
	if (dunMode) return;
	C3D_Mtx m;
	Mtx_Copy(&m, &g_view);
	Mtx_Translate(&m, 0, -0.12f + sinf(t*0.8f)*0.05f, 0, true);
	C3D_FVUnifMtx4x4(GPU_VERTEX_SHADER, uMV, &m);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uMul, 0.30f, 0.62f, 0.85f, 0.62f);
	C3D_FVUnifSet(GPU_VERTEX_SHADER, uAdd, 0.02f, 0.05f, 0.08f, 0);
	C3D_DrawArrays(GPU_TRIANGLES, waterr.start, waterr.count);
}

bool world_to_screen(int eye, V3 p, float* sx, float* sy) {
	C3D_FVec v = FVec4_New(p.x, p.y, p.z, 1);
	C3D_FVec e = Mtx_MultiplyFVec4(&g_view, v);
	C3D_FVec c = Mtx_MultiplyFVec4(&projN[eye], e);
	if (c.w <= 0.05f) return false;
	float nx = c.x / c.w, ny = c.y / c.w;
	*sx = (nx * 0.5f + 0.5f) * 400.f;
	*sy = (1.f - (ny * 0.5f + 0.5f)) * 240.f;
	return *sx > -40 && *sx < 440 && *sy > -40 && *sy < 280;
}

static void prep2d(C3D_RenderTarget* t) {
	C2D_Prepare();
	C2D_SceneBegin(t);
	C3D_DepthTest(false, GPU_ALWAYS, GPU_WRITE_COLOR);
}
void gfx_begin_2d_top(int eye) { prep2d(topT[eye]); }
void gfx_begin_2d_bottom(void) {
	C2D_Flush();
	C3D_RenderTargetClear(botT, C3D_CLEAR_ALL, 0x1B1F2EFF, 0);
	prep2d(botT);
}

void gfx_debug_font(float x, float y, int s) {
	static Tex3DS_SubTexture full = { 128, 128, 0, 1, 1, 0 };
	C2D_Image img = { &fontTex, &full };
	C2D_DrawImageAt(img, x, y, 0.5f, NULL, s, s);
}
