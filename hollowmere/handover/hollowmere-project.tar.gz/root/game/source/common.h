// Hollowmere — a little 3DS adventure
#pragma once
#define HM_VERSION "v1.30"
#include <3ds.h>
#include <citro3d.h>
#include <citro2d.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "icons.h"

#define PI 3.14159265f
#define TAU 6.2831853f

typedef struct { float x, y, z; } V3;
static inline V3 v3(float x, float y, float z) { V3 r = {x, y, z}; return r; }
static inline V3 v3add(V3 a, V3 b) { return v3(a.x+b.x, a.y+b.y, a.z+b.z); }
static inline V3 v3sub(V3 a, V3 b) { return v3(a.x-b.x, a.y-b.y, a.z-b.z); }
static inline V3 v3mul(V3 a, float s) { return v3(a.x*s, a.y*s, a.z*s); }
static inline float v3dot(V3 a, V3 b) { return a.x*b.x + a.y*b.y + a.z*b.z; }
static inline V3 v3cross(V3 a, V3 b) { return v3(a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x); }
static inline float v3len(V3 a) { return sqrtf(v3dot(a, a)); }
static inline V3 v3norm(V3 a) { float l = v3len(a); return l > 1e-6f ? v3mul(a, 1.0f/l) : v3(0,1,0); }
static inline float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static inline float lerpf(float a, float b, float t) { return a + (b-a)*t; }
static inline float smooth01(float t) { t = clampf(t, 0, 1); return t*t*(3-2*t); }
static inline float dist2d(float ax, float az, float bx, float bz) { float dx = ax-bx, dz = az-bz; return sqrtf(dx*dx+dz*dz); }

// random
u32 rnd_u32(void);
float rndf(void);            // [0,1)
float rndr(float a, float b);
int rndi(int a, int b);      // inclusive
float hash2(int x, int y, int seed);

// ---------------- gfx ----------------
typedef struct { float px, py, pz; float nx, ny, nz; u8 r, g, b, a; } Vtx;

enum { MESH_CUBE, MESH_SPHERE, MESH_CONE, MESH_CYL, MESH_OCTA, MESH_HALFSPH, MESH_PYR, MESH_RING, MESH_DISC, MESH_CONE5, MESH_SPHERE_LO, MESH_CYL_LO, MESH_COUNT };

#define WORLD_N 112 // v1.21: island stretched outward again (village unchanged)
#define CELL 1.5f
#define WORLD_HALF (WORLD_N*CELL*0.5f)
#define CHUNK_CELLS 8
#define CHUNKS (WORLD_N/CHUNK_CELLS)
#define ISLAND_K 2.8f   // how much the land past the village was stretched (v1.17 1.4, v1.21 2.8)
#define ISLAND_R0 12.0f // radius the stretch starts at
void island_save_remap(float* x, float* z); // pre-1.17 save position -> new island

typedef struct {
	float camx, camy, camz, tx, ty, tz;
	float fov, iod, focal;
	u32 sky;           // 0xRRGGBB
	float fogStart, fogEnd;
	float ambient, light;
	float lightTint[3];
	float shakeX, shakeY;
} RenderParams;

extern RenderParams rp;
extern C3D_Mtx g_view;

void gfx_init(void);
void gfx_exit(void);
void gfx_build_world(void);                    // after world gen
void gfx_build_dungeon(const u8* t, int w, int h, float ox, float oz, float ts, float wh, u32 fc, u32 wc, u32 tc);
void gfx_dungeon_mode(bool on);
// dungeons replace the ground, zones and collision while you're inside one
extern bool dunOn; extern u8 dunZone;
bool dun_blocked(float x, float z, float r, float* outx, float* outz);
void gfx_frame_begin(void);
void gfx_frame_end(void);
int  gfx_eyes(void);
void gfx_begin_eye(int eye);                   // clears and binds 3D
void gfx_draw_world_static(void);
void gfx_begin_2d_top(int eye);
void gfx_begin_2d_bottom(void);
float gfx_eye_offset(int eye);                 // for HUD parallax: pixels per unit depth

// object drawing
void obj(int mesh, float x, float y, float z, float sx, float sy, float sz, float yaw, u32 rgb);
void obj_ex(int mesh, float x, float y, float z, float sx, float sy, float sz, float yaw, float pitch, u32 rgb, float alpha, float emit);
void gfx_set_flash(float f);                   // white flash add on next objs
void gfx_transparent(bool on);
bool world_to_screen(int eye, V3 p, float* sx, float* sy);
bool gfx_visible(float x, float z, float r);

// text (8x8 bitmap font)
void text(float x, float y, int scale, u32 rgba, const char* s);
void text_shadow(float x, float y, int scale, u32 rgba, const char* s);
void text_center(float cx, float y, int scale, u32 rgba, const char* s);
int  text_w(const char* s, int scale);
int  text_wrap(float x, float y, int scale, u32 rgba, const char* s, int maxW, int maxLines); // returns lines
int  text_wrap_n(float x, float y, int scale, u32 rgba, const char* s, int maxW, int maxLines, int reveal);
void rect(float x, float y, float w, float h, u32 rgba);
void icon(int id, float x, float y, float size);
void scene_draw(float x, float y);
void rect_grad(float x, float y, float w, float h, u32 top, u32 bottom);
void rect_outline(float x, float y, float w, float h, float t, u32 rgba);
void circle(float x, float y, float r, u32 rgba);
void tri2d(float x0, float y0, float x1, float y1, float x2, float y2, u32 rgba);
void minimap_draw(float x, float y, float size);
#define RGBA(r,g,b,a) C2D_Color32((r),(g),(b),(a))
static inline u32 rgb_to_c2d(u32 rgb, u8 a) { return C2D_Color32((rgb>>16)&255, (rgb>>8)&255, rgb&255, a); }

// ---------------- world ----------------
enum { Z_VILLAGE, Z_MEADOW, Z_BEACH, Z_RUINS, Z_FOREST, Z_SWAMP, Z_COUNT };
extern const char* zone_names[Z_COUNT];
extern float heights[WORLD_N+1][WORLD_N+1];
extern u8 cellzone[WORLD_N][WORLD_N];
// element seals: cells of an outer zone that touch another zone (barrier props + the break prompt)
typedef struct { float x, z, y; u8 zone; u8 seed; } SealPt;
#define MAX_SEAL 900
extern SealPt sealpts[MAX_SEAL]; extern int nseal;
extern u32 cellcolor[WORLD_N][WORLD_N];

typedef struct { float x, z, r; } Obstacle;
#define MAX_OBST 2600
extern Obstacle obst[MAX_OBST];
extern int nobst;

// static prop list (baked into chunk meshes)
typedef struct { u8 mesh; float x, y, z, sx, sy, sz, yaw, pitch; u32 rgb; } Prop;
#define MAX_PROPS 7000
extern Prop props[MAX_PROPS];
extern int nprops;

void world_gen(void);
float ground_h(float x, float z);
int zone_at(float x, float z);
bool world_blocked(float x, float z, float r, float* outx, float* outz); // resolves push-out
bool world_spot_free(float x, float z, float clear);
void add_obst_pub(float x, float z, float r);
void add_prop(int mesh, float x, float y, float z, float sx, float sy, float sz, float yaw, u32 rgb);
void add_prop_p(int mesh, float x, float y, float z, float sx, float sy, float sz, float yaw, float pitch, u32 rgb);
bool find_spot(int zone, float* ox, float* oz, float minClear);
void world_reserve(float x, float z, float r); // keep gatherables/chests clear of a spot

// ---------------- audio ----------------
enum { SFX_PICK, SFX_COIN, SFX_HIT, SFX_CRIT, SFX_KILL, SFX_SWING, SFX_HURT, SFX_LEVEL, SFX_ACH, SFX_CHEST,
       SFX_BLIP, SFX_QUEST, SFX_DODGE, SFX_LOOT_RARE, SFX_LOOT_EPIC, SFX_DIG, SFX_BUY, SFX_MEOW, SFX_SLAM, SFX_COUNT };
void audio_init(void);
void audio_synth(int part);
void audio_start(void);
void audio_exit(void);
void sfx(int id);
void sfx_pitch(int id, float pitch);
void music_set_night(bool night);
void audio_update(float dt);
