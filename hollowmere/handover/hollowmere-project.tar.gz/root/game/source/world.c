#include "common.h"
#include "data.h"

const char* zone_names[Z_COUNT] = { "Hollow Village", "Sunny Meadow", "Sunspray Beach", "The Old Ruins", "Whisperwood", "Mirefen Swamp" };
float heights[WORLD_N+1][WORLD_N+1];
u8 cellzone[WORLD_N][WORLD_N];
SealPt sealpts[MAX_SEAL]; int nseal;
u32 cellcolor[WORLD_N][WORLD_N];
Obstacle obst[MAX_OBST];
int nobst;
Prop props[MAX_PROPS];
int nprops;

static u32 rs = 0x9E3779B9;
u32 rnd_u32(void) { rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; return rs; }
float rndf(void) { return (rnd_u32() >> 8) / 16777216.f; }
float rndr(float a, float b) { return a + (b - a) * rndf(); }
int rndi(int a, int b) { return a + (int)(rnd_u32() % (u32)(b - a + 1)); }
float hash2(int x, int y, int seed) {
	u32 h = (u32)x * 374761393u + (u32)y * 668265263u + (u32)seed * 2246822519u;
	h = (h ^ (h >> 13)) * 1274126177u; h ^= h >> 16;
	return (h & 0xFFFFFF) / 16777216.f;
}
static float vnoise(float x, float z, int seed) {
	int ix = (int)floorf(x), iz = (int)floorf(z);
	float fx = x - ix, fz = z - iz;
	fx = fx*fx*(3-2*fx); fz = fz*fz*(3-2*fz);
	float a = hash2(ix, iz, seed), b = hash2(ix+1, iz, seed), c = hash2(ix, iz+1, seed), d = hash2(ix+1, iz+1, seed);
	return lerpf(lerpf(a, b, fx), lerpf(c, d, fx), fz);
}
static float fbm(float x, float z, int seed) {
	float s = 0, a = 0.5f, f = 1;
	for (int o = 0; o < 4; o++) { s += a * vnoise(x*f, z*f, seed + o*17); a *= 0.5f; f *= 2.03f; }
	return s;
}

// The island was stretched outward in v1.17 for more room. Terrain is still generated
// from the original layout: map each point back to where it used to be.
static void to_old(float* x, float* z) {
	float r = sqrtf(*x * *x + *z * *z); if (r <= ISLAND_R0) return;
	float k = (ISLAND_R0 + (r - ISLAND_R0) / ISLAND_K) / r; *x *= k; *z *= k;
}
void island_save_remap(float* x, float* z) {
	float r = sqrtf(*x * *x + *z * *z); if (r <= ISLAND_R0) return;
	float k = (ISLAND_R0 + (r - ISLAND_R0) * ISLAND_K) / r; *x *= k; *z *= k;
}
static int zone_raw(float x, float z) {
	to_old(&x, &z);
	float r = sqrtf(x*x + z*z);
	float wob = (vnoise(x*0.08f, z*0.08f, 5) - 0.5f) * 6;
	if (r + wob*0.5f < 11) return Z_VILLAGE;
	if (r + wob < 21) return Z_MEADOW;
	float a = atan2f(z, x) + (vnoise(x*0.05f, z*0.05f, 9) - 0.5f) * 0.6f;
	if (a > PI) a -= TAU; if (a < -PI) a += TAU;
	if (a > PI/4 && a < 3*PI/4) return Z_BEACH;
	if (a >= -PI/4 && a <= PI/4) return Z_RUINS;
	if (a < -PI/4 && a > -3*PI/4) return Z_FOREST;
	return Z_SWAMP;
}

static float gen_height(float x, float z) {
	// small bumps in true (stretched) coordinates so the bigger island isn't smoothed flat
	float rr = sqrtf(x*x + z*z), detail = (fbm(x * 0.11f, z * 0.11f, 61) - 0.5f) * 0.7f * smooth01((rr - 16) / 8);
	to_old(&x, &z);
	float r = sqrtf(x*x + z*z);
	float rn = r / 42.f;
	float coast = 1 - smooth01((rn - 0.80f + (vnoise(x*0.07f, z*0.07f, 3) - 0.5f) * 0.22f) / 0.17f);
	float base = 0.45f + fbm(x*0.06f, z*0.06f, 1) * 1.1f;
	float a = atan2f(z, x);
	float ca = cosf(a), sa = sinf(a);
	float wE = ca > 0 ? ca*ca : 0, wW = ca < 0 ? ca*ca : 0, wS = sa > 0 ? sa*sa : 0, wN = sa < 0 ? sa*sa : 0;
	float outer = smooth01((r - 17) / 7);
	float h = base;
	h += outer * (wE * (1.3f + (vnoise(x*0.15f, z*0.15f, 21) > 0.62f ? 0.6f : 0)) + wN * fbm(x*0.12f, z*0.12f, 33) * 2.4f - wS * 0.35f);
	h = lerpf(h, 0.16f + fbm(x*0.2f, z*0.2f, 44) * 0.3f, outer * wW * 0.85f);
	float v = 1 - smooth01((r - 8) / 6);
	h = lerpf(h, 0.75f, v);
	return h * coast + (coast - 1) * 2.6f + detail * coast;
}

float ground_h(float x, float z) {
	if (dunOn) return 0;
	float fx = (x + WORLD_HALF) / CELL, fz = (z + WORLD_HALF) / CELL;
	if (fx < 0 || fz < 0 || fx >= WORLD_N || fz >= WORLD_N) return -2.6f;
	int ix = (int)fx, iz = (int)fz;
	float tx = fx - ix, tz = fz - iz;
	float a = heights[iz][ix], b = heights[iz][ix+1], c = heights[iz+1][ix], d = heights[iz+1][ix+1];
	return lerpf(lerpf(a, b, tx), lerpf(c, d, tx), tz);
}
int zone_at(float x, float z) {
	if (dunOn) return dunZone;
	int ix = (int)((x + WORLD_HALF) / CELL), iz = (int)((z + WORLD_HALF) / CELL);
	if (ix < 0 || iz < 0 || ix >= WORLD_N || iz >= WORLD_N) return Z_BEACH;
	return cellzone[iz][ix];
}

void add_prop_p(int mesh, float x, float y, float z, float sx, float sy, float sz, float yaw, float pitch, u32 rgb) {
	if (nprops >= MAX_PROPS) return;
	Prop* p = &props[nprops++];
	p->mesh = mesh; p->x = x; p->y = y; p->z = z; p->sx = sx; p->sy = sy; p->sz = sz; p->yaw = yaw; p->pitch = pitch; p->rgb = rgb;
}
void add_prop(int mesh, float x, float y, float z, float sx, float sy, float sz, float yaw, u32 rgb) { add_prop_p(mesh, x, y, z, sx, sy, sz, yaw, 0, rgb); }
static void add_obst(float x, float z, float r) { if (nobst < MAX_OBST) { obst[nobst].x = x; obst[nobst].z = z; obst[nobst].r = r; nobst++; } }

// reserved clear areas (plaza, arenas, npc spots)
typedef struct { float x, z, r; } Circ;
static Circ reserved[48]; static int nres;
void add_obst_pub(float x, float z, float r) { add_obst(x, z, r); }
static void reserve(float x, float z, float r) { if (nres < 48) { reserved[nres].x = x; reserved[nres].z = z; reserved[nres].r = r; nres++; } }
void world_reserve(float x, float z, float r) { reserve(x, z, r); }
static bool is_path(float x, float z) {
	float r = sqrtf(x*x+z*z);
	if (r < 4.5f) return true;
	if (r < 36 && (fabsf(x) < 1.6f || fabsf(z) < 1.6f)) return true;
	return false;
}
static bool spot_ok(float x, float z, float clear) {
	if (ground_h(x, z) < 0.12f) return false;
	if (is_path(x, z)) return false;
	for (int i = 0; i < nres; i++) if (dist2d(x, z, reserved[i].x, reserved[i].z) < reserved[i].r + clear) return false;
	for (int i = 0; i < nobst; i++) if (dist2d(x, z, obst[i].x, obst[i].z) < obst[i].r + clear) return false;
	return true;
}
bool world_spot_free(float x, float z, float clear) { return spot_ok(x, z, clear); }
bool find_spot(int zone, float* ox, float* oz, float clear) {
	for (int t = 0; t < 1500; t++) {
		int i = rndi(1, WORLD_N-2), j = rndi(1, WORLD_N-2);
		if (cellzone[j][i] != zone) continue;
		float x = -WORLD_HALF + (i + rndf()) * CELL, z = -WORLD_HALF + (j + rndf()) * CELL;
		if (!spot_ok(x, z, clear)) continue;
		*ox = x; *oz = z; return true;
	}
	return false;
}

bool world_blocked(float x, float z, float r, float* outx, float* outz) {
	if (dunOn) return dun_blocked(x, z, r, outx, outz);
	bool hit = false;
	for (int i = 0; i < nobst; i++) {
		float dx = x - obst[i].x, dz = z - obst[i].z, rr = obst[i].r + r;
		if (fabsf(dx) > rr || fabsf(dz) > rr) continue;
		float d2 = dx*dx + dz*dz;
		if (d2 < rr*rr) {
			float d = sqrtf(d2); if (d < 0.001f) { dx = 1; d = 1; }
			x = obst[i].x + dx / d * rr; z = obst[i].z + dz / d * rr;
			hit = true;
		}
	}
	float lim = WORLD_HALF - 2;
	if (x < -lim) x = -lim; if (x > lim) x = lim; if (z < -lim) z = -lim; if (z > lim) z = lim;
	*outx = x; *outz = z;
	return hit;
}

// ---------------------------------------------------------------- prop builders
static void tree_round(float x, float z, float s) {
	float y = ground_h(x, z);
	u32 leaf = (rndf() < 0.5f) ? 0x5DB24A : 0x6CC255;
	if (rndf() < 0.12f) leaf = 0xE8A23C; // autumn tree
	add_prop(MESH_CYL, x, y - 0.1f, z, 0.35f*s, 1.6f*s, 0.35f*s, 0, 0x7A5230);
	add_prop(MESH_SPHERE, x, y + 1.9f*s, z, 2.0f*s, 1.7f*s, 2.0f*s, rndf()*TAU, leaf);
	add_prop(MESH_SPHERE, x + 0.5f*s, y + 1.5f*s, z + 0.3f*s, 1.2f*s, 1.0f*s, 1.2f*s, 0, leaf - 0x081008);
	add_obst(x, z, 0.45f*s);
}
static void tree_pine(float x, float z, float s) {
	float y = ground_h(x, z);
	u32 c = rndf() < 0.5f ? 0x2E7D3E : 0x357F45;
	add_prop(MESH_CYL, x, y - 0.1f, z, 0.32f*s, 1.2f*s, 0.32f*s, 0, 0x5E3E24);
	add_prop(MESH_CONE5, x, y + 0.8f*s, z, 2.3f*s, 1.7f*s, 2.3f*s, rndf()*TAU, c);
	add_prop(MESH_CONE5, x, y + 1.7f*s, z, 1.8f*s, 1.5f*s, 1.8f*s, rndf()*TAU, c + 0x061006);
	add_prop(MESH_CONE5, x, y + 2.5f*s, z, 1.2f*s, 1.3f*s, 1.2f*s, rndf()*TAU, c + 0x0C200C);
	add_obst(x, z, 0.4f*s);
}
static void tree_palm(float x, float z, float s) {
	float y = ground_h(x, z);
	float yaw = rndf()*TAU, lean = 0.25f;
	float dx = sinf(yaw), dz = cosf(yaw);
	float px = x, py = y - 0.1f, pz = z;
	for (int i = 0; i < 4; i++) {
		add_prop_p(MESH_CYL, px, py, pz, 0.3f*s, 0.95f*s, 0.3f*s, yaw, lean*(i+1)*0.5f, i & 1 ? 0x9C7A4C : 0x8A6A40);
		float l = 0.9f*s;
		px += dx * sinf(lean*(i+1)*0.5f) * l; pz += dz * sinf(lean*(i+1)*0.5f) * l; py += cosf(lean*(i+1)*0.5f) * l;
	}
	for (int f = 0; f < 6; f++) {
		float fy = f * TAU / 6 + rndf()*0.3f;
		add_prop_p(MESH_PYR, px + sinf(fy)*0.9f*s, py - 0.15f, pz + cosf(fy)*0.9f*s, 0.6f*s, 0.25f*s, 2.2f*s, fy, 0.35f, 0x4FA83C);
	}
	add_prop(MESH_SPHERE, px, py - 0.2f, pz, 0.45f*s, 0.45f*s, 0.45f*s, 0, 0x6B4A2A);
	add_obst(x, z, 0.35f*s);
}
static void rock(float x, float z, float s, u32 col) {
	float y = ground_h(x, z);
	add_prop(MESH_OCTA, x, y + 0.2f*s, z, 1.6f*s, 1.1f*s, 1.3f*s, rndf()*TAU, col);
	if (rndf() < 0.5f) add_prop(MESH_OCTA, x + 0.6f*s, y + 0.1f*s, z + 0.3f*s, 0.8f*s, 0.6f*s, 0.8f*s, rndf()*TAU, col + 0x080808);
	add_obst(x, z, 0.7f*s);
}
static void pillar(float x, float z) {
	float y = ground_h(x, z);
	float h = rndr(1.2f, 4.0f);
	u32 c = rndf() < 0.5f ? 0xB8B2A2 : 0xA8A294;
	add_prop(MESH_CUBE, x, y + 0.15f, z, 1.4f, 0.3f, 1.4f, 0, c - 0x101010);
	add_prop(MESH_CYL, x, y + 0.3f, z, 0.9f, h, 0.9f, 0, c);
	if (h > 3.0f) add_prop(MESH_CUBE, x, y + 0.3f + h + 0.15f, z, 1.4f, 0.3f, 1.4f, 0, c);
	else add_prop(MESH_OCTA, x + 0.8f, y + 0.2f, z + 0.4f, 0.8f, 0.5f, 0.6f, rndf()*TAU, c);
	add_obst(x, z, 0.65f);
}
static void dead_tree(float x, float z) {
	float y = ground_h(x, z);
	add_prop(MESH_CYL, x, y - 0.1f, z, 0.4f, 2.6f, 0.4f, 0, 0x4A3B2C);
	for (int b = 0; b < 3; b++) {
		float a = rndf()*TAU;
		add_prop_p(MESH_CYL, x + sinf(a)*0.1f, y + 1.3f + b*0.5f, z + cosf(a)*0.1f, 0.15f, 1.2f, 0.15f, a, 0.9f, 0x4A3B2C);
	}
	add_prop(MESH_SPHERE, x, y + 2.6f, z, 1.4f, 0.6f, 1.4f, 0, 0x5D6B3A);
	add_obst(x, z, 0.45f);
}
static void house(float x, float z, float yaw, u32 wall, u32 roof) {
	float y = ground_h(x, z);
	add_prop(MESH_CUBE, x, y + 1.0f, z, 3.4f, 2.4f, 3.0f, yaw, wall);
	add_prop(MESH_PYR, x, y + 2.2f, z, 4.9f, 1.9f, 4.3f, yaw, roof);
	float fx = sinf(yaw), fz = cosf(yaw);
	add_prop(MESH_CUBE, x + fx*1.52f, y + 0.6f, z + fz*1.52f, 0.8f, 1.3f, 0.12f, yaw, 0x6B4425);
	float rx = cosf(yaw), rz = -sinf(yaw);
	add_prop(MESH_CUBE, x + fx*1.52f + rx*1.0f, y + 1.3f, z + fz*1.52f + rz*1.0f, 0.55f, 0.5f, 0.1f, yaw, 0xFFE38A);
	add_prop(MESH_CUBE, x + fx*1.52f - rx*1.0f, y + 1.3f, z + fz*1.52f - rz*1.0f, 0.55f, 0.5f, 0.1f, yaw, 0xFFE38A);
	add_prop(MESH_CUBE, x - rx*0.9f, y + 2.9f, z - rz*0.9f, 0.45f, 1.0f, 0.45f, yaw, 0x8C8C8C); // chimney
	add_obst(x, z, 1.9f);
	add_obst(x + rx*1.1f, z + rz*1.1f, 1.3f);
	add_obst(x - rx*1.1f, z - rz*1.1f, 1.3f);
}

static u32 mixc(u32 a, u32 b, float t) {
	int r = (int)lerpf((a>>16)&255, (b>>16)&255, t), g = (int)lerpf((a>>8)&255, (b>>8)&255, t), bb = (int)lerpf(a&255, b&255, t);
	return (r<<16)|(g<<8)|bb;
}

void world_gen(void) {
	for (int j = 0; j <= WORLD_N; j++) for (int i = 0; i <= WORLD_N; i++) {
		float x = -WORLD_HALF + i*CELL, z = -WORLD_HALF + j*CELL;
		heights[j][i] = gen_height(x, z);
	}
	for (int j = 0; j < WORLD_N; j++) for (int i = 0; i < WORLD_N; i++) {
		float x = -WORLD_HALF + (i+0.5f)*CELL, z = -WORLD_HALF + (j+0.5f)*CELL;
		int zn = zone_raw(x, z);
		cellzone[j][i] = zn;
		float h = (heights[j][i] + heights[j][i+1] + heights[j+1][i] + heights[j+1][i+1]) * 0.25f;
		float n = vnoise(x*0.3f, z*0.3f, 77);
		u32 c;
		switch (zn) {
		case Z_VILLAGE: c = mixc(0x8FD16A, 0x9FDA74, n); if (is_path(x, z)) c = sqrtf(x*x+z*z) < 4.5f ? 0xC4BBA8 : 0xCDA772; break;
		case Z_MEADOW: c = mixc(0x7CC75A, 0x95D460, n); if (n > 0.78f) c = 0xB6D96A; break;
		case Z_FOREST: c = mixc(0x3F8F46, 0x4E9A48, n); break;
		case Z_SWAMP: c = mixc(0x5F7436, 0x72803F, n); if (n < 0.25f) c = 0x4A5A2C; break;
		case Z_RUINS: c = mixc(0x9AAE7A, 0xA9B888, n); if (n > 0.66f) c = 0xA8A190; break;
		default: c = mixc(0x86C860, 0x7CC75A, n);
		}
		if (zn != Z_SWAMP && h < 0.45f) c = mixc(0xE6D59A, 0xEEDFA8, n);
		if (zn == Z_BEACH && h < 0.9f) c = mixc(0xE6D59A, 0xF0E2AE, n);
		if (h < 0.0f) c = zn == Z_SWAMP ? 0x3F4A28 : 0xC9B880;
		cellcolor[j][i] = c;
	}
	// element seals: every outer-zone cell that borders another zone
	nseal = 0;
	for (int j = 1; j < WORLD_N - 1; j++) for (int i = 1; i < WORLD_N - 1; i++) {
		int zn = cellzone[j][i]; if (zn < Z_BEACH) continue;
		if (cellzone[j][i-1] == zn && cellzone[j][i+1] == zn && cellzone[j-1][i] == zn && cellzone[j+1][i] == zn) continue;
		float x = -WORLD_HALF + (i+0.5f)*CELL, z = -WORLD_HALF + (j+0.5f)*CELL, y = ground_h(x, z);
		if (y < -0.5f || nseal >= MAX_SEAL) continue;
		SealPt* sp = &sealpts[nseal++]; sp->x = x; sp->z = z; sp->y = y; sp->zone = zn; sp->seed = (u8)(i * 37 + j * 91);
	}
	nprops = 0; nobst = 0; nres = 0;
	// reserved: plaza, arenas, npc homes
	reserve(0, 0, 5.5f);
	add_obst(0, 0, 0.9f); // the Great Lantern
	for (int i = 0; i < NPC_COUNT - 1; i++) { if (i == NPC_MARI) continue; /* v1.8 NPC: added after gen so the world is unchanged */ reserve(npcdefs[i].x, npcdefs[i].z, 2.2f); add_obst(npcdefs[i].x, npcdefs[i].z, 0.45f); }
	for (int z = 1; z < Z_COUNT; z++) reserve(arena_pos[z][0], arena_pos[z][1], 6);

	// village houses
	house(-8.5f, -8.0f, PI*0.25f, 0xF2E3C6, 0xC4473A);
	house(8.5f, -8.0f, -PI*0.25f, 0xE9D7F0, 0x4D6FC4);
	house(-8.5f, 8.0f, PI*0.75f, 0xF7E6B5, 0x8A5A3A);
	house(8.5f, 8.0f, -PI*0.75f, 0xD9EEF0, 0xC46A3A);
	// market stall (Bram) east of plaza
	{
		float x = 5.5f, z = 2.8f, y = ground_h(x, z);
		add_prop(MESH_CUBE, x, y + 0.5f, z, 2.6f, 1.0f, 1.0f, 0, 0x9C6B3E);
		add_prop(MESH_CYL, x - 1.2f, y, z - 0.4f, 0.15f, 2.4f, 0.15f, 0, 0x6B4425);
		add_prop(MESH_CYL, x + 1.2f, y, z - 0.4f, 0.15f, 2.4f, 0.15f, 0, 0x6B4425);
		add_prop_p(MESH_CUBE, x, y + 2.4f, z - 0.1f, 3.0f, 0.12f, 1.6f, 0, -0.25f, 0xE85A4F);
		add_prop(MESH_SPHERE, x - 0.7f, y + 1.15f, z, 0.35f, 0.35f, 0.35f, 0, 0xE04848);
		add_prop(MESH_SPHERE, x + 0.1f, y + 1.15f, z, 0.35f, 0.35f, 0.35f, 0, 0x7CD04A);
		add_prop(MESH_CYL, x + 0.8f, y + 1.0f, z, 0.25f, 0.4f, 0.25f, 0, 0xB070E0);
		add_obst(x, z, 1.4f);
	}
	// bounty board west of plaza
	{
		float x = -5.6f, z = 2.6f, y = ground_h(x, z);
		add_prop(MESH_CYL, x - 0.9f, y, z, 0.15f, 2.0f, 0.15f, 0, 0x6B4425);
		add_prop(MESH_CYL, x + 0.9f, y, z, 0.15f, 2.0f, 0.15f, 0, 0x6B4425);
		add_prop(MESH_CUBE, x, y + 1.5f, z, 2.2f, 1.1f, 0.15f, 0, 0x9C6B3E);
		add_prop(MESH_CUBE, x - 0.4f, y + 1.55f, z + 0.09f, 0.5f, 0.6f, 0.02f, 0.1f, 0xF4EAD0);
		add_prop(MESH_CUBE, x + 0.45f, y + 1.45f, z + 0.09f, 0.5f, 0.6f, 0.02f, -0.12f, 0xF4EAD0);
		add_prop(MESH_PYR, x, y + 2.05f, z, 2.6f, 0.4f, 0.6f, 0, 0x8A5A3A);
		add_obst(x, z, 1.1f);
	}
	// barrels & crates & flower boxes around the village
	for (int i = 0; i < 10; i++) {
		float a = rndf()*TAU, r = rndr(6, 10);
		float x = cosf(a)*r, z = sinf(a)*r;
		if (!spot_ok(x, z, 0.8f)) continue;
		float y = ground_h(x, z);
		if (i & 1) { add_prop(MESH_CYL, x, y, z, 0.7f, 0.9f, 0.7f, 0, 0x8B5E34); add_prop(MESH_CYL, x, y + 0.88f, z, 0.72f, 0.05f, 0.72f, 0, 0x555555); }
		else add_prop(MESH_CUBE, x, y + 0.35f, z, 0.75f, 0.7f, 0.75f, rndf(), 0xB08850);
		add_obst(x, z, 0.45f);
	}
	// fence ring around village edge (low posts)
	for (int i = 0; i < 48; i++) {
		float a = TAU * i / 48; float x = cosf(a) * 12.5f, z = sinf(a) * 12.5f;
		if (fabsf(x) < 2.2f || fabsf(z) < 2.2f) continue;
		float y = ground_h(x, z);
		add_prop(MESH_CUBE, x, y + 0.4f, z, 0.18f, 0.8f, 0.18f, a, 0xA07850);
		add_prop(MESH_CUBE, x, y + 0.55f, z, 0.1f, 0.1f, 1.7f, a, 0xB08860);
	}

	float x, z;
	// v1.21: about twice the scenery for an island with three times the land; each zone keeps its own look
	for (int i = 0; i < 80; i++) if (find_spot(Z_MEADOW, &x, &z, 1.8f)) tree_round(x, z, rndr(0.8f, 1.3f));
	for (int i = 0; i < 6; i++) if (find_spot(Z_VILLAGE, &x, &z, 2.0f)) tree_round(x, z, rndr(0.9f, 1.1f));
	for (int i = 0; i < 210; i++) if (find_spot(Z_FOREST, &x, &z, 1.2f)) { if (rndf() < 0.8f) tree_pine(x, z, rndr(0.8f, 1.4f)); else tree_round(x, z, rndr(0.9f, 1.3f)); }
	for (int i = 0; i < 60; i++) if (find_spot(Z_BEACH, &x, &z, 2.0f)) tree_palm(x, z, rndr(0.8f, 1.2f));
	for (int i = 0; i < 80; i++) if (find_spot(Z_RUINS, &x, &z, 1.6f)) pillar(x, z);
	for (int i = 0; i < 16; i++) if (find_spot(Z_RUINS, &x, &z, 1.6f)) tree_round(x, z, rndr(0.8f, 1.0f));
	for (int i = 0; i < 70; i++) if (find_spot(Z_SWAMP, &x, &z, 1.6f)) dead_tree(x, z);
	for (int i = 0; i < 24; i++) if (find_spot(Z_SWAMP, &x, &z, 1.6f)) tree_pine(x, z, rndr(0.7f, 1.0f));
	// ruin arches
	for (int i = 0; i < 10; i++) if (find_spot(Z_RUINS, &x, &z, 3.0f)) {
		float yaw = rndf()*TAU, rx = cosf(yaw)*1.6f, rz = -sinf(yaw)*1.6f, y = ground_h(x, z);
		add_prop(MESH_CUBE, x + rx, y + 1.6f, z + rz, 0.8f, 3.4f, 0.8f, yaw, 0xB0AA9A);
		add_prop(MESH_CUBE, x - rx, y + 1.6f, z - rz, 0.8f, 3.4f, 0.8f, yaw, 0xB0AA9A);
		add_prop(MESH_CUBE, x, y + 3.5f, z, 4.2f, 0.7f, 1.0f, yaw, 0xA49E8E);
		add_obst(x + rx, z + rz, 0.6f); add_obst(x - rx, z - rz, 0.6f);
	}
	int zr[] = {Z_MEADOW, Z_BEACH, Z_RUINS, Z_FOREST, Z_SWAMP};
	for (int k = 0; k < 5; k++) for (int i = 0; i < 20; i++) if (find_spot(zr[k], &x, &z, 1.2f)) rock(x, z, rndr(0.6f, 1.3f), zr[k] == Z_SWAMP ? 0x6A6E5A : (zr[k] == Z_BEACH ? 0xB4A890 : 0x9A9A96));
	// decor (no collision): grass tufts, flowers, reeds, lily pads, starfish
	for (int i = 0; i < 640; i++) {
		int zn = zr[rndi(0, 4)];
		if (!find_spot(zn, &x, &z, 0.3f)) continue;
		float y = ground_h(x, z);
		switch (zn) {
		case Z_MEADOW: if (rndf() < 0.5f) { u32 fc[] = {0xFF6B8A, 0xFFD54A, 0xFFFFFF, 0xB58CFF}; add_prop(MESH_CYL, x, y, z, 0.05f, 0.35f, 0.05f, 0, 0x4C9A34); add_prop(MESH_SPHERE, x, y + 0.38f, z, 0.22f, 0.12f, 0.22f, 0, fc[rndi(0,3)]); }
			else add_prop(MESH_CONE5, x, y - 0.05f, z, 0.35f, 0.5f, 0.35f, rndf(), 0x5FB548); break;
		case Z_FOREST: if (rndf() < 0.5f) add_prop(MESH_CONE5, x, y - 0.05f, z, 0.4f, 0.55f, 0.4f, rndf(), 0x2F7A3A);
			else { add_prop_p(MESH_CYL, x, y + 0.2f, z, 0.35f, 1.8f, 0.35f, rndf()*TAU, PI/2, 0x6B4A2E); } break;
		case Z_SWAMP: if (y < 0.2f) add_prop(MESH_DISC, x, 0.03f, z, 0.9f, 1, 0.9f, 0, 0x4E8E3A);
			else { for (int r = 0; r < 3; r++) add_prop(MESH_CONE5, x + rndr(-0.3f, 0.3f), y - 0.05f, z + rndr(-0.3f, 0.3f), 0.12f, rndr(0.8f, 1.4f), 0.12f, 0, 0x7A8A3A); } break;
		case Z_BEACH: if (rndf() < 0.4f) add_prop(MESH_PYR, x, y + 0.02f, z, 0.45f, 0.08f, 0.45f, rndf(), 0xF08A5A);
			else add_prop(MESH_CONE5, x, y - 0.05f, z, 0.3f, 0.45f, 0.3f, rndf(), 0x9BB860); break;
		case Z_RUINS: if (rndf() < 0.5f) add_prop(MESH_CUBE, x, y + 0.15f, z, rndr(0.4f, 0.9f), 0.3f, rndr(0.4f, 0.9f), rndf(), 0xA8A294);
			else add_prop(MESH_CONE5, x, y - 0.05f, z, 0.35f, 0.5f, 0.35f, rndf(), 0x7E9A5A); break;
		}
	}
}
