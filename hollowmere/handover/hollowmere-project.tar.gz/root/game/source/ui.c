#include "game.h"

void gfx_draw_water(float t);
static void render_gacha_top(int eye);
static void render_gacha_bottom(void);
static float popx(int eye, float k);
static void keycap(float x, float y, const char* k);

// ------------------------------------------------------------ part helper (local -> world)
static float Bx, By, Bz, Byaw, Bcy, Bsy;
static void base(float x, float y, float z, float yaw) { Bx = x; By = y; Bz = z; Byaw = yaw; Bcy = cosf(yaw); Bsy = sinf(yaw); }
static V3 lpos(float lx, float ly, float lz) { return v3(Bx + lx*Bcy + lz*Bsy, By + ly, Bz - lx*Bsy + lz*Bcy); }
static void part(int mesh, float lx, float ly, float lz, float sx, float sy, float sz, float pitch, u32 col, float emit) {
	V3 w = lpos(lx, ly, lz);
	obj_ex(mesh, w.x, w.y, w.z, sx, sy, sz, Byaw, pitch, col, 1, emit);
}
static void part_a(int mesh, float lx, float ly, float lz, float sx, float sy, float sz, float yawOff, float pitch, u32 col, float alpha, float emit) {
	V3 w = lpos(lx, ly, lz);
	obj_ex(mesh, w.x, w.y, w.z, sx, sy, sz, Byaw + yawOff, pitch, col, alpha, emit);
}
static float camdist(float x, float z) { return dist2d(x, z, rp.tx, rp.tz); }
static bool vis(float x, float z, float r, float maxd) { return camdist(x, z) < maxd && gfx_visible(x, z, r); }

// shadows are collected and drawn in the transparent pass
typedef struct { float x, y, z, r; } Shadow;
static Shadow shadows[96]; static int nshadow;
static void shadow(float x, float z, float r) { if (nshadow < 96) { float g = ground_h(x, z); if (g < -0.12f) g = -0.12f; shadows[nshadow].x = x; shadows[nshadow].y = g + 0.04f; shadows[nshadow].z = z; shadows[nshadow].r = r; nshadow++; } }

// ------------------------------------------------------------ characters
static void draw_cat(float x, float y, float z, float yaw, float s, u32 col, u32 col2) {
	base(x, y, z, yaw);
	float t = gtime;
	part(MESH_SPHERE, 0, 0.3f*s, 0, 0.55f*s, 0.42f*s, 0.75f*s, 0, col, 0);
	part(MESH_SPHERE, 0, 0.58f*s, 0.36f*s, 0.42f*s, 0.38f*s, 0.4f*s, 0, col, 0);
	part(MESH_PYR, 0.11f*s, 0.72f*s, 0.36f*s, 0.14f*s, 0.2f*s, 0.12f*s, 0, col2, 0);
	part(MESH_PYR, -0.11f*s, 0.72f*s, 0.36f*s, 0.14f*s, 0.2f*s, 0.12f*s, 0, col2, 0);
	part(MESH_CUBE, 0.08f*s, 0.6f*s, 0.55f*s, 0.05f*s, 0.06f*s, 0.02f*s, 0, 0x202020, 0);
	part(MESH_CUBE, -0.08f*s, 0.6f*s, 0.55f*s, 0.05f*s, 0.06f*s, 0.02f*s, 0, 0x202020, 0);
	part(MESH_SPHERE, 0, 0.53f*s, 0.56f*s, 0.06f*s, 0.05f*s, 0.04f*s, 0, 0xFF8FA8, 0);
	part(MESH_CYL, 0, 0.3f*s, -0.32f*s, 0.07f*s, 0.5f*s, 0.07f*s, -0.7f + sinf(t*3)*0.25f, col2, 0);
	shadow(x, z, 0.45f*s);
}

// hat: 0 none 1 wizard 2 chef 3 cap 4 rainhat 5 hood 6 witch 7 helmet 8 pigtails
static void draw_person(float x, float y, float z, float yaw, u32 body, u32 skin, u32 hair, u32 hatcol, int hat, float s, float walk, bool moving, bool beard, float hurt) {
	base(x, y, z, yaw);
	float sw = moving ? sinf(walk) : 0;
	float bob = moving ? fabsf(sinf(walk)) * 0.06f*s : sinf(gtime*2 + x) * 0.015f;
	By += bob;
	if (hurt > 0) gfx_set_flash(0.5f);
	// legs
	part(MESH_CYL, -0.13f*s, 0, sw*0.12f*s, 0.17f*s, 0.42f*s, 0.17f*s, 0, 0x3B3F55, 0);
	part(MESH_CYL, 0.13f*s, 0, -sw*0.12f*s, 0.17f*s, 0.42f*s, 0.17f*s, 0, 0x3B3F55, 0);
	// body
	part(MESH_CYL, 0, 0.36f*s, 0, 0.56f*s, 0.56f*s, 0.44f*s, 0, body, 0);
	// arms
	part(MESH_CUBE, -0.34f*s, 0.66f*s, -sw*0.1f*s, 0.13f*s, 0.42f*s, 0.13f*s, sw*0.6f, body, 0);
	part(MESH_CUBE, 0.34f*s, 0.66f*s, sw*0.1f*s, 0.13f*s, 0.42f*s, 0.13f*s, -sw*0.6f, body, 0);
	part(MESH_SPHERE, -0.34f*s, 0.43f*s, -sw*0.18f*s, 0.13f*s, 0.13f*s, 0.13f*s, 0, skin, 0);
	part(MESH_SPHERE, 0.34f*s, 0.43f*s, sw*0.18f*s, 0.13f*s, 0.13f*s, 0.13f*s, 0, skin, 0);
	// head
	part(MESH_SPHERE, 0, 1.17f*s, 0, 0.52f*s, 0.5f*s, 0.5f*s, 0, skin, 0);
	if (hat != 5 && hat != 7) part(MESH_HALFSPH, 0, 1.18f*s, -0.03f*s, 0.56f*s, 0.5f*s, 0.56f*s, 0, hair, 0);
	part(MESH_CUBE, -0.1f*s, 1.17f*s, 0.24f*s, 0.06f*s, 0.09f*s, 0.03f*s, 0, 0x1A1A1A, 0);
	part(MESH_CUBE, 0.1f*s, 1.17f*s, 0.24f*s, 0.06f*s, 0.09f*s, 0.03f*s, 0, 0x1A1A1A, 0);
	if (beard) part(MESH_SPHERE, 0, 0.98f*s, 0.17f*s, 0.34f*s, 0.3f*s, 0.2f*s, 0, hair, 0);
	switch (hat) {
	case 1: part(MESH_DISC, 0, 1.36f*s, 0, 0.8f*s, 1, 0.8f*s, 0, hatcol, 0); part(MESH_CONE, 0, 1.36f*s, 0, 0.55f*s, 0.8f*s, 0.55f*s, -0.15f, hatcol, 0); break;
	case 2: part(MESH_CYL, 0, 1.33f*s, 0, 0.44f*s, 0.25f*s, 0.44f*s, 0, 0xFFFFFF, 0); part(MESH_SPHERE, 0, 1.64f*s, 0, 0.58f*s, 0.36f*s, 0.58f*s, 0, 0xFFFFFF, 0); break;
	case 3: part(MESH_HALFSPH, 0, 1.22f*s, 0, 0.58f*s, 0.48f*s, 0.58f*s, 0, hatcol, 0); part(MESH_CUBE, 0, 1.3f*s, 0.27f*s, 0.42f*s, 0.04f*s, 0.26f*s, 0, hatcol, 0); break;
	case 4: part(MESH_CONE, 0, 1.3f*s, 0, 0.95f*s, 0.42f*s, 0.95f*s, 0, hatcol, 0); break;
	case 5: part(MESH_SPHERE, 0, 1.2f*s, -0.1f*s, 0.62f*s, 0.62f*s, 0.6f*s, 0, hatcol, 0); part(MESH_CONE, 0, 1.38f*s, -0.22f*s, 0.3f*s, 0.4f*s, 0.3f*s, -0.9f, hatcol, 0); break;
	case 6: part(MESH_DISC, 0, 1.38f*s, 0, 1.05f*s, 1, 1.05f*s, 0, hatcol, 0); part(MESH_CONE, 0, 1.38f*s, -0.03f*s, 0.55f*s, 0.95f*s, 0.55f*s, -0.25f, hatcol, 0); part(MESH_CYL, 0, 1.4f*s, 0, 0.57f*s, 0.07f*s, 0.57f*s, 0, 0x9C4AD8, 0); break;
	case 7: part(MESH_HALFSPH, 0, 1.12f*s, 0, 0.62f*s, 0.6f*s, 0.62f*s, 0, hatcol, 0); part(MESH_CUBE, 0, 1.17f*s, 0.27f*s, 0.4f*s, 0.06f*s, 0.04f*s, 0, 0x202028, 0);
		part(MESH_CONE5, 0, 1.38f*s, -0.05f*s, 0.12f*s, 0.5f*s, 0.4f*s, -0.4f, 0xD83838, 0); break;
	case 8: part(MESH_SPHERE, 0.32f*s, 1.12f*s, -0.06f*s, 0.24f*s, 0.3f*s, 0.24f*s, 0, hair, 0); part(MESH_SPHERE, -0.32f*s, 1.12f*s, -0.06f*s, 0.24f*s, 0.3f*s, 0.24f*s, 0, hair, 0); break;
	}
	gfx_set_flash(0);
	shadow(x, z, 0.5f*s);
}

static void draw_weapon(float swingA, float pitch, float len_scale, bool trail) {
	const Gear* w = &S.weapon;
	u32 rc = rarity_col[w->rarity];
	u32 blade = w->rarity == R_COMMON ? 0xC8CCD4 : rc;
	float em = w->rarity >= R_RARE ? 0.35f : 0;
	if (w->used && w->elem) { blade = elem_col[w->elem]; em = 0.55f + 0.15f * sinf(gtime * 6); } // an infused blade glows its element
	float hx = 0.36f, hy = 0.5f, hz = 0.12f;
	int b = w->base;
	float len = (b == 0 ? 0.75f : b == 1 ? 0.6f : b == 5 ? 1.45f : b == 7 ? 1.15f : b == 6 ? 0.65f : 0.95f) * len_scale;
	float cp = cosf(pitch), sp = sinf(pitch);
	float dx = sinf(swingA)*cp, dy = -sp, dz = cosf(swingA)*cp;
	int passes = trail ? 4 : 1;
	for (int k = passes - 1; k >= 0; k--) {
		float a = swingA + k * 0.32f, alpha = k == 0 ? 1.0f : 0.35f - k * 0.08f;
		if (k > 0) { dx = sinf(a)*cp; dz = cosf(a)*cp; } else { dx = sinf(swingA)*cp; dz = cosf(swingA)*cp; }
		float yawo = a;
		u32 bc = b == 0 ? 0x8A6A40 : (b == 3 || b == 4 || b == 5 || b == 7 || b == 6) ? 0x7A5230 : blade;
		if (k > 0) { part_a(MESH_CUBE, hx + dx*len*0.5f, hy + dy*len*0.5f, hz + dz*len*0.5f, 0.12f, 0.05f, len, yawo, pitch, 0xFFFFFF, alpha, 0.8f); continue; }
		part_a(MESH_CUBE, hx + dx*len*0.5f, hy + dy*len*0.5f, hz + dz*len*0.5f, b == 0 ? 0.07f : 0.09f, 0.06f, len, yawo, pitch, bc, 1, b == 2 || b == 1 ? em : 0);
		float ex = hx + dx*len, ey = hy + dy*len, ez = hz + dz*len;
		switch (b) {
		case 1: case 2: part_a(MESH_CUBE, hx + dx*0.12f, hy + dy*0.12f, hz + dz*0.12f, 0.32f, 0.07f, 0.07f, yawo, pitch, 0x8A6A40, 1, 0); break;
		case 3: part_a(MESH_CUBE, ex - dx*0.15f, ey - dy*0.15f, ez - dz*0.15f, 0.08f, 0.3f, 0.32f, yawo, pitch, blade, 1, em); break;
		case 4: part_a(MESH_CUBE, ex - dx*0.12f, ey - dy*0.12f, ez - dz*0.12f, 0.32f, 0.3f, 0.3f, yawo, pitch, blade, 1, em); break;
		case 5: part_a(MESH_OCTA, ex, ey, ez, 0.16f, 0.16f, 0.36f, yawo, pitch, blade, 1, em); break;
		case 6: part_a(MESH_SPHERE, ex, ey, ez, 0.22f, 0.22f, 0.22f, yawo, 0, rc, 1, 0.8f); break;
		case 7: part_a(MESH_CUBE, ex - 0.2f*cosf(a), ey, ez + 0.2f*sinf(a), 0.5f, 0.05f, 0.1f, yawo, 0, blade, 1, em); break;
		}
	}
}

static void draw_player(void) {
	if (P.deadT > 0) {
		base(P.p.x, P.p.y, P.p.z, P.yaw);
		part(MESH_CUBE, 0, 0.2f, 0, 0.6f, 0.3f, 1.2f, 0, 0x3C7DD9, 0);
		return;
	}
	bool blink = P.inv > 0 && P.rollT <= 0 && ((int)(gtime * 20) & 1);
	if (blink) return;
	float roll = P.rollT > 0 ? (1 - P.rollT / 0.32f) * TAU : 0;
	if (P.rollT > 0) {
		base(P.p.x, P.p.y, P.p.z, P.yaw);
		part(MESH_SPHERE, 0, 0.5f, 0, 0.8f, 0.8f, 0.8f, roll, 0x3C7DD9, 0);
		part(MESH_HALFSPH, 0, 0.5f, 0, 0.82f, 0.6f, 0.82f, roll, 0x5BAE4A, 0);
		shadow(P.p.x, P.p.z, 0.5f);
		return;
	}
	if (P.aHeld && P.chargeT > 0.2f) { float k = clampf(P.chargeT / 0.55f, 0, 1); obj_ex(MESH_RING, P.p.x, P.p.y + 0.06f, P.p.z, 0.5f + 0.7f * k, 1, 0.5f + 0.7f * k, gtime * 3, 0, k >= 1 ? 0xFFE14A : 0xFFFFFF, 0.4f + 0.4f * k, 1); } // heavy charge
	draw_person(P.p.x, P.p.y, P.p.z, P.yaw, S.armor.used ? armor_tint[S.armor.base % ARMOR_BASES] : 0x3C7DD9, 0xF7D3B5, 0x7A4A2A, 0x4FA83C, 3, 1.0f, P.walk, P.moving, false, P.hurtT);
	base(P.p.x, P.p.y + (P.moving ? fabsf(sinf(P.walk)) * 0.06f : 0), P.p.z, P.yaw);
	// cape
	float cs = P.moving ? 0.35f : 0.12f + sinf(gtime*2)*0.05f;
	part(MESH_CUBE, 0, 0.62f, -0.27f - cs*0.2f, 0.5f, 0.62f, 0.05f, -cs, 0xC8323C, 0);
	// weapon
	if (P.atkT > 0) {
		float dur = P.finisher ? 0.36f : 0.3f;
		float k = 1 - P.atkT / dur;
		float a = (P.combo == 2) ? lerpf(-1.5f, 1.5f, k) : lerpf(1.6f, -1.6f, k);
		if (P.finisher) a = lerpf(2.4f, -2.4f, k);
		draw_weapon(a, 0.05f, P.finisher ? 1.25f : 1.0f, false);
	} else draw_weapon(0.35f, 1.0f, 1.0f, false);
}
static void draw_player_trail(void) {
	if (P.atkT <= 0 || P.deadT > 0) return;
	float dur = P.finisher ? 0.36f : 0.3f;
	float k = 1 - P.atkT / dur;
	float a = (P.combo == 2) ? lerpf(-1.5f, 1.5f, k) : lerpf(1.6f, -1.6f, k);
	if (P.finisher) a = lerpf(2.4f, -2.4f, k);
	base(P.p.x, P.p.y, P.p.z, P.yaw);
	float dir = (P.combo == 2) ? -1 : 1;
	for (int i = 1; i <= 5; i++) {
		float aa = a + dir * i * 0.22f, len = (P.finisher ? 1.9f : 1.5f);
		u32 tc = S.weapon.used && S.weapon.elem ? elem_col[S.weapon.elem] : P.finisher ? 0xFFC060 : 0xFFFFFF;
		part_a(MESH_CUBE, 0.2f + sinf(aa)*len*0.55f, 0.55f, 0.1f + cosf(aa)*len*0.55f, P.heavy ? 0.12f : 0.06f, 0.04f, len*0.9f, aa, 0, tc, 0.42f - i*0.07f, 1.0f);
	}
}

// ------------------------------------------------------------ enemies
static void eyes(float y, float z, float sep, float sz, float s, u32 white) {
	part(MESH_SPHERE, -sep*s, y*s, z*s, sz*s, sz*s, sz*0.6f*s, 0, white, 0);
	part(MESH_SPHERE, sep*s, y*s, z*s, sz*s, sz*s, sz*0.6f*s, 0, white, 0);
	part(MESH_SPHERE, -sep*s, y*s, (z + sz*0.25f)*s, sz*0.5f*s, sz*0.55f*s, sz*0.35f*s, 0, 0x151515, 0);
	part(MESH_SPHERE, sep*s, y*s, (z + sz*0.25f)*s, sz*0.5f*s, sz*0.55f*s, sz*0.35f*s, 0, 0x151515, 0);
}
static void crown(float y, float s) {
	part(MESH_CYL, 0, y*s, 0, 0.45f*s, 0.12f*s, 0.45f*s, 0, 0xFFC93A, 0.4f);
	for (int i = 0; i < 5; i++) { float a = TAU * i / 5; part(MESH_CONE5, cosf(a)*0.19f*s, (y + 0.1f)*s, sinf(a)*0.19f*s, 0.12f*s, 0.2f*s, 0.12f*s, 0, 0xFFC93A, 0.4f); }
	part(MESH_OCTA, 0, (y + 0.22f)*s, 0.2f*s, 0.1f*s, 0.12f*s, 0.06f*s, 0, 0xFF3A6A, 0.6f);
}
static void draw_enemy(Enemy* e) {
	const EnemyDef* d = &endefs[e->type];
	float s = d->scale * en_size(e); // stronger than you = visibly bigger
	if (e->state == ES_DEAD) s *= 1 + e->deadT * 0.8f;
	float fl = e->flash > 0 ? 0.9f : 0;
	if (e->state == ES_WINDUP) fl = 0.25f + 0.25f * sinf(gtime * 40);
	if (e->slamT > 0) fl = 0.2f + 0.2f * sinf(gtime * 30);
	gfx_set_flash(fl);
	u32 c = d->col;
	int fam = d->fam;
	if (e->type == EN_GLOOPA) fam = FAM_SLIME; else if (e->type == EN_PINCER) fam = FAM_CRAB; else if (e->type == EN_BRAMBLE) fam = FAM_BOAR;
	else if (e->type == EN_CROAK) fam = FAM_TOAD; else if (e->type == EN_COLOSSUS) fam = FAM_GOLEM;
	float y = e->p.y;
	float wind = e->state == ES_WINDUP ? 1 : 0;
	switch (fam) {
	case FAM_SLIME: {
		float hp = sinf(e->hop * PI); float h = hp > 0 ? hp * 0.55f * (e->boss ? 0.5f : 1) : 0;
		float sq = hp > 0 ? 1.0f + hp*0.15f : 0.8f + 0.1f*sinf(gtime*6);
		if (wind) sq = 0.7f;
		if (e->slamT > 0) { h = (1.1f - e->slamT) * 1.6f; sq = 1.2f; }
		base(e->p.x, y + h, e->p.z, e->yaw);
		part(MESH_SPHERE, 0, 0.38f*s*sq, 0, 0.95f*s / sqrtf(sq), 0.78f*s*sq, 0.95f*s / sqrtf(sq), 0, c, 0.1f);
		part(MESH_SPHERE, 0.12f*s, 0.6f*s*sq, 0.2f*s, 0.2f*s, 0.12f*s, 0.12f*s, 0, 0xFFFFFF, 0.5f);
		eyes(0.45f*sq, 0.36f, 0.16f, 0.2f, s, 0xFFFFFF);
		if (e->boss) crown(0.82f*sq, s);
		shadow(e->p.x, e->p.z, 0.55f*s);
	} break;
	case FAM_CRAB: {
		base(e->p.x, y, e->p.z, e->yaw);
		float sn = sinf(gtime * 10 + e->p.x) * 0.06f;
		part(MESH_HALFSPH, 0, 0.18f*s, 0, 1.1f*s, 0.75f*s, 0.85f*s, 0, c, 0);
		float cl = wind ? 0.5f : 0.2f;
		part(MESH_SPHERE, -0.58f*s, 0.35f*s + sn, (0.42f+cl*0.3f)*s, 0.4f*s, 0.3f*s, 0.36f*s, 0, c + 0x101008, 0);
		part(MESH_SPHERE, 0.58f*s, 0.35f*s - sn, (0.42f+cl*0.3f)*s, 0.4f*s, 0.3f*s, 0.36f*s, 0, c + 0x101008, 0);
		part(MESH_CYL, -0.15f*s, 0.45f*s, 0.22f*s, 0.06f*s, 0.25f*s, 0.06f*s, 0, c, 0);
		part(MESH_CYL, 0.15f*s, 0.45f*s, 0.22f*s, 0.06f*s, 0.25f*s, 0.06f*s, 0, c, 0);
		part(MESH_SPHERE, -0.15f*s, 0.72f*s, 0.22f*s, 0.13f*s, 0.13f*s, 0.13f*s, 0, 0x111111, 0);
		part(MESH_SPHERE, 0.15f*s, 0.72f*s, 0.22f*s, 0.13f*s, 0.13f*s, 0.13f*s, 0, 0x111111, 0);
		for (int i = 0; i < 3; i++) { float zz = (-0.25f + i*0.25f)*s; part(MESH_CUBE, -0.55f*s, 0.12f*s + (i&1?sn:-sn), zz, 0.35f*s, 0.06f*s, 0.06f*s, 0, c - 0x101000, 0); part(MESH_CUBE, 0.55f*s, 0.12f*s + (i&1?-sn:sn), zz, 0.35f*s, 0.06f*s, 0.06f*s, 0, c - 0x101000, 0); }
		if (e->boss) crown(0.62f, s);
		shadow(e->p.x, e->p.z, 0.65f*s);
	} break;
	case FAM_THORN: {
		float sw = sinf(gtime*5 + e->p.z) * 0.1f;
		base(e->p.x, y + fabsf(sinf(gtime*8 + e->p.x))*0.1f, e->p.z, e->yaw);
		part(MESH_CONE5, 0, 0, 0, 0.8f*s, 1.15f*s, 0.8f*s, sw, c, 0);
		for (int i = 0; i < 4; i++) { float a = TAU*i/4 + 0.4f; part(MESH_PYR, cosf(a)*0.15f*s, 1.0f*s, sinf(a)*0.15f*s, 0.2f*s, 0.45f*s, 0.12f*s, 0, 0x8FD14A, 0); }
		part(MESH_SPHERE, -0.12f*s, 0.6f*s, 0.25f*s, 0.12f*s, 0.14f*s, 0.06f*s, 0, 0xFFEA4A, 0.9f);
		part(MESH_SPHERE, 0.12f*s, 0.6f*s, 0.25f*s, 0.12f*s, 0.14f*s, 0.06f*s, 0, 0xFFEA4A, 0.9f);
		part(MESH_CUBE, -0.38f*s, 0.45f*s, 0.1f*s, 0.35f*s, 0.06f*s, 0.06f*s, wind ? -0.8f : sw, 0x3E7A2A, 0);
		part(MESH_CUBE, 0.38f*s, 0.45f*s, 0.1f*s, 0.35f*s, 0.06f*s, 0.06f*s, wind ? -0.8f : -sw, 0x3E7A2A, 0);
		shadow(e->p.x, e->p.z, 0.45f*s);
	} break;
	case FAM_BOAR: {
		float run = sinf(gtime * 14 + e->p.x) * (e->state == ES_CHASE ? 0.12f : 0.03f);
		base(e->p.x, y, e->p.z, e->yaw);
		part(MESH_CUBE, 0, 0.62f*s + run*0.3f, -0.05f*s, 0.8f*s, 0.7f*s, 1.25f*s, 0, c, 0);
		part(MESH_CUBE, 0, 0.66f*s, 0.68f*s, 0.6f*s, 0.52f*s, 0.45f*s, wind ? 0.3f : 0, c + 0x080808, 0);
		part(MESH_CUBE, 0, 0.56f*s, 0.94f*s, 0.3f*s, 0.22f*s, 0.12f*s, 0, 0xD89A8A, 0);
		part(MESH_CONE5, -0.2f*s, 0.48f*s, 0.92f*s, 0.08f*s, 0.3f*s, 0.08f*s, 0.6f, 0xF4F0E0, 0);
		part(MESH_CONE5, 0.2f*s, 0.48f*s, 0.92f*s, 0.08f*s, 0.3f*s, 0.08f*s, 0.6f, 0xF4F0E0, 0);
		part(MESH_SPHERE, -0.17f*s, 0.8f*s, 0.9f*s, 0.1f*s, 0.1f*s, 0.06f*s, 0, 0xFF3A2A, 0.8f);
		part(MESH_SPHERE, 0.17f*s, 0.8f*s, 0.9f*s, 0.1f*s, 0.1f*s, 0.06f*s, 0, 0xFF3A2A, 0.8f);
		for (int i = 0; i < 4; i++) { float lx = (i & 1 ? 0.28f : -0.28f)*s, lz = (i < 2 ? 0.4f : -0.45f)*s; part(MESH_CUBE, lx, 0.15f*s, lz + ((i^(i>>1))&1 ? run : -run), 0.18f*s, 0.4f*s, 0.18f*s, 0, c - 0x181818, 0); }
		for (int i = 0; i < 5; i++) part(MESH_CONE5, 0, 0.95f*s, (-0.5f + i*0.22f)*s, 0.14f*s, 0.3f*s, 0.14f*s, -0.3f, 0x4E8A3A, 0);
		if (e->boss) {
			part(MESH_CYL, -0.25f*s, 0.85f*s, 0.6f*s, 0.08f*s, 0.8f*s, 0.08f*s, -0.5f, 0x6B4A2E, 0);
			part(MESH_CYL, 0.25f*s, 0.85f*s, 0.6f*s, 0.08f*s, 0.8f*s, 0.08f*s, -0.5f, 0x6B4A2E, 0);
			part(MESH_SPHERE, -0.4f*s, 1.5f*s, 0.35f*s, 0.25f*s, 0.25f*s, 0.25f*s, 0, 0x4E9A3A, 0);
			part(MESH_SPHERE, 0.4f*s, 1.5f*s, 0.35f*s, 0.25f*s, 0.25f*s, 0.25f*s, 0, 0x4E9A3A, 0);
			part(MESH_OCTA, 0, 1.25f*s, 0.6f*s, 0.15f*s, 0.25f*s, 0.15f*s, 0, 0xFFC94A, 0.9f);
		}
		shadow(e->p.x, e->p.z, 0.7f*s);
	} break;
	case FAM_TOAD: {
		float hp = sinf(e->hop * PI); float h = hp > 0 ? hp * 0.8f * (e->boss ? 0.4f : 1) : 0;
		if (e->slamT > 0) h = (1.1f - e->slamT) * 1.4f;
		base(e->p.x, y + h, e->p.z, e->yaw);
		float th = 1 + 0.15f * sinf(gtime * 4);
		part(MESH_SPHERE, 0, 0.38f*s, 0, 1.15f*s, 0.75f*s, 1.05f*s, 0, c, 0);
		part(MESH_SPHERE, 0, 0.3f*s, 0.25f*s, 0.75f*s*th, 0.5f*s*th, 0.6f*s, 0, 0xE6D98A, 0);
		eyes(0.78f, 0.22f, 0.26f, 0.32f, s, 0xF2E85A);
		part(MESH_CUBE, 0, 0.42f*s, 0.5f*s, 0.5f*s, 0.03f*s, 0.04f*s, 0, 0x2A3A1A, 0);
		if (e->boss) crown(0.98f, s);
		shadow(e->p.x, e->p.z, 0.6f*s);
	} break;
	case FAM_WISP: {
		float fy = 1.0f + sinf(gtime * 3 + e->p.x) * 0.3f;
		base(e->p.x, y + fy, e->p.z, e->yaw);
		part(MESH_SPHERE, 0, 0, 0, 0.35f*s, 0.35f*s, 0.35f*s, 0, 0xFFFFFF, 1.0f);
		part(MESH_OCTA, 0, 0, 0, 0.7f*s, 0.9f*s, 0.7f*s, 0, c, 0.6f);
		part(MESH_CUBE, -0.12f*s, 0.05f*s, 0.3f*s, 0.07f*s, 0.12f*s, 0.04f*s, 0, 0x101020, 0);
		part(MESH_CUBE, 0.12f*s, 0.05f*s, 0.3f*s, 0.07f*s, 0.12f*s, 0.04f*s, 0, 0x101020, 0);
		if (rndf() < 0.3f) spawn_part(v3(e->p.x + rndr(-0.2f, 0.2f), y + fy, e->p.z + rndr(-0.2f, 0.2f)), v3(0, 0.6f, 0), 0.7f, 0.09f, c, -0.5f, 1, MESH_OCTA);
		shadow(e->p.x, e->p.z, 0.35f*s);
	} break;
	case FAM_GOLEM: {
		float st = sinf(gtime * 5 + e->p.x) * (e->state == ES_CHASE ? 0.1f : 0.02f);
		float raise = e->slamT > 0 ? (1.1f - e->slamT) : (wind ? 0.6f : 0);
		base(e->p.x, y, e->p.z, e->yaw);
		part(MESH_CUBE, -0.25f*s, 0.3f*s, st*s, 0.32f*s, 0.6f*s, 0.36f*s, 0, c - 0x101010, 0);
		part(MESH_CUBE, 0.25f*s, 0.3f*s, -st*s, 0.32f*s, 0.6f*s, 0.36f*s, 0, c - 0x101010, 0);
		part(MESH_CUBE, 0, 0.95f*s, 0, 0.95f*s, 0.75f*s, 0.6f*s, 0, c, 0);
		part(MESH_CUBE, 0, 1.52f*s, 0.04f*s, 0.5f*s, 0.42f*s, 0.45f*s, 0, c + 0x080808, 0);
		part(MESH_CUBE, 0, 1.55f*s, 0.27f*s, 0.34f*s, 0.08f*s, 0.04f*s, 0, e->boss ? 0xFF7A3A : 0x5CE6FF, 1.0f);
		part(MESH_CUBE, -0.65f*s, (0.95f + raise*0.6f)*s, 0.1f*s, 0.32f*s, 0.8f*s, 0.32f*s, -raise*1.8f, c - 0x080808, 0);
		part(MESH_CUBE, 0.65f*s, (0.95f + raise*0.6f)*s, 0.1f*s, 0.32f*s, 0.8f*s, 0.32f*s, -raise*1.8f, c - 0x080808, 0);
		part(MESH_CUBE, 0, 1.0f*s, 0.31f*s, 0.25f*s, 0.25f*s, 0.02f*s, 0.785f, e->boss ? 0xFF7A3A : 0x5CE6FF, 0.8f);
		part(MESH_CONE5, 0.3f*s, 1.3f*s, 0, 0.2f*s, 0.3f*s, 0.2f*s, 0, 0x6E9A4A, 0);
		if (e->boss) crown(1.75f, s);
		shadow(e->p.x, e->p.z, 0.7f*s);
	} break;
	case FAM_MOTH: {
		float fy = 1.3f + sinf(gtime * 4 + e->p.x) * 0.35f;
		float flap = sinf(gtime * 26 + e->p.z) * 0.7f;
		base(e->p.x, y + fy, e->p.z, e->yaw);
		part(MESH_SPHERE, 0, 0, 0, 0.22f*s, 0.22f*s, 0.6f*s, 0, 0x9A8A70, 0.2f);
		part(MESH_SPHERE, 0, 0.05f*s, 0.3f*s, 0.2f*s, 0.2f*s, 0.2f*s, 0, 0xC8B890, 0.2f);
		part(MESH_SPHERE, -0.08f*s, 0.1f*s, 0.42f*s, 0.07f*s, 0.07f*s, 0.05f*s, 0, 0xFFE070, 1.0f);
		part(MESH_SPHERE, 0.08f*s, 0.1f*s, 0.42f*s, 0.07f*s, 0.07f*s, 0.05f*s, 0, 0xFFE070, 1.0f);
		// wings: flat boxes hinged at the body, flapping
		{ V3 w = lpos(-0.42f*s, 0.05f + flap*0.25f, 0); obj_ex(MESH_CUBE, w.x, w.y, w.z, 0.75f*s, 0.04f, 0.55f*s, Byaw, 0, c, 1, 0.35f);
		  w = lpos(0.42f*s, 0.05f + flap*0.25f, 0); obj_ex(MESH_CUBE, w.x, w.y, w.z, 0.75f*s, 0.04f, 0.55f*s, Byaw, 0, c, 1, 0.35f); }
		part(MESH_CYL, -0.07f*s, 0.15f*s, 0.42f*s, 0.02f, 0.3f*s, 0.02f, -0.6f, 0x6A5A40, 0);
		part(MESH_CYL, 0.07f*s, 0.15f*s, 0.42f*s, 0.02f, 0.3f*s, 0.02f, -0.6f, 0x6A5A40, 0);
		if (rndf() < 0.2f) spawn_part(v3(e->p.x + rndr(-0.3f, 0.3f), y + fy, e->p.z + rndr(-0.3f, 0.3f)), v3(0, -0.3f, 0), 0.9f, 0.05f, 0xFFF0B0, 0.2f, 1, MESH_OCTA);
		shadow(e->p.x, e->p.z, 0.3f*s);
	} break;
	case FAM_GAUNT: {
		float sway = sinf(gtime * 2 + e->p.x) * 0.08f;
		float reach = wind ? 0.9f : 0.2f;
		base(e->p.x, y + 0.15f + sinf(gtime * 2.5f + e->p.z) * 0.1f, e->p.z, e->yaw);
		part(MESH_CONE5, 0, 0, 0, 0.75f*s, 1.7f*s, 0.6f*s, sway, c, 0);
		part(MESH_SPHERE, 0, 1.75f*s, 0.05f*s, 0.42f*s, 0.5f*s, 0.42f*s, 0, c + 0x080810, 0);
		part(MESH_SPHERE, -0.1f*s, 1.8f*s, 0.24f*s, 0.07f*s, 0.05f*s, 0.04f*s, 0, 0xB0F0FF, 1.0f);
		part(MESH_SPHERE, 0.1f*s, 1.8f*s, 0.24f*s, 0.07f*s, 0.05f*s, 0.04f*s, 0, 0xB0F0FF, 1.0f);
		part(MESH_CUBE, -0.4f*s, 1.15f*s, 0.2f*s, 0.1f*s, 0.9f*s, 0.1f*s, -reach, c, 0);
		part(MESH_CUBE, 0.4f*s, 1.15f*s, 0.2f*s, 0.1f*s, 0.9f*s, 0.1f*s, -reach, c, 0);
		shadow(e->p.x, e->p.z, 0.5f*s);
	} break;
	}
	gfx_set_flash(0);
}

// ------------------------------------------------------------ world things
// element seals: a barrier made of the zone's own element along its border
static void draw_seal(const SealPt* sp) {
	float r1 = (sp->seed % 13) / 13.f, r2 = (sp->seed % 7) / 7.f, t = gtime;
	base(sp->x, sp->y, sp->z, sp->seed * 0.37f);
	switch (sp->zone) {
	case Z_BEACH: // ice wall: blue crystal shards
		part(MESH_CUBE, 0, 0.35f, 0, 1.3f, 0.7f + r2 * 0.3f, 1.1f, 0, 0xA8DDF5, 0.25f);
		part(MESH_CONE5, -0.35f, 0.5f, 0.1f, 0.5f, 1.6f + r1 * 1.0f, 0.5f, 0.12f, 0xCFF3FF, 0.45f);
		part(MESH_CONE5, 0.4f, 0.5f, -0.2f, 0.4f, 1.1f + r2 * 0.8f, 0.4f, -0.2f, 0x8FD8FF, 0.4f);
		break;
	case Z_FOREST: // thorn wall: purple brambles with venom buds
		part(MESH_CYL, 0, 0.1f, 0, 0.22f, 1.9f + r1 * 0.6f, 0.22f, 0.35f, 0x4A2E4E, 0);
		part(MESH_CYL, 0.3f, 0.1f, 0.2f, 0.18f, 1.6f + r2 * 0.6f, 0.18f, -0.45f, 0x5A3A5E, 0);
		for (int k = 0; k < 3; k++) part(MESH_CONE, -0.4f + k * 0.4f, 0.5f + k * 0.45f, 0.1f, 0.18f, 0.55f, 0.18f, 1.2f - k, 0x6B3A7A, 0);
		part(MESH_SPHERE, 0.1f, 1.3f + r1 * 0.5f, 0, 0.26f, 0.26f, 0.26f, 0, 0x8CE05A, 0.6f + 0.3f * sinf(t * 3 + sp->seed));
		break;
	case Z_SWAMP: { // storm reeds: tall reeds crackling with sparks
		for (int k = 0; k < 3; k++) part(MESH_CYL, -0.45f + k * 0.45f, 0, (k & 1) * 0.3f, 0.14f, 2.0f + ((sp->seed + k * 5) % 9) * 0.12f, 0.14f, (k - 1) * 0.12f, 0x5E6A3E, 0);
		float f = sinf(t * 17 + sp->seed * 1.3f);
		if (f > -0.2f) part(MESH_OCTA, (r1 - 0.5f) * 0.9f, 1.4f + r2 * 0.8f, 0, 0.3f, 0.42f, 0.3f, t * 6, 0xFFE14A, 1);
		part(MESH_SPHERE, 0, 2.2f + r1 * 0.3f, 0, 0.16f, 0.3f, 0.16f, 0, 0x8A7A4A, 0.1f);
		break; }
	case Z_RUINS: { // fire ward: dark stones with standing flames
		part(MESH_CUBE, 0, 0.3f, 0, 1.1f, 0.6f + r2 * 0.4f, 0.9f, 0, 0x4A3A36, 0);
		float fl = 1 + 0.15f * sinf(t * 9 + sp->seed);
		part(MESH_CONE5, 0, 0.6f + r2 * 0.4f, 0, 0.7f, (1.2f + r1 * 0.7f) * fl, 0.7f, 0, 0xFF7A2A, 1);
		part(MESH_CONE5, 0.05f, 0.65f + r2 * 0.4f, 0, 0.4f, (0.8f + r1 * 0.4f) * fl, 0.4f, 0, 0xFFD24A, 1);
		break; }
	}
}
// ---- dungeons (v1.28)
static u32 shade_rgb(u32 c, float f) { int r = (int)(((c >> 16) & 255) * f), g = (int)(((c >> 8) & 255) * f), b = (int)((c & 255) * f); if (r > 255) r = 255; if (g > 255) g = 255; if (b > 255) b = 255; return (r << 16) | (g << 8) | b; }
static float DUN_OX0(void) { return dun_x(0) - DTS * 0.5f; }
static float DUN_OZ0(void) { return dun_z(0) - DTS * 0.5f; }
static void draw_chest_at(float x, float y, float z, float yaw, bool golden, bool open, float openT) {
	base(x, y, z, yaw);
	u32 wood = golden ? 0xE8B730 : 0x8B5A2B, band = golden ? 0xFFF0A0 : 0x4A3A2A;
	float em = !open ? (golden ? 0.3f + 0.15f * sinf(gtime * 4) : 0.12f) : 0;
	part(MESH_CUBE, 0, 0.32f, 0, 1.0f, 0.62f, 0.7f, 0, wood, em);
	part(MESH_CUBE, 0.3f, 0.32f, 0, 0.08f, 0.64f, 0.72f, 0, band, em);
	part(MESH_CUBE, -0.3f, 0.32f, 0, 0.08f, 0.64f, 0.72f, 0, band, em);
	float th = open ? -clampf(openT, 0, 1) * 1.9f : 0, vy = 0.13f, vz = 0.36f;
	float ly = vy * cosf(th) - vz * sinf(th), lz = vy * sinf(th) + vz * cosf(th);
	part(MESH_CUBE, 0, 0.63f + ly, -0.36f + lz, 1.04f, 0.26f, 0.74f, th, wood, em);
	if (!open) part(MESH_CUBE, 0, 0.55f, 0.37f, 0.16f, 0.2f, 0.05f, 0, 0xFFD23F, 0.4f);
	else part(MESH_CUBE, 0, 0.6f, 0, 0.86f, 0.05f, 0.56f, 0, 0x2A1A0A, 0);
	shadow(x, z, 0.75f);
}
static void draw_gate(const DunGate* g, bool open) {
	float y = ground_h(g->x, g->z);
	if (g->kind == 1) {
		if (!open) return; // rifts don't exist until the story tears them open // rift: a slow purple tear standing in the air
		for (int k = 0; k < 3; k++) obj_ex(MESH_RING, g->x, y + 1.7f, g->z, 1.9f - k * 0.45f, 1, 1.9f - k * 0.45f, gtime * (1.2f + k * 0.7f), PI / 2, k == 1 ? 0xE0A0FF : 0x8040E0, 1, 1.0f);
		float p = 0.4f + 0.08f * sinf(gtime * 5);
		obj_ex(MESH_SPHERE, g->x, y + 1.7f, g->z, p, p, p, 0, 0, 0x1A0A2A, 1, 0);
		obj_ex(MESH_DISC, g->x, y + 0.03f, g->z, 2.6f, 1, 2.6f, 0, 0, 0x6A3AA0, 1, 0.4f);
		if (rndf() < 0.3f) { float a = rndf() * TAU; spawn_part(v3(g->x + cosf(a) * 1.8f, y + 1.7f + sinf(a) * 1.8f, g->z), v3(-cosf(a) * 1.6f, -sinf(a) * 1.6f, 0), 0.9f, 0.09f, 0xB070FF, 0, 1, MESH_OCTA); }
		return;
	}
	// depths: a stone arch over steps going down, facing town. A lamp burns on top once you've cleared it.
	float yaw = atan2f(-g->x, -g->z); u32 st = dun_pal[g->zone][1], tp = dun_pal[g->zone][2];
	base(g->x, y, g->z, yaw);
	part(MESH_CUBE, 1.3f, 1.2f, 0, 0.7f, 2.4f, 0.7f, 0, tp, 0);
	part(MESH_CUBE, -1.3f, 1.2f, 0, 0.7f, 2.4f, 0.7f, 0, tp, 0);
	part(MESH_CUBE, 0, 2.55f, 0, 3.4f, 0.5f, 0.8f, 0, st, 0);
	part(MESH_CUBE, 0, 0.02f, -0.2f, 1.9f, 0.06f, 2.2f, 0, 0x070506, 0);
	for (int k = 0; k < 3; k++) part(MESH_CUBE, 0, -0.05f - k * 0.18f, 0.65f - k * 0.5f, 1.8f, 0.2f, 0.5f, 0, shade_rgb(st, 0.9f - k * 0.25f), 0);
	bool lit = (S.depDone >> g->zone) & 1;
	part(MESH_CYL, 0, 2.8f, 0, 0.12f, 0.35f, 0.12f, 0, 0x3A3A3A, 0);
	part(MESH_OCTA, 0, 3.25f, 0, 0.32f, 0.4f, 0.32f, 0, lit ? 0xFFD23F : 0x50505A, lit ? 0.9f + 0.1f * sinf(gtime * 7) : 0);
	if (S.depFloor[g->zone] > 1 && !lit) part(MESH_OCTA, 0, 3.25f, 0, 0.18f, 0.22f, 0.18f, 0, 0xFF9A3A, 0.6f); // an ember: you've got partway
	if (!open) for (int k = 0; k < 3; k++) part(MESH_CUBE, 0, 0.5f + k * 0.65f, 0.2f, 2.2f, 0.22f, 0.08f, (k - 1) * 0.12f, 0x8A6A44, 0); // boarded up
	shadow(g->x, g->z, 1.6f);
}
static void draw_dungeon(void) {
	int ci = dun_ti(P.p.x), cj = dun_tj(P.p.z), R = 12;
	u32 tc = DG.kind ? 0xB070FF : 0xFFA040;
	for (int j = cj - R; j <= cj + R; j++) for (int i = ci - R; i <= ci + R; i++) {
		int t = dun_tile(i, j); float x = dun_x(i), z = dun_z(j);
		if (t == DT_ROCK) { // torches on some walls that face a floor
			if (hash2(i, j, 11) < 0.86f || !vis(x, z, 1.5f, 26)) continue;
			const int di[4] = {1, -1, 0, 0}, dj[4] = {0, 0, 1, -1};
			for (int k = 0; k < 4; k++) if (dun_tile(i + di[k], j + dj[k]) != DT_ROCK) {
				float tx = x + di[k] * (DTS * 0.5f + 0.12f), tz = z + dj[k] * (DTS * 0.5f + 0.12f), f = 1 + 0.18f * sinf(gtime * 11 + i * 3 + j);
				obj_ex(MESH_CYL, tx, 1.0f, tz, 0.08f, 0.4f, 0.08f, 0, 0, 0x3A2A1A, 1, 0);
				obj_ex(MESH_CONE5, tx, 1.4f, tz, 0.22f, 0.4f * f, 0.22f, gtime, 0, tc, 1, 1);
				obj_ex(MESH_CONE5, tx, 1.42f, tz, 0.12f, 0.24f * f, 0.12f, -gtime, 0, 0xFFF0B0, 1, 1);
				break;
			}
			continue;
		}
		if (t == DT_FLOOR || !vis(x, z, 1.5f, 30)) continue;
		if (t == DT_DOWN) {
			obj_ex(MESH_CUBE, x, 0.02f, z, 1.9f, 0.05f, 1.9f, 0, 0, 0x050404, 1, 0);
			for (int k = 0; k < 3; k++) obj_ex(MESH_CUBE, x, 0.06f, z - 0.6f + k * 0.45f, 1.7f, 0.04f, 0.18f, 0, 0, shade_rgb(dun_pal[DG.kind ? Z_COUNT : DG.zone][2], 0.9f - k * 0.3f), 1, 0); // steps fading into the dark
			obj_ex(MESH_RING, x, 0.05f, z, 2.3f + 0.1f * sinf(gtime * 3), 1, 2.3f + 0.1f * sinf(gtime * 3), gtime, 0, 0x9FE8FF, 0.8f, 1);
		} else if (t == DT_UP) {
			for (int k = 0; k < 3; k++) obj_ex(MESH_CUBE, x, 0.15f + k * 0.3f, z - 0.4f + k * 0.4f, 1.6f, 0.3f, 0.5f, 0, 0, shade_rgb(dun_pal[DG.kind ? Z_COUNT : DG.zone][2], 1.1f + k * 0.1f), 1, 0);
			obj_ex(MESH_RING, x, 0.05f, z, 2.2f, 1, 2.2f, 0, 0, 0xFFF0C0, 1, 0.8f); // daylight from above
		} else if (t == DT_PORTAL) {
			for (int k = 0; k < 3; k++) obj_ex(MESH_RING, x, 1.6f, z, 1.7f - k * 0.4f, 1, 1.7f - k * 0.4f, gtime * (1.5f + k), PI / 2, k == 1 ? 0xFFF0A0 : 0xFFC94A, 1, 1.0f);
			obj_ex(MESH_SPHERE, x, 1.6f, z, 0.45f, 0.45f, 0.45f, 0, 0, 0xFFFFFF, 1, 1);
		}
	}
	for (int k = 0; k < DG.nch; k++) { DChest* c = &DG.ch[k]; float x = dun_x(c->i), z = dun_z(c->j); if (vis(x, z, 1, 30)) draw_chest_at(x, 0, z, (c->i * 7 + c->j) * 0.9f, c->reward, c->open, c->openT); }
	// gates (bars) and puzzle pieces
	for (int k = 0; k < DG.ng; k++) if (DG.t[DG.gj[k]][DG.gi[k]] == DT_GATE) { float x = dun_x(DG.gi[k]), z = dun_z(DG.gj[k]); if (!vis(x, z, 1.5f, 30)) continue;
		bool vert = dun_tile(DG.gi[k] - 1, DG.gj[k]) == DT_ROCK || dun_tile(DG.gi[k] + 1, DG.gj[k]) == DT_ROCK || dun_tile(DG.gi[k] - 1, DG.gj[k]) == DT_GATE;
		u32 gc = DG.lock == 1 ? 0x6A4A2A : 0x5A5A66;
		for (int b = -1; b <= 1; b++) obj_ex(MESH_CYL, x + (vert ? b * 0.6f : 0), 0, z + (vert ? 0 : b * 0.6f), 0.12f, 1.8f, 0.12f, 0, 0, gc, 1, 0);
		obj_ex(MESH_CUBE, x, 1.6f, z, vert ? 2.0f : 0.25f, 0.2f, vert ? 0.25f : 2.0f, 0, 0, gc, 1, 0);
		if (DG.lock == 1) obj_ex(MESH_CUBE, x, 0.9f, z, vert ? 1.9f : 0.2f, 1.6f, vert ? 0.2f : 1.9f, 0, 0, 0x4A3220, 1, 0); }
	for (int k = 0; k < DG.nob; k++) { DObj* o = &DG.ob[k]; float x = dun_x(o->i), z = dun_z(o->j); if (!vis(x, z, 1.2f, 30)) continue;
		switch (o->type) {
		case OB_LORE: obj_ex(MESH_CUBE, x, 0.45f, z, 0.6f, 0.9f, 0.5f, 0.3f, 0, 0x5A4A3A, 1, 0); obj_ex(MESH_CUBE, x, 0.95f, z, 0.8f, 0.08f, 0.6f, 0.3f, 0.35f, 0xF2E6C8, 1, 0.3f);
			if (!(S.depLore[DG.zone] & (1 << DG.floor))) obj_ex(MESH_OCTA, x, 1.6f + 0.1f * sinf(gtime * 3), z, 0.2f, 0.28f, 0.2f, gtime, 0, 0xFFE9A0, 1, 1); break;
		case OB_NOTE: obj_ex(MESH_CYL, x, 0, z, 0.08f, 1.2f, 0.08f, 0, 0, 0x5A4030, 1, 0); obj_ex(MESH_CUBE, x, 1.2f, z, 0.5f, 0.6f, 0.05f, 0.2f, 0, 0xF2E6C8, 1, 0.4f);
			if (!((S.depNote >> DG.zone) & 1)) obj_ex(MESH_OCTA, x, 1.9f + 0.1f * sinf(gtime * 3), z, 0.2f, 0.28f, 0.2f, gtime, 0, 0xFFE9A0, 1, 1); break;
		case OB_LEVER: { obj_ex(MESH_CUBE, x, 0.25f, z, 0.6f, 0.5f, 0.6f, 0, 0, 0x4A4A55, 1, 0);
			float a = o->state ? 0.7f * clampf(o->anim, 0, 1) : -0.7f; obj_ex(MESH_CYL, x, 0.5f, z, 0.08f, 0.9f, 0.08f, 0, a, 0x8A6A44, 1, 0);
			obj_ex(MESH_SPHERE, x, 0.5f + cosf(a) * 0.9f, z + sinf(a) * 0.9f, 0.22f, 0.22f, 0.22f, 0, 0, o->state ? 0x7CF07C : 0xFF5A3A, 1, 0.6f); } break;
		case OB_PLATE: obj_ex(MESH_CUBE, x, 0.04f, z, 1.6f, 0.08f, 1.6f, 0, 0, o->state ? 0x7CF07C : 0x8A8070, 1, o->state ? 0.6f : 0.1f); break;
		case OB_BLOCK: obj_ex(MESH_CUBE, x, 0.8f, z, 1.85f, 1.6f, 1.85f, 0, 0, 0x8A8478, 1, 0); obj_ex(MESH_CUBE, x, 1.62f, z, 1.5f, 0.06f, 1.5f, 0, 0, 0xA8A090, 1, 0); shadow(x, z, 1.0f); break;
		} }
	static const u32 pc[4] = { 0xFF5A3A, 0x6AFFB0, 0x6AB8FF, 0xFFE14A };
	for (int k = 0; k < DG.npyl; k++) { float x = dun_x(DG.pyl[k].i), z = dun_z(DG.pyl[k].j); if (!vis(x, z, 1, 30)) continue;
		u32 c = DG.pyl[k].used ? 0x4A4A55 : pc[DG.pyl[k].type]; float b = DG.pyl[k].used ? 0 : 0.6f + 0.3f * sinf(gtime * 4 + k);
		obj_ex(MESH_CUBE, x, 0.3f, z, 0.9f, 0.6f, 0.9f, 0.3f, 0, 0x3A3448, 1, 0);
		obj_ex(MESH_OCTA, x, 1.5f + (DG.pyl[k].used ? 0 : 0.15f * sinf(gtime * 2 + k)), z, 0.5f, 0.9f, 0.5f, gtime, 0, c, 1, b);
		if (!DG.pyl[k].used) obj_ex(MESH_RING, x, 0.05f, z, 2.4f, 1, 2.4f, -gtime, 0, c, 1, 0.8f); }
	for (int k = 0; k < 8; k++) if (DG.blastT[k] > 0) { float t = 1 - DG.blastT[k] / 0.9f;
		obj_ex(MESH_DISC, DG.blastX[k], 0.06f, DG.blastZ[k], 4.8f * t, 1, 4.8f * t, 0, 0, 0xFF3030, 0.35f, 1);
		obj_ex(MESH_RING, DG.blastX[k], 0.07f, DG.blastZ[k], 4.8f, 1, 4.8f, 0, 0, 0xFF3030, 0.8f, 1); }
}
static void draw_dun_map(float mx, float my, float ms, bool small) {
	// fog of war: only what you've seen. Each row is drawn as runs to keep the 2D vertex count low.
	int i0 = 0, j0 = 0, n = DG.w > DG.h ? DG.w : DG.h;
	if (small) { n = 15; i0 = dun_ti(P.p.x) - 7; j0 = dun_tj(P.p.z) - 7; }
	float ts = ms / n;
	rect(mx - 2, my - 2, ms + 4, ms + 4, RGBA(8, 6, 12, small ? 170 : 255));
	u32 fc = DG.kind ? RGBA(120, 90, 170, 255) : RGBA(150, 130, 105, 255);
	for (int j = 0; j < n; j++) {
		int run = -1;
		for (int i = 0; i <= n; i++) {
			int ti = i0 + i, tj = j0 + j;
			bool on = i < n && ti >= 0 && tj >= 0 && ti < DG.w && tj < DG.h && DG.seen[tj][ti] && DG.t[tj][ti] != DT_ROCK;
			if (on && run < 0) run = i;
			if (!on && run >= 0) { rect(mx + run * ts, my + j * ts, (i - run) * ts, ts, fc); run = -1; }
		}
	}
	#define DMX(ti) (mx + ((ti) - i0 + 0.5f) * ts)
	#define DMZ(tj) (my + ((tj) - j0 + 0.5f) * ts)
	#define DIN(ti, tj) ((ti) >= i0 && (tj) >= j0 && (ti) < i0 + n && (tj) < j0 + n && DG.seen[tj][ti])
	float r = small ? 2.5f : 3;
	if (DIN(DG.si, DG.sj)) circle(DMX(DG.si), DMZ(DG.sj), r, RGBA(255, 240, 190, 255));
	if (DIN(DG.xi, DG.xj)) { int t = DG.t[DG.xj][DG.xi]; circle(DMX(DG.xi), DMZ(DG.xj), r + 0.5f, t == DT_DOWN ? RGBA(120, 230, 255, 255) : t == DT_PORTAL ? RGBA(255, 210, 60, 255) : RGBA(255, 80, 70, 255)); }
	for (int k = 0; k < DG.nch; k++) if (!DG.ch[k].open && DIN(DG.ch[k].i, DG.ch[k].j)) rect(DMX(DG.ch[k].i) - 2, DMZ(DG.ch[k].j) - 2, 4, 4, RGBA(255, 200, 60, 255));
	{ float px = mx + ((P.p.x - DUN_OX0()) / DTS - i0) * ts, pz = my + ((P.p.z - DUN_OZ0()) / DTS - j0) * ts;
	  float fx = sinf(P.yaw), fz = cosf(P.yaw);
	  tri2d(px + fx * 5, pz + fz * 5, px - fx * 3 + fz * 3, pz - fz * 3 - fx * 3, px - fx * 3 - fz * 3, pz - fz * 3 + fx * 3, RGBA(255, 230, 80, 255)); }
	#undef DMX
	#undef DMZ
	#undef DIN
}
static void draw_node(Node* n) {
	float k = 1;
	if (!n->alive) { if (n->pop > 0) k = n->pop / 0.25f; else return; }
	else if (n->pop < 0) k = 1 + n->pop / 0.3f;
	if (k <= 0.01f) return;
	float x = n->x, y = n->y, z = n->z, w = sinf(n->wob * 1.7f) * 0.06f;
	base(x, y, z, n->x * 3.1f);
	switch (n->type) {
	case ND_BERRY:
		part(MESH_SPHERE, 0, 0.42f*k, 0, 1.15f*k, 0.9f*k, 1.15f*k, w, 0x3E9A3A, 0);
		for (int i = 0; i < 6; i++) { float a = i * 1.1f, r = 0.48f; part(MESH_SPHERE, cosf(a)*r*k, (0.42f + sinf(i*2.3f)*0.25f)*k, sinf(a)*r*k, 0.2f*k, 0.2f*k, 0.2f*k, 0, 0xD9365A, 0.25f); }
		shadow(x, z, 0.6f); break;
	case ND_SUNPETAL:
		part(MESH_CYL, 0, 0, 0, 0.07f*k, 0.75f*k, 0.07f*k, w, 0x4C9A34, 0);
		part(MESH_SPHERE, 0, 0.8f*k, 0.05f, 0.7f*k, 0.14f*k, 0.7f*k, -0.5f, 0xFFD23F, 0.25f);
		part(MESH_SPHERE, 0, 0.84f*k, 0.09f, 0.26f*k, 0.12f*k, 0.26f*k, -0.5f, 0xE8833A, 0.2f);
		part(MESH_PYR, 0.15f, 0.3f*k, 0, 0.25f*k, 0.08f*k, 0.4f*k, 0.4f, 0x4C9A34, 0); break;
	case ND_SHELL:
		part(MESH_HALFSPH, 0, 0, 0, 0.55f*k, 0.4f*k, 0.65f*k, 0, 0xF7B6A3, 0.15f);
		part(MESH_CONE5, 0, 0, -0.3f*k, 0.2f*k, 0.2f*k, 0.2f*k, 0, 0xF7C6B3, 0); break;
	case ND_DRIFT:
		part(MESH_CYL, -0.6f*k, 0.15f, 0, 0.26f*k, 1.3f*k, 0.26f*k, 0, 0xA9865B, 0);
		obj_ex(MESH_CYL, x, y + 0.15f, z, 0.26f*k, 1.3f*k, 0.26f*k, Byaw + PI/2, PI/2, 0xA9865B, 1, 0); break;
	case ND_SILVER:
		for (int i = 0; i < 4; i++) { float a = i * 1.6f; part(MESH_CONE5, cosf(a)*0.15f, 0, sinf(a)*0.15f, 0.14f*k, (0.7f + i*0.08f)*k, 0.14f*k, w*(i&1?1:-1), 0xBFE3D6, 0.3f); } break;
	case ND_GLOWCAP:
		part(MESH_CYL, 0, 0, 0, 0.16f*k, 0.42f*k, 0.16f*k, 0, 0xF0EEE0, 0);
		part(MESH_HALFSPH, 0, 0.38f*k, 0, 0.6f*k, 0.5f*k, 0.6f*k, w, 0xC86BFF, night_now() ? 1.0f : 0.5f);
		part(MESH_CYL, 0.35f, 0, 0.2f, 0.1f*k, 0.25f*k, 0.1f*k, 0, 0xF0EEE0, 0);
		part(MESH_HALFSPH, 0.35f, 0.22f*k, 0.2f, 0.35f*k, 0.3f*k, 0.35f*k, 0, 0xC86BFF, night_now() ? 1.0f : 0.5f); break;
	case ND_LILY: {
		float wy = y < 0 ? 0.0f : y; base(x, wy, z, Byaw);
		part(MESH_DISC, 0, 0.04f, 0, 1.0f*k, 1, 1.0f*k, 0, 0x4E9A3A, 0);
		for (int i = 0; i < 5; i++) { float a = TAU*i/5; part_a(MESH_PYR, cosf(a)*0.14f*k, 0.06f, sinf(a)*0.14f*k, 0.18f*k, 0.35f*k, 0.12f*k, -a + PI/2, 0.5f, 0xF6F6F6, 1, 0.2f); }
		part(MESH_SPHERE, 0, 0.12f*k, 0, 0.16f*k, 0.12f*k, 0.16f*k, 0, 0xFFD23F, 0.3f); } break;
	case ND_CRYSTAL:
		part(MESH_OCTA, 0, 0.55f*k, 0, 0.42f*k, 1.15f*k, 0.42f*k, 0, 0xB98CFF, 0.55f + sinf(gtime*3 + x)*0.15f);
		part(MESH_OCTA, 0.3f, 0.3f*k, 0.15f, 0.25f*k, 0.6f*k, 0.25f*k, 0.5f, 0xC9A8FF, 0.5f);
		part(MESH_OCTA, -0.25f, 0.25f*k, -0.1f, 0.22f*k, 0.5f*k, 0.22f*k, -0.4f, 0xA070F0, 0.5f); break;
	case ND_DIG:
		part(MESH_HALFSPH, 0, -0.05f, 0, 1.0f*k, 0.35f*k, 1.0f*k, 0, 0x7A5A3A, 0);
		part(MESH_CUBE, 0, 0.12f, 0, 0.6f*k, 0.04f, 0.12f*k, 0, 0xFFE9A0, 0.4f);
		obj_ex(MESH_CUBE, x, y + 0.12f, z, 0.6f*k, 0.04f, 0.12f*k, Byaw + PI/2, 0, 0xFFE9A0, 1, 0.4f); break;
	case ND_MOONBLOOM:
		part(MESH_CYL, 0, 0, 0, 0.06f*k, 0.6f*k, 0.06f*k, w, 0x3E7A5A, 0);
		part(MESH_PYR, 0.12f, 0.2f*k, 0, 0.22f*k, 0.06f*k, 0.36f*k, 0.5f, 0x3E7A5A, 0);
		if (night_now()) {
			float pulse = 0.85f + 0.15f * sinf(gtime * 2.5f + x);
			for (int i = 0; i < 6; i++) { float a = TAU*i/6; part_a(MESH_PYR, cosf(a)*0.16f*k, 0.62f*k, sinf(a)*0.16f*k, 0.2f*k, 0.42f*k, 0.12f*k, -a + PI/2, 0.9f, 0xCFE2FF, 1, 0.9f * pulse); }
			part(MESH_SPHERE, 0, 0.66f*k, 0, 0.14f*k, 0.12f*k, 0.14f*k, 0, 0xFFF6C0, 1.0f);
			if (rndf() < 0.04f) spawn_part(v3(x + rndr(-0.2f, 0.2f), y + 0.8f, z + rndr(-0.2f, 0.2f)), v3(0, 0.6f, 0), 1.4f, 0.05f, 0xCFE2FF, -0.2f, 1, MESH_OCTA);
		} else part(MESH_SPHERE, 0, 0.64f*k, 0, 0.14f*k, 0.24f*k, 0.14f*k, 0, 0x5A7A9A, 0); // closed bud by day
		break;
	case ND_KITTEN: {
		static const u32 kc[3][2] = { {0xF4F4F4, 0xE8C8C8}, {0x9A9AA0, 0x7A7A80}, {0x2A2A2E, 0xF4F4F4} };
		if (QS(Q_T0) != QS_ACTIVE || (S.kittens & (1 << n->kid))) return;
		draw_cat(x, y, z, gtime * 0.5f + n->kid, 0.65f, kc[n->kid][0], kc[n->kid][1]); } break;
	}
}
static void draw_chest(int i) {
	Chest* c = &chests[i];
	bool open = (S.chestsOpened & (1u << i)) != 0;
	base(c->x, c->y, c->z, c->yaw);
	u32 wood = c->golden ? 0xE8B730 : 0x8B5A2B, band = c->golden ? 0xFFF0A0 : 0x4A3A2A;
	float em = c->golden && !open ? 0.25f + 0.15f * sinf(gtime * 4) : 0;
	part(MESH_CUBE, 0, 0.32f, 0, 1.0f, 0.62f, 0.7f, 0, wood, em);
	part(MESH_CUBE, 0.3f, 0.32f, 0, 0.08f, 0.64f, 0.72f, 0, band, em);
	part(MESH_CUBE, -0.3f, 0.32f, 0, 0.08f, 0.64f, 0.72f, 0, band, em);
	float th = open ? -clampf(c->openT, 0, 1) * 1.9f : 0;
	float vy = 0.13f, vz = 0.36f;
	float ly = vy * cosf(th) - vz * sinf(th), lz = vy * sinf(th) + vz * cosf(th);
	part(MESH_CUBE, 0, 0.63f + ly, -0.36f + lz, 1.04f, 0.26f, 0.74f, th, wood, em);
	if (!open) part(MESH_CUBE, 0, 0.55f, 0.37f, 0.16f, 0.2f, 0.05f, 0, 0xFFD23F, 0.4f);
	else part(MESH_CUBE, 0, 0.6f, 0, 0.86f, 0.05f, 0.56f, 0, 0x2A1A0A, 0);
	if (!open && c->golden && rndf() < 0.15f) spawn_part(v3(c->x + rndr(-0.5f, 0.5f), c->y + 0.8f, c->z + rndr(-0.4f, 0.4f)), v3(0, 1.2f, 0), 0.7f, 0.07f, 0xFFF2A0, -0.5f, 1, MESH_OCTA);
	shadow(c->x, c->z, 0.75f);
}
static void draw_lantern(void) {
	float y = ground_h(0, 0);
	obj(MESH_CYL, 0, y - 0.1f, 0, 2.4f, 0.4f, 2.4f, 0, 0xA8A294);
	obj(MESH_CYL, 0, y + 0.25f, 0, 1.6f, 0.3f, 1.6f, 0, 0xB8B2A2);
	obj(MESH_CYL, 0, y + 0.5f, 0, 0.3f, 2.6f, 0.3f, 0, 0x3A3A48);
	obj(MESH_CUBE, 0, y + 3.05f, 0, 1.1f, 0.12f, 1.1f, 0, 0x3A3A48);
	for (int i = 0; i < 4; i++) { float a = PI/4 + i * PI/2; obj(MESH_CUBE, cosf(a)*0.5f, y + 3.55f, sinf(a)*0.5f, 0.08f, 1.0f, 0.08f, 0, 0x3A3A48); }
	obj(MESH_PYR, 0, y + 4.05f, 0, 1.4f, 0.6f, 1.4f, 0, 0x3A3A48);
	obj(MESH_SPHERE, 0, y + 4.75f, 0, 0.2f, 0.2f, 0.2f, 0, 0x3A3A48);
	float glow = S.lantern ? 0.9f + 0.1f * sinf(gtime * 3) : 0.05f + 0.07f * IC(IT_SHARD);
	u32 oc = S.lantern ? 0xFFD86A : 0x8A92B0;
	obj_ex(MESH_SPHERE, 0, y + 3.55f, 0, 0.62f, 0.62f, 0.62f, gtime * 0.5f, 0, oc, 1, glow);
	if (S.lantern && rndf() < 0.3f) spawn_part(v3(rndr(-0.3f, 0.3f), y + 3.6f, rndr(-0.3f, 0.3f)), v3(rndr(-0.6f, 0.6f), rndr(0.8f, 1.8f), rndr(-0.6f, 0.6f)), 1.6f, 0.07f, 0xFFE38A, -0.2f, 1, MESH_OCTA);
}
static void draw_marker(float x, float y, float z, int m) {
	if (!m) return;
	float b = sinf(gtime * 3) * 0.12f;
	if (m == 1) obj_ex(MESH_OCTA, x, y + b, z, 0.32f, 0.55f, 0.32f, gtime * 2, 0, 0xFFC93A, 1, 0.75f);
	else if (m == 2) { float p = 1 + 0.12f * sinf(gtime * 8); obj_ex(MESH_OCTA, x, y + b, z, 0.42f*p, 0.65f*p, 0.42f*p, gtime * 3, 0, 0x6BFF7A, 1, 0.8f); }
	else if (m == 4) obj_ex(MESH_OCTA, x, y + b + 0.1f, z, 0.4f, 0.7f, 0.4f, gtime * 2, 0, 0xB070FF, 1, 0.9f);
	else if (m == 5) { float p = 1 + 0.15f * sinf(gtime * 8); obj_ex(MESH_OCTA, x, y + b + 0.1f, z, 0.46f*p, 0.72f*p, 0.46f*p, gtime * 3, 0, 0xD9A8FF, 1, 1.0f); }
	else if (m == 6) obj_ex(MESH_OCTA, x, y + b, z, 0.24f, 0.36f, 0.24f, gtime, 0, 0x8A60C0, 1, 0.5f);
	else obj_ex(MESH_OCTA, x, y + b, z, 0.2f, 0.32f, 0.2f, gtime, 0, 0xB0B0B8, 1, 0.3f);
}
static void draw_drop(Drop* d) {
	if (d->kind != 3 && d->t > 280 && ((int)(gtime * 8) & 1)) return; // about to vanish
	float bob = d->settled ? sinf(gtime * 3 + d->p.x) * 0.1f : 0;
	if (d->kind == 0) obj_ex(MESH_CYL, d->p.x, d->p.y + bob, d->p.z, 0.34f, 0.07f, 0.34f, gtime * 5 + d->p.z, PI/2, 0xFFC93A, 1, 0.35f);
	else if (d->kind == 3) {
		float p = 1 + 0.15f * sinf(gtime * 8 + d->p.x);
		obj_ex(MESH_SPHERE, d->p.x, d->p.y + bob + 0.15f, d->p.z, 0.38f * p, 0.38f * p, 0.38f * p, 0, 0, 0x3FA0FF, 1, 0.55f);
		obj_ex(MESH_OCTA, d->p.x, d->p.y + bob + 0.15f, d->p.z, 0.17f, 0.5f * p, 0.17f, gtime * 3, 0, 0x7CC4FF, 1, 0.7f);
		if (rndf() < 0.12f) spawn_part(v3(d->p.x + rndr(-0.3f, 0.3f), d->p.y + 0.3f, d->p.z + rndr(-0.3f, 0.3f)), v3(0, 1.4f, 0), 0.7f, 0.07f, 0x3FA0FF, -0.5f, 0.7f, MESH_OCTA);
	}
	else if (d->kind == 1) obj_ex(MESH_OCTA, d->p.x, d->p.y + bob, d->p.z, 0.3f, 0.36f, 0.3f, gtime * 3, 0, itemd(d->item)->col, 1, 0.35f);
	else {
		u32 c = rarity_col[d->g.rarity];
		if (d->g.kind == 0) obj_ex(MESH_CUBE, d->p.x, d->p.y + 0.25f + bob, d->p.z, 0.1f, 0.75f, 0.1f, gtime * 2, 0.4f, c, 1, 0.5f);
		else obj_ex(MESH_OCTA, d->p.x, d->p.y + 0.2f + bob, d->p.z, 0.32f, 0.45f, 0.32f, gtime * 2, 0, c, 1, 0.6f);
	}
	shadow(d->p.x, d->p.z, 0.25f);
}

void render_world(int eye) {
	nshadow = 0;
	gfx_draw_world_static();
	if (!dunOn) draw_lantern();
	for (int i = 0; i < NPC_COUNT; i++) {
		const NpcDef* n = &npcdefs[i];
		if (!vis(n->x, n->z, 1.5f, 34)) continue;
		float y = ground_h(n->x, n->z);
		if (i != NPC_BOARD) {
			float look = n->yaw;
			if (dist2d(P.p.x, P.p.z, n->x, n->z) < 5) look = atan2f(P.p.x - n->x, P.p.z - n->z);
			draw_person(n->x, y, n->z, look, n->body, n->skin, n->hair, n->hatcol, n->hat, n->scale, 0, false, i == NPC_ELDER || i == NPC_GUS, 0);
			if (i == NPC_MARI) { base(n->x, y, n->z, look); part(MESH_CUBE, 0.0f, 0.62f, 0.32f, 0.42f, 0.5f, 0.1f, 0.25f, 0x7A4A2A, 0); part(MESH_CUBE, 0.0f, 0.62f, 0.36f, 0.36f, 0.44f, 0.04f, 0.25f, 0xF2E6C8, 0); }
			if (i == NPC_ELDER) { base(n->x, y, n->z, look); part(MESH_CYL, 0.45f, 0, 0.2f, 0.08f, 1.9f, 0.08f, 0, 0x7A5230, 0); part(MESH_OCTA, 0.45f, 2.0f, 0.2f, 0.2f, 0.3f, 0.2f, gtime, 0x9CE0FF, 0.8f); }
			draw_marker(n->x, y + 2.25f * n->scale + (n->hat == 1 || n->hat == 6 ? 0.5f : 0.15f), n->z, npc_marker(i));
		} else draw_marker(n->x, y + 2.7f, n->z, npc_marker(i));
	}
	// Biscuit and found kittens around Tilly
	if (!dunOn) {
		const NpcDef* t = &npcdefs[NPC_TILLY];
		float y = ground_h(t->x + 0.9f, t->z + 0.5f);
		draw_cat(t->x + 0.9f, y, t->z + 0.5f, -0.6f + sinf(gtime*0.3f)*0.3f, 1.0f, 0xF0A04A, 0xE07A2A);
		static const u32 kc[3][2] = { {0xF4F4F4, 0xE8C8C8}, {0x9A9AA0, 0x7A7A80}, {0x2A2A2E, 0xF4F4F4} };
		for (int k = 0; k < 3; k++) if (S.kittens & (1 << k)) {
			float a = gtime * 0.4f + k * 2.1f, kx = t->x + 0.9f + cosf(a) * 1.3f, kz = t->z + 0.5f + sinf(a) * 1.3f;
			draw_cat(kx, ground_h(kx, kz), kz, a + PI/2, 0.6f, kc[k][0], kc[k][1]);
		}
	}
	// buildings: boarded up when run-down, alive once restored
	for (int b = 0; b < BLD_COUNT; b++) {
		const BuildingDef* bd = &blddefs[b];
		if (!vis(bd->x, bd->z, 4, 34)) continue;
		int st = bld_stage(b);
		float y = ground_h(bd->x, bd->z);
		base(bd->x, y, bd->z, bd->yaw);
		if (st == 0) {
			part(MESH_CUBE, 0, 0.65f, 1.6f, 1.0f, 0.12f, 0.08f, 0.5f, 0x5A3A22, 0);   // planks across the door
			part(MESH_CUBE, 0, 0.75f, 1.62f, 1.0f, 0.12f, 0.08f, -0.5f, 0x4A3018, 0);
			part(MESH_CUBE, 0.9f, 2.55f, 0.7f, 0.7f, 0.08f, 0.6f, 0.6f, 0x2A2A2A, 0); // hole in the roof
			part(MESH_CUBE, 1.0f, 1.3f, 1.58f, 0.6f, 0.55f, 0.06f, 0, 0x3A3A3A, 0);   // dark, dusty windows
			part(MESH_CUBE, -1.0f, 1.3f, 1.58f, 0.6f, 0.55f, 0.06f, 0, 0x3A3A3A, 0);
		} else {
			u32 glow = b == 0 ? 0xFF8A3A : 0x8CFF9A;
			float fl = 0.6f + 0.25f * sinf(gtime * 7 + b);
			part(MESH_CUBE, 1.0f, 1.3f, 1.58f, 0.6f, 0.55f, 0.06f, 0, glow, fl);
			part(MESH_CUBE, -1.0f, 1.3f, 1.58f, 0.6f, 0.55f, 0.06f, 0, glow, fl);
			// signboard over the door
			part(MESH_CUBE, 0, 1.95f, 1.62f, 1.1f, 0.35f, 0.06f, 0, 0x6B4425, 0);
			part(MESH_CUBE, 0, 1.95f, 1.66f, b == 0 ? 0.35f : 0.3f, 0.2f, 0.04f, 0, b == 0 ? 0xC0C0C8 : 0x8CFF9A, 0.4f);
			if (b == 0) { part(MESH_CUBE, 1.6f, 0.35f, 2.2f, 0.5f, 0.35f, 0.3f, 0, 0x3A3A44, 0); part(MESH_CUBE, 1.6f, 0.6f, 2.2f, 0.65f, 0.12f, 0.25f, 0, 0x55555F, 0); } // anvil
			else { for (int k = 0; k < 3; k++) part(MESH_SPHERE, 1.5f + k * 0.22f, 0.35f, 2.1f, 0.14f, 0.2f, 0.14f, 0, k == 0 ? 0xFF5C7A : k == 1 ? 0x8CFF9A : 0x7AB8FF, 0.5f); } // bottles
			if (rndf() < 0.25f) { V3 c = lpos(-0.9f, 3.5f, 0); spawn_part(c, v3(rndr(-0.2f, 0.2f), 1.2f, rndr(-0.2f, 0.2f)), 1.8f, 0.16f, b == 0 ? 0x8A8A8A : 0xC8F0D0, -0.3f, 0, MESH_SPHERE); }
			if (st >= 2) {
				part(MESH_CUBE, 1.0f, 0.9f, 1.75f, 0.7f, 0.2f, 0.25f, 0, 0x6B4425, 0); // flower boxes
				part(MESH_CUBE, -1.0f, 0.9f, 1.75f, 0.7f, 0.2f, 0.25f, 0, 0x6B4425, 0);
				for (int k = 0; k < 4; k++) { part(MESH_SPHERE, 0.75f + k * 0.17f, 1.05f, 1.75f, 0.12f, 0.12f, 0.12f, 0, k & 1 ? 0xFFD23F : 0xFF6FA8, 0.3f); part(MESH_SPHERE, -1.25f + k * 0.17f, 1.05f, 1.75f, 0.12f, 0.12f, 0.12f, 0, k & 1 ? 0xB98CFF : 0xFFD23F, 0.3f); }
				part(MESH_CYL, -1.7f, 0, 2.3f, 0.08f, 1.6f, 0.08f, 0, 0x3A3A48, 0); // lamp post
				part(MESH_SPHERE, -1.7f, 1.7f, 2.3f, 0.2f, 0.25f, 0.2f, 0, 0xFFE38A, night_now() ? 1.0f : 0.5f);
			}
		}
	}
	// world event: surge ring or portal, plus keys
	if (EV.on) {
		float gy = ground_h(EV.x, EV.z); if (gy < -0.1f) gy = -0.1f;
		if (EV.type == EVT_PORTAL && vis(EV.x, EV.z, 4, 40)) {
			for (int k = 0; k < 3; k++) obj_ex(MESH_RING, EV.x, gy + 2.0f, EV.z, 2.4f - k * 0.5f, 1, 2.4f - k * 0.5f, gtime * (1.5f + k), PI / 2, k == 1 ? 0xE0A0FF : 0x9050FF, 1, 1.0f);
			obj_ex(MESH_SPHERE, EV.x, gy + 2.0f, EV.z, 0.5f + 0.1f * sinf(gtime * 6), 0.5f + 0.1f * sinf(gtime * 6), 0.5f, 0, 0, 0xFFFFFF, 1, 1.0f);
			if (rndf() < 0.5f) { float a = rndf() * TAU; spawn_part(v3(EV.x + cosf(a) * 2, gy + 2 + sinf(a) * 2, EV.z), v3(-cosf(a) * 2, -sinf(a) * 2, 0), 0.8f, 0.1f, 0xB070FF, 0, 1, MESH_OCTA); }
		}
		if (EV.type == EVT_PORTAL) for (int k = 0; k < EV.nkeys; k++) if (!(EV.prog & (1 << k)) && vis(EV.kx[k], EV.kz[k], 1, 34)) {
			float ky = ground_h(EV.kx[k], EV.kz[k]); if (ky < -0.1f) ky = -0.1f;
			float bob = sinf(gtime * 3 + k) * 0.15f;
			base(EV.kx[k], ky + 0.9f + bob, EV.kz[k], gtime * 2 + k);
			part(MESH_CYL, 0, 0, 0, 0.09f, 0.7f, 0.09f, 0, 0xFFD23F, 0.7f);
			part(MESH_RING, 0, 0.8f, 0, 0.45f, 1, 0.45f, PI / 2, 0xFFD23F, 0.8f);
			part(MESH_CUBE, 0.12f, 0.08f, 0, 0.2f, 0.08f, 0.06f, 0, 0xFFD23F, 0.7f);
			part(MESH_CUBE, 0.12f, 0.25f, 0, 0.16f, 0.08f, 0.06f, 0, 0xFFD23F, 0.7f);
		}
	}
	if (dunOn) draw_dungeon();
	else for (int i = 0; i < ngates; i++) if (vis(gates[i].x, gates[i].z, 3, 40)) draw_gate(&gates[i], gate_open(i));
	draw_player();
	if ((guideOn || dunOn) && guideValid && P.deadT <= 0 && !D.on) {
		float dx = guideX - P.p.x, dz = guideZ - P.p.z, d = sqrtf(dx*dx + dz*dz);
		if (d > 2.5f) {
			float yaw = atan2f(dx, dz), bob = sinf(gtime * 4) * 0.25f;
			float ax = P.p.x + dx / d * (1.5f + bob), az = P.p.z + dz / d * (1.5f + bob);
			obj_ex(MESH_CONE, ax, P.p.y + 0.3f, az, 0.75f, 1.25f, 0.3f, yaw, PI / 2, 0xFFC93A, 1, 0.75f);
		}
	}
	for (int i = 0; i < MAX_EN; i++) if (en[i].on && vis(en[i].p.x, en[i].p.z, 1.0f + 1.5f * en[i].boss * 2, 32)) draw_enemy(&en[i]);
	gfx_set_flash(0);
	// the telegraph language: RED on the ground = a big hit coming there (move / roll); BLUE shimmer = guarding (stop swinging)
	for (int i = 0; i < MAX_EN; i++) {
		Enemy* e = &en[i]; if (!e->on || e->state == ES_DEAD || !vis(e->p.x, e->p.z, 3, 32)) continue;
		const EnemyDef* d = &endefs[e->type]; float sz = d->scale * en_size(e), gy = ground_h(e->p.x, e->p.z) + 0.06f;
		int gap = e->lvl - S.lvl;
		if (e->state == ES_WINDUP && e->atk == 2) { // charger: arrow along the dash
			float len = 7.5f, k = clampf(1 - e->windup / 0.85f, 0.2f, 1), yaw = atan2f(e->aimX, e->aimZ);
			obj_ex(MESH_CUBE, e->p.x + e->aimX * len * 0.5f, gy, e->p.z + e->aimZ * len * 0.5f, 1.0f, 0.03f, len, yaw, 0, 0xFF3030, 0.18f + 0.3f * k, 1);
			obj_ex(MESH_PYR, e->p.x + e->aimX * (len + 0.4f), gy, e->p.z + e->aimZ * (len + 0.4f), 1.6f, 0.04f, 1.0f, yaw, 0, 0xFF3030, 0.5f, 1);
		}
		if (e->state == ES_WINDUP && e->atk == 1) { // brute: ring where the slam lands
			float k = clampf(1 - e->windup / 1.0f, 0.1f, 1), y2 = ground_h(e->aimX, e->aimZ) + 0.06f;
			obj_ex(MESH_DISC, e->aimX, y2, e->aimZ, 2.4f * k, 1, 2.4f * k, 0, 0, 0xFF3030, 0.35f, 1);
			obj_ex(MESH_RING, e->aimX, y2, e->aimZ, 2.4f, 1, 2.4f, 0, 0, 0xFF3030, 0.7f, 1);
		}
		if (e->castT > 0) { // caster: circle where you stood
			float k = clampf(1 - e->castT / 1.15f, 0.1f, 1), y2 = ground_h(e->castX, e->castZ) + 0.06f;
			obj_ex(MESH_DISC, e->castX, y2, e->castZ, 1.8f * k, 1, 1.8f * k, 0, 0, 0xFF3030, 0.35f, 1);
			obj_ex(MESH_RING, e->castX, y2, e->castZ, 1.8f, 1, 1.8f, gtime * 2, 0, d->col, 0.8f, 1);
		}
		if (e->boss && e->slamT > 0) obj_ex(MESH_RING, e->p.x, gy, e->p.z, 4.6f, 1, 4.6f, 0, 0, 0xFF3030, 0.7f, 1);
		if (e->guardT > 0) { float p = 1 + 0.06f * sinf(gtime * 18); obj_ex(MESH_SPHERE, e->p.x, e->p.y + 0.7f * sz, e->p.z, 1.3f * sz * p, 1.3f * sz * p, 1.3f * sz * p, 0, 0, 0x6FB8FF, 0.32f, 1); }
		if (e->freezeT > 0) obj_ex(MESH_CUBE, e->p.x, e->p.y + 0.55f * sz, e->p.z, 1.3f * sz, 1.2f * sz, 1.3f * sz, 0.3f, 0, 0xBFEFFF, 0.45f, 0.8f);
		if (e->stunT > 0 || e->recoverT > 0.2f) for (int k = 0; k < 3; k++) { float a = gtime * 5 + k * TAU / 3; obj_ex(MESH_OCTA, e->p.x + cosf(a) * 0.4f, e->p.y + 1.3f * sz + 0.3f, e->p.z + sinf(a) * 0.4f, 0.12f, 0.12f, 0.12f, a, 0, e->stunT > 0 ? 0xFFE14A : 0xDDDDDD, 1, 1); }
		if (e->chillT > 0 && e->freezeT <= 0) obj_ex(MESH_RING, e->p.x, gy + 0.02f, e->p.z, 0.9f * sz, 1, 0.9f * sz, 0, 0, 0x9FE8FF, 0.6f, 1);
		if (e->elite && !e->boss) { float p = 0.7f + 0.3f * sinf(gtime * 4); obj_ex(MESH_RING, e->p.x, gy + 0.04f, e->p.z, 1.6f * sz, 1, 1.6f * sz, -gtime, 0, 0xFFC93A, p, 1); }
		if (gap >= 2 && !e->boss) { float p = 0.5f + 0.3f * sinf(gtime * 5 + i); obj_ex(MESH_RING, e->p.x, gy + 0.03f, e->p.z, 1.15f * sz, 1, 1.15f * sz, gtime, 0, gap >= 4 ? 0x7020A0 : 0x501018, p, 0.2f); } // danger aura: dark, unlike the bright red attack markers
	}
	for (int i = 0; i < nnodes; i++) if (vis(nodes[i].x, nodes[i].z, 1.0f, 28)) draw_node(&nodes[i]);
	for (int i = 0; i < nseal; i++) if (!zone_open(sealpts[i].zone) && vis(sealpts[i].x, sealpts[i].z, 2.0f, 30)) draw_seal(&sealpts[i]);
	for (int i = 0; i < nchests; i++) if (vis(chests[i].x, chests[i].z, 1.0f, 30)) draw_chest(i);
	for (int i = 0; i < MAX_DROPS; i++) if (drops[i].on && vis(drops[i].p.x, drops[i].p.z, 0.5f, 30)) draw_drop(&drops[i]);
	for (int i = 0; i < MAX_SHOTS; i++) if (shots[i].on) { Shot* s = &shots[i]; float p = 1 + 0.2f * sinf(gtime * 20 + i);
		obj_ex(MESH_SPHERE, s->p.x, s->p.y, s->p.z, 0.32f * p, 0.32f * p, 0.32f * p, 0, 0, s->col, 1, 0.9f);
		obj_ex(MESH_SPHERE, s->p.x - s->v.x * 0.03f, s->p.y - s->v.y * 0.03f, s->p.z - s->v.z * 0.03f, 0.18f, 0.18f, 0.18f, 0, 0, 0xFFFFFF, 0.6f, 1.0f);
		shadow(s->p.x, s->p.z, 0.18f); }
	for (int i = 0; i < MAX_PART; i++) {
		Part* q = &parts[i]; if (!q->on) continue;
		if (!vis(q->p.x, q->p.z, 0.3f, 26)) continue;
		float k = q->life / q->max; float s = q->size * (0.3f + 0.7f * k);
		obj_ex(q->mesh, q->p.x, q->p.y, q->p.z, s, s, s, q->life * 6, q->life * 4, q->col, 1, q->emit);
	}

	// ---------------- transparent pass
	gfx_transparent(true);
	for (int i = 0; i < nshadow; i++) obj_ex(MESH_DISC, shadows[i].x, shadows[i].y, shadows[i].z, shadows[i].r*2, 1, shadows[i].r*2, 0, 0, 0x000000, 0.28f, 0);
	gfx_draw_water(gtime);
	for (int i = 0; i < MAX_DROPS; i++) {
		Drop* d = &drops[i]; if (!d->on || d->kind != 2 || d->g.rarity == R_COMMON) continue;
		u32 c = rarity_col[d->g.rarity]; float g = ground_h(d->p.x, d->p.z); if (g < -0.1f) g = -0.1f;
		float pulse = 0.85f + 0.15f * sinf(gtime * 5 + i);
		obj_ex(MESH_CYL, d->p.x, g, d->p.z, 0.32f * pulse, 3.0f + d->g.rarity * 1.6f, 0.32f * pulse, 0, 0, c, 0.30f, 0.9f);
		obj_ex(MESH_CYL, d->p.x, g, d->p.z, 0.12f, 3.0f + d->g.rarity * 1.6f, 0.12f, 0, 0, 0xFFFFFF, 0.45f, 1.0f);
		obj_ex(MESH_RING, d->p.x, g + 0.05f, d->p.z, 1.4f * pulse, 1, 1.4f * pulse, gtime, 0, c, 0.6f, 0.9f);
	}
	for (int i = 0; i < MAX_EN; i++) {
		Enemy* e = &en[i]; if (!e->on || e->slamT <= 0) continue;
		float k = 1 - e->slamT / 1.1f; float g = ground_h(e->p.x, e->p.z); if (g < -0.1f) g = -0.1f;
		obj_ex(MESH_RING, e->p.x, g + 0.08f, e->p.z, 9.2f, 1, 9.2f, 0, 0, 0xFF3A3A, 0.7f, 0.8f);
		obj_ex(MESH_DISC, e->p.x, g + 0.06f, e->p.z, 9.2f * k, 1, 9.2f * k, 0, 0, 0xFF3A3A, 0.3f, 0.6f);
	}
	draw_player_trail();
	if (guideOn && guideValid && dist2d(P.p.x, P.p.z, guideX, guideZ) > 2.5f && dist2d(rp.tx, rp.tz, guideX, guideZ) < 45) {
		float g = ground_h(guideX, guideZ); if (g < -0.1f) g = -0.1f;
		float pulse = 0.85f + 0.15f * sinf(gtime * 3);
		obj_ex(MESH_CYL, guideX, g, guideZ, 0.5f * pulse, 14, 0.5f * pulse, 0, 0, 0xFFC93A, 0.22f, 1.0f);
		obj_ex(MESH_RING, guideX, g + 0.06f, guideZ, 2.2f * pulse, 1, 2.2f * pulse, gtime, 0, 0xFFC93A, 0.55f, 1.0f);
	}
	if (EV.on) {
		float gy = ground_h(EV.x, EV.z); if (gy < -0.1f) gy = -0.1f;
		if (EV.type == EVT_HORDE && dist2d(rp.tx, rp.tz, EV.x, EV.z) < 50) {
			float pulse = 0.9f + 0.1f * sinf(gtime * 4);
			obj_ex(MESH_RING, EV.x, gy + 0.08f, EV.z, 32 * pulse, 1, 32 * pulse, gtime * 0.3f, 0, 0xFF6A2A, 0.45f, 1.0f);
			obj_ex(MESH_CYL, EV.x, gy, EV.z, 0.6f, 14, 0.6f, 0, 0, 0xFF6A2A, 0.22f, 1.0f);
		}
		if (EV.type == EVT_PORTAL) {
			obj_ex(MESH_DISC, EV.x, gy + 2.0f, EV.z, 3.6f, 1, 3.6f, gtime, PI / 2, 0x6A30C0, 0.35f, 1.0f);
			for (int k = 0; k < EV.nkeys; k++) if (!(EV.prog & (1 << k)) && dist2d(rp.tx, rp.tz, EV.kx[k], EV.kz[k]) < 50) {
				float ky = ground_h(EV.kx[k], EV.kz[k]); if (ky < -0.1f) ky = -0.1f;
				obj_ex(MESH_CYL, EV.kx[k], ky, EV.kz[k], 0.35f, 10, 0.35f, 0, 0, 0xFFD23F, 0.28f, 1.0f);
			}
		}
	}
	if (S.lantern) { float y = ground_h(0, 0); float p = 1 + 0.08f * sinf(gtime * 3); obj_ex(MESH_SPHERE, 0, y + 3.0f, 0, 2.2f*p, 2.2f*p, 2.2f*p, 0, 0, 0xFFD86A, 0.18f, 1.0f); }
	if (levelFlashT > 1.2f) { float k = (levelFlashT - 1.2f) / 1.3f; obj_ex(MESH_CYL, P.p.x, P.p.y, P.p.z, 1.6f, 9, 1.6f, 0, 0, 0x9CF0FF, 0.35f * k, 1.0f); obj_ex(MESH_RING, P.p.x, P.p.y + 0.1f, P.p.z, (1 - k) * 8 + 1, 1, (1 - k) * 8 + 1, 0, 0, 0x9CF0FF, 0.7f * k, 1); }
	gfx_transparent(false);
}

// ------------------------------------------------------------ HUD
// HUD text sits on the screen plane; only big transient titles float, by whole pixels
static float popx(int eye, float k) { if (k < 10) return 0; return roundf(-gfx_eye_offset(eye) * 3); }
static void bar(float x, float y, float w, float h, float f, u32 bg, u32 fg, u32 hi) {
	rect(x - 1, y - 1, w + 2, h + 2, RGBA(10, 10, 20, 200));
	rect(x, y, w, h, bg);
	f = clampf(f, 0, 1);
	rect_grad(x, y, w * f, h, hi, fg);
}
static void icon_coin(float x, float y, float r) { circle(x, y, r, RGBA(170, 110, 20, 255)); circle(x, y, r * 0.8f, RGBA(255, 205, 60, 255)); rect(x - r*0.15f, y - r*0.5f, r*0.3f, r, RGBA(255, 240, 160, 255)); }
static void icon_heart(float x, float y, float s, u32 c) { circle(x - s*0.5f, y - s*0.2f, s*0.55f, c); circle(x + s*0.5f, y - s*0.2f, s*0.55f, c); tri2d(x - s*1.05f, y, x + s*1.05f, y, x, y + s*1.1f, c); }
static void icon_trophy(float x, float y, float s, u32 c) { rect(x - s, y - s, s*2, s*1.2f, c); circle(x, y + s*0.2f, s, c); rect(x - s*0.25f, y + s*0.8f, s*0.5f, s*0.6f, c); rect(x - s*0.7f, y + s*1.3f, s*1.4f, s*0.35f, c); }

static int tracked_quest(void) {
	if (S.tracked == TRACK_MAIN) return mq_active() ? TRACK_MAIN : -1;
	if (S.tracked == TRACK_EVENT) return mq_active() && S.mqState == 1 ? TRACK_MAIN : -1;
	if (S.tracked == TRACK_RUMBLE) return S.rumbleSeen == 1 ? TRACK_RUMBLE : -1;
	if (S.tracked >= 0 && S.tracked < Q_COUNT && QS(S.tracked) == QS_ACTIVE) return S.tracked;
	if (mq_active() && S.mqState == 1) return TRACK_MAIN;
	for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_ACTIVE && quest_ready(q)) return q;
	for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_ACTIVE) return q;
	return -1;
}

void render_hud(int eye) {
	gfx_begin_2d_top(eye);
	char b[96];
	// world-anchored: floating numbers, enemy hp bars, npc markers
	for (int i = 0; i < MAX_FTXT; i++) {
		FText* f = &ftx[i]; if (!f->on) continue;
		float k = f->t / f->life;
		V3 p = v3add(f->p, v3(0, k * 1.4f, 0));
		float sx, sy;
		if (!world_to_screen(eye, p, &sx, &sy)) continue;
		u8 a = (u8)(255 * clampf((1 - k) * 2.5f, 0, 1));
		bool tagged = f->s[0] && (u8)f->s[strlen(f->s) - 1] >= 0x80; // ends in element icons
		int sc = tagged ? 1 : f->scale; if (k < 0.12f && sc == 2) sc = 3;
		text_center(sx, sy, sc, rgb_to_c2d(f->col, a), f->s);
	}
	if (S.optLevels) for (int i = 0; i < MAX_EN; i++) { // level tags over the foes you're fighting
		Enemy* e = &en[i]; if (!e->on || e->state == ES_DEAD || e->boss) continue;
		bool engaged = e->state == ES_CHASE || e->state == ES_WINDUP || e->hitShow > 0;
		float ed_ = dist2d(e->p.x, e->p.z, P.p.x, P.p.z);
		if ((!engaged && ed_ > 11) || ed_ > 16) continue; // close foes show their level so you can judge before engaging
		float sx, sy;
		if (!world_to_screen(eye, v3add(e->p, v3(0, 1.3f * endefs[e->type].scale + 0.4f, 0)), &sx, &sy)) continue;
		char lb[12]; sprintf(lb, "Lv%d", e->lvl);
		int lg = e->lvl - S.lvl;
		u32 lc = lg >= 4 ? RGBA(230, 90, 255, 255) : lg >= 2 ? RGBA(255, 90, 80, 255) : lg >= 1 ? RGBA(255, 170, 90, 255) : lg >= -2 ? RGBA(255, 255, 255, 255) : RGBA(170, 170, 185, 255);
		text_shadow(sx - text_w(lb, 1) / 2.f, sy - 11, 1, lc, lb);
		if (lg >= 4) icon(ICO_SKULL, sx + text_w(lb, 1) / 2.f + 2, sy - 13, 11); // run
		if (e->hp >= e->maxhp && e->elem) icon(elem_icon(e->elem), sx - text_w(lb, 1) / 2.f - 13, sy - 13, 11);
	}
	for (int i = 0; i < MAX_EN; i++) {
		Enemy* e = &en[i]; if (!e->on || e->state == ES_DEAD || e->boss || e->hp >= e->maxhp) continue;
		float sx, sy;
		if (!world_to_screen(eye, v3add(e->p, v3(0, 1.3f * endefs[e->type].scale + 0.4f, 0)), &sx, &sy)) continue;
		bar(sx - 16, sy, 32, 3, e->hp / e->maxhp, RGBA(60, 20, 20, 220), RGBA(230, 60, 60, 255), RGBA(255, 140, 140, 255));
		if (e->elem) icon(elem_icon(e->elem), sx - 29, sy - 4, 11);
	}
	{ // Bram's cart: a coin over the spot that opens the shop directly
		float sx, sy, d = dist2d(P.p.x, P.p.z, STALL_X, STALL_Z);
		if (d < 12 && world_to_screen(eye, v3(STALL_X, ground_h(STALL_X, STALL_Z) + 1.9f + sinf(gtime * 3) * 0.08f, STALL_Z), &sx, &sy)) icon(ICO_COIN, sx - 7, sy - 7, 14);
	}
	for (int i = 0; i < NPC_COUNT; i++) {
		int m = npc_marker(i); if (m != 1 && m != 2 && m != 4 && m != 5) continue;
		const NpcDef* n = &npcdefs[i];
		if (dist2d(n->x, n->z, P.p.x, P.p.z) > 26) continue;
		float sx, sy;
		float hy = i == NPC_BOARD ? 3.2f : 2.25f * n->scale + (n->hat == 1 || n->hat == 6 ? 1.05f : 0.7f);
		if (!world_to_screen(eye, v3(n->x, ground_h(n->x, n->z) + hy, n->z), &sx, &sy)) continue;
		u32 mc = m == 1 ? RGBA(255, 210, 60, 255) : m == 2 ? RGBA(110, 255, 130, 255) : RGBA(205, 150, 255, 255);
		if (m == 2 || m == 5) icon(ICO_CHECK, sx - 9, sy - 12, 18);
		else text_center(sx, sy - 8, 2, mc, (m == 1 || m == 4) ? "!" : "?");
	}

	// low HP vignette
	if (S.hp < P.maxhp * 0.3f && P.deadT <= 0) {
		u8 a = (u8)(70 + 50 * sinf(gtime * 6));
		rect_grad(0, 0, 400, 30, RGBA(200, 0, 0, a), RGBA(200, 0, 0, 0));
		rect_grad(0, 210, 400, 30, RGBA(200, 0, 0, 0), RGBA(200, 0, 0, a));
	}

	// level + hp + xp
	float ox = popx(eye, 2);
	circle(20 + ox, 20, 15, RGBA(20, 24, 40, 220));
	circle(20 + ox, 20, 12, RGBA(70, 140, 230, 255));
	sprintf(b, "%d", S.lvl); text_center(20 + ox, 13, S.lvl >= 10 ? 1 : 2, RGBA(255, 255, 255, 255), b);
	icon(ICO_HEART, 38 + ox, 5, 12);
	bar(52 + ox, 7, 92, 9, S.hp / P.maxhp, RGBA(70, 20, 30, 230), RGBA(220, 50, 70, 255), RGBA(255, 120, 130, 255));
	sprintf(b, "%d/%d", (int)ceilf(S.hp), (int)P.maxhp); text_shadow(56 + ox, 8, 1, RGBA(255, 255, 255, 255), b);
	{ float sk = P.sta / sta_max(); if (sk < 0) sk = 0; // endurance
	  rect(52 + ox, 17.5f, 92, 3, RGBA(20, 40, 20, 220)); rect(52 + ox, 17.5f, 92 * sk, 3, hudStaFlash > 0 && ((int)(gtime * 16) & 1) ? RGBA(255, 120, 80, 255) : sk < 0.3f ? RGBA(230, 220, 90, 255) : RGBA(130, 235, 110, 255)); }
	bar(52 + ox, 22, 92, 5, S.lvl >= LVL_CAP ? 1 : (float)S.xp / xp_next(S.lvl), RGBA(16, 30, 60, 230), RGBA(63, 160, 255, 255), RGBA(150, 205, 255, 255));
	if (hudXpFlash > 0) rect(52 + ox, 22, 92, 5, RGBA(150, 205, 255, (u8)(200 * hudXpFlash)));
	text_shadow(150 + ox, 21, 1, RGBA(160, 220, 255, 255), "XP");
	// gold + tonics
	sprintf(b, "%d", (int)(goldShown + 0.5f));
	text_shadow(388 - text_w(b, 2) + ox, 6, 2, RGBA(255, 220, 90, 255), b);
	float coinX = 370 - text_w(b, 2) + ox + 8, coinY = 12;
	{ float cp = 1 + 0.35f * (hudCoinPulse > 0 ? hudCoinPulse : 0);
	  if (!(hudCoinFullT > 0 && ((int)(gtime * 10) & 1))) icon(ICO_COIN, coinX - 8 * cp, coinY - 8 * cp, 16 * cp);
	  if (hudCoinFullT > 0) text_shadow(coinX - 34, coinY + 10, 1, RGBA(255, 150, 80, 255), "FULL");
	  if (hudBagFullT > 0) { float bs = 18 + 4 * sinf(gtime * 14); icon(ICO_BAG, coinX - 30 - bs / 2, coinY + 22, bs); text_shadow(coinX - 12, coinY + 28, 1, RGBA(255, 150, 80, 255), "PACK FULL"); } }
	if (S.weapon.used && S.weapon.elem) { icon(ICO_SWORDS, 214 + ox, 4, 12); icon(elem_icon(S.weapon.elem), 226 + ox, 4, 12); } // weapon's element at a glance
	// healing tonics live next to the health bar: X drinks one
	icon(ICO_TONIC, 150 + ox, 4, 14);
	sprintf(b, "x%d", IC(IT_TONIC));
	text_shadow(166 + ox, 8, 1, IC(IT_TONIC) ? RGBA(255, 170, 190, 255) : RGBA(150, 120, 130, 255), b);
	keycap(168 + text_w(b, 1) + 3 + ox, 6, "X");
	// pickups flying to their meters, plus a burst where they land
	{
		float sx0 = 200, sy0 = 140;
		world_to_screen(eye, v3add(P.p, v3(0, 1.0f, 0)), &sx0, &sy0);
		for (int i = 0; i < MAX_HFLY; i++) {
			HudFly* f = &hfly[i]; if (!f->on) continue;
			if (!f->init) { if (eye != 0) continue; f->init = true; f->sx = sx0 + rndr(-8, 8); f->sy = sy0 + rndr(-8, 8); }
			if (f->t < 0) continue;
			float tx = f->kind == 0 ? 98 + ox : coinX, ty = f->kind == 0 ? 24 : coinY;
			float k = clampf(f->t / f->dur, 0, 1), e = k * k * (3 - 2 * k);
			float mx = (f->sx + tx) / 2 + f->cx, my = (f->sy + ty) / 2 + f->cy;
			float u = 1 - e, x = u*u*f->sx + 2*u*e*mx + e*e*tx, y = u*u*f->sy + 2*u*e*my + e*e*ty;
			u32 c = f->kind == 0 ? RGBA(63, 160, 255, 255) : RGBA(255, 210, 70, 255);
			float r = 4.5f - 1.5f * k;
			circle(x, y, r + 2, f->kind == 0 ? RGBA(63, 160, 255, 90) : RGBA(255, 210, 70, 90));
			if (f->kind == 1) icon(ICO_COIN, x - 6, y - 6, 12); else circle(x, y, r, c);
			// short trail
			for (int tr = 1; tr <= 3; tr++) { float k2 = clampf((f->t - tr * 0.03f) / f->dur, 0, 1), e2 = k2 * k2 * (3 - 2 * k2), u2 = 1 - e2;
				float x2 = u2*u2*f->sx + 2*u2*e2*mx + e2*e2*tx, y2 = u2*u2*f->sy + 2*u2*e2*my + e2*e2*ty; circle(x2, y2, r - tr, f->kind == 0 ? RGBA(63, 160, 255, 150 - tr * 40) : RGBA(255, 210, 70, 150 - tr * 40)); }
		}
		// landing bursts
		if (hudXpFlash > 0) { float k = 1 - hudXpFlash; for (int s = 0; s < 10; s++) { float a = s * TAU / 10 + 0.3f; circle(98 + ox + cosf(a) * (8 + 26 * k), 24 + sinf(a) * (4 + 12 * k), 2.2f * hudXpFlash + 0.5f, RGBA(63, 160, 255, (u8)(255 * hudXpFlash))); } }
		if (hudCoinPulse > 0) { float k = 1 - hudCoinPulse; for (int s = 0; s < 8; s++) { float a = s * TAU / 8; circle(coinX + cosf(a) * (6 + 18 * k), coinY + sinf(a) * (6 + 18 * k), 2.2f * hudCoinPulse + 0.5f, RGBA(255, 210, 70, (u8)(255 * hudCoinPulse))); } }
	}
	// world event panel
	if (EV.on) {
		char eb[48]; event_progress_text(eb);
		float px0 = 248 + ox, py0 = 64;
		rect(px0, py0, 148, 30, RGBA(40, 14, 10, 190)); rect_outline(px0, py0, 148, 30, 1, EV.type == EVT_PORTAL ? RGBA(190, 120, 255, 255) : RGBA(255, 130, 60, 255));
		icon(EV.type == EVT_PORTAL ? ICO_PORTAL : ICO_EVENT, px0 + 3, py0 + 3, 16);
		text_shadow(px0 + 22, py0 + 4, 1, EV.type == EVT_PORTAL ? RGBA(220, 180, 255, 255) : RGBA(255, 180, 120, 255), event_name());
		text_shadow(px0 + 22, py0 + 15, 1, RGBA(240, 240, 250, 255), eb);
		rect(px0 + 3, py0 + 26, 142, 2, RGBA(0, 0, 0, 160)); rect(px0 + 3, py0 + 26, 142 * (1 - EV.t / EV.dur), 2, RGBA(255, 200, 90, 255));
	}
	for (int b = 0; b < BLD_COUNT; b++) if (S.holdN[blddefs[b].station - 1]) {
		float dx, dz; bld_door(b, &dx, &dz);
		if (dist2d(dx, dz, P.p.x, P.p.z) > 30) continue;
		float sx, sy; if (!world_to_screen(eye, v3(dx, ground_h(dx, dz) + 3.6f, dz), &sx, &sy)) continue;
		float p = 1 + 0.1f * sinf(gtime * 6); icon(b == 0 ? ICO_ANVIL : ICO_POTION, sx - 10 * p, sy - 10 * p, 20 * p);
		icon(ICO_CHECK, sx + 6, sy - 14, 11);
	}
	// crafting in progress
	if (S.jobs[0].state) {
		const CraftJob* j = &S.jobs[0];
		int sec = (int)ceilf(j->left); sprintf(b, "%d:%02d", sec / 60, sec % 60);
		float x = 392 - text_w(b, 1) + ox;
		text_shadow(x, 28, 1, RGBA(255, 220, 170, 255), b);
		icon(recipe_icon(j->r), x - 16, 24, 14);
		rect(x - 16, 40, 16 + text_w(b, 1), 2, RGBA(40, 30, 20, 200)); rect(x - 16, 40, (16 + text_w(b, 1)) * (1 - j->left / j->total), 2, RGBA(255, 180, 80, 255));
	}
	if (S.readyCache[0] + S.readyCache[1] + S.readyCache[2]) { float p = 1 + 0.12f * sinf(gtime * 8); icon(ICO_GIFT, 376 + ox, 44, 16 * p); }
	// tracked quest
	int q = tracked_quest();
	if (q >= 0 || S.bActive) {
		char pr[160];
		const char* title; u32 tc;
		if (q == TRACK_RUMBLE) { hl("Find Biscuit with Tilly in town", pr, 150); title = "The Earth Shook"; tc = RGBA(255, 190, 120, 255); }
		else if (q == TRACK_MAIN && !(guideOn && guideBounty && S.bActive)) {
			mq_progress_text(pr); title = mainq[S.mq].title; tc = mq_ready() ? RGBA(120, 255, 140, 255) : RGBA(205, 150, 255, 255);
			if (S.mqState == 1 && !mq_items_ok() && mainq[S.mq].type == MQT_ITEM && !guideValid) { for (int r = 0; r < RECIPE_COUNT; r++) if (recipes[r].out == CR_ITEM && recipes[r].arg == mainq[S.mq].target && can_craft(r)) { sprintf(pr, "Ready to craft: open the Craft tab"); tc = RGBA(120, 255, 140, 255); } }
		}
		else if (q >= 0 && !(guideOn && guideBounty && S.bActive)) { quest_progress_text(q, pr); title = questdefs[q].title; tc = quest_ready(q) ? RGBA(120, 255, 140, 255) : RGBA(255, 220, 110, 255); }
		else { bounty_text(pr); title = "Bounty"; tc = RGBA(255, 176, 74, 255); }
		char tbuf[64];
		if (guideOn && guideValid) { sprintf(tbuf, "%s  > %dm", title, (int)dist2d(P.p.x, P.p.z, guideX, guideZ)); title = tbuf; }
		int w = text_w(pr, 1); int tw = text_w(title, 1); if (tw > w) w = tw;
		rect(4 + ox, 31, w + 10, 22, q == TRACK_MAIN && !(guideOn && guideBounty && S.bActive) ? RGBA(40, 16, 60, 170) : RGBA(10, 14, 30, 140));
		if (q == TRACK_MAIN) rect(4 + ox, 31, 2, 22, RGBA(190, 130, 255, 255));
		text_shadow(9 + ox, 33, 1, tc, title);
		text_shadow(9 + ox, 43, 1, RGBA(235, 235, 245, 255), pr);
	}
	// pickup feed
	for (int i = 0; i < 6; i++) {
		if (!feed[i].s[0] || feed[i].t > 3.5f) continue;
		float a = clampf((3.5f - feed[i].t) * 2, 0, 1);
		float slide = feed[i].t < 0.15f ? (0.15f - feed[i].t) * 300 : 0;
		text_shadow(392 - text_w(feed[i].s, 1) + slide + ox, 132 + i * 10, 1, rgb_to_c2d(feed[i].col, (u8)(255 * a)), feed[i].s);
	}
	// zone / boss banner
	if (zoneBannerT > 0) {
		float a = clampf(zoneBannerT, 0, 1) * clampf((3.0f - zoneBannerT) * 3, 0, 1);
		float px = popx(eye, 5);
		int w = text_w(zoneBanner, 2);
		rect_grad(200 - w/2 - 30 + px, 104, w + 60, 26, RGBA(0, 0, 0, 0), RGBA(0, 0, 0, (u8)(130 * a)));
		text_center(200 + px, 110, 2, rgb_to_c2d(zoneBannerCol, (u8)(255 * a)), zoneBanner);
	}
	// toast
	if (toastN > 0) {
		Toast* t = &toastQ[0];
		float k = t->t < 0.25f ? t->t / 0.25f : (t->t > 2.3f ? (2.6f - t->t) / 0.3f : 1);
		k = clampf(k, 0, 1);
		float y = 12 + 46 * smooth01(k);
		float px = popx(eye, 9);
		int tw1 = text_w(t->title, 1), tw2 = text_w(t->sub, 2); if (tw2 > 250) tw2 = text_w(t->sub, 1);
		float w = (tw1 > tw2 ? tw1 : tw2) + 56; if (w < 190) w = 190; if (w > 380) w = 380;
		u8 ta = (u8)(255 * smooth01(k));
		u32 c = t->col;
		rect(200 - w/2 + px, y, w, 42, RGBA(14, 16, 32, (u8)(ta * 0.9f)));
		rect_outline(200 - w/2 + px, y, w, 42, 2, rgb_to_c2d(c, ta));
		if (t->kind == 1) icon_trophy(200 - w/2 + 22 + px, y + 17, 7, rgb_to_c2d(c, 255));
		else if (t->kind == 2) { float s = 9 + sinf(gtime * 10); tri2d(200 - w/2 + 22 + px, y + 21 - s, 200 - w/2 + 22 + px - s*0.7f, y + 21, 200 - w/2 + 22 + px + s*0.7f, y + 21, rgb_to_c2d(c, 255)); tri2d(200 - w/2 + 22 + px, y + 21 + s, 200 - w/2 + 22 + px - s*0.7f, y + 21, 200 - w/2 + 22 + px + s*0.7f, y + 21, rgb_to_c2d(c, 255)); }
		else if (t->kind == 3) { tri2d(200 - w/2 + 22 + px, y + 9, 200 - w/2 + 13 + px, y + 23, 200 - w/2 + 31 + px, y + 23, rgb_to_c2d(c, 255)); rect(200 - w/2 + 18 + px, y + 23, 8, 9, rgb_to_c2d(c, 255)); }
		else circle(200 - w/2 + 22 + px, y + 21, 7, rgb_to_c2d(c, 255));
		text_shadow(200 - w/2 + 40 + px, y + 7, 1, rgb_to_c2d(c, 255), t->title);
		int sc = text_w(t->sub, 2) > 250 ? 1 : 2;
		text_shadow(200 - w/2 + 40 + px, y + (sc == 2 ? 19 : 23), sc, RGBA(255, 255, 255, 255), t->sub);
	}
	// big level-up text
	if (levelFlashT > 1.3f) {
		float k = (levelFlashT - 1.3f) / 1.2f;
		float px = popx(eye, 14);
		text_center(200 + px, 150 - (1 - k) * 20, 3, RGBA(140, 240, 255, (u8)(255 * clampf(k * 2, 0, 1))), "LEVEL UP!");
	}
	if (dunOn && !D.on) draw_dun_map(328, 28, 66, true);
	if (has_pk(PK_WHIRL) && !D.on) { char wb[48], wo[64]; if (whirlCd > 0) sprintf(wb, "[ZR] Whirlwind %d", (int)ceilf(whirlCd)); else strcpy(wb, "[ZR] Whirlwind");
		hl(wb, wo, 64); text_shadow(6, 226, 1, whirlCd > 0 ? RGBA(150, 150, 170, 255) : RGBA(235, 235, 245, 255), wo); }
	if (dunOn && DG.kind == 1 && !D.on) { // rift status under the top bar
		char rb[48]; float bx = 176, by = 30, bw = 146;
		if (DG.rtype == RT_HUNT) {
			float f = DG.guardOn || DG.done ? 1 : DG.prog / DG.need; int tl = (int)ceilf(DG.timeLeft);
			rect(bx - 1, by - 1, bw + 2, 8, RGBA(10, 6, 20, 220)); rect(bx, by, bw * f, 6, DG.guardOn ? RGBA(255, 70, 90, 255) : RGBA(190, 120, 255, 255));
			sprintf(rb, DG.done ? "Tier %d - closed" : DG.guardOn ? "Tier %d - GUARDIAN  %d:%02d" : "Tier %d   %d:%02d", DG.tier, tl / 60, tl % 60);
			text_center(bx + bw / 2, by + 9, 1, DG.timeUp ? RGBA(255, 110, 110, 255) : tl < 30 && !DG.done ? RGBA(255, 190, 90, 255) : RGBA(230, 215, 255, 255), rb);
		} else if (DG.rtype == RT_ARENA) {
			for (int k = 0; k < 5; k++) rect(bx + k * 30, by, 26, 6, k < DG.prog ? RGBA(190, 120, 255, 255) : k < DG.wave ? RGBA(255, 200, 90, 255) : RGBA(40, 30, 60, 220));
			sprintf(rb, DG.done ? "Tier %d - conquered" : DG.wave ? "Tier %d - wave %d of 5" : "Tier %d - step into the pit", DG.tier, DG.wave); text_center(bx + bw / 2, by + 9, 1, RGBA(230, 215, 255, 255), rb);
		} else {
			sprintf(rb, "Floor %d  Haul %d  x%.1f", DG.floor, (int)DG.haul, 1 + 0.5f * (DG.floor - 1)); text_center(bx + bw / 2, by, 1, RGBA(220, 190, 255, 255), rb);
		}
		static const char* pl[4] = { "POWER", "HASTE", "WARD", "STORM" }; const u32 plc[4] = { RGBA(255, 120, 90, 255), RGBA(110, 255, 180, 255), RGBA(110, 180, 255, 255), RGBA(255, 225, 80, 255) };
		float px = bx + bw / 2; int na = 0; for (int k = 0; k < 4; k++) if (pylT[k] > 0) na++;
		px -= na * 30; for (int k = 0; k < 4; k++) if (pylT[k] > 0) { sprintf(rb, "%s %d", pl[k], (int)ceilf(pylT[k])); text(px, by + 21, 1, plc[k], rb); px += 60; }
	}
	// boss bar
	bool bossShown = false;
	if (bossIdx >= 0 && en[bossIdx].on) {
		Enemy* e = &en[bossIdx];
		bossShown = true;
		{ char nb[48]; sprintf(nb, e->guard ? "Rift Guardian %s" : e->elite && !e->boss ? "Champion %s" : "%s", endefs[e->type].name); text_center(200, 204, 1, e->elite ? RGBA(255, 210, 100, 255) : RGBA(255, 160, 150, 255), nb); }
		bar(60, 215, 280, 8, e->hp / e->maxhp, RGBA(60, 10, 10, 230), RGBA(220, 40, 40, 255), RGBA(255, 130, 100, 255));
	}
	// interaction prompt
	if (promptText[0] && !D.on && P.deadT <= 0) {
		int w = text_w(promptText, 1) + 16;
		float y = bossShown ? 184 : 216;
		rect(200 - w/2.f, y, w, 16, RGBA(10, 12, 26, 200));
		rect_outline(200 - w/2.f, y, w, 16, 1, RGBA(255, 220, 110, 200));
		text_shadow(200 - w/2.f + 8, y + 4, 1, RGBA(255, 240, 200, 255), promptText);
	}
	// dialog
	if (D.on) {
		float px = popx(eye, 3);
		rect(8 + px, 150, 384, 84, RGBA(14, 16, 34, 235));
		rect_outline(8 + px, 150, 384, 84, 2, RGBA(255, 220, 110, 255));
		const char* nm = D.spk[D.cur][0] ? D.spk[D.cur] : npcdefs[D.npc].name;
		bool cat = strcmp(nm, "Biscuit") == 0;
		u32 tag = RGBA(255, 210, 90, 255);
		if (cat) tag = RGBA(240, 160, 74, 255); else if (strcmp(nm, "Marigold") == 0) tag = RGBA(110, 210, 200, 255); else if (strcmp(nm, "Gus") == 0) tag = RGBA(130, 170, 230, 255);
		bool story = D.action == ACT_MQ_ACCEPT || D.action == ACT_MQ_COMPLETE || !strcmp(D.spk[D.cur], "Marigold") || !strcmp(D.spk[D.cur], "Gus") || !strcmp(D.spk[D.cur], "Biscuit");
		if (story) rect_outline(8 + px, 150, 384, 84, 2, RGBA(190, 130, 255, 255));
		int nw = text_w(nm, 1) + 14;
		rect(16 + px, 141, nw, 15, tag);
		text(23 + px, 145, 1, RGBA(30, 20, 10, 255), nm);
		if (story) { const char* st = "MAIN STORY"; rect(384 - text_w(st, 1) - 10 + px, 141, text_w(st, 1) + 10, 15, RGBA(120, 70, 190, 255)); text(389 - text_w(st, 1) - 10 + px, 145, 1, RGBA(255, 255, 255, 255), st); }
		int n = (int)D.chars; int len = strlen(D.pages[D.cur]); if (n > len) n = len;
		text_wrap_n(20 + px, 162, 1, cat ? RGBA(215, 200, 235, 255) : RGBA(245, 245, 255, 255), D.pages[D.cur], 356, 6, n);
		if (n >= len && ((int)(gtime * 3) & 1)) tri2d(372 + px, 220, 382 + px, 220, 377 + px, 227, RGBA(255, 220, 110, 255));
	}
	if (shopOpen) {
		const char* st = bankMode ? "Strongbox: use the bottom screen. B to leave" : "Shopping: use the bottom screen. B to leave";
		int w = text_w(st, 1) + 20;
		rect(200 - w / 2.f, 148, w, 22, RGBA(14, 16, 34, 225));
		rect_outline(200 - w / 2.f, 148, w, 22, 1, RGBA(255, 220, 110, 200));
		text_center(200, 155, 1, RGBA(255, 220, 110, 255), st);
	}
	// ending
	if (endingT > 3 && endingT < 15) {
		float a = clampf((endingT - 3), 0, 1) * clampf(15 - endingT, 0, 1);
		float px = popx(eye, 10);
		text_center(200 + px, 100, 2, RGBA(255, 230, 140, (u8)(255 * a)), "Thank you for playing!");
		text_center(200 + px, 124, 1, RGBA(255, 255, 255, (u8)(255 * a)), "Bounties, treasure and trophies still await...");
	}
	// death
	if (P.deadT > 0) {
		float a = clampf(3 - P.deadT, 0, 1);
		rect(0, 0, 400, 240, RGBA(20, 0, 10, (u8)(160 * a)));
		text_center(200 + popx(eye, 6), 100, 3, RGBA(255, 120, 130, (u8)(255 * a)), "You fainted...");
	}
	if (G.on) { render_gacha_top(eye); return; }
	if (riftPick) { // choose a tier: the gamble
		static const char* rn[3] = { "HUNT", "ARENA", "DELVE" };
		static const char* rd[3][3] = {
			{ "- Fight to fill the bar", "- Then slay the Rift Guardian", "- Beat the 4:00 clock: up to +3 tiers" },
			{ "- Survive 5 waves in the pit", "- Gold after every wave", "- Leave between waves, or push on" },
			{ "- Go down floor after floor", "- Your haul grows x0.5 per floor", "- Faint and the rift keeps it ALL" } };
		int rt = S.riftNext % 3, t = riftPickTier;
		rect(0, 0, 400, 240, RGBA(8, 0, 20, 200));
		text_center(200 + popx(eye, 6), 18, 2, RGBA(200, 150, 255, 255), "SHIMMERING RIFT");
		sprintf(b, "This tear: %s", rn[rt]); text_center(200, 46, 1, RGBA(255, 220, 120, 255), b);
		float pp = popx(eye, 8);
		text_center(200 + pp, 72, 3, RGBA(255, 255, 255, 255), "");
		sprintf(b, "TIER %d", t); text_center(200 + pp, 70, 3, RGBA(255, 255, 255, 255), b);
		u32 ac = RGBA(255, 230, 120, 255);
		if (t > 1) tri2d(120, 82, 132, 74, 132, 90, ac);
		if (t < rift_max()) tri2d(280, 82, 268, 74, 268, 90, ac);
		sprintf(b, "Foes: health x%.1f   damage x%.1f", rift_hp_mul(t), rift_dmg_mul(t)); text_center(200, 106, 1, RGBA(255, 160, 140, 255), b);
		{ float rc = 0.08f + 0.05f * t; if (rc > 0.6f) rc = 0.6f; sprintf(b, "Loot: %d+ items, %d%% rare", 2 + t / 3, (int)(rc * 100)); text_center(200, 120, 1, RGBA(150, 230, 160, 255), b); }
		for (int k = 0; k < 3; k++) text(110, 142 + k * 14, 1, RGBA(210, 205, 235, 255), rd[rt][k]);
		sprintf(b, "Highest tier open: %d", rift_max()); text_center(200, 192, 1, RGBA(160, 150, 200, 255), b);
		text_center(200, 214, 1, RGBA(170, 180, 210, 255), (S.testUnlock & 2) ? "Left/Right tier  [Y] type (test)  [A] enter" : "Left/Right tier   [A] enter   [B] back");
		return;
	}
	if (S.perkPicks > 0 && perkOffer[0] >= 0 && !D.on && !shopOpen && levelFlashT < 1.6f) { // perk cards: a new tool
		rect(0, 0, 400, 240, RGBA(14, 6, 0, 185));
		float px = popx(eye, 10);
		text_center(200 + px, 20, 3, RGBA(255, 190, 90, 255), "NEW PERK");
		text_center(200, 50, 1, RGBA(230, 220, 210, 255), "Every third level: choose a new tool");
		for (int k = 0; k < 3; k++) { int p = perkOffer[k]; if (p < 0) continue;
			bool sel = k == perkSel; float cx = 72 + k * 128, cy = 70, w = 120, h = 122, pp = sel ? popx(eye, 6) : popx(eye, 2);
			rect(cx - w / 2 + pp, cy, w, h, sel ? RGBA(80, 50, 16, 245) : RGBA(36, 30, 44, 235));
			if (sel) { rect(cx - w / 2 + pp, cy, w, 3, RGBA(255, 190, 90, 255)); rect(cx - w / 2 + pp, cy + h - 3, w, 3, RGBA(255, 190, 90, 255)); }
			static const int pi[PK_COUNT] = { ICO_SWORDS, ICO_FIRE, ICO_RUNNER, ICO_SHIELDOK, ICO_HEART, ICO_ANGER, ICO_SHIELD, ICO_BOLT, ICO_MONEYBAG, ICO_POTION };
			float s = sel ? 32 + 3 * sinf(gtime * 6) : 28; icon(pi[p], cx - s / 2 + pp, cy + 10, s);
			text_center(cx + pp, cy + 52, 1, sel ? RGBA(255, 220, 130, 255) : RGBA(240, 235, 240, 255), pk_name[p]);
			char d1[40]; hl(pk_d1[p], d1, 40); text_center(cx + pp, cy + 74, 1, RGBA(210, 205, 220, 255), d1);
			text_center(cx + pp, cy + 88, 1, RGBA(170, 165, 190, 255), pk_d2[p]);
		}
		text_center(200, 220, 1, RGBA(190, 180, 170, 255), "Left/Right choose   [A] take it");
		return;
	}
	if (S.lvlPicks > 0 && !D.on && !shopOpen && levelFlashT < 1.6f) { // level-up reward cards
		rect(0, 0, 400, 240, RGBA(0, 0, 12, 170));
		float px = popx(eye, 10);
		sprintf(b, "LEVEL %d!", S.lvl); text_center(200 + px, 22, 3, RGBA(140, 240, 255, 255), b);
		text_center(200, 52, 1, RGBA(220, 225, 240, 255), "Choose a reward");
		static const char* tt[4] = { "Fortune", "Pack Point", "Hardier", "Endurance" };
		static const int ti[4] = { ICO_MONEYBAG, ICO_BAG, ICO_HEART, ICO_RUNNER };
		char d1[4][32], d2[4][32];
		strcpy(d1[0], "+10% gold"); strcpy(d2[0], "per kill");
		strcpy(d1[1], "+1 pouch"); strcpy(d2[1], "(Bag tab)");
		strcpy(d1[2], "+15 HP"); strcpy(d2[2], "+4 defence");
		strcpy(d1[3], "+20 stamina"); strcpy(d2[3], "quicker rest");
		for (int k = 0; k < 4; k++) {
			bool sel = k == lvlPickSel; float cx = 52 + k * 99, cy = 72, w = 94, h = 120;
			float pp = sel ? popx(eye, 6) : popx(eye, 2);
			rect(cx - w / 2 + pp, cy, w, h, sel ? RGBA(70, 60, 24, 245) : RGBA(30, 34, 56, 235));
			if (sel) { rect(cx - w / 2 + pp, cy, w, 3, RGBA(255, 220, 90, 255)); rect(cx - w / 2 + pp, cy + h - 3, w, 3, RGBA(255, 220, 90, 255)); }
			float s = sel ? 34 + 3 * sinf(gtime * 6) : 30;
			icon(ti[k], cx - s / 2 + pp, cy + 10, s);
			text_center(cx + pp, cy + 52, 1, sel ? RGBA(255, 230, 120, 255) : RGBA(235, 235, 245, 255), tt[k]);
			text_center(cx + pp, cy + 74, 1, RGBA(200, 205, 225, 255), d1[k]);
			text_center(cx + pp, cy + 88, 1, RGBA(150, 160, 190, 255), d2[k]);
		}
		if (S.lvlPicks > 1) { sprintf(b, "%d more to choose after this", S.lvlPicks - 1); text_center(200, 200, 1, RGBA(160, 200, 255, 255), b); }
		text_center(200, 220, 1, RGBA(170, 180, 210, 255), "Left/Right choose   [A] take it");
		return;
	}
	// pause
	if (paused && camAdjOn) { // shoulder-camera tuning: keep the view clear, panel along the bottom
		static const char* nm[4] = { "Side", "Height", "Distance", "Tilt" };
		rect(0, 150, 400, 90, RGBA(0, 0, 10, 190));
		text_center(200, 155, 1, RGBA(255, 255, 255, 255), "SHOULDER CAMERA");
		for (int i = 0; i < 4; i++) {
			float ry = 168 + i * 14; bool sel = i == camAdjSel;
			u32 c = sel ? RGBA(255, 220, 90, 255) : RGBA(200, 200, 220, 255);
			if (sel) rect(70, ry - 2, 260, 13, RGBA(60, 50, 20, 200));
			text(80, ry, 1, c, nm[i]);
			rect(170, ry + 3, 140, 4, RGBA(40, 44, 70, 255));
			rect(170, ry + 3, 140 * S.camAdj[i] / 20.f, 4, sel ? RGBA(255, 200, 90, 255) : RGBA(120, 160, 230, 255));
			rect(170 + 140 * CAM_ADJ_DEF[i] / 20.f - 1, ry, 2, 10, RGBA(255, 255, 255, 160));
		}
		text_center(200, 226, 1, RGBA(160, 170, 200, 255), "Up/Down pick  Left/Right adjust  Y reset  A done");
	} else if (paused) {
		rect(0, 0, 400, 240, RGBA(0, 0, 10, 160));
		text_center(200 + popx(eye, 8), 34, 3, RGBA(255, 255, 255, 255), "PAUSED");
		char dl[40]; sprintf(dl, "Difficulty: %d%% %s", S.optDiff, diff_name(S.optDiff));
		char ro[40]; sprintf(ro, "Rumble odds: 1 in %d", S.rumbleN * 50);
		char sp_[40]; sprintf(sp_, "Spawn rate: %d%%", S.spawnPct);
		const char* rs = in_town() ? (S.retOn ? "Return Stone: back out" : "Return Stone (you're home)") : "Return Stone: go home";
		const char* it[PAUSE_N] = { "Resume", rs, dl, ro, sp_, S.optCam ? "Camera: Over the shoulder" : "Camera: Classic", "Adjust shoulder camera...",
			S.optLevels ? "Enemy levels: ON" : "Enemy levels: OFF", "Save", "Save & quit to title",
			(S.testUnlock & 1) ? "Test: all Depths open (ON)" : "Test: open all Depths", (S.testUnlock & 2) ? "Test: Rifts open (ON)" : "Test: open Rifts" };
		for (int i = 0; i < PAUSE_N; i++) {
			float ry = 64 + i * 13;
			u32 c = i == pauseSel ? RGBA(255, 220, 90, 255) : RGBA(200, 200, 220, 255);
			if (i == pauseSel) { rect(90, ry, 220, 13, RGBA(60, 50, 20, 200)); }
			text_center(200, ry + 3, 1, i >= 10 ? (i == pauseSel ? RGBA(255, 170, 120, 255) : RGBA(170, 140, 130, 255)) : i == 1 ? (i == pauseSel ? RGBA(180, 220, 255, 255) : RGBA(140, 190, 240, 255)) : c, it[i]);
			if (i == pauseSel && (i >= 2 && i <= 5)) { // left/right adjusts these
				tri2d(97, ry + 7, 103, ry + 2.5f, 103, ry + 11.5f, c); tri2d(303, ry + 7, 297, ry + 2.5f, 297, ry + 11.5f, c);
			}
		}
		if (pauseSel == 2) { // the slider itself, with the original balance marked at 75
			float bx = 120, bw = 160, by = 64 + PAUSE_N * 13 + 3;
			rect(bx, by, bw, 4, RGBA(40, 44, 70, 255));
			rect(bx, by, bw * S.optDiff / 100.f, 4, RGBA(255, 120 + (100 - S.optDiff), 80, 255));
			rect(bx + bw * 0.75f - 1, by - 3, 2, 10, RGBA(255, 255, 255, 200));
		}
		if (pauseSel == 3) text_center(200, 64 + PAUSE_N * 13 + 1, 1, RGBA(255, 190, 120, 255), "Chance a kill shakes the wilds up to your level");
		if (pauseSel == 1) text_center(200, 64 + PAUSE_N * 13 + 1, 1, RGBA(160, 200, 255, 255), "Flash home, then use it again to go back");
		if (pauseSel == 4) { float bx = 120, bw = 160, by = 64 + PAUSE_N * 13 + 3; // spawn-rate slider, tuned rate marked at 25
			rect(bx, by, bw, 4, RGBA(40, 44, 70, 255)); rect(bx, by, bw * S.spawnPct / 100.f, 4, RGBA(255, 150, 90, 255)); rect(bx + bw * 0.25f - 1, by - 3, 2, 10, RGBA(255, 255, 255, 200)); }
		sprintf(b, "Play time %d:%02d", (int)(S.playTime / 3600), ((int)S.playTime / 60) % 60);
		if (pauseSel < 1 || pauseSel > 4) text_center(200, 228, 1, RGBA(160, 160, 190, 255), b);
	}
}

// ------------------------------------------------------------ bottom screen
static int helpScroll;
static const char* tabn[7] = { "Quests", "Bag", "Craft", "Gear", "Map", "Trophies", "Help" };
static const int tabico[7] = { ICO_SCROLL, ICO_BAG, ICO_TOOLS, ICO_SWORDS, ICO_MAP, ICO_TROPHY, ICO_HELP };
#define TAB_H 25
#define TAB_SEL_W 98
static float tab_x(int i) { float ow = (320.f - TAB_SEL_W) / 6; return i <= tab ? i * ow : (i - 1) * ow + TAB_SEL_W; }
static float tab_w(int i) { return i == tab ? TAB_SEL_W : (320.f - TAB_SEL_W) / 6; }
static void keycap(float x, float y, const char* k) {
	circle(x + 6, y + 5, 7, RGBA(30, 32, 44, 255)); circle(x + 6, y + 5, 6, RGBA(214, 218, 230, 255)); // a solid round button
	text(floorf(x + 6 - (text_w(k, 1) - 1) / 2.f + 0.5f), y + 1, 1, RGBA(30, 32, 44, 255), k); // centred in the circle
}
static int gearList[BAG_N], ngear;
static void build_gear_list(void) { ngear = 0; for (int i = 0; i < BAG_N; i++) if (S.bag[i].used) gearList[ngear++] = i; }
static void gear_stat(const Gear* g, char* out) {
	if (g->special == 1) { sprintf(out, "+60%% Luck, +120%% Pickup"); return; }
	if (g->kind == 0 && g->elem) sprintf(out, "Power %d  %c strong vs %c", g->power, 0x80 + elem_icon(g->elem), 0x80 + elem_icon(elem_weak[g->elem] == 0 ? 0 : (g->elem == EL_FIRE ? EL_FROST : g->elem == EL_FROST ? EL_FIRE : g->elem == EL_VENOM ? EL_STORM : EL_VENOM)));
	else if (g->kind == 0) sprintf(out, "Power %d  (no element)", g->power);
	else if (g->kind == 2) sprintf(out, g->elem ? "Defense %d  %c resist" : "Defense %d (-%d%%)", g->power, g->elem ? 0x80 + elem_icon(g->elem) : (int)(100.f * g->power / (g->power + 50.f)));
	else if (g->base == 3) sprintf(out, "+%d %s", g->power, charm_stat[g->base]);
	else sprintf(out, "+%d%% %s", g->power, charm_stat[g->base]);
}
static void button(float x, float y, float w, float h, const char* s, u32 c, bool en) {
	rect(x, y, w, h, en ? c : RGBA(60, 60, 70, 255));
	rect_grad(x, y, w, h/2, RGBA(255, 255, 255, 40), RGBA(255, 255, 255, 0));
	text_center(x + w/2, y + h/2 - 4, 1, en ? RGBA(255, 255, 255, 255) : RGBA(150, 150, 150, 255), s);
}
static void fmt_time(char* b, float t) { int s = (int)ceilf(t); if (s < 0) s = 0; sprintf(b, "%d:%02d", s / 60, s % 60); }
static int quest_list[Q_COUNT + 3], nql, qScroll;
#define QROWS 4
#define QROW_H 43
#define QROW_IN 36
static void build_quest_list(void) {
	nql = 0;
	if (mq_active()) quest_list[nql++] = -2;           // the main story is always pinned on top
	if (EV.on) quest_list[nql++] = -3;                 // a live world event comes next
	if (S.rumbleSeen == 1) quest_list[nql++] = -4;   // the first rumble: go and see Biscuit
	if (S.bActive) quest_list[nql++] = -1;
	for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_ACTIVE && quest_ready(q)) quest_list[nql++] = q;
	for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_ACTIVE && !quest_ready(q)) quest_list[nql++] = q;
}
static bool entry_guided(int id) {
	if (!guideOn) return false;
	if (id == -1) return guideBounty;
	if (id == -2) return !guideBounty && S.tracked == TRACK_MAIN;
	if (id == -3) return !guideBounty && S.tracked == TRACK_EVENT;
	if (id == -4) return !guideBounty && S.tracked == TRACK_RUMBLE;
	return !guideBounty && S.tracked == id;
}
static int quest_icon(int id) {
	if (id == -2) return ICO_STAR;
	if (id == -3) return EV.type == EVT_PORTAL ? ICO_PORTAL : ICO_EVENT;
	if (id == -4) return ICO_CAT;
	if (id == -1) return ICO_CLIPBOARD;
	const QuestDef* d = &questdefs[id];
	switch (d->type) {
	case QT_FORAGE: return item_icon(d->target);
	case QT_KILL: return ICO_SWORDS;
	case QT_DELIVER: return ICO_PACKAGE;
	case QT_BOSS: return ICO_CROWN;
	case QT_KITTEN: return ICO_CAT;
	case QT_LANTERN: return ICO_LANTERN;
	case QT_TOME: return ICO_BOOKB;
	}
	return ICO_SCROLL;
}
// crafting list: story items first, then side-quest items, story parts, craftable, the rest; locked last
static int craft_list[RECIPE_COUNT], ncl, crScroll;
#define CROW_H 29
#define DONE_SHOW 3
// recipes start lower when the 'completed' list is showing
static int craft_y(void) { int n = S.doneN > DONE_SHOW ? DONE_SHOW : S.doneN; return S.doneN ? 76 + 18 + n * 21 + 4 : 76; }
static int craft_rows(void) { return (219 - craft_y()) / CROW_H; }
#define CROW_Y craft_y()
#define CROWS craft_rows()
static void build_craft_list(void) {
	ncl = 0;
	static const int mclass[4] = { 0, 1, 0, 2 };
	for (int pass = 0; pass < 6; pass++) for (int r = 0; r < RECIPE_COUNT; r++) {
		bool un = recipe_unlocked(r), ok = un && can_craft(r); int m = un ? recipe_quest_mark(r) : 0;
		int cls = !un ? 5 : (m ? mclass[m] : (ok ? 3 : 4));
		if (cls == pass) craft_list[ncl++] = r;
	}
}
static int craft_pos(int r) { for (int i = 0; i < ncl; i++) if (craft_list[i] == r) return i; return 0; }
static void quest_badge(float x, float y, int m) {
	u32 c = m == 1 ? RGBA(255, 210, 60, 255) : RGBA(190, 120, 255, 255);
	if (m == 3) { circle(x, y, 3.5f, c); return; }
	circle(x, y, 6, c); text(x - 2, y - 4, 1, RGBA(30, 10, 40, 255), "!");
}
static int bagScroll, bagSel;
static int bagIds[ALL_ITEMS + 2], bagN;
static void build_bag(void) { bagN = 0; if (S.packPts > 0) { bagIds[bagN++] = -1; bagIds[bagN++] = -2; } for (int pass = 0; pass < 2; pass++) for (int i = pass ? 0 : IT_COUNT; i < (pass ? IT_COUNT : ALL_ITEMS); i++) if (IC(i) && i != IT_TONIC) bagIds[bagN++] = i; if (bagSel >= bagN) bagSel = bagN - 1; if (bagSel < 0) bagSel = 0; }
#define GROWS 3

#define SHOP_N 10
static int shopScroll;
static void button(float x, float y, float w, float h, const char* label, u32 col, bool on);
static void render_bank(void) {
	char b[64];
	icon(ICO_LOCK, 8, 4, 20);
	text_shadow(32, 8, 2, RGBA(255, 220, 110, 255), "Strongbox");
	rect(6, 30, 308, 48, RGBA(30, 34, 56, 255));
	icon(ICO_COIN, 14, 36, 14); sprintf(b, "Purse  %d", S.gold); text_shadow(32, 38, 1, RGBA(255, 230, 140, 255), b);
	text(16, 56, 1, RGBA(200, 190, 210, 255), "Purse is at risk (30% dropped if you faint).");
	icon(ICO_LOCK, 176, 36, 14); sprintf(b, "Vault  %lu/%d", (unsigned long)S.bank, bank_cap()); text_shadow(194, 38, 1, RGBA(160, 220, 255, 255), b);
	text(16, 66, 1, RGBA(200, 190, 210, 255), "The vault is safe, and shops in town use it.");
	char up[48]; sprintf(up, "Bigger vault (%d)", bank_cap() + 2000);
	const char* nm[BANK_N] = { "Deposit everything", "Withdraw 100", "Withdraw all", up };
	int cost[BANK_N] = { 0, 0, 0, vault_cost() };
	for (int i = 0; i < BANK_N; i++) {
		float y = 84 + i * 32;
		rect(6, y, 308, 26, i == shopSel ? RGBA(48, 54, 86, 255) : RGBA(30, 34, 56, 255));
		if (i == shopSel) rect_outline(6, y, 308, 26, 2, RGBA(255, 210, 90, 255));
		text_shadow(16, y + 9, 1, RGBA(255, 255, 255, 255), nm[i]);
		if (cost[i]) { sprintf(b, "%d", cost[i]); button(250, y + 4, 58, 18, b, (int)(S.gold + S.bank) >= cost[i] ? RGBA(60, 160, 80, 255) : RGBA(120, 50, 50, 255), true); }
	}
	text_center(160, 225, 1, RGBA(150, 150, 180, 255), "D-pad + A or Y, or tap. B to leave.");
}
static void render_shop(void) {
	char b[64];
	icon(ICO_MONEYBAG, 8, 4, 20);
	text_shadow(32, 8, 2, RGBA(255, 220, 110, 255), "Bram's Wares");
	if (in_town() && S.bank) sprintf(b, "%d+%lu", S.gold, (unsigned long)S.bank); else sprintf(b, "%d", S.gold);
	text_shadow(312 - text_w(b, 1), 11, 1, RGBA(255, 230, 140, 255), b); icon(ICO_COIN, 296 - text_w(b, 1), 7, 14);
	const char* nm[SHOP_N]; static const char* nm0[SHOP_N] = { "Healing Tonic", "Whetstone", "XP Tome", "Grand XP Tome", "Weapon Cache", "Armour Cache", "Charm Cache", "Vigour Boost", "Iron Skin", "Second Wind" };
	for (int i = 0; i < SHOP_N; i++) nm[i] = nm0[i];
	const int ic[SHOP_N] = { ICO_TONIC, ICO_WHET, ICO_BOOKB, ICO_BOOKR, ICO_GIFT, ICO_GIFT, ICO_GIFT, ICO_HEARTS, ICO_SHIELD, ICO_RUNNER };
	char desc[SHOP_N][64]; int cost[SHOP_N] = { tonic_cost(), whetstone_cost(), tome_cost(0), tome_cost(1), cache_cost(), cache_cost(), cache_cost(), boost_cost(S.boostHp), boost_cost(S.boostDef), boost_cost(S.boostSta) };
	sprintf(desc[0], "Heals 50%% HP (you have %d)", IC(IT_TONIC));
	if (S.weapon.upg >= 10) strcpy(desc[1], "Fully upgraded!"); else sprintf(desc[1], "Weapon +%d to +%d, +10%% power", S.weapon.upg, S.weapon.upg + 1);
	sprintf(desc[2], "+%d XP: a quarter level", tome_xp(0));
	sprintf(desc[3], "+%d XP: a whole level", tome_xp(1));
	strcpy(desc[4], "Uncommon or better weapon");
	strcpy(desc[5], "Uncommon or better armour");
	strcpy(desc[6], "Uncommon or better charm");
	strcpy(desc[7], "+5 max HP, for good"); strcpy(desc[8], "+2 defence, for good"); strcpy(desc[9], "+8 stamina, for good");
	char bn[3][32]; sprintf(bn[0], "Vigour Boost (%d)", S.boostHp); sprintf(bn[1], "Iron Skin (%d)", S.boostDef); sprintf(bn[2], "Second Wind (%d)", S.boostSta);
	nm[7] = bn[0]; nm[8] = bn[1]; nm[9] = bn[2];
	if (shopSel < shopScroll) shopScroll = shopSel; if (shopSel >= shopScroll + 7) shopScroll = shopSel - 6;
	for (int i = shopScroll; i < SHOP_N && i < shopScroll + 7; i++) {
		float y = 30 + (i - shopScroll) * 27;
		bool ok = (int)(S.gold + (in_town() ? S.bank : 0)) >= cost[i] && !(i == 1 && S.weapon.upg >= 10) && !((i == 2 || i == 3) && S.lvl >= LVL_CAP);
		rect(6, y, 308, 23, i == shopSel ? RGBA(48, 54, 86, 255) : RGBA(30, 34, 56, 255));
		if (i == shopSel) rect_outline(6, y, 308, 23, 2, RGBA(255, 210, 90, 255));
		icon(ic[i], 11, y + 2, 20);
		text_shadow(38, y + 3, 1, (i == 2 || i == 3) ? RGBA(140, 230, 255, 255) : i >= 7 ? RGBA(150, 255, 160, 255) : RGBA(255, 255, 255, 255), nm[i]);
		text(38, y + 13, 1, RGBA(180, 180, 205, 255), desc[i]);
		sprintf(b, "%d", cost[i]);
		button(250, y + 3, 58, 18, b, ok ? RGBA(60, 160, 80, 255) : RGBA(120, 50, 50, 255), true);
	}
	if (shopScroll > 0) tri2d(305, 26, 313, 26, 309, 21, RGBA(150, 160, 200, 255));
	if (shopScroll + 7 < SHOP_N) tri2d(305, 219, 313, 219, 309, 224, RGBA(150, 160, 200, 255));
	text_center(160, 225, 1, RGBA(150, 150, 180, 255), "D-pad + A or Y, or tap, to buy. B to leave.");
}

// ------------------------------------------------------------ cache opening (gacha)
static u32 rar_c2d(int r, u8 a) { return rgb_to_c2d(rarity_col[r], a); }
static void render_gacha_top(int eye) {
	char b[64];
	float t = G.t, px = popx(eye, 12);
	rect(0, 0, 400, 240, RGBA(6, 6, 16, 200));
	float sh = G.shake > 0 ? G.shake : 0;
	float cx = 200 + px + sinf(gtime * 60) * 6 * sh, cy = 128 + cosf(gtime * 47) * 3 * sh;
	int r = G.phase >= 2 ? G.g.rarity : G.shown;
	u32 rc = rarity_col[r];
	{
		float spd = G.phase == 1 ? 0.4f + 0.4f * r : 0.4f, len = G.phase >= 2 ? 260 : 100 + 30 * r;
		u8 a = (u8)(G.phase >= 2 ? 120 : 40 + 28 * r);
		for (int k = 0; k < 12; k++) {
			float a0 = gtime * spd + k * TAU / 12, a1 = a0 + 0.12f;
			tri2d(cx, cy, cx + cosf(a0) * len, cy + sinf(a0) * len, cx + cosf(a1) * len, cy + sinf(a1) * len, rgb_to_c2d(rc, a));
		}
		circle(cx, cy, 36 + 6 * r + 4 * sinf(gtime * 8), rgb_to_c2d(rc, 90));
	}
	if (G.phase <= 1) {
		// the cache: punch it! it squashes on every hit
		float bounce = G.stepT > 0 ? G.stepT / 0.25f : 0;
		float idle = 0.03f * sinf(gtime * 9);
		float sc = fminf(1, t * 4) * (1 + 0.18f * bounce + idle);
		float w = 84 * sc * (1 + 0.1f * bounce), h = 56 * sc * (1 - 0.12f * bounce);
		u32 body = G.kind == 0 ? RGBA(170, 110, 50, 255) : (G.kind == 2 ? RGBA(120, 130, 150, 255) : RGBA(130, 70, 170, 255));
		rect(cx - w / 2, cy - h / 2 + 8, w, h, body);
		rect(cx - w / 2 - 3, cy - h / 2 - 6, w + 6, 18 * sc, RGBA(90, 60, 30, 255));
		rect(cx - w / 2 + 10, cy - h / 2 + 8, 8 * sc, h, rar_c2d(r, 255));
		rect(cx + w / 2 - 18, cy - h / 2 + 8, 8 * sc, h, rar_c2d(r, 255));
		rect(cx - 9 * sc, cy - 4, 18 * sc, 18 * sc, RGBA(255, 210, 80, 255));
		const char* kn = G.kind == 0 ? "WEAPON CACHE" : (G.kind == 2 ? "ARMOUR CACHE" : "CHARM CACHE");
		text_center(200 + px, 30, 2, RGBA(255, 230, 160, 255), kn);
		text_center(200 + px, 52, 2, rar_c2d(r, 255), rarity_name[r]);
		// hits left
		int n = G.steps; float dw = 14, dx0 = 200 - n * dw / 2 + px;
		for (int i = 0; i < n; i++) circle(dx0 + i * dw + dw / 2, 196, 4.5f, RGBA(255, 220, 110, 255));
		if (((int)(gtime * 4) & 1) || G.stepT > 0) text_center(200 + popx(eye, 6), 210, 2, RGBA(255, 255, 255, 255), "MASH A!");
	} else {
		float k = fminf(1, t * 3);
		float iy = cy - 10 - 20 * k;
		icon(gear_icon(&G.g), cx - 28, iy - 28, 56);
		if (G.g.elem) icon(elem_icon(G.g.elem), cx + 14, iy + 8, 26);
		const char* big = r == R_LEGEND ? "LEGENDARY!!" : (r == R_EPIC ? "EPIC!" : (r == R_RARE ? "RARE!" : rarity_name[r]));
		int bs = r >= R_EPIC ? 4 : 3;
		text_center(200 + popx(eye, 14), 22, bs, rar_c2d(r, 255), big);
		char nm[48]; gear_name(&G.g, nm);
		if (G.phase >= 3 || t > 0.5f) {
			text_center(200, 176, 2, rar_c2d(r, 255), nm);
			const Gear* cur = G.g.kind == 0 ? &S.weapon : (G.g.kind == 2 ? &S.armor : &S.charm);
			if (G.g.kind == 1) sprintf(b, "%s +%d%s", charm_stat[G.g.base % CHARM_BASES], G.g.power, G.g.base == 3 ? "" : "%");
			else { int d = (int)G.g.power - (int)(cur->used ? cur->power : 0); sprintf(b, "%s %d   (%s%d vs equipped)%s%s", G.g.kind == 0 ? "Power" : "Defense", G.g.power, d >= 0 ? "+" : "", d, G.g.elem ? "   " : "", G.g.elem ? elem_name[G.g.elem] : ""); }
			text_center(200, 196, 1, RGBA(235, 235, 245, 255), b);
		}
		if (G.phase == 3) text_center(200, 214, 1, RGBA(255, 220, 110, 255), "A: Equip    B: Keep in bag    Y: Salvage");
	}
	if (G.flash > 0) rect(0, 0, 400, 240, RGBA(255, 255, 255, (u8)(255 * fminf(1, G.flash))));
}
static void render_gacha_bottom(void) {
	char b[48];
	text_center(160, 16, 2, RGBA(255, 220, 110, 255), G.phase == 3 ? "Your loot!" : "Crack it open!");
	if (G.phase == 3) {
		button(20, 60, 280, 38, "Equip now (A)", RGBA(60, 160, 80, 255), true);
		button(20, 108, 280, 38, "Keep in bag (B)", RGBA(70, 90, 140, 255), true);
		sprintf(b, "Salvage for %dg (Y)", salvage_value(&G.g));
		button(20, 156, 280, 38, b, RGBA(180, 120, 40, 255), true);
	} else if (G.phase == 1) {
		float p = G.stepT > 0 ? 6 * G.stepT / 0.25f : 0;
		button(40 + p, 70 + p, 240 - 2 * p, 90 - 2 * p, "HIT! (A)", RGBA(220, 120, 40, 255), true);
		sprintf(b, "%d hit%s to go", G.steps, G.steps == 1 ? "" : "s"); text_center(160, 176, 1, RGBA(220, 220, 240, 255), b);
	} else text_center(160, 110, 1, RGBA(200, 200, 220, 255), "...");
}

static void ingredient(float x, float y, int id, int have, int need, bool raw) {
	char b[16]; sprintf(b, "%d/%d", have > 99 ? 99 : have, need);
	icon(item_icon(id), x, y, 14);
	u32 c = have >= need ? RGBA(130, 255, 150, 255) : (raw ? RGBA(255, 200, 110, 255) : RGBA(255, 130, 130, 255));
	text(x + 16, y + 3, 1, c, b);
	if (item_night(id)) icon(ICO_MOON, x + 16 + text_w(b, 1) + 1, y + 2, 10);
}

int craftForce = -1;
void render_bottom(void) {
	gfx_begin_2d_bottom();
	char b[160];
	rect_grad(0, 0, 320, 240, RGBA(28, 32, 54, 255), RGBA(16, 18, 32, 255));
	if (G.on) { render_gacha_bottom(); return; }
	if (S.perkPicks > 0 && perkOffer[0] >= 0 && !D.on && !shopOpen && levelFlashT < 1.6f) {
		rect(0, 0, 320, 240, RGBA(24, 14, 6, 255));
		text_center(160, 12, 1, RGBA(255, 190, 90, 255), "NEW PERK! Tap one");
		for (int k = 0; k < 3; k++) { int p = perkOffer[k]; if (p < 0) continue; float y = 28 + k * 64; bool sel = k == perkSel;
			rect(10, y, 300, 58, sel ? RGBA(80, 50, 16, 255) : RGBA(40, 32, 44, 255));
			text(20, y + 8, 2, sel ? RGBA(255, 220, 130, 255) : RGBA(240, 235, 240, 255), pk_name[p]);
			char d[64], o[80]; sprintf(d, "%s %s", pk_d1[p], pk_d2[p]); hl(d, o, 80); text(20, y + 38, 1, RGBA(210, 205, 220, 255), o); }
		return;
	}
	if (S.lvlPicks > 0 && !D.on && !shopOpen && levelFlashT < 1.6f) {
		rect(0, 0, 320, 240, RGBA(14, 16, 28, 255));
		text_center(160, 12, 1, RGBA(140, 240, 255, 255), "LEVEL UP! Tap a reward");
		static const char* tt[4] = { "Fortune", "Pack Point", "Hardier", "Endurance" };
		static const int ti[4] = { ICO_MONEYBAG, ICO_BAG, ICO_HEART, ICO_RUNNER };
		for (int k = 0; k < 4; k++) {
			float y = 28 + k * 50; bool sel = k == lvlPickSel;
			rect(10, y, 300, 44, sel ? RGBA(70, 60, 24, 255) : RGBA(34, 40, 66, 255));
			icon(ti[k], 20, y + 8, 28);
			text(58, y + 14, 2, sel ? RGBA(255, 230, 120, 255) : RGBA(235, 235, 245, 255), tt[k]);
		}
		return;
	}
	if (shopOpen) { if (bankMode) render_bank(); else render_shop(); return; }
	if (tab == 3) S.newGear = 0;
	{ static int lastTab = -1; if (tab == 2 && lastTab != 2) { build_craft_list(); if (ncl) craftSel = craft_list[0]; crScroll = 0; } lastTab = tab; if (craftForce >= 0) { craftSel = craftForce; craftForce = -1; } }
	// ---- tab bar: icons, the open tab shows its name
	rect(0, 0, 320, TAB_H, RGBA(14, 16, 28, 255));
	for (int i = 0; i < 7; i++) {
		float x = tab_x(i), w = tab_w(i);
		bool sel = i == tab;
		rect(x + 1, 1, w - 2, TAB_H - 3, sel ? RGBA(255, 205, 90, 255) : RGBA(44, 50, 80, 255));
		if (sel) { icon(tabico[i], x + 5, 3, 18); text(x + 26, 9, 1, RGBA(40, 30, 10, 255), tabn[i]); }
		else icon(tabico[i], x + w / 2 - 9, 3, 18);
		if (i == 3 && S.newGear) { circle(x + w - 6, 6, 4.5f, RGBA(255, 70, 70, 255)); }
		if (i == 2 && !sel) {
			int any = 0; for (int r = 0; r < RECIPE_COUNT; r++) if (can_craft(r)) { int m = recipe_quest_mark(r); if (m == 2 || m == 3) any = 2; else if (!any) any = 1; }
			if (S.readyCache[0] + S.readyCache[1] + S.readyCache[2]) any = 3;
			if (S.doneN) { rect(x + w - 13, 0, 13, 12, RGBA(30, 90, 45, 255)); icon(ICO_CHECK, x + w - 12, 1, 11); }
			else if (any) circle(x + w - 6, 6, any >= 2 ? 4.5f : 3.5f, any == 3 ? RGBA(255, 120, 60, 255) : any == 2 ? RGBA(200, 140, 255, 255) : RGBA(110, 255, 130, 255));
		}
		if (i == 0 && !sel && (mq_ready() || bounty_ready())) circle(x + w - 6, 6, 4, RGBA(110, 255, 130, 255));
	}
	int Y0 = TAB_H + 4;
	if (tab == 0) {
		build_quest_list();
		int nent = nql;
		if (qScroll > nent - QROWS) qScroll = nent - QROWS; if (qScroll < 0) qScroll = 0;
		if (nent == 0) {
			icon(ICO_SCROLL, 148, 70, 24);
			text_center(160, 102, 1, RGBA(200, 200, 220, 255), "No active quests.");
			text_center(160, 116, 1, RGBA(255, 210, 60, 255), "Look for a ! above someone's head.");
		}
		int y = Y0;
		for (int e = qScroll; e < nent && e < qScroll + QROWS; e++) {
			int id = quest_list[e];
			bool isB = id == -1, isM = id == -2, isE = id == -3, isR = id == -4;
			bool rd = isE || isR ? false : isM ? mq_ready() : isB ? bounty_ready() : quest_ready(id);
			bool sel = entry_guided(id);
			u32 bg = isM ? RGBA(58, 30, 86, 255) : isE ? RGBA(70, 30, 20, 255) : isB ? RGBA(60, 44, 24, 255) : RGBA(36, 42, 70, 255);
			if (sel) bg = isM ? RGBA(92, 52, 136, 255) : isB ? RGBA(96, 70, 30, 255) : RGBA(60, 70, 120, 255);
			rect(6, y, 308, QROW_IN, bg);
			if (isM) { rect_outline(6, y, 308, QROW_IN, 1, RGBA(190, 130, 255, 255)); rect(6, y, 4, QROW_IN, RGBA(190, 130, 255, 255)); }
			else if (sel) rect(6, y, 4, QROW_IN, RGBA(255, 210, 90, 255));
			icon(quest_icon(id), 13, y + 6, 24);
			char pr[160];
			const char* title;
			u32 tc = rd ? RGBA(120, 255, 140, 255) : RGBA(255, 220, 110, 255);
			char tbuf2[64];
			if (isM) { mq_progress_text(pr); title = mainq[S.mq].title; if (!rd) tc = RGBA(225, 190, 255, 255); }
			else if (isE) { event_progress_text(pr); title = event_name(); tc = RGBA(255, 170, 110, 255); }
			else if (isR) { hl("Find Biscuit with Tilly in town", pr, 150); title = "The Earth Shook"; tc = RGBA(255, 190, 120, 255); }
			else if (isB) { bounty_text(pr); title = "Bounty"; if (!rd) tc = RGBA(255, 176, 74, 255); }
			else { quest_progress_text(id, pr); title = questdefs[id].title; if (quest_night(id)) { sprintf(tbuf2, "%s " IS_MOON, title); title = tbuf2; } }
			float tx = 44;
			if (isM) { rect(tx, y + 5, text_w("MAIN", 1) + 6, 10, RGBA(150, 90, 230, 255)); text(tx + 3, y + 6, 1, RGBA(255, 255, 255, 255), "MAIN"); tx += text_w("MAIN", 1) + 10; }
			text_shadow(tx, y + 7, 1, tc, title);
			text_shadow(44, y + 22, 1, RGBA(225, 225, 240, 255), pr);
			if (rd) { rect(254, y + 4, 54, 12, RGBA(60, 170, 80, 255)); text_center(281, y + 6, 1, RGBA(255, 255, 255, 255), "READY"); }
			else if (sel) { icon(ICO_PIN, 292, y + 3, 14); }
			y += QROW_H;
		}
		if (qScroll > 0) tri2d(300, 206, 310, 206, 305, 200, RGBA(150, 160, 200, 255));
		if (qScroll + QROWS < nent) tri2d(300, 209, 310, 209, 305, 215, RGBA(150, 160, 200, 255));
		int done = 0; for (int q = 0; q < Q_COUNT; q++) if (QS(q) == QS_DONE) done++;
		sprintf(b, IS_SCROLL " %d/%d   " IS_STAR " %d/%d   " IS_SHARD " %d/5", done, Q_COUNT - 1, S.mq, MQ_COUNT, S.lantern ? 5 : IC(IT_SHARD));
		text_center(160, 208, 1, RGBA(170, 180, 215, 255), b);
	} else if (tab == 1) {
		build_bag(); int* ids = bagIds; int n = bagN;
		int rows = (n + 1) / 2;
		if (bagSel / 2 < bagScroll) bagScroll = bagSel / 2; if (bagSel / 2 >= bagScroll + 6) bagScroll = bagSel / 2 - 5;
		if (bagScroll > rows - 6) bagScroll = rows - 6; if (bagScroll < 0) bagScroll = 0;
		for (int k = bagScroll * 2; k < n && k < (bagScroll + 6) * 2; k++) {
			int i = ids[k], rr = k / 2 - bagScroll;
			float x = 6 + (k & 1) * 157, y = Y0 + rr * 26;
			if (i < 0) { // pouch upgrades that aren't items
				rect(x, y, 151, 21, k == bagSel ? RGBA(90, 76, 30, 255) : RGBA(30, 60, 70, 255));
				icon(i == -1 ? ICO_TONIC : ICO_SWORDS, x + 3, y + 2, 16);
				text_shadow(x + 23, y + 6, 1, RGBA(200, 240, 255, 255), i == -1 ? "Tonic pouch" : "Gear pouch");
				sprintf(b, "%d", i == -1 ? item_cap(IT_TONIC) : gear_cap()); text_shadow(x + 148 - text_w(b, 1), y + 6, 1, RGBA(160, 230, 255, 255), b);
				continue;
			}
			bool fullp = !item_key(i) && item_full(i);
			rect(x, y, 151, 21, k == bagSel ? RGBA(90, 76, 30, 255) : i >= IT_COUNT ? RGBA(48, 36, 70, 255) : RGBA(36, 42, 70, 255));
			icon(item_icon(i), x + 3, y + 2, 16);
			text_shadow(x + 23, y + 6, 1, RGBA(235, 235, 245, 255), itemd(i)->name);
			if (item_night(i)) icon(ICO_MOON, x + 24 + text_w(itemd(i)->name, 1), y + 5, 10);
			if (item_key(i)) sprintf(b, "x%d", IC(i)); else sprintf(b, "%d/%d", IC(i), item_cap(i));
			text_shadow(x + 148 - text_w(b, 1), y + 6, 1, fullp ? RGBA(255, 140, 90, 255) : RGBA(255, 220, 110, 255), b);
		}
		if (bagScroll > 0) tri2d(155, 184, 165, 184, 160, 179, RGBA(150, 160, 200, 255));
		if (bagScroll + 6 < rows) tri2d(155, 182, 165, 182, 160, 188, RGBA(150, 160, 200, 255));
		if (!n) { icon(ICO_BAG, 148, 70, 24); text_center(160, 102, 1, RGBA(180, 180, 200, 255), "Your bag is empty. Go forage!"); }
		rect(6, 192, 308, 26, RGBA(60, 30, 44, 255));
		icon(ICO_TONIC, 12, 195, 20);
		text_shadow(38, 201, 1, RGBA(255, 220, 230, 255), "Tonic");
		sprintf(b, "x%d/%d", IC(IT_TONIC), item_cap(IT_TONIC)); text_shadow(38 + text_w("Tonic ", 1), 201, 1, RGBA(255, 220, 230, 255), b);
		if (S.packPts) { sprintf(b, "%d pack pt%s", S.packPts, S.packPts > 1 ? "s" : ""); text_shadow(128, 201, 1, RGBA(140, 230, 255, 255), b); }
		button(222, 195, 86, 20, "Drink (X)", RGBA(200, 60, 90, 255), IC(IT_TONIC) > 0 && S.hp < P.maxhp);
	} else if (tab == 3) {
		build_gear_list();
		char nm[48];
		const Gear* eq[3] = { &S.weapon, &S.armor, &S.charm };
		const char* slotn[3] = { "Weapon", "Armour", "Charm" };
		const int sloti[3] = { ICO_SWORDS, ICO_SHIELD, ICO_CLOVER };
		for (int k = 0; k < 3; k++) {
			float y = Y0 + k * 30;
			rect(6, y, 308, 25, RGBA(36, 42, 70, 255));
			text(306 - text_w(slotn[k], 1), y + 2, 1, RGBA(120, 130, 160, 255), slotn[k]);
			if (eq[k]->used) {
				rect(6, y, 4, 25, rgb_to_c2d(rarity_col[eq[k]->rarity], 255));
				icon(gear_icon(eq[k]), 13, y + 2, 21);
				if (eq[k]->elem) icon(elem_icon(eq[k]->elem), 25, y + 13, 11);
				gear_name(eq[k], nm); text_shadow(40, y + 3, 1, rgb_to_c2d(rarity_col[eq[k]->rarity], 255), nm);
				gear_stat(eq[k], b); text(40, y + 14, 1, RGBA(210, 210, 228, 255), b);
				{ float ax = 44 + text_w(b, 1); if (eq[k]->pad && eq[k]->pad < AF_COUNT) { text(ax, y + 14, 1, RGBA(200, 160, 255, 255), af_name[eq[k]->pad]); ax += text_w(af_name[eq[k]->pad], 1) + 6; }
				  if (eq[k]->special >= LP_EMBERS && eq[k]->special < LP_END) text(ax, y + 14, 1, RGBA(255, 170, 80, 255), "+power"); }
			} else { icon(sloti[k], 13, y + 2, 21); text(40, y + 9, 1, RGBA(140, 140, 160, 255), k == 1 ? "Empty: Bram sells caches" : "Nothing equipped"); }
		}
		if (scrollGear > ngear - GROWS) scrollGear = ngear - GROWS; if (scrollGear < 0) scrollGear = 0;
		float ly = Y0 + 3 * 30 + 1;
		{ const Gear* sg = selGear >= 0 && S.bag[selGear].used ? &S.bag[selGear] : NULL; // the selected piece's affix and power, in words
		  if (sg && sg->special >= LP_EMBERS && sg->special < LP_END) text(8, ly, 1, RGBA(255, 170, 80, 255), lp_desc[sg->special - LP_EMBERS]);
		  else if (sg && sg->pad && sg->pad < AF_COUNT) { sprintf(b, "%s: %s", af_name[sg->pad], af_desc[sg->pad]); text(8, ly, 1, RGBA(200, 160, 255, 255), b); }
		  else { sprintf(b, IS_BAG " Bag %d/%d", ngear, BAG_N); text(8, ly, 1, RGBA(150, 160, 190, 255), b); } }
		ly += 14;
		for (int r = 0; r < GROWS; r++) {
			int li = scrollGear + r; if (li >= ngear) break;
			int i = gearList[li]; Gear* g = &S.bag[i];
			float y = ly + r * 23;
			rect(6, y, 280, 19, i == selGear ? RGBA(80, 70, 30, 255) : RGBA(32, 38, 62, 255));
			if (i == selGear) rect_outline(6, y, 280, 19, 1, RGBA(255, 210, 90, 255));
			icon(gear_icon(g), 9, y + 2, 15);
			if (g->elem) icon(elem_icon(g->elem), 17, y + 9, 9);
			gear_name(g, nm); text(28, y + 6, 1, rgb_to_c2d(rarity_col[g->rarity], 255), nm);
			const Gear* cur = g->kind == 0 ? &S.weapon : (g->kind == 2 ? &S.armor : NULL);
			bool up = false;
			if (cur) { int d = (int)g->power - (int)(cur->used ? cur->power : 0); up = d > 0; sprintf(b, "%s %d %s%d", g->kind == 0 ? "PWR" : "DEF", g->power, d >= 0 ? "+" : "", d); }
			else sprintf(b, "%s", charm_stat[g->base % CHARM_BASES]);
			text(282 - text_w(b, 1), y + 6, 1, up ? RGBA(120, 255, 140, 255) : RGBA(180, 180, 200, 255), b);
			if (up) icon(ICO_UP, 282 - text_w(b, 1) - 13, y + 4, 11);
		}
		if (ngear == 0) text_center(150, ly + 30, 1, RGBA(150, 150, 170, 255), "Loot goes here. Equip what you like.");
		button(290, ly, 24, GROWS * 23 / 2 - 2, "^", RGBA(60, 70, 110, 255), scrollGear > 0);
		button(290, ly + GROWS * 23 / 2, 24, GROWS * 23 / 2 - 2, "v", RGBA(60, 70, 110, 255), scrollGear < ngear - GROWS);
		bool sel = selGear >= 0 && S.bag[selGear].used;
		button(8, 199, 146, 19, "Equip (Y)", RGBA(60, 160, 80, 255), sel);
		if (sel) sprintf(b, "Salvage +%dg", salvage_value(&S.bag[selGear])); else strcpy(b, "Salvage");
		button(160, 199, 152, 19, b, RGBA(180, 120, 40, 255), sel);
	} else if (tab == 2) {
		build_craft_list();
		// header: crafter level
		icon(ICO_TOOLS, 6, Y0 - 1, 16);
		sprintf(b, "Crafter Lv %d", S.crafterLvl);
		text_shadow(26, Y0 + 3, 1, RGBA(255, 190, 110, 255), b);
		int bx = 26 + text_w(b, 1) + 8;
		if (S.crafterLvl < CRAFTER_MAX) {
			bar(bx, Y0 + 5, 60, 5, (float)S.crafterXp / crafter_xp_need[S.crafterLvl], RGBA(50, 36, 30, 255), RGBA(255, 160, 70, 255), RGBA(255, 220, 150, 255));
			sprintf(b, "%d/%d", S.crafterXp, crafter_xp_need[S.crafterLvl]); text(bx + 66, Y0 + 3, 1, RGBA(200, 170, 140, 255), b);
		} else text(bx, Y0 + 3, 1, RGBA(200, 170, 140, 255), "MAX");
		int rc = S.readyCache[0] + S.readyCache[1] + S.readyCache[2];
		if (rc) { float p = 1 + 0.1f * sinf(gtime * 8); icon(ICO_GIFT, 248, Y0 - 2, 18 * p); sprintf(b, "x%d Y:open", rc); text(268, Y0 + 3, 1, RGBA(255, 200, 120, 255), b); }

		// queue: four slots, the first one is being worked on
		float qy = Y0 + 19;
		for (int k = 0; k < CRAFT_SLOTS; k++) {
			float x = 6 + k * 77.5f;
			const CraftJob* j = &S.jobs[k];
			rect(x, qy, 74, 21, j->state ? (k == 0 ? RGBA(70, 52, 30, 255) : RGBA(44, 40, 40, 255)) : RGBA(26, 28, 44, 255));
			if (!j->state) { icon(ICO_HOURGLASS, x + 30, qy + 4, 13); continue; }
			icon(recipe_icon(j->r), x + 3, qy + 2, 17);
			if (k == 0) { fmt_time(b, j->left); text(x + 24, qy + 4, 1, RGBA(255, 230, 170, 255), b); rect(x + 24, qy + 15, 46, 3, RGBA(30, 20, 10, 255)); rect(x + 24, qy + 15, 46 * (1 - j->left / j->total), 3, RGBA(255, 180, 80, 255)); }
			else { fmt_time(b, j->total); text(x + 24, qy + 7, 1, RGBA(170, 160, 150, 255), b); }
		}
		// finished crafts: tick them off one by one, or all at once
		if (S.doneN) {
			float dy = 74;
			icon(ICO_CHECK, 8, dy, 14);
			sprintf(b, "Completed (%d)", S.doneN); text_shadow(26, dy + 4, 1, RGBA(140, 255, 160, 255), b);
			button(200, dy - 1, 114, 16, "Tick all", RGBA(60, 150, 80, 255), true);
			for (int k = 0; k < S.doneN && k < DONE_SHOW; k++) {
				float y = dy + 18 + k * 21;
				const Recipe* c = &recipes[S.doneR[k]];
				rect(6, y, 308, 18, RGBA(28, 58, 38, 255));
				icon(recipe_icon(S.doneR[k]), 12, y + 1, 16);
				if (c->out == CR_ITEM && c->amount > 1) sprintf(b, "%s x%d", c->name, c->amount); else strcpy(b, c->name);
				text(34, y + 5, 1, RGBA(225, 245, 230, 255), b);
				text(c->station ? 196 : 220, y + 5, 1, RGBA(140, 200, 150, 255), c->out == CR_CACHE ? "ready: Y" : c->station ? (c->station == ST_FORGE ? "at the Forge" : "at Apothecary") : "in bag");
				rect(286, y + 2, 24, 14, RGBA(60, 150, 80, 255)); icon(ICO_CHECK, 291, y + 2, 14);
			}
			if (S.doneN > DONE_SHOW) { sprintf(b, "+%d more", S.doneN - DONE_SHOW); text(140, dy + 4, 1, RGBA(140, 200, 150, 255), b); }
		}
		int cp = craft_pos(craftSel);
		if (cp < crScroll) crScroll = cp; if (cp >= crScroll + CROWS) crScroll = cp - CROWS + 1;
		if (crScroll > ncl - CROWS) crScroll = ncl - CROWS; if (crScroll < 0) crScroll = 0;
		for (int row = 0; row < CROWS; row++) {
			int li = crScroll + row; if (li >= ncl) break;
			int r = craft_list[li];
			const Recipe* c = &recipes[r];
			float y = CROW_Y + row * CROW_H;
			bool un = recipe_unlocked(r), ok = un && can_craft(r), sel = r == craftSel;
			int qm = un ? recipe_quest_mark(r) : 0;
			u32 bg = !un ? RGBA(24, 26, 40, 255) : ok ? RGBA(30, 70, 44, 255) : RGBA(34, 40, 66, 255);
			if (sel) bg = !un ? RGBA(44, 44, 56, 255) : ok ? RGBA(46, 104, 62, 255) : RGBA(70, 64, 34, 255);
			rect(6, y, 308, CROW_H - 5, bg);
			if (ok) { rect(6, y, 4, CROW_H - 5, RGBA(110, 255, 130, 255)); rect_grad(10, y, 60, CROW_H - 5, RGBA(120, 255, 140, 50), RGBA(120, 255, 140, 0)); }
			if (sel) rect_outline(6, y, 308, CROW_H - 5, 1, ok ? RGBA(140, 255, 160, 255) : RGBA(255, 210, 90, 255));
			icon(un ? recipe_icon(r) : ICO_LOCK, 12, y + 2, 19);
			if (c->tier >= 2 && un) { rect(24, y + 13, 11, 8, RGBA(230, 170, 60, 255)); text(25, y + 13, 1, RGBA(60, 30, 0, 255), "2"); }
			text_shadow(38, y + 3, 1, !un ? RGBA(120, 120, 135, 255) : ok ? RGBA(150, 255, 165, 255) : RGBA(225, 225, 240, 255), c->name);
			float nx = 38 + text_w(c->name, 1) + 9;
			if (qm) { quest_badge(nx, y + 7, qm); nx += 12; }
			if (queued_count(c->out == CR_ITEM ? c->arg : -1) && c->out == CR_ITEM) icon(ICO_HOURGLASS, nx - 3, y + 1, 11);
			if (c->station) icon(c->station == ST_FORGE ? ICO_ANVIL : ICO_POTION, 292, y + 13, 10);
			if (!un) {
				if (c->station && S.crafterLvl >= c->unlock) sprintf(b, c->stage >= 2 ? "Needs %s fully restored" : "Needs %s repaired", station_name(c->station));
				else sprintf(b, "Unlocks at Crafter Lv %d", c->unlock);
				text(38, y + 13, 1, RGBA(120, 110, 100, 255), b); continue;
			}
			const char* ds = c->desc; u32 dc = RGBA(150, 155, 185, 255);
			if (ok && recipe_uses_raw(r)) { ds = "Makes parts from raw"; dc = RGBA(255, 210, 120, 255); }
			else if (qm == 3) { ds = "Story part"; dc = RGBA(200, 160, 255, 255); }
			char db[48]; strncpy(db, ds, 47); db[47] = 0;
			int maxw = 196 - 38;
			if (text_w(db, 1) > maxw) { int L = strlen(db); while (L > 2 && text_w(db, 1) > maxw) { db[--L] = 0; db[L-1] = '.'; } }
			text(38, y + 13, 1, dc, db);
			bool raw = ok && c->tier >= 2;
			ingredient(200, y + 1, c->inA, IC(c->inA), c->nA, raw);
			ingredient(254, y + 1, c->inB, IC(c->inB), c->nB, raw);
			{ char tb[12]; fmt_time(tb, 0); (void)tb; }
		}
		if (crScroll > 0) tri2d(155, CROW_Y - 2, 165, CROW_Y - 2, 160, CROW_Y - 6, RGBA(150, 160, 200, 255));
		if (crScroll + CROWS < ncl) tri2d(155, CROW_Y + CROWS * CROW_H - 4, 165, CROW_Y + CROWS * CROW_H - 4, 160, CROW_Y + CROWS * CROW_H + 1, RGBA(150, 160, 200, 255));
	} else if (tab == 4 && dunOn) {
		draw_dun_map(6, Y0, 168, false);
		float lx = 184, ly = Y0 + 2; char b2[48];
		text(lx, ly, 1, DG.kind ? RGBA(200, 160, 255, 255) : RGBA(255, 215, 150, 255), dun_name()); ly += 14;
		{ static const char* rn[3] = { "Hunt", "Arena", "Delve" };
		  if (DG.kind) sprintf(b2, DG.rtype == RT_DELVE ? "%s, floor %d" : "%s", rn[DG.rtype], DG.floor); else sprintf(b2, "Floor %d of %d", DG.floor, DG.floors);
		  text(lx, ly, 1, RGBA(220, 220, 235, 255), b2); ly += 14; }
		if (DG.kind) { sprintf(b2, "Tier %d", DG.tier); text(lx, ly, 1, RGBA(220, 220, 235, 255), b2); ly += 14; if (DG.mod) { text(lx, ly, 1, RGBA(255, 150, 120, 255), rift_mods[DG.mod]); ly += 14; } }
		ly += 6;
		circle(lx + 4, ly + 4, 3, RGBA(255, 240, 190, 255)); text(lx + 12, ly, 1, RGBA(200, 200, 215, 255), "Way out"); ly += 13;
		circle(lx + 4, ly + 4, 3, RGBA(120, 230, 255, 255)); text(lx + 12, ly, 1, RGBA(200, 200, 215, 255), "Stairs down"); ly += 13;
		circle(lx + 4, ly + 4, 3, RGBA(255, 80, 70, 255)); text(lx + 12, ly, 1, RGBA(200, 200, 215, 255), "Champion"); ly += 13;
		rect(lx + 2, ly + 2, 4, 4, RGBA(255, 200, 60, 255)); text(lx + 12, ly, 1, RGBA(200, 200, 215, 255), "Chest"); ly += 13;
	} else if (tab == 4) {
		float mx = 6, my = Y0, ms = 168;
		rect(mx - 2, my - 2, ms + 4, ms + 4, RGBA(10, 12, 20, 255));
		minimap_draw(mx, my, ms);
		#define MAPX(wx) (mx + ((wx) + WORLD_HALF) / (2*WORLD_HALF) * ms)
		#define MAPZ(wz) (my + ((wz) + WORLD_HALF) / (2*WORLD_HALF) * ms)
		circle(MAPX(0), MAPZ(0), 3, S.lantern ? RGBA(255, 220, 90, 255) : RGBA(140, 150, 180, 255));
		for (int i = 0; i < NPC_COUNT; i++) {
			int m = npc_marker(i);
			u32 c = m == 1 ? RGBA(255, 210, 60, 255) : m == 2 ? RGBA(110, 255, 130, 255) : (m >= 4 ? RGBA(200, 140, 255, 255) : RGBA(230, 230, 240, 255));
			circle(MAPX(npcdefs[i].x), MAPZ(npcdefs[i].z), (m && m != 3 && m != 6) ? 3.5f : 2, c);
		}
		static const int bq[5][2] = { {EN_GLOOPA, Q_E2}, {EN_PINCER, Q_G2}, {EN_BRAMBLE, Q_F2}, {EN_CROAK, Q_O2}, {EN_COLOSSUS, Q_R2} };
		for (int k = 0; k < 5; k++) if (QS(bq[k][1]) == QS_ACTIVE && !QP(bq[k][1])) {
			int z = endefs[bq[k][0]].zone; float x = MAPX(arena_pos[z][0]), y = MAPZ(arena_pos[z][1]);
			icon(ICO_CROWN, x - 7, y - 7, 14);
		}
		if (QS(Q_T0) == QS_ACTIVE) for (int k = 0; k < 3; k++) if (!(S.kittens & (1 << k))) {
			float x = MAPX(kittenPos[k][0] + 3), y = MAPZ(kittenPos[k][1] - 2);
			for (int a = 0; a < 12; a++) { float an = TAU * a / 12 + gtime; rect(x + cosf(an)*9 - 1, y + sinf(an)*9 - 1, 2, 2, RGBA(255, 160, 220, 255)); }
		}
		for (int b = 0; b < BLD_COUNT; b++) icon(b == 0 ? ICO_ANVIL : ICO_POTION, MAPX(blddefs[b].x) - 6, MAPZ(blddefs[b].z) - 6, 12);
		for (int g = 0; g < ngates; g++) if (zone_open(gates[g].zone) && gate_open(g)) { float x = MAPX(gates[g].x), y = MAPZ(gates[g].z);
			if (gates[g].kind) { circle(x, y, 3.5f, RGBA(190, 120, 255, 255)); circle(x, y, 1.5f, RGBA(30, 10, 50, 255)); }
			else { rect(x - 3.5f, y - 3.5f, 7, 7, (S.depDone >> gates[g].zone) & 1 ? RGBA(255, 210, 70, 255) : RGBA(150, 120, 90, 255)); rect(x - 1.5f, y - 1.5f, 3, 3, RGBA(20, 14, 10, 255)); } }
		if (EV.on) {
			float pz = 1 + 0.15f * sinf(gtime * 6);
			icon(EV.type == EVT_PORTAL ? ICO_PORTAL : ICO_EVENT, MAPX(EV.x) - 8 * pz, MAPZ(EV.z) - 8 * pz, 16 * pz);
			if (EV.type == EVT_PORTAL) for (int k = 0; k < EV.nkeys; k++) if (!(EV.prog & (1 << k))) icon(ICO_KEY, MAPX(EV.kx[k]) - 5, MAPZ(EV.kz[k]) - 5, 10);
		}
		if (guideOn && guideValid) icon(ICO_PIN, MAPX(guideX) - 6, MAPZ(guideZ) - 13, 13);
		float px = MAPX(P.p.x), pz = MAPZ(P.p.z);
		float fx = sinf(P.yaw), fz = cosf(P.yaw);
		tri2d(px + fx*7, pz + fz*7, px - fx*4 + fz*4, pz - fz*4 - fx*4, px - fx*4 - fz*4, pz - fz*4 + fx*4, RGBA(255, 70, 70, 255));
		float lx = 182; int ly = Y0 + 2;
		static const u32 zc[Z_COUNT] = { 0x9FDA74, 0x7CC75A, 0xE6D59A, 0xA9B888, 0x3F8F46, 0x6B7F3A };
		for (int z = 0; z < Z_COUNT; z++) {
			bool v = S.zonesVisited & (1 << z);
			rect(lx, ly, 8, 8, rgb_to_c2d(zc[z], 255));
			text(lx + 12, ly, 1, v ? RGBA(230, 230, 240, 255) : RGBA(110, 110, 130, 255), v ? zone_names[z] : "???");
			if (v && zone_elem[z]) icon(elem_icon(zone_elem[z]), lx + 14 + text_w(zone_names[z], 1), ly - 2, 11);
			ly += 13;
		}
		ly += 6;
		circle(lx + 4, ly + 4, 3.5f, RGBA(255, 210, 60, 255)); text(lx + 12, ly, 1, RGBA(200, 200, 220, 255), "New quest"); ly += 13;
		circle(lx + 4, ly + 4, 3.5f, RGBA(110, 255, 130, 255)); text(lx + 12, ly, 1, RGBA(200, 200, 220, 255), "Turn in"); ly += 13;
		circle(lx + 4, ly + 4, 3.5f, RGBA(200, 140, 255, 255)); text(lx + 12, ly, 1, RGBA(200, 200, 220, 255), "Main story"); ly += 13;
		icon(ICO_CROWN, lx - 2, ly - 2, 12); text(lx + 12, ly, 1, RGBA(200, 200, 220, 255), "Boss"); ly += 13;
		icon(ICO_PIN, lx - 1, ly - 2, 11); text(lx + 12, ly, 1, RGBA(200, 200, 220, 255), "Guide"); ly += 13;
		int h = (int)(S.tod * 24 + 6) % 24;
		icon(night_now() ? ICO_MOON : ICO_SUN, lx - 2, 196, 14);
		sprintf(b, "%02d:%02d %s", h, (int)(S.tod * 24 * 60) % 60, night_now() ? "Night" : "Day");
		text(lx + 16, 200, 1, RGBA(160, 170, 210, 255), b);
	} else if (tab == 5) {
		int got = 0; for (int i = 0; i < A_COUNT; i++) if (S.ach[i >> 5] & (1u << (i & 31))) got++;
		icon(ICO_TROPHY, 6, Y0 - 1, 16);
		sprintf(b, "%d/%d", got, A_COUNT);
		text_shadow(26, Y0 + 3, 1, RGBA(255, 220, 110, 255), b);
		bar(80, Y0 + 4, 200, 6, (float)got / A_COUNT, RGBA(40, 40, 60, 255), RGBA(255, 190, 60, 255), RGBA(255, 240, 160, 255));
		for (int r = 0; r < 6; r++) {
			int i = scrollAch + r; if (i >= A_COUNT) break;
			bool u = S.ach[i >> 5] & (1u << (i & 31));
			float y = Y0 + 18 + r * 28;
			rect(6, y, 280, 24, u ? RGBA(54, 50, 30, 255) : RGBA(30, 34, 52, 255));
			if (u) icon(ICO_TROPHY, 10, y + 3, 16); else icon(ICO_LOCK, 10, y + 3, 16);
			text(32, y + 3, 1, u ? RGBA(255, 230, 150, 255) : RGBA(150, 150, 170, 255), achdefs[i].name);
			text(32, y + 13, 1, u ? RGBA(210, 210, 220, 255) : RGBA(110, 110, 130, 255), achdefs[i].desc);
		}
		button(290, Y0 + 16, 24, 82, "^", RGBA(60, 70, 110, 255), scrollAch > 0);
		button(290, Y0 + 102, 24, 82, "v", RGBA(60, 70, 110, 255), scrollAch < A_COUNT - 6);
	} else if (tab == 6) {
		int y = Y0 + 2;
		const char* lab[8] = { "Monsters defeated", "Things foraged", "Chests opened", "Critical hits", "Gold earned", "Bounties done", "Things crafted", "Play time" };
		const int li[8] = { ICO_SWORDS, ICO_HERB, ICO_GIFT, ICO_FIST, ICO_COIN, ICO_CLIPBOARD, ICO_TOOLS, ICO_CLOCK };
		char val[8][24];
		sprintf(val[0], "%lu", (unsigned long)S.sKills); sprintf(val[1], "%lu", (unsigned long)S.sForage); sprintf(val[2], "%lu/%d", (unsigned long)S.sChests, nchests);
		sprintf(val[3], "%lu", (unsigned long)S.sCrits); sprintf(val[4], "%lu", (unsigned long)S.sGoldTotal); sprintf(val[5], "%lu", (unsigned long)S.sBounties);
		sprintf(val[6], "%lu", (unsigned long)S.sCrafts); sprintf(val[7], "%d:%02d", (int)(S.playTime / 3600), ((int)S.playTime / 60) % 60);
		int rows = tabHelpOpen ? 0 : 8;
		for (int i = 0; i < rows; i++) { icon(li[i], 12, y - 2, 13); text(30, y + 1, 1, RGBA(200, 200, 220, 255), lab[i]); text(306 - text_w(val[i], 1), y + 1, 1, RGBA(255, 255, 255, 255), val[i]); y += 17; }
		y += 5;
		rect(6, y, 308, 18, RGBA(50, 60, 100, 255));
		icon(ICO_HELP, 10, y + 2, 14);
		text_shadow(28, y + 5, 1, RGBA(255, 255, 255, 255), tabHelpOpen ? "How it works  (tap or Y to close)  v" : "How it works  (tap or Y to open)  >");
		y += 22;
		if (tabHelpOpen) { // one short line each, scrolls with the D-pad
			static const char* hl_[] = {
				"\x01" "Circle Pad" "\x03" "  move",
				"\x01" "A" "\x03" "  attack / talk / gather",
				"\x01" "B" "\x03" "  dodge roll",
				"\x01" "X" "\x03" "  drink a Healing Tonic",
				"\x01" "Y" "\x03" "  use things in menus",
				"\x01" "L / R" "\x03" "  turn the camera",
				"\x01" "SELECT" "\x03" "  switch camera",
				"\x01" "D-Pad" "\x03" "  tabs and lists",
				"\x01" "START" "\x03" "  pause, difficulty, camera",
				"",
				"Purple ! is the main story.",
				"Yellow ! is a quest. " IS_CHECK " means hand it in.",
				"Bram's XP Tomes beat brawls.",
				"No healing over time: drink Tonics.",
				"Crafts take 1-5 minutes. Queue up to 4.",
				"Night " IS_MOON " brings moonblooms and moths.",
				"Opening a cache? Mash A!",
				"Shop fast: A at the " IS_COIN " on Bram's cart.",
				"Town is safe: monsters lose interest.",
				"Each person gives one quest at a time.",
				"The purple story introduces everyone.",
				"Each material has its own pouch. Level",
				"up for pack points to make pouches bigger.",
				"Bag tab: [Y] sells 5 (or spends a point).",
				"Gold you carry is at risk: faint and 30%",
				"drops where you fell. Bank it in Bram's",
				"strongbox (west end of his cart).",
				"START > Return Stone: home and back.",
				"Drops vanish after 5 minutes.",
				"Attacks and rolls use stamina (green bar).",
				"RED on the ground: a big hit lands there.",
				"Move or roll! BLUE shimmer: they're",
				"guarding. Stop swinging, or break it",
				"with Fire or a heavy blow.",
				"Hold [A] after a swing: heavy blow.",
				"Roll just as a hit lands: PERFECT dodge",
				"(slow-mo + a guaranteed crit).",
				"Crabs block in front: go round them,",
				"or hit them right after they swing.",
				"Fire burns. Frost slows, then freezes.",
				"Storm interrupts wind-ups and arcs.",
				"Venom poisons and weakens their hits.",
				"Bigger foe + red ring = above your level.",
				"Some foes shoot: roll through the shots.",
				"A kill can make the earth rumble: the",
				"wilds then catch up to your level.",
				"",
				"Foe levels rise the further from town",
				"you go: about +5 by the far shores.",
				"White = your level. Orange/red: tougher.",
				"purple " IS_SKULL " = 4+ above you. Run!",
				"Each zone's boss drops the element",
				"the next zone is weak to.",
				"",
				"Seals wall off each wild zone:",
				"- South: ice wall. Break with " IS_FIRE,
				"- North: thorn wall. Break with " IS_BOLT,
				"- West: storm reeds. Break with " IS_SNAKE,
				"- East: fire ward. Break with " IS_ICE,
				"Equip the right weapon, walk up, [A].",
				"The Forge can infuse a weapon too.",
				"",
				"Loot: rarer gear rolls an affix",
				"(purple) that changes how you play.",
				"Legendaries also carry a power (orange).",
				"Select a bag item to read it.",
				"Bosses and champions burst with loot.",
				"Every third level: pick a perk.",
				"Whirlwind is used with [ZR].",
				"",
				"Depths (stone arch): open with the story.",
				"- 5 floors. Floors you reach are saved.",
				"- Floor 2: a locked door. Read the note,",
				"  then ask the islander it names.",
				"- Levers, and stones to push onto plates.",
				"- A champion and a journal page at the end.",
				"- Fainting below drops gold at the door.",
				"Rifts (purple tears): after King Pincer.",
				"- Pick a tier: higher = tougher, richer.",
				"- Hunt: fill the bar, kill the Guardian,",
				"  beat the clock to unlock higher tiers.",
				"- Arena: 5 waves. Leave between waves.",
				"- Delve: deeper = bigger haul. Faint",
				"  and the rift keeps it all.",
				"- Shrines give a short power-up.",
				"",
				"Elements: " IS_FIRE " beats " IS_ICE ", " IS_ICE " beats " IS_FIRE ",",
				IS_SNAKE " beats " IS_BOLT ", " IS_BOLT " beats " IS_SNAKE ".",
				"Armour wards block their element.",
				"",
				"Damage numbers show how a hit went:",
				"48 " IS_EVENT IS_FIRE "  weak to fire",
				"12 " IS_SHIELDOK IS_SNAKE "  it blocks venom",
				"3 " IS_NO IS_ICE "  immune to frost",
				"-9 " IS_SHIELDOK IS_FIRE "  your ward blocks fire",
				"-30 " IS_ANGER IS_FIRE "  fire hits you hard",
			};
			const int nh = sizeof hl_ / sizeof hl_[0], vis = (int)((218 - y) / 13);
			if (helpScroll > nh - vis) helpScroll = nh - vis; if (helpScroll < 0) helpScroll = 0;
			for (int i = 0; i < vis && helpScroll + i < nh; i++) text(12, y + i * 13, 1, RGBA(215, 220, 240, 255), hl_[helpScroll + i]);
			if (helpScroll > 0) tri2d(300, y + 6, 310, y + 6, 305, y, RGBA(150, 160, 200, 255));
			if (helpScroll + vis < nh) tri2d(300, 208, 310, 208, 305, 214, RGBA(150, 160, 200, 255));
		}
	}
	// footer
	rect(0, 222, 320, 18, RGBA(10, 12, 22, 255));
	sprintf(b, "Lv %d", S.lvl); text(6, 227, 1, RGBA(140, 200, 255, 255), b);
	{ float cx = 6 + text_w(b, 1) + 6; icon(ICO_COIN, cx, 224, 12); sprintf(b, "%d", S.gold); text(cx + 14, 227, 1, RGBA(255, 220, 90, 255), b); }
	{
		const char* yv = NULL;
		if (tab == 0) yv = "Guide"; else if (tab == 2) yv = (S.readyCache[0] + S.readyCache[1] + S.readyCache[2]) ? "Open cache" : "Craft"; else if (tab == 3) yv = "Equip"; else if (tab == 6) yv = tabHelpOpen ? "Close" : "Open";
		if (yv) { keycap(112, 225, "Y"); text(126, 227, 1, RGBA(210, 220, 240, 255), yv); }
		else if (tab == 1) { keycap(112, 225, "Y"); text(126, 227, 1, RGBA(210, 220, 240, 255), S.packPts ? "Upgrade" : "Sell 5"); }
	}
	{
		const char* zn = dunOn ? dun_name() : curZone >= 0 ? zone_names[curZone] : "";
		float zx = 314 - text_w(zn, 1);
		text(zx, 227, 1, RGBA(170, 180, 210, 255), zn);
		icon(night_now() ? ICO_MOON : ICO_SUN, zx - 15, 224, 12);
	}
}

// select a quest-tab entry; tapping the guided one again turns the guide off
static void select_entry(int e, bool toggle) {
	build_quest_list();
	if (e < 0 || e >= nql) return;
	int id = quest_list[e];
	if (toggle && entry_guided(id)) { guideOn = false; sfx(SFX_BLIP); return; }
	if (id == -1) guideBounty = true;
	else { guideBounty = false; S.tracked = id == -2 ? TRACK_MAIN : id == -3 ? TRACK_EVENT : id == -4 ? TRACK_RUMBLE : id; }
	guideOn = true;
	sfx(SFX_PICK);
}
void ui_dpad(int dir) {
	if (shopOpen) { int n = bankMode ? BANK_N : SHOP_N; shopSel = (shopSel + dir + n) % n; sfx(SFX_BLIP); return; }
	if (tab == 2) { build_craft_list(); int p = craft_pos(craftSel); p = (p + dir + ncl) % ncl; craftSel = craft_list[p]; sfx(SFX_BLIP); return; }
	if (tab == 0) {
		build_quest_list();
		int nent = nql;
		if (nent == 0) return;
		int cur = -1;
		for (int i = 0; i < nql; i++) if (entry_guided(quest_list[i])) cur = i;
		int nx = cur < 0 ? (dir > 0 ? 0 : nent - 1) : (cur + dir + nent) % nent;
		select_entry(nx, false);
		if (nx < qScroll) qScroll = nx;
		if (nx >= qScroll + QROWS) qScroll = nx - QROWS + 1;
	} else if (tab == 1) {
		build_bag(); if (bagN) { bagSel = (bagSel + dir + bagN) % bagN; sfx(SFX_BLIP); }
	} else if (tab == 3) {
		build_gear_list();
		if (!ngear) return;
		int cur = -1; for (int i = 0; i < ngear; i++) if (gearList[i] == selGear) cur = i;
		int nx = cur < 0 ? 0 : cur + dir; if (nx < 0) nx = 0; if (nx >= ngear) nx = ngear - 1;
		selGear = gearList[nx];
		if (nx < scrollGear) scrollGear = nx;
		if (nx >= scrollGear + GROWS) scrollGear = nx - GROWS + 1;
		sfx(SFX_BLIP);
	} else if (tab == 6) {
		if (tabHelpOpen) { helpScroll += dir * 3; sfx(SFX_BLIP); }
	} else if (tab == 5) {
		scrollAch += dir * 3; if (scrollAch < 0) scrollAch = 0; if (scrollAch > A_COUNT - 6) scrollAch = A_COUNT - 6;
		sfx(SFX_BLIP);
	}
}

void ui_menu_y(void) {
	if (tab == 0) {
		build_quest_list();
		if (!nql) return;
		int cur = -1; for (int i = 0; i < nql; i++) if (entry_guided(quest_list[i])) cur = i;
		select_entry(cur < 0 ? 0 : cur, true); // toggles the guide on the highlighted quest
	} else if (tab == 2) {
		if (S.readyCache[0] + S.readyCache[1] + S.readyCache[2]) open_ready_cache(); else craft(craftSel);
	} else if (tab == 3) {
		if (selGear >= 0 && S.bag[selGear].used) { equip_bag(selGear); selGear = -1; }
	} else if (tab == 6) { tabHelpOpen = !tabHelpOpen; sfx(SFX_BLIP); }
	else if (tab == 1) { build_bag(); if (bagN) { int id = bagIds[bagSel]; if (S.packPts > 0 && (id < 0 || !item_key(id))) pouch_up(id); else if (id >= 0) sell_item(id); } }
}
void ui_tap(int x, int y) {
	if (S.perkPicks > 0 && perkOffer[0] >= 0 && !D.on && !shopOpen && levelFlashT < 1.6f) { if (y >= 28 && y < 220) { int k = (y - 28) / 64; if (k > 2) k = 2; if (k == perkSel) perk_pick(k); else { perkSel = k; sfx(SFX_BLIP); } } return; }
	if (S.lvlPicks > 0 && !D.on && !shopOpen && levelFlashT < 1.6f) { if (y >= 28 && y < 228) { int k = (y - 28) / 50; if (k > 3) k = 3; if (k == lvlPickSel) level_pick(k); else { lvlPickSel = k; sfx(SFX_BLIP); } } return; }
	if (G.on) {
		if (G.phase == 1 && y >= 60 && y < 170) gacha_hit();
		else if (G.phase == 3) { if (y >= 60 && y < 98) gacha_choice(0); else if (y >= 108 && y < 146) gacha_choice(1); else if (y >= 156 && y < 194) gacha_choice(2); }
		return;
	}
	if (shopOpen && bankMode) { for (int i = 0; i < BANK_N; i++) { float by = 84 + i * 32; if (y >= by && y < by + 26) { shopSel = i; shop_buy(i); } } return; }
	if (shopOpen) {
		for (int i = 0; i < 7; i++) { float by = 30 + i * 27; if (y >= by && y < by + 23 && x >= 6 && x < 314 && shopScroll + i < SHOP_N) { shopSel = shopScroll + i; shop_buy(shopSel); } }
		return;
	}
	if (y < TAB_H) { for (int i = 0; i < 7; i++) if (x >= tab_x(i) && x < tab_x(i) + tab_w(i)) { tab = i; sfx(SFX_BLIP); return; } return; }
	int Y0 = TAB_H + 4;
	if (tab == 0) {
		build_quest_list();
		for (int e = qScroll; e < nql && e < qScroll + QROWS; e++) {
			int yy = Y0 + (e - qScroll) * QROW_H;
			if (y < yy || y >= yy + QROW_IN) continue;
			select_entry(e, true);
		}
	} else if (tab == 1) {
		if (x >= 222 && y >= 195 && y < 215) { use_tonic(); return; }
		build_bag();
		int Y0b = TAB_H + 4, rr = (y - Y0b) / 26, k = (bagScroll + rr) * 2 + (x >= 160);
		if (y >= Y0b && rr < 6 && k < bagN) { if (k == bagSel) { int id = bagIds[k]; if (S.packPts > 0 && (id < 0 || !item_key(id))) pouch_up(id); else if (id >= 0) sell_item(id); } else { bagSel = k; sfx(SFX_BLIP); } }
	} else if (tab == 3) {
		build_gear_list();
		float ly = Y0 + 3 * 30 + 1 + 14;
		if (x >= 290 && y >= ly && y < ly + GROWS * 23 / 2) { scrollGear--; if (scrollGear < 0) scrollGear = 0; sfx(SFX_BLIP); return; }
		if (x >= 290 && y >= ly + GROWS * 23 / 2 && y < ly + GROWS * 23) { scrollGear++; sfx(SFX_BLIP); return; }
		if (y >= ly && y < ly + GROWS * 23 && x < 286) { int r = (int)((y - ly) / 23), li = scrollGear + r; if (li < ngear) { selGear = gearList[li]; sfx(SFX_BLIP); } return; }
		if (y >= 199 && y < 218 && selGear >= 0) {
			if (x < 154) { equip_bag(selGear); selGear = -1; }
			else { salvage_bag(selGear); selGear = -1; }
		}
	} else if (tab == 2) {
		if (S.doneN) {
			if (y >= 73 && y < 91 && x >= 200) { ack_craft(-1); return; }
			for (int k = 0; k < S.doneN && k < DONE_SHOW; k++) { float ry = 74 + 18 + k * 21; if (y >= ry && y < ry + 18) { ack_craft(k); return; } }
		}
		if (y < 70 && x >= 240 && (S.readyCache[0] + S.readyCache[1] + S.readyCache[2])) { open_ready_cache(); return; }
		build_craft_list();
		for (int row = 0; row < CROWS; row++) { int li = crScroll + row; if (li >= ncl) break; float ry = CROW_Y + row * CROW_H; if (y >= ry && y < ry + CROW_H - 5) { int r = craft_list[li]; if (craftSel == r) craft(r); else { craftSel = r; sfx(SFX_BLIP); } } }
	} else if (tab == 5) {
		if (x >= 290 && y >= Y0 + 16 && y < Y0 + 98) { scrollAch -= 4; if (scrollAch < 0) scrollAch = 0; sfx(SFX_BLIP); }
		if (x >= 290 && y >= Y0 + 102 && y < Y0 + 184) { scrollAch += 4; if (scrollAch > A_COUNT - 6) scrollAch = A_COUNT - 6; sfx(SFX_BLIP); }
	} else if (tab == 6) {
		int hy = tabHelpOpen ? Y0 + 7 : Y0 + 7 + 8 * 17;
		if (y >= hy - 4 && y < hy + 22) { tabHelpOpen ^= 1; sfx(SFX_BLIP); }
	}
}


// ------------------------------------------------------------ ambient scene layer (loading + title)
static float hh(int i, int k) { float v = sinf(i * 12.9898f + k * 78.233f) * 43758.5453f; return v - floorf(v); }
static void ambient_layer(int eye, float t, bool lanternGlow) {
	// drifting clouds, slightly behind the screen
	float dpx = roundf(-gfx_eye_offset(eye) * 1.0f);
	for (int c = 0; c < 4; c++) {
		float spd = 3 + hh(c, 1) * 5;
		float x = fmodf(hh(c, 2) * 520 + t * spd, 520) - 60 + dpx, y = 12 + hh(c, 3) * 46;
		for (int k = 0; k < 5; k++) {
			float cx = x + (k - 2) * 12 + hh(c, 10 + k) * 6, cy = y + (k == 2 ? -4 : 0) + hh(c, 20 + k) * 3, r = 10 + hh(c, 30 + k) * 8;
			for (int f = 0; f < 3; f++) circle(cx, cy, r * (1 - f * 0.28f), RGBA(255, 255, 255, 13)); // feathered puffs
		}
	}
	// birds crossing now and then
	for (int b = 0; b < 3; b++) {
		float period = 16 + b * 5, ph = fmodf(t + b * 7.3f, period) / 11.0f;
		if (ph > 1) continue;
		float x = -20 + ph * 440, y = 34 + b * 13 + sinf(t * 1.3f + b) * 4;
		float fl = sinf(t * 9 + b * 2) * 3;
		u32 bc = RGBA(40, 55, 80, 210);
		tri2d(x, y, x - 7, y - 2 - fl, x - 2, y + 1, bc);
		tri2d(x, y, x + 7, y - 2 - fl, x + 2, y + 1, bc);
	}
	// floating motes of pollen
	for (int i = 0; i < 18; i++) {
		float sp = 5 + hh(i, 4) * 9;
		float y = 250 - fmodf(t * sp + hh(i, 5) * 260, 260);
		float x = hh(i, 6) * 400 + sinf(t * 0.7f + i) * 10;
		float a = 0.45f + 0.55f * sinf(t * 2.5f + i * 1.7f);
		if (a < 0) a = 0;
		circle(x, y, 1.2f + hh(i, 7) * 1.3f, RGBA(255, 246, 200, (u8)(200 * a)));
	}
	if (lanternGlow) {
		float g = 0.75f + 0.25f * sinf(t * 2.2f);
		circle(200, 92, 13 * g + 3, RGBA(255, 220, 140, (u8)(45 * g)));
		circle(200, 92, 7 * g + 1, RGBA(255, 236, 170, (u8)(110 * g)));
	}
}
static void title_words(int eye, float t) {
	float px = popx(eye, 12), bob = sinf(t * 1.6f) * 2;
	rect_grad(0, 40, 400, 70, RGBA(0, 0, 0, 0), RGBA(0, 0, 0, 120));
	rect_grad(0, 110, 400, 20, RGBA(0, 0, 0, 120), RGBA(0, 0, 0, 0));
	text_shadow(200 - text_w("HOLLOWMERE", 4) / 2 + px + 2, 62 + 2 + bob, 4, RGBA(120, 60, 10, 255), "HOLLOWMERE");
	text_center(200 + px, 62 + bob, 4, RGBA(255, 215, 110, 255), "HOLLOWMERE");
	text_center(200 + popx(eye, 6), 102, 1, RGBA(255, 255, 255, 230), "a tiny island adventure");
}
void render_loading(int eye, float t, float progress) {
	gfx_begin_2d_top(eye);
	scene_draw(0, 0);
	ambient_layer(eye, t, true);
	title_words(eye, t);
	char b[32]; int dots = (int)(t * 2.5f) % 4;
	strcpy(b, "Loading"); for (int i = 0; i < dots; i++) strcat(b, ".");
	text_shadow(200 - text_w("Loading...", 1) / 2, 200, 1, RGBA(255, 255, 255, 230), b);
	rect(140, 214, 120, 4, RGBA(0, 0, 0, 120));
	rect(140, 214, 120 * clampf(progress, 0.04f, 1), 4, RGBA(255, 215, 110, 255));
	text_shadow(394 - text_w(HM_VERSION, 1), 228, 1, RGBA(255, 255, 255, 200), HM_VERSION);
	if (t < 0.35f) rect(0, 0, 400, 240, RGBA(0, 0, 0, (u8)(255 * (1 - t / 0.35f))));
}
void render_loading_bottom(float t, float progress) {
	static const char* tips[] = {
		"Bram sells XP Tomes. Books teach more than brawls.",
		"Wounds don't heal by themselves. Carry Healing Tonics!",
		"Moonblooms only open after dark.",
		"Crafts take a few minutes. Queue up to four at once.",
		"A purple ! means the main story continues.",
		"Mash A to crack a loot cache open.",
		"Bosses glow red before they slam. Roll out of it!",
	};
	gfx_begin_2d_bottom();
	rect_grad(0, 0, 320, 240, RGBA(28, 32, 54, 255), RGBA(16, 18, 32, 255));
	text_center(160, 26, 2, RGBA(255, 215, 110, 255), "Hollowmere");
	float g = 1 + 0.08f * sinf(t * 3);
	for (int f = 0; f < 4; f++) circle(160, 104, (30 - f * 6) * g, RGBA(255, 170, 70, 22));
	icon(ICO_LANTERN, 160 - 20 * g, 84 - 20 * g + sinf(t * 1.5f) * 2, 40 * g);
	int k = (int)(t / 4.0f) % (int)(sizeof tips / sizeof *tips);
	float fa = fmodf(t, 4.0f); float a = clampf(fminf(fa * 3, (4.0f - fa) * 3), 0, 1);
	char tb[160]; hl(tips[k], tb, sizeof tb);
	text_wrap_n(20, 150, 1, RGBA(220, 224, 245, (u8)(255 * a)), tb, 280, 3, 999);
	rect(40, 200, 240, 6, RGBA(10, 12, 22, 255));
	rect(40, 200, 240 * clampf(progress, 0.04f, 1), 6, RGBA(255, 215, 110, 255));
	if (t < 0.35f) rect(0, 0, 320, 240, RGBA(0, 0, 0, (u8)(255 * (1 - t / 0.35f))));
}

// ------------------------------------------------------------ title
void render_title(int eye) {
	gfx_draw_world_static();
	draw_lantern();
	for (int i = 0; i < NPC_COUNT - 1; i++) {
		const NpcDef* n = &npcdefs[i];
		if (dist2d(n->x, n->z, 0, 0) > 12) continue;
		draw_person(n->x, ground_h(n->x, n->z), n->z, n->yaw + sinf(gtime + i) * 0.4f, n->body, n->skin, n->hair, n->hatcol, n->hat, n->scale, 0, false, i == NPC_ELDER, 0);
	}
	gfx_transparent(true);
	gfx_draw_water(gtime);
	gfx_transparent(false);
#ifdef HM_SHOTSCENE
	return;
#endif
	gfx_begin_2d_top(eye);
	ambient_layer(eye, gtime, false);
	title_words(eye, gtime);
	if ((int)(gtime * 2) & 1) text_center(200 + popx(eye, 3), 196, 2, RGBA(255, 255, 255, 255), "Press A");
	text_shadow(394 - text_w(HM_VERSION, 1), 228, 1, RGBA(255, 255, 255, 200), HM_VERSION);
}
void render_title_bottom(void) {
	gfx_begin_2d_bottom();
	rect_grad(0, 0, 320, 240, RGBA(28, 32, 54, 255), RGBA(16, 18, 32, 255));
	text_center(160, 26, 2, RGBA(255, 215, 110, 255), "Hollowmere");
	if (hasSave) {
		button(60, 70, 200, 45, "Continue", titleSel == 0 ? RGBA(60, 160, 80, 255) : RGBA(50, 60, 90, 255), true);
		button(60, 125, 200, 45, "New game (erases save)", titleSel == 1 ? RGBA(170, 80, 60, 255) : RGBA(50, 60, 90, 255), true);
	} else button(60, 70, 200, 45, "New game", RGBA(60, 160, 80, 255), true);
	text_center(160, 196, 1, RGBA(140, 150, 180, 255), "Turn up the 3D slider!");
	text_center(160, 212, 1, RGBA(100, 110, 140, 255), "Saves to sdmc:/3ds/hollowmere.sav");
	text(316 - text_w(HM_VERSION, 1), 228, 1, RGBA(140, 150, 180, 255), HM_VERSION);
}
