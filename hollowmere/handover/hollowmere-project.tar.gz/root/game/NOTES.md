# Playtest notes (2026-10-31, v1.24): waiting for "go"

Overall: it's fun, a good long session, "we have something", but it's missing a compulsive loop (wanted it closer to Diablo).

## What Michael said
- **Backpack**
  - Full constantly, so he kept walking back to town. The intent is right (no hoarding quest items in advance), but it's too annoying.
  - Idea: "pouches". Each kind of thing (each material, tonics, weapons, armour…) has its own pouch with its own limit.
  - Idea: the level-up Pack card gives a pack point that he spends inside the backpack on whichever pouch he likes, rather than separate level-up choices.
- **Purse**
  - Shop price rises clash with the purse limit. Later in the game he couldn't afford anything, so coins became useless, even though he wasn't hoarding.
  - Idea: a bank in town that holds far more than the purse but is still limited. The bank is upgraded some other way, not by levelling up.
- **Weapon elements**
  - Changing element by crafting at the Forge was OK but unclear. He couldn't tell it was happening.
  - The element doesn't feel like it matters. Ideas: frost slows, venom poisons, storm shocks or staggers.
- **Strong enemies**
  - +4 felt rigged: instant death with no warning.
  - Make strong enemies visibly bigger.
- **Bosses** shouldn't come back unless a story beat or world event brings them back.
- **Dungeons** (Diablo-like)
  - Two per zone: one random each time, with fog of war, something to find on each floor, mystery woven into the story, and rift/gem-style rewards.
  - The other is a fixed story dungeon with several floors, where you can return to any floor you've reached.
- **Combat**
  - Samey and button-mashy, not skilful.
  - Enemies all just charge; he can't read them.
  - He couldn't see the parry coming.
  - Wants mechanics that reward reading the enemy.
- **Biomes**
  - Need to be more distinct and more cut off (walls, barriers).
  - Unreachable, or hard to reach, until you're ready.
  - The world still feels small because you can walk into any zone freely. He wants it to feel like an adventure.
- **Open invitation:** any other ideas that would add the missing hook.

## Proposed approach (draft, to discuss before building)
1. **Pouches + pack points**
   - Each material has its own pouch, starting at about 15. Tonics have a pouch (about 5). Gear has slots for weapons, armour and charms.
   - Quest and key items never count.
   - The level-up Pack card gives 1 pack point, spent in a new "Pouches" screen in the Bag tab. Each point adds about +10 to a material pouch, +2 tonics or +2 gear slots.
   - The overall pack limit goes away.
2. **Bank + flatter prices**
   - A bank in the village (Bram's strongbox, or a third building to restore) to deposit and withdraw gold.
   - Starts at about 2,000, upgraded with gold plus materials, or through a short Bram quest chain.
   - Buying in town draws from purse plus bank.
   - Price curves flattened: tomes closer to linear, caches capped, so a level-15 shop trip still makes sense.
   - The purse stays small for risk: it's what you carry and could lose.
3. **Element identity and clarity**
   - The weapon glows in its element colour, swings leave a matching trail, and the element icon sits beside the weapon on the HUD.
   - The Forge plays a big "Infused" moment.
   - On entering a zone: "Your weapon: 🔥 strong here", or a warning if it's wrong.
   - Effects:
     - Fire burns (damage over time).
     - Frost chills (slows, then freezes after a few hits).
     - Venom poisons (stacks, and poisoned foes hit softer).
     - Storm shocks (staggers, and arcs to a nearby foe).
4. **Readable danger**
   - Foes above you grow about 6% in size per level (up to +30%). At +2 they get a dark aura, and at +4 the skull.
   - A single hit can't take more than about 45% of your max HP unless the foe is 5 or more above you.
   - Strong foes growl or flash when they notice you.
   - Bosses stay dead, and only return through a "Rematch" world event or the story.
5. **Combat depth**
   - **Enemy types, each with a clear tell:**
     - Charger: crouches and glows, a ground arrow appears, then a straight dash you sidestep.
     - Brute: slow overhead swing with a red ring on the ground.
     - Shield-bearer: blocks from the front; hit it from behind or after it swings.
     - Swarmers: weak and come in packs.
     - Caster: puts ground circles down.
     - Ranged: what's there now.
   - **A visible guard for parries:** foes raise a blue shimmer before they can parry, so stopping your combo is the skill.
   - **For the player:**
     - Perfect dodge: roll at the last moment for a brief slow-mo and a bonus hit.
     - Charged heavy attack: hold A.
     - An element skill on a cooldown.
6. **Gated, distinct biomes**
   - Natural barriers opened by the story. Ideas:
     - Gus repairs the bridge to the beach.
     - Fire burns away the thorn wall into Whisperwood.
     - A raft crosses into Mirefen.
     - The ruins gate opens with shards.
   - Each biome gets its own fog colour, music, ambient particles, weather, signature props and ground texture.
   - Waypoint shrines for fast travel.
7. **Dungeons (the big one)**
   - A separate game mode with its own small tile map and mesh, built when you enter.
   - Rooms and corridors with fog of war on the minimap, an exit stair on each floor, and a chest or objective per floor.
   - **Story dungeon:** handmade, 3–4 floors. Floor checkpoints are saved, and the zone's shard and boss live at the bottom.
   - **Rift:** random each run, with modifiers ("foes explode", "darkness", "double ranged"). It drops gems and keys.
   - Rift keys come from world events.
8. **Loot depth (the Diablo hook)**
   - Affixes on gear (e.g. "+12% fire damage", "rolls leave frost", "life on kill").
   - Sockets with gems from rifts.
   - A few legendary powers that change how you play.
   - Salvage for crafting gear upgrades.

Suggested order:
- Economy (1, 2)
- Readable combat (4, then 3, 5)
- Gated biomes and waypoints (6)
- Dungeons (7)
- Loot depth (8)

## Revised recommendations after design research (2026-10-31)
- **Inventory**
  - Hoarding is already handled by quest design (progress counts only after you accept), so the pack doesn't need to police it.
  - Take materials out of the pack entirely (a material satchel with generous per-type stacks, the way Diablo IV and PoE separate currency).
  - Keep gear limited: that's the meaningful "what do I keep" decision.
  - Make the trip home cheap with a Town Portal-style return stone (Diablo 2's town trips were a short round trip, not a long walk).
- **Gold**
  - Replace the hard purse cap with risk: carried gold is partly dropped on death, banked gold is safe (Diablo 2 model).
  - Price shop items against gold earned per hour of play, not against a cap.
- **Danger**
  - Less multiplier stacking for strong foes.
  - Strong foes signal it (size, aura, sound) and get slower, bigger, more telegraphed attacks rather than just bigger numbers.
  - Cap damage per hit.
- **Combat**
  - An enemy roster with roles, each demanding a different player verb.
  - One consistent telegraph language: a single "unblockable/danger" flash meaning "roll", a guard shimmer meaning "stop attacking".
  - Pair enemy types only after each has been learned on its own.
- **Elements**
  - Each element answers an enemy problem: storm interrupts wind-ups, frost slows wind-ups, fire burns through shields/guard, venom weakens brutes.
  - Element weapons double as zone keys (Zelda-style): fire burns the thorn wall, frost freezes the swamp to cross it.
- **Gating**
  - Hard gates between zones via those element keys; soft gates (distance-based foe levels) inside zones.
- **Levels**
  - Level-ups should add tools and perks, not only capacity.
- **Loot and repeatable content**
  - Fewer, more exciting drops.
  - Affixes that change play.
  - Boss loot explosions.
  - Rifts built from handmade room templates recombined (Spelunky/Hades method) as the repeatable content engine (Diablo III's Adventure Mode fix).


# Phase plan (status)
1. Combat (v1.25): done
2. Economy (v1.26): done
3. Element seals (v1.27): done
4. Dungeons (v1.28), reworked in v1.29 after playtest:
   - Rifts: Diablo-style Hunt / Arena / Delve, tier picker, clock, shrines, story-locked
   - Depths: 5 floors, story door + islander key, levers, stones, lore
5. Loot (v1.30): done. Affixes, legendary powers, perks every 3rd level (Whirlwind on ZR), boss loot fountains

## Playtest 2026-11-02 (v1.28)
- Rifts felt samey, mazy, no reason, no risk/reward. Should feel like Diablo rifts; also arena and extraction variants
- Depths should be hard, same every time, visited back and forth (Stardew mines), story-locked doors with notes and townsfolk, lore interactables, Zelda-style puzzles (switches, push blocks)
- Dungeons and rifts should unlock through the story; START menu test switches to open them
- Ideas still open for Depths: more puzzle kinds (timed switches, torches, pressure sequences), per-dungeon set pieces
