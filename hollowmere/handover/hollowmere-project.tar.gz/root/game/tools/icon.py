# 48x48 icon: night-blue tile, golden lantern with glow, green island
from PIL import Image, ImageDraw
import sys
im = Image.new("RGBA", (48, 48), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
d.rounded_rectangle([0, 0, 47, 47], 8, fill=(30, 42, 84, 255))
for r, a in [(20, 40), (15, 70), (11, 110)]:
    d.ellipse([24 - r, 19 - r, 24 + r, 19 + r], fill=(255, 210, 100, a))
d.ellipse([4, 34, 44, 52], fill=(90, 170, 80, 255))
d.ellipse([10, 36, 38, 46], fill=(120, 200, 95, 255))
d.rectangle([23, 22, 25, 40], fill=(50, 50, 64, 255))
d.polygon([(17, 12), (31, 12), (24, 6)], fill=(50, 50, 64, 255))
d.rectangle([18, 12, 30, 24], outline=(50, 50, 64, 255), width=2)
d.ellipse([20, 14, 28, 22], fill=(255, 225, 120, 255))
im.save(sys.argv[1])
