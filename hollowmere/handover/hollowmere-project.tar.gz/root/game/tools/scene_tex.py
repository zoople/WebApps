# Bakes the 400x240 title scene into a 512x256 RGB565 Morton-tiled texture
from PIL import Image
import sys
im = Image.open(sys.argv[1]).convert("RGB").crop((0, 0, 400, 240))
W, H = 512, 256
canvas = Image.new("RGB", (W, H), (0, 0, 0)); canvas.paste(im, (0, 0))
px = canvas.load()
out = [0] * (W * H)
for y in range(H):
    for x in range(W):
        r, g, b = px[x, y]
        v = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)
        ofs = ((y >> 3) * (W >> 3) + (x >> 3)) * 64
        ix, iy = x & 7, y & 7
        m = (ix & 1) | ((iy & 1) << 1) | ((ix & 2) << 1) | ((iy & 2) << 2) | ((ix & 4) << 2) | ((iy & 4) << 3)
        out[ofs + m] = v
with open(sys.argv[2], "w") as f:
    f.write("#include <stdint.h>\n__attribute__((aligned(16))) const uint16_t scene_tex[%d]={" % len(out))
    f.write(",".join(str(v) for v in out)); f.write("};\n")
