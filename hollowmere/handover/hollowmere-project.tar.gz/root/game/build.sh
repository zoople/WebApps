#!/bin/sh
set -e
cd "$(dirname "$0")"
export PATH=$HOME/dk/bin:$PATH
mkdir -p build
picasso -o build/world.shbin source/world.v.pica
python3 - <<'PY'
d=open('build/world.shbin','rb').read()
open('build/world_shbin.h','w').write('#pragma once\n#include <stdint.h>\nextern const uint8_t world_shbin[];\nextern const uint32_t world_shbin_size;\n')
open('build/world_shbin.c','w').write('#include <stdint.h>\n__attribute__((aligned(4))) const uint8_t world_shbin[]={%s};\nconst uint32_t world_shbin_size=%d;\n'%(','.join(map(str,d)),len(d)))
PY
CF="-O2 $EXTRA -ffunction-sections -fdata-sections -D__3DS__ -I$HOME/dk/3ds/include -isystem $HOME/dk/arm-none-eabi/include -Ibuild -Wall -Wno-misleading-indentation -Wno-unused-function -Wno-unused-variable -Wno-missing-braces"
OBJS=""
[ -f build/icons_tex.c ] || python3 tools/emoji_atlas.py build source/icons.h
[ -f build/scene_tex.c ] || python3 tools/scene_tex.py cia/scene.png build/scene_tex.c
for f in source/*.c build/world_shbin.c build/icons_tex.c build/scene_tex.c; do
  o=build/$(basename $f .c).o
  arm-none-eabi-gcc $CF -c $f -o $o
  OBJS="$OBJS $o"
done
3ds-link build/hollowmere.elf $OBJS 2>&1 | grep -v "nostartfiles" || true
python3 tools/icon.py build/icon.png
smdhtool --create "Hollowmere" "A tiny island adventure" "Claude" build/icon.png build/hollowmere.smdh
3dsxtool build/hollowmere.elf build/hollowmere.3dsx --smdh=build/hollowmere.smdh
ls -la build/hollowmere.3dsx
